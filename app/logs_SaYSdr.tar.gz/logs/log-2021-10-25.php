<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-25 00:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 00:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 00:14:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 00:14:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 00:14:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 00:14:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 00:15:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 00:15:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 00:16:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 00:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 00:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 00:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 00:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 00:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 00:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 00:33:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 00:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 00:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 00:58:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 01:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 01:28:19 --> 404 Page Not Found: City/10
ERROR - 2021-10-25 01:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 02:00:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 02:00:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 02:00:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 02:00:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 02:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 02:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 02:16:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 02:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 02:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 02:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 02:58:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 02:58:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 02:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 03:21:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 03:26:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 03:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 03:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 03:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 03:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 04:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 04:09:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 04:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 04:10:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 04:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 04:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 04:35:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 04:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 04:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 04:46:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 04:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 04:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 04:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 05:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 05:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 05:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 05:55:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 05:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 06:13:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 06:13:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 06:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 06:23:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 06:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 06:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 06:36:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 06:36:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 06:36:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 06:36:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 06:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 07:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 07:02:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 07:02:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 07:02:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 07:03:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 07:03:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 07:03:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 07:12:59 --> 404 Page Not Found: Xwzz/hydt
ERROR - 2021-10-25 07:25:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 07:25:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 07:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 07:29:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 07:30:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 07:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 07:32:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 07:33:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 07:36:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 07:46:53 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-10-25 07:46:53 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-10-25 07:46:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 07:46:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 07:46:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 07:46:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 07:46:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 07:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 07:46:54 --> 404 Page Not Found: Include/taglib
ERROR - 2021-10-25 07:46:56 --> 404 Page Not Found: Member/space
ERROR - 2021-10-25 07:46:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 07:46:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 07:46:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 07:46:57 --> 404 Page Not Found: Data/cache
ERROR - 2021-10-25 07:46:58 --> 404 Page Not Found: Data/cache
ERROR - 2021-10-25 07:46:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 07:46:59 --> 404 Page Not Found: Dede/templets
ERROR - 2021-10-25 07:46:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 07:46:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 07:47:00 --> 404 Page Not Found: Data/cache
ERROR - 2021-10-25 07:47:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 07:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 07:56:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 08:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 08:17:15 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 08:17:15 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 08:17:15 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 08:17:15 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 08:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 08:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 08:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 08:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 08:39:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 08:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 09:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 09:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 09:19:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 09:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 09:19:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 09:20:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 09:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 09:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 09:35:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 09:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 09:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 09:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 09:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 09:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 09:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 10:18:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:18:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:19:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:20:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 10:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 10:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 10:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 10:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 10:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 10:24:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:25:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:26:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 10:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 10:30:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:30:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:31:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:31:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:31:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:34:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:34:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:34:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:34:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:34:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:35:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:35:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 10:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 10:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 11:08:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:13:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:15:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 11:29:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:30:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:30:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:36:44 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-10-25 11:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 11:42:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:42:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:42:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:44:41 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-10-25 11:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 11:48:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:48:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:48:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:48:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:49:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:49:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 11:50:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 11:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 11:58:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 12:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 12:26:58 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 12:26:58 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 12:26:58 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 12:26:58 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 12:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 12:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 12:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 12:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 12:36:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 12:39:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 12:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 12:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 12:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 13:00:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 13:00:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 13:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 13:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 13:08:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:11:18 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-10-25 13:15:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:15:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:16:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:16:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 13:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 13:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 13:55:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:55:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:56:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:56:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:56:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:56:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:57:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:57:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 13:57:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 14:02:05 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-10-25 14:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 14:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 14:20:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 14:30:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 14:30:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 14:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 14:41:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 14:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 14:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 14:50:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 14:57:06 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-25 14:57:09 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-25 15:06:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 15:06:53 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-10-25 15:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 15:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 15:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 15:32:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 15:33:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 15:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 15:44:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 15:45:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 15:46:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 15:46:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 15:47:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 15:47:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 15:51:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 15:52:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 15:52:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 15:52:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 15:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 15:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 15:57:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 16:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 16:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 16:05:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 16:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 16:10:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 16:12:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 16:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 16:15:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 16:18:51 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-10-25 16:20:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 16:21:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 16:26:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 16:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 16:33:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 16:36:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 16:37:27 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-25 16:41:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 16:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 16:52:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 16:58:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 17:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 17:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 17:08:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 17:13:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 17:20:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 17:23:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 17:33:37 --> 404 Page Not Found: Index/login
ERROR - 2021-10-25 17:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 17:37:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 17:38:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 17:39:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 17:47:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 17:49:37 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 17:49:37 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 17:49:50 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 17:49:50 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 17:53:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 17:53:40 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 17:53:40 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 17:54:17 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 17:54:17 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-10-25 17:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 18:07:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:07:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:08:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:08:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:08:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:08:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:09:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:09:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:09:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:09:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 18:10:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 18:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 18:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 18:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 18:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 18:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 18:45:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:45:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 18:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 19:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 19:19:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 19:19:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 19:19:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 19:23:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 19:23:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 19:26:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 19:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 19:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 19:32:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 19:45:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 19:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 19:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 19:52:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 19:52:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 19:54:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 19:57:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 19:58:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 19:59:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 20:01:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:01:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:02:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:02:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:02:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 20:03:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:03:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:04:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 20:05:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:19:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:20:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:25:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:30:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:32:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:32:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:32:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:34:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:34:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:34:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:34:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:41:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:41:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 20:42:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 20:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 20:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:02:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 21:05:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:06:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:06:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:06:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:07:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 21:08:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:09:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 21:27:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 21:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 21:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 21:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 21:36:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 21:38:59 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-25 21:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 21:47:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 21:50:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 21:50:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 21:50:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 21:50:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 21:51:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 21:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 21:52:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:54:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:56:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 21:58:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 22:16:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-25 22:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 22:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 22:47:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 22:50:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 22:50:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 22:51:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-25 22:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 22:52:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 22:52:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-25 22:53:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 22:54:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 23:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-25 23:48:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 23:50:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-25 23:51:23 --> 404 Page Not Found: Robotstxt/index
