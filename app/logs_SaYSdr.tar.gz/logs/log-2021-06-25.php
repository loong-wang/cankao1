<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-25 00:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:02:47 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-25 00:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:10:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 00:11:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 00:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:15:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 00:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:25:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 00:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:31:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 00:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:33:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 00:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:40:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 00:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:44:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 00:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:45:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 00:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:49:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 00:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:51:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 00:53:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 00:53:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 00:54:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 00:54:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:55:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 00:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 00:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:02:23 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-25 01:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:06:38 --> 404 Page Not Found: Article/info
ERROR - 2021-06-25 01:06:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 01:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:08:07 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-25 01:09:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 01:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:09:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 01:10:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 01:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:11:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 01:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:15:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:18:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 01:20:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 01:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:23:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 01:24:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 01:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:30:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 01:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:50:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 01:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:55:32 --> 404 Page Not Found: Env/index
ERROR - 2021-06-25 01:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 01:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:06:00 --> 404 Page Not Found: City/2
ERROR - 2021-06-25 02:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:15:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:15:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 02:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:18:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 02:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:21:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:25:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 02:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:38:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 02:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:44:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 02:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:48:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 02:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 02:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:06:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:11:01 --> 404 Page Not Found: City/10
ERROR - 2021-06-25 03:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:13:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:16:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 03:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:21:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 03:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:24:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 03:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:26:42 --> 404 Page Not Found: Env/index
ERROR - 2021-06-25 03:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:29:52 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-25 03:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:30:55 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 03:31:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:35:01 --> 404 Page Not Found: Env/index
ERROR - 2021-06-25 03:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:37:03 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-25 03:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:44:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 03:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:48:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 03:49:34 --> 404 Page Not Found: H5/index
ERROR - 2021-06-25 03:49:34 --> 404 Page Not Found: admin/Index/index
ERROR - 2021-06-25 03:49:34 --> 404 Page Not Found: Base/exchange_article
ERROR - 2021-06-25 03:49:34 --> 404 Page Not Found: Market/market-ws
ERROR - 2021-06-25 03:49:35 --> 404 Page Not Found: Wap/trading
ERROR - 2021-06-25 03:49:35 --> 404 Page Not Found: H5/index
ERROR - 2021-06-25 03:49:35 --> 404 Page Not Found: Legal/currency
ERROR - 2021-06-25 03:49:35 --> 404 Page Not Found: Otc/index
ERROR - 2021-06-25 03:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:49:37 --> 404 Page Not Found: Wap/trading
ERROR - 2021-06-25 03:49:37 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-06-25 03:49:37 --> 404 Page Not Found: M/ticker
ERROR - 2021-06-25 03:49:37 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-06-25 03:49:38 --> 404 Page Not Found: Web/api
ERROR - 2021-06-25 03:49:41 --> 404 Page Not Found: User/allroleinfo
ERROR - 2021-06-25 03:49:41 --> 404 Page Not Found: Api/content_bottom
ERROR - 2021-06-25 03:49:41 --> 404 Page Not Found: M/allticker
ERROR - 2021-06-25 03:49:41 --> 404 Page Not Found: User/userlist
ERROR - 2021-06-25 03:49:41 --> 404 Page Not Found: N/news
ERROR - 2021-06-25 03:49:41 --> 404 Page Not Found: Home/loadmymanager
ERROR - 2021-06-25 03:49:42 --> 404 Page Not Found: Room/1002
ERROR - 2021-06-25 03:49:42 --> 404 Page Not Found: Room/getRoomBangFans
ERROR - 2021-06-25 03:49:43 --> 404 Page Not Found: Recruit/download_url
ERROR - 2021-06-25 03:49:44 --> 404 Page Not Found: Account/login
ERROR - 2021-06-25 03:49:44 --> 404 Page Not Found: Index/login
ERROR - 2021-06-25 03:49:45 --> 404 Page Not Found: Api/user
ERROR - 2021-06-25 03:49:45 --> 404 Page Not Found: S_api/basic
ERROR - 2021-06-25 03:49:47 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-06-25 03:49:47 --> 404 Page Not Found: V1/management
ERROR - 2021-06-25 03:49:47 --> 404 Page Not Found: Ajax/allcoin_a
ERROR - 2021-06-25 03:49:47 --> 404 Page Not Found: Pc/Lang
ERROR - 2021-06-25 03:49:47 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-06-25 03:49:47 --> 404 Page Not Found: Xianyu/index
ERROR - 2021-06-25 03:49:48 --> 404 Page Not Found: Xy/index
ERROR - 2021-06-25 03:49:49 --> 404 Page Not Found: Home/Bind
ERROR - 2021-06-25 03:49:50 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-06-25 03:49:50 --> 404 Page Not Found: S_api/basic
ERROR - 2021-06-25 03:49:51 --> 404 Page Not Found: Data/json
ERROR - 2021-06-25 03:49:51 --> 404 Page Not Found: GetLocale/index
ERROR - 2021-06-25 03:49:51 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-06-25 03:49:51 --> 404 Page Not Found: Iframe/rankgiftgotapi
ERROR - 2021-06-25 03:49:51 --> 404 Page Not Found: Home/GetAllGameCategory
ERROR - 2021-06-25 03:49:52 --> 404 Page Not Found: FePublicInfo/index
ERROR - 2021-06-25 03:49:53 --> 404 Page Not Found: Infe/rest
ERROR - 2021-06-25 03:49:54 --> 404 Page Not Found: Home/GetQrCodeInfo
ERROR - 2021-06-25 03:49:54 --> 404 Page Not Found: Infe/rest
ERROR - 2021-06-25 03:49:54 --> 404 Page Not Found: Mobile/v3
ERROR - 2021-06-25 03:49:56 --> 404 Page Not Found: Mh/phone.do
ERROR - 2021-06-25 03:49:57 --> 404 Page Not Found: Static/local
ERROR - 2021-06-25 03:49:58 --> 404 Page Not Found: Bannerdo/index
ERROR - 2021-06-25 03:49:58 --> 404 Page Not Found: Api/ApiHub
ERROR - 2021-06-25 03:49:59 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-25 03:50:00 --> 404 Page Not Found: Verificationasp/index
ERROR - 2021-06-25 03:50:01 --> 404 Page Not Found: Step1asp/index
ERROR - 2021-06-25 03:50:01 --> 404 Page Not Found: Front/User
ERROR - 2021-06-25 03:50:01 --> 404 Page Not Found: CscpLoginWeb/app
ERROR - 2021-06-25 03:50:03 --> 404 Page Not Found: Ajax/index
ERROR - 2021-06-25 03:50:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 03:50:03 --> 404 Page Not Found: Front/FctPage
ERROR - 2021-06-25 03:50:03 --> 404 Page Not Found: Ajax/index
ERROR - 2021-06-25 03:50:03 --> 404 Page Not Found: admin//index
ERROR - 2021-06-25 03:50:03 --> 404 Page Not Found: Api/index
ERROR - 2021-06-25 03:50:03 --> 404 Page Not Found: Mtjahtml/index
ERROR - 2021-06-25 03:50:04 --> 404 Page Not Found: Home/Get
ERROR - 2021-06-25 03:50:05 --> 404 Page Not Found: Site/get-hq
ERROR - 2021-06-25 03:50:05 --> 404 Page Not Found: Api/uploads
ERROR - 2021-06-25 03:50:05 --> 404 Page Not Found: Home/login
ERROR - 2021-06-25 03:50:06 --> 404 Page Not Found: Home/GetInitSource
ERROR - 2021-06-25 03:50:07 --> 404 Page Not Found: Ws/index
ERROR - 2021-06-25 03:50:08 --> 404 Page Not Found: Api/Index
ERROR - 2021-06-25 03:50:08 --> 404 Page Not Found: Api/v
ERROR - 2021-06-25 03:50:09 --> 404 Page Not Found: Homes/index
ERROR - 2021-06-25 03:50:09 --> 404 Page Not Found: Static/data
ERROR - 2021-06-25 03:50:10 --> 404 Page Not Found: Promotions/list.mvc
ERROR - 2021-06-25 03:50:11 --> 404 Page Not Found: Homes/index
ERROR - 2021-06-25 03:50:12 --> 404 Page Not Found: Sign/index
ERROR - 2021-06-25 03:50:12 --> 404 Page Not Found: Api/site
ERROR - 2021-06-25 03:50:13 --> 404 Page Not Found: Api/wallet
ERROR - 2021-06-25 03:50:13 --> 404 Page Not Found: Api/stock
ERROR - 2021-06-25 03:50:13 --> 404 Page Not Found: H5/index
ERROR - 2021-06-25 03:50:14 --> 404 Page Not Found: Anquan/qgga.asp
ERROR - 2021-06-25 03:50:14 --> 404 Page Not Found: Base/goexjs
ERROR - 2021-06-25 03:50:15 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-25 03:50:15 --> 404 Page Not Found: Index/register.html
ERROR - 2021-06-25 03:50:15 --> 404 Page Not Found: Index/index
ERROR - 2021-06-25 03:50:15 --> 404 Page Not Found: Api/message
ERROR - 2021-06-25 03:50:16 --> 404 Page Not Found: Api/product
ERROR - 2021-06-25 03:50:16 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-25 03:50:20 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-06-25 03:50:20 --> 404 Page Not Found: Content/favicon.ico
ERROR - 2021-06-25 03:50:21 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-06-25 03:50:21 --> 404 Page Not Found: Api/apps
ERROR - 2021-06-25 03:50:21 --> 404 Page Not Found: Api/currency
ERROR - 2021-06-25 03:50:21 --> 404 Page Not Found: Market/getStockBaseInfo
ERROR - 2021-06-25 03:50:21 --> 404 Page Not Found: Stock/search.html
ERROR - 2021-06-25 03:50:21 --> 404 Page Not Found: Api/contactWay
ERROR - 2021-06-25 03:50:22 --> 404 Page Not Found: Api/mobile
ERROR - 2021-06-25 03:50:22 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-25 03:50:22 --> 404 Page Not Found: Loan/index
ERROR - 2021-06-25 03:50:22 --> 404 Page Not Found: Api/index
ERROR - 2021-06-25 03:50:22 --> 404 Page Not Found: Kkrps/im_group
ERROR - 2021-06-25 03:50:23 --> 404 Page Not Found: FriendGroup/list
ERROR - 2021-06-25 03:50:23 --> 404 Page Not Found: Api/exclude
ERROR - 2021-06-25 03:50:23 --> 404 Page Not Found: Index/api
ERROR - 2021-06-25 03:50:23 --> 404 Page Not Found: Im/in
ERROR - 2021-06-25 03:50:24 --> 404 Page Not Found: Api/common
ERROR - 2021-06-25 03:50:24 --> 404 Page Not Found: Api/config-init
ERROR - 2021-06-25 03:50:24 --> 404 Page Not Found: Appxz/index.html
ERROR - 2021-06-25 03:50:24 --> 404 Page Not Found: Portal/index
ERROR - 2021-06-25 03:50:24 --> 404 Page Not Found: Api/user
ERROR - 2021-06-25 03:50:24 --> 404 Page Not Found: Home/main
ERROR - 2021-06-25 03:50:27 --> 404 Page Not Found: Api/user
ERROR - 2021-06-25 03:50:31 --> 404 Page Not Found: M/index
ERROR - 2021-06-25 03:50:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 03:50:36 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-25 03:50:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 03:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:57:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 03:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:58:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 03:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 03:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-06-25 04:02:26 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 04:02:26 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 04:02:26 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-25 04:02:26 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 04:02:26 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-25 04:02:27 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 04:02:28 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-25 04:02:28 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-25 04:02:28 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-25 04:02:28 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-25 04:02:28 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 04:02:28 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 04:02:28 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 04:02:28 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-25 04:02:28 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-25 04:02:28 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-25 04:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:06:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 04:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:07:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:08:57 --> 404 Page Not Found: H5/index
ERROR - 2021-06-25 04:08:57 --> 404 Page Not Found: admin/Index/index
ERROR - 2021-06-25 04:08:57 --> 404 Page Not Found: Base/exchange_article
ERROR - 2021-06-25 04:08:57 --> 404 Page Not Found: Market/market-ws
ERROR - 2021-06-25 04:08:57 --> 404 Page Not Found: H5/index
ERROR - 2021-06-25 04:08:58 --> 404 Page Not Found: Wap/trading
ERROR - 2021-06-25 04:08:58 --> 404 Page Not Found: Otc/index
ERROR - 2021-06-25 04:08:58 --> 404 Page Not Found: Legal/currency
ERROR - 2021-06-25 04:08:58 --> 404 Page Not Found: Wap/trading
ERROR - 2021-06-25 04:08:59 --> 404 Page Not Found: M/ticker
ERROR - 2021-06-25 04:08:59 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-06-25 04:09:00 --> 404 Page Not Found: User/allroleinfo
ERROR - 2021-06-25 04:09:00 --> 404 Page Not Found: M/allticker
ERROR - 2021-06-25 04:09:01 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-06-25 04:09:02 --> 404 Page Not Found: Room/getRoomBangFans
ERROR - 2021-06-25 04:09:02 --> 404 Page Not Found: Api/content_bottom
ERROR - 2021-06-25 04:09:03 --> 404 Page Not Found: User/userlist
ERROR - 2021-06-25 04:09:04 --> 404 Page Not Found: N/news
ERROR - 2021-06-25 04:09:04 --> 404 Page Not Found: Web/api
ERROR - 2021-06-25 04:09:04 --> 404 Page Not Found: Home/loadmymanager
ERROR - 2021-06-25 04:09:04 --> 404 Page Not Found: Index/login
ERROR - 2021-06-25 04:09:05 --> 404 Page Not Found: Recruit/download_url
ERROR - 2021-06-25 04:09:06 --> 404 Page Not Found: S_api/basic
ERROR - 2021-06-25 04:09:06 --> 404 Page Not Found: Room/1002
ERROR - 2021-06-25 04:09:06 --> 404 Page Not Found: Api/user
ERROR - 2021-06-25 04:09:06 --> 404 Page Not Found: Account/login
ERROR - 2021-06-25 04:09:07 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-06-25 04:09:07 --> 404 Page Not Found: V1/management
ERROR - 2021-06-25 04:09:08 --> 404 Page Not Found: S_api/basic
ERROR - 2021-06-25 04:09:08 --> 404 Page Not Found: Ajax/allcoin_a
ERROR - 2021-06-25 04:09:08 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-06-25 04:09:09 --> 404 Page Not Found: Xianyu/index
ERROR - 2021-06-25 04:09:09 --> 404 Page Not Found: Xy/index
ERROR - 2021-06-25 04:09:10 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-06-25 04:09:10 --> 404 Page Not Found: GetLocale/index
ERROR - 2021-06-25 04:09:10 --> 404 Page Not Found: Iframe/rankgiftgotapi
ERROR - 2021-06-25 04:09:10 --> 404 Page Not Found: Pc/Lang
ERROR - 2021-06-25 04:09:11 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-06-25 04:09:11 --> 404 Page Not Found: Data/json
ERROR - 2021-06-25 04:09:11 --> 404 Page Not Found: FePublicInfo/index
ERROR - 2021-06-25 04:09:11 --> 404 Page Not Found: Home/GetAllGameCategory
ERROR - 2021-06-25 04:09:11 --> 404 Page Not Found: Infe/rest
ERROR - 2021-06-25 04:09:12 --> 404 Page Not Found: Home/Bind
ERROR - 2021-06-25 04:09:12 --> 404 Page Not Found: Home/GetQrCodeInfo
ERROR - 2021-06-25 04:09:12 --> 404 Page Not Found: Infe/rest
ERROR - 2021-06-25 04:09:13 --> 404 Page Not Found: Static/local
ERROR - 2021-06-25 04:09:13 --> 404 Page Not Found: Mh/phone.do
ERROR - 2021-06-25 04:09:13 --> 404 Page Not Found: Mobile/v3
ERROR - 2021-06-25 04:09:14 --> 404 Page Not Found: Api/ApiHub
ERROR - 2021-06-25 04:09:15 --> 404 Page Not Found: Bannerdo/index
ERROR - 2021-06-25 04:09:18 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-25 04:09:23 --> 404 Page Not Found: CscpLoginWeb/app
ERROR - 2021-06-25 04:09:23 --> 404 Page Not Found: Front/User
ERROR - 2021-06-25 04:09:23 --> 404 Page Not Found: Ajax/index
ERROR - 2021-06-25 04:09:24 --> 404 Page Not Found: Ajax/index
ERROR - 2021-06-25 04:09:26 --> 404 Page Not Found: Verificationasp/index
ERROR - 2021-06-25 04:09:26 --> 404 Page Not Found: admin//index
ERROR - 2021-06-25 04:09:27 --> 404 Page Not Found: Step1asp/index
ERROR - 2021-06-25 04:09:27 --> 404 Page Not Found: Front/FctPage
ERROR - 2021-06-25 04:09:27 --> 404 Page Not Found: Api/index
ERROR - 2021-06-25 04:09:27 --> 404 Page Not Found: Home/Get
ERROR - 2021-06-25 04:09:27 --> 404 Page Not Found: Mtjahtml/index
ERROR - 2021-06-25 04:09:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 04:09:29 --> 404 Page Not Found: Site/get-hq
ERROR - 2021-06-25 04:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:09:31 --> 404 Page Not Found: Api/uploads
ERROR - 2021-06-25 04:09:34 --> 404 Page Not Found: Home/GetInitSource
ERROR - 2021-06-25 04:09:35 --> 404 Page Not Found: Ws/index
ERROR - 2021-06-25 04:09:37 --> 404 Page Not Found: Home/login
ERROR - 2021-06-25 04:09:38 --> 404 Page Not Found: Api/v
ERROR - 2021-06-25 04:09:38 --> 404 Page Not Found: Api/Index
ERROR - 2021-06-25 04:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:09:40 --> 404 Page Not Found: Homes/index
ERROR - 2021-06-25 04:09:40 --> 404 Page Not Found: Static/data
ERROR - 2021-06-25 04:09:44 --> 404 Page Not Found: Promotions/list.mvc
ERROR - 2021-06-25 04:09:44 --> 404 Page Not Found: Homes/index
ERROR - 2021-06-25 04:09:46 --> 404 Page Not Found: Api/site
ERROR - 2021-06-25 04:09:48 --> 404 Page Not Found: Sign/index
ERROR - 2021-06-25 04:09:49 --> 404 Page Not Found: Api/wallet
ERROR - 2021-06-25 04:09:49 --> 404 Page Not Found: H5/index
ERROR - 2021-06-25 04:09:50 --> 404 Page Not Found: Api/stock
ERROR - 2021-06-25 04:09:51 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-25 04:09:51 --> 404 Page Not Found: Anquan/qgga.asp
ERROR - 2021-06-25 04:09:52 --> 404 Page Not Found: Base/goexjs
ERROR - 2021-06-25 04:09:53 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-25 04:09:53 --> 404 Page Not Found: Index/register.html
ERROR - 2021-06-25 04:09:54 --> 404 Page Not Found: Index/index
ERROR - 2021-06-25 04:09:55 --> 404 Page Not Found: Api/message
ERROR - 2021-06-25 04:09:58 --> 404 Page Not Found: Api/product
ERROR - 2021-06-25 04:10:02 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-06-25 04:10:03 --> 404 Page Not Found: Api/currency
ERROR - 2021-06-25 04:10:03 --> 404 Page Not Found: Content/favicon.ico
ERROR - 2021-06-25 04:10:03 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-06-25 04:10:04 --> 404 Page Not Found: Api/apps
ERROR - 2021-06-25 04:10:04 --> 404 Page Not Found: Market/getStockBaseInfo
ERROR - 2021-06-25 04:10:05 --> 404 Page Not Found: Index/api
ERROR - 2021-06-25 04:10:05 --> 404 Page Not Found: Api/contactWay
ERROR - 2021-06-25 04:10:06 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-25 04:10:06 --> 404 Page Not Found: Loan/index
ERROR - 2021-06-25 04:10:07 --> 404 Page Not Found: Kkrps/im_group
ERROR - 2021-06-25 04:10:07 --> 404 Page Not Found: Api/exclude
ERROR - 2021-06-25 04:10:07 --> 404 Page Not Found: FriendGroup/list
ERROR - 2021-06-25 04:10:08 --> 404 Page Not Found: Api/user
ERROR - 2021-06-25 04:10:08 --> 404 Page Not Found: Im/in
ERROR - 2021-06-25 04:10:09 --> 404 Page Not Found: Api/mobile
ERROR - 2021-06-25 04:10:09 --> 404 Page Not Found: Api/common
ERROR - 2021-06-25 04:10:09 --> 404 Page Not Found: Api/config-init
ERROR - 2021-06-25 04:10:10 --> 404 Page Not Found: Api/index
ERROR - 2021-06-25 04:10:10 --> 404 Page Not Found: Stock/search.html
ERROR - 2021-06-25 04:10:10 --> 404 Page Not Found: Portal/index
ERROR - 2021-06-25 04:10:11 --> 404 Page Not Found: Appxz/index.html
ERROR - 2021-06-25 04:10:11 --> 404 Page Not Found: Api/user
ERROR - 2021-06-25 04:10:12 --> 404 Page Not Found: Home/main
ERROR - 2021-06-25 04:10:17 --> 404 Page Not Found: M/index
ERROR - 2021-06-25 04:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:17:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 04:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:22:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 04:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:28:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 04:28:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 04:28:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 04:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:33:32 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-25 04:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:39:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 04:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:41:27 --> 404 Page Not Found: Company/view
ERROR - 2021-06-25 04:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:53:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 04:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 04:54:17 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 04:54:18 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-25 04:54:19 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-25 04:54:19 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-25 04:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:58:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 04:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:05:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 05:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:09:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:11:47 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-25 05:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:19:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 05:19:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 05:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:42:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 05:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:43:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:51:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 05:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:51:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 05:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 05:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:52:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 05:52:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 05:53:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 05:53:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 05:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 05:55:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 05:56:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 05:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:57:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 05:57:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 05:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:58:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 05:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:59:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 05:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 05:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:00:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 06:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:01:23 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-06-25 06:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:02:26 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-25 06:02:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 06:03:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 06:03:28 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-25 06:04:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 06:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:08:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 06:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 06:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:15:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 06:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:18:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 06:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:19:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 06:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:20:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 06:21:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 06:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:23:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:27:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:29:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 06:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:35:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 06:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:38:45 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 06:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:41:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 06:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:43:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 06:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:47:23 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-25 06:47:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:52:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 06:53:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:54:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 06:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 06:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:06:12 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-25 07:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:19:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:23:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 07:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:34:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 07:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:34:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 07:35:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 07:35:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 07:35:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 07:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:36:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 07:36:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 07:36:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 07:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:37:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 07:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:45:27 --> 404 Page Not Found: Api/.env
ERROR - 2021-06-25 07:45:28 --> 404 Page Not Found: Laravel/.env
ERROR - 2021-06-25 07:45:29 --> 404 Page Not Found: Test/.env
ERROR - 2021-06-25 07:45:31 --> 404 Page Not Found: admin/Env/index
ERROR - 2021-06-25 07:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:45:59 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-06-25 07:46:01 --> 404 Page Not Found: Sites/.env
ERROR - 2021-06-25 07:46:02 --> 404 Page Not Found: Blog/.env
ERROR - 2021-06-25 07:46:03 --> 404 Page Not Found: System/.env
ERROR - 2021-06-25 07:46:05 --> 404 Page Not Found: Public/.env
ERROR - 2021-06-25 07:46:06 --> 404 Page Not Found: Shop/.env
ERROR - 2021-06-25 07:46:53 --> 404 Page Not Found: English/index
ERROR - 2021-06-25 07:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:57:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 07:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:02:48 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-25 08:02:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 08:02:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 08:02:49 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-25 08:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:09:19 --> 404 Page Not Found: Js/common.js%20%20
ERROR - 2021-06-25 08:09:28 --> 404 Page Not Found: Js/common.js%20%20
ERROR - 2021-06-25 08:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:11:05 --> 404 Page Not Found: Js/common.js%20%20
ERROR - 2021-06-25 08:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:20:08 --> 404 Page Not Found: City/10
ERROR - 2021-06-25 08:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:24:34 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-25 08:25:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 08:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:31:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 08:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:33:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 08:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:44:40 --> 404 Page Not Found: Blog/index
ERROR - 2021-06-25 08:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:50:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:50:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 08:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:53:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 08:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 08:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:57:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:58:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 08:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 08:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:00:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:00:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:01:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:02:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 09:02:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:03:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:04:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:05:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:09:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:09:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:09:57 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-25 09:09:57 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-25 09:09:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:10:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:10:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:11:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:11:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:14:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:14:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:15:26 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-25 09:16:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:16:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:19:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:20:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-60, 60' at line 7 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_city` = 1
AND  `hao_title` LIKE '%66666%' ESCAPE '!'
AND `hao_lock` <=0
ORDER BY `hao_time` DESC
 LIMIT -60, 60
ERROR - 2021-06-25 09:20:55 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 117
ERROR - 2021-06-25 09:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:26:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:30:45 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-25 09:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:31:52 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-25 09:32:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:33:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:33:01 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-25 09:34:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 09:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:34:09 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-25 09:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:35:21 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-25 09:35:21 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-25 09:36:30 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-25 09:37:37 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-25 09:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:38:45 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-25 09:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:39:51 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-25 09:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:40:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 09:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:45:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 09:46:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:47:15 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-25 09:47:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 09:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 09:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:54:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:56:12 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-25 09:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 09:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:01:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 10:01:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 10:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:07:58 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 10:07:58 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-25 10:07:59 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-25 10:08:00 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-25 10:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:13:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:16:05 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-25 10:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:25:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:25:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:26:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:26:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:29:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:38:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:38:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:39:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:45:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 10:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:46:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 10:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:49:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 10:49:59 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-06-25 10:50:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-06-25 10:50:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-06-25 10:51:01 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-06-25 10:51:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-06-25 10:51:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-06-25 10:51:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 10:51:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:51:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:52:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:52:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:53:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:53:19 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-06-25 10:53:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:53:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 10:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:57:01 --> 404 Page Not Found: City/2
ERROR - 2021-06-25 10:57:09 --> 404 Page Not Found: City/2
ERROR - 2021-06-25 10:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:57:12 --> 404 Page Not Found: City/2
ERROR - 2021-06-25 10:57:14 --> 404 Page Not Found: City/2
ERROR - 2021-06-25 10:57:21 --> 404 Page Not Found: City/2
ERROR - 2021-06-25 10:57:21 --> 404 Page Not Found: City/2
ERROR - 2021-06-25 10:57:26 --> 404 Page Not Found: City/2
ERROR - 2021-06-25 10:57:27 --> 404 Page Not Found: City/2
ERROR - 2021-06-25 10:57:36 --> 404 Page Not Found: City/2
ERROR - 2021-06-25 10:57:38 --> 404 Page Not Found: 10/10000
ERROR - 2021-06-25 10:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 10:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:01:58 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-25 11:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:05:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 11:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:06:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 11:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:09:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:13:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 11:14:07 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-25 11:14:07 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-25 11:14:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 11:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:16:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 11:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:27:09 --> 404 Page Not Found: 10/10000
ERROR - 2021-06-25 11:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:33:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:35:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 11:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:38:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 11:38:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 11:39:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 11:40:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 11:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:45:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 11:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:47:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:49:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 11:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:50:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:54:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 11:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 11:59:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 12:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:02:40 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 12:02:40 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 12:02:40 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-25 12:02:40 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 12:02:40 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 12:02:40 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-25 12:02:41 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-25 12:02:42 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-25 12:02:42 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-25 12:02:42 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 12:02:42 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 12:02:42 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 12:02:42 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-25 12:02:42 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-25 12:02:42 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-25 12:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:03:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:05:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 12:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:12:15 --> 404 Page Not Found: Config/getuser
ERROR - 2021-06-25 12:12:47 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-06-25 12:12:49 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-06-25 12:12:50 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-06-25 12:12:50 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-06-25 12:12:50 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-06-25 12:12:50 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-06-25 12:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:13:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:16:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 12:16:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:16:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 12:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:16:53 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-06-25 12:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:19:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 12:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:20:19 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 12:20:19 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 12:20:19 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-25 12:20:19 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 12:20:19 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 12:20:19 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-25 12:20:19 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 12:20:19 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-25 12:20:19 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 12:20:19 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 12:20:19 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 12:20:20 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 12:20:21 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-25 12:20:21 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-25 12:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:20:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:21:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:21:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:21:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:21:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:21:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:21:35 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-25 12:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:23:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 12:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:30:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:30:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:31:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:31:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:31:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:31:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:32:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:32:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:33:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:33:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 12:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:33:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 12:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:35:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 12:35:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:36:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:36:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:37:21 --> 404 Page Not Found: Www20210623rar/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Wwwxuanhaonet20210623rar/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Www_xuanhao_net20210623rar/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Wwwxuanhaonet20210623rar/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Xuanhaonet20210623rar/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Xuanhao_net20210623rar/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Xuanhaonet20210623rar/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Xuanhao20210623rar/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Www20210623targz/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Wwwxuanhaonet20210623targz/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Www_xuanhao_net20210623targz/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Wwwxuanhaonet20210623targz/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Xuanhaonet20210623targz/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Xuanhao_net20210623targz/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Xuanhaonet20210623targz/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Xuanhao20210623targz/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Www20210623zip/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Wwwxuanhaonet20210623zip/index
ERROR - 2021-06-25 12:37:22 --> 404 Page Not Found: Www_xuanhao_net20210623zip/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Wwwxuanhaonet20210623zip/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Xuanhaonet20210623zip/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Xuanhao_net20210623zip/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Xuanhaonet20210623zip/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Xuanhao20210623zip/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Www2021-06-23rar/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Wwwxuanhaonet2021-06-23rar/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Www_xuanhao_net2021-06-23rar/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Wwwxuanhaonet2021-06-23rar/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Xuanhaonet2021-06-23rar/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Xuanhao_net2021-06-23rar/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Xuanhaonet2021-06-23rar/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Xuanhao2021-06-23rar/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Www2021-06-23targz/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Wwwxuanhaonet2021-06-23targz/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Www_xuanhao_net2021-06-23targz/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Wwwxuanhaonet2021-06-23targz/index
ERROR - 2021-06-25 12:37:23 --> 404 Page Not Found: Xuanhaonet2021-06-23targz/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Xuanhao_net2021-06-23targz/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Xuanhaonet2021-06-23targz/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Xuanhao2021-06-23targz/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Www2021-06-23zip/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Wwwxuanhaonet2021-06-23zip/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Www_xuanhao_net2021-06-23zip/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Wwwxuanhaonet2021-06-23zip/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Xuanhaonet2021-06-23zip/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Xuanhao_net2021-06-23zip/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Xuanhaonet2021-06-23zip/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Xuanhao2021-06-23zip/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Www20210623rar/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Wwwxuanhaonet20210623rar/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Www_xuanhao_net20210623rar/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Wwwxuanhaonet20210623rar/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Xuanhaonet20210623rar/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Xuanhao_net20210623rar/index
ERROR - 2021-06-25 12:37:24 --> 404 Page Not Found: Xuanhaonet20210623rar/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Xuanhao20210623rar/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Www20210623targz/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Wwwxuanhaonet20210623targz/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Www_xuanhao_net20210623targz/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Wwwxuanhaonet20210623targz/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Xuanhaonet20210623targz/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Xuanhao_net20210623targz/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Xuanhaonet20210623targz/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Xuanhao20210623targz/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Www20210623zip/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Wwwxuanhaonet20210623zip/index
ERROR - 2021-06-25 12:37:25 --> 404 Page Not Found: Www_xuanhao_net20210623zip/index
ERROR - 2021-06-25 12:37:26 --> 404 Page Not Found: Wwwxuanhaonet20210623zip/index
ERROR - 2021-06-25 12:37:26 --> 404 Page Not Found: Xuanhaonet20210623zip/index
ERROR - 2021-06-25 12:37:26 --> 404 Page Not Found: Xuanhao_net20210623zip/index
ERROR - 2021-06-25 12:37:26 --> 404 Page Not Found: Xuanhaonet20210623zip/index
ERROR - 2021-06-25 12:37:26 --> 404 Page Not Found: Xuanhao20210623zip/index
ERROR - 2021-06-25 12:37:26 --> 404 Page Not Found: 20210623rar/index
ERROR - 2021-06-25 12:37:26 --> 404 Page Not Found: 20210623targz/index
ERROR - 2021-06-25 12:37:26 --> 404 Page Not Found: 20210623zip/index
ERROR - 2021-06-25 12:37:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:38:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:39:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 12:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:40:29 --> 404 Page Not Found: Semaltcom/index
ERROR - 2021-06-25 12:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:44:11 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-25 12:44:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 12:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:47:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:48:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 12:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 12:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:02:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:02:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:02:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:02:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:03:09 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/member_dingdan_show.php 74
ERROR - 2021-06-25 13:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:07:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:07:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 13:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:10:38 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-06-25 13:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:17:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 13:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:23:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:25:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:30:51 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-06-25 13:31:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:33:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:33:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:33:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:34:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:34:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:34:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:34:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 13:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:35:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:37:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:39:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:39:33 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-25 13:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:41:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:43:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:44:37 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-25 13:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:45:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:46:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:47:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:47:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:49:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 13:49:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:51:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:53:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 13:53:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:55:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:55:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:55:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:56:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 13:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:57:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 13:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 13:59:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 13:59:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 13:59:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 14:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:02:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 14:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:02:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 14:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:12:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 14:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:14:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 14:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:19:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 14:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:23:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 14:24:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:24:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 14:25:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:26:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 14:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:30:52 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-25 14:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:37:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 14:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:39:31 --> 404 Page Not Found: Cpcx/Manage
ERROR - 2021-06-25 14:39:35 --> 404 Page Not Found: Thread-47686-1-1html/index
ERROR - 2021-06-25 14:39:38 --> 404 Page Not Found: SYSA/make
ERROR - 2021-06-25 14:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:39:51 --> 404 Page Not Found: ChangeDetail/handicap.aspx
ERROR - 2021-06-25 14:39:55 --> 404 Page Not Found: Info/1021
ERROR - 2021-06-25 14:39:56 --> 404 Page Not Found: Workflow/Task
ERROR - 2021-06-25 14:39:58 --> 404 Page Not Found: Applicant/Details
ERROR - 2021-06-25 14:40:02 --> 404 Page Not Found: Dfgl/SQDZZ
ERROR - 2021-06-25 14:40:08 --> 404 Page Not Found: Prjsp/index
ERROR - 2021-06-25 14:40:11 --> 404 Page Not Found: Abroad/liuxue
ERROR - 2021-06-25 14:40:19 --> 404 Page Not Found: IrobotBox/Product
ERROR - 2021-06-25 14:40:26 --> 404 Page Not Found: Modules/Default
ERROR - 2021-06-25 14:40:27 --> 404 Page Not Found: T-1235178-1-2html/index
ERROR - 2021-06-25 14:40:33 --> 404 Page Not Found: Comment/html
ERROR - 2021-06-25 14:40:42 --> 404 Page Not Found: Show-57-4426-1html/index
ERROR - 2021-06-25 14:40:43 --> 404 Page Not Found: Aos/shipment
ERROR - 2021-06-25 14:40:46 --> 404 Page Not Found: Notice_showhtml/index
ERROR - 2021-06-25 14:40:52 --> 404 Page Not Found: Pre/subimages
ERROR - 2021-06-25 14:41:01 --> 404 Page Not Found: Content/column
ERROR - 2021-06-25 14:41:21 --> 404 Page Not Found: PageData/course
ERROR - 2021-06-25 14:41:21 --> 404 Page Not Found: Cms-portal/goResDetailInfo.html
ERROR - 2021-06-25 14:41:26 --> 404 Page Not Found: Index22fasp/index
ERROR - 2021-06-25 14:41:27 --> 404 Page Not Found: Workflow/request
ERROR - 2021-06-25 14:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:45:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 14:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:47:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 14:47:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 14:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:47:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 14:48:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 14:50:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 14:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 14:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:00:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 15:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:00:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 15:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:03:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 15:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:09:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 15:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:15:25 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-25 15:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:16:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 15:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:20:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 15:20:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 15:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:21:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 15:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:23:04 --> 404 Page Not Found: Wp-includes/index
ERROR - 2021-06-25 15:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:30:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 15:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:31:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:32:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 15:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:37:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:43:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 15:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:47:06 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-25 15:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:47:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 15:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:48:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 15:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:48:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 15:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:53:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 15:55:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 15:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 15:59:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 15:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:00:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:01:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 16:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:09:22 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-25 16:10:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 16:10:32 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-25 16:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:13:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 16:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:13:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 16:14:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 16:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:14:56 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-25 16:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:18:08 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-25 16:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:20:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 16:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:24:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 16:24:42 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-25 16:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:26:56 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-25 16:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 16:29:03 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-25 16:29:04 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-25 16:29:05 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-25 16:29:05 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 16:29:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 16:29:05 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 16:29:05 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-25 16:29:05 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-25 16:29:05 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-25 16:29:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:33:28 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-25 16:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:34:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:35:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:35:28 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-25 16:35:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:36:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:39:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 16:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:39:45 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-25 16:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:40:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:40:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:40:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:41:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:41:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:41:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:42:40 --> 404 Page Not Found: Clientaccesspolicyxml/index
ERROR - 2021-06-25 16:42:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:43:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:43:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:43:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:44:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 16:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:48:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 16:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:49:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 16:49:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:50:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 16:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 16:59:41 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-25 16:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:00:57 --> 404 Page Not Found: City/10
ERROR - 2021-06-25 17:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:07:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 17:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:20:54 --> 404 Page Not Found: Blog/index
ERROR - 2021-06-25 17:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:21:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 17:21:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 17:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:27:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 17:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:43:10 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-25 17:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:44:00 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-25 17:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:46:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 17:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:52:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 17:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:54:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 17:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:55:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 17:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:56:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 17:57:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 17:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 17:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:04:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 18:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:06:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:06:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:06:50 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-25 18:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:07:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:07:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:09:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:09:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 18:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:12:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:13:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:14:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 18:14:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:14:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 18:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:14:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 18:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:15:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 18:15:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 18:15:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 18:16:20 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-25 18:19:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 18:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:21:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:21:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:22:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:24:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:25:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:25:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:25:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 18:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:26:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:27:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 18:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:37:29 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-25 18:37:29 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-25 18:37:29 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 18:37:29 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 18:37:29 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-25 18:37:30 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-25 18:37:30 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 18:37:30 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 18:37:30 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-25 18:37:30 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-25 18:37:30 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 18:37:30 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 18:37:30 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 18:37:30 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 18:37:30 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-25 18:37:30 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-25 18:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:42:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 18:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:42:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 18:42:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:43:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 18:43:55 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 18:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:45:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 18:45:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 18:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:47:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 18:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 18:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:02:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:03:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:04:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:05:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:06:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:06:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 19:07:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:08:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:09:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:10:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:11:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:12:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 19:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:12:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:13:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:13:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 19:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:14:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:15:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:16:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:17:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:17:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:17:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:17:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:18:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 19:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 19:19:25 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-25 19:19:26 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 19:19:26 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 19:19:26 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-25 19:19:26 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 19:19:26 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 19:19:26 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-25 19:19:27 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 19:19:27 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-25 19:19:27 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-25 19:19:27 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-25 19:19:27 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-25 19:19:27 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 19:19:27 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 19:19:27 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 19:19:27 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-25 19:19:27 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-25 19:19:27 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-25 19:19:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:20:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:21:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:22:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 19:22:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 19:22:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 19:22:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 19:22:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:22:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:23:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:25:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:26:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:27:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:28:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:29:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:30:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:32:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:33:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:34:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 19:34:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:35:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 19:35:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:36:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 19:36:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:37:30 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 19:37:31 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 19:37:31 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 19:37:31 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 19:37:31 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 19:37:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:38:14 --> Severity: Warning --> Missing argument 1 for Home::city() /www/wwwroot/www.xuanhao.net/app/controllers/Home.php 156
ERROR - 2021-06-25 19:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:38:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:39:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:39:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 19:39:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 19:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:40:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:41:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:42:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 19:42:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:43:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:43:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 19:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:43:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:44:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:45:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 19:45:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 19:46:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 19:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:49:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 19:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:56:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 19:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:00:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 20:00:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 20:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:01:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 20:02:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 20:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 20:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:03:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 20:04:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 20:04:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 20:04:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 20:04:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 20:04:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 20:04:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 20:04:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 20:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:06:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 20:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:08:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 20:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:09:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 20:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:10:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 20:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:14:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 20:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:14:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 20:14:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 20:14:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 20:14:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 20:14:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 20:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:16:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 20:16:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 20:16:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 20:16:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 20:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:18:26 --> 404 Page Not Found: Wp-includes/index
ERROR - 2021-06-25 20:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:24:58 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 20:24:59 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 20:24:59 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 20:24:59 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 20:24:59 --> 404 Page Not Found: City/1
ERROR - 2021-06-25 20:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:40:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 20:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:50:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 20:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 20:58:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:03:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:08:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:08:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:08:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:08:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:09:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:09:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:10:08 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-25 21:10:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:11:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:20:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:21:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 21:21:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 21:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:22:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:23:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 21:23:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 21:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:24:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 21:24:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:24:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:26:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:28:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:28:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:28:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:28:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:30:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 21:30:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:30:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:30:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:30:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:33:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:33:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:33:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:33:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:37:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:38:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:38:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:38:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:39:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:39:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:39:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:39:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:39:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:40:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:40:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:40:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:41:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:41:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:42:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 21:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:47:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 21:47:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 21:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:48:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 21:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:53:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:53:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 21:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:54:10 --> 404 Page Not Found: Env/index
ERROR - 2021-06-25 21:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:54:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:55:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:55:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:55:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:55:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 21:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 21:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:02:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 22:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:05:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 22:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:07:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 22:08:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 22:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:11:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 22:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:12:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 22:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:16:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 22:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:19:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 22:20:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 22:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:20:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 22:22:29 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-25 22:22:30 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-25 22:22:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 22:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:23:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 22:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:25:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 22:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:30:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 22:30:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 22:30:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 22:30:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 22:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:32:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 22:32:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 22:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:36:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-60, 60' at line 7 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_city` = 1
AND  `hao_title` LIKE '%66666%' ESCAPE '!'
AND `hao_lock` <=0
ORDER BY `hao_time` DESC
 LIMIT -60, 60
ERROR - 2021-06-25 22:36:53 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 117
ERROR - 2021-06-25 22:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:38:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 22:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:44:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 22:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:45:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 22:45:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 22:45:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 22:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:56:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 22:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:58:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 22:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 22:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:00:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 23:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:07:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 23:07:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 23:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:13:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 23:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:19:15 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-25 23:19:41 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-25 23:21:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-25 23:21:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 23:22:03 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-25 23:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:23:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 23:23:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 23:24:02 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-25 23:24:31 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-25 23:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:26:20 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-25 23:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:26:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 23:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:27:16 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-25 23:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:28:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-25 23:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:29:06 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-25 23:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:34:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 23:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:36:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-25 23:37:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:40:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-25 23:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:45:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:54:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:56:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-25 23:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-25 23:59:47 --> 404 Page Not Found: Robotstxt/index
