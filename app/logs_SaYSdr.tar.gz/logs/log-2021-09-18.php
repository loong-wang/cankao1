<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-18 00:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:05:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:06:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-18 00:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:08:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 00:08:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 00:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:16:00 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-18 00:16:34 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-18 00:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:17:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:25:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 00:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:35:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 00:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:40:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 00:41:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 00:41:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 00:42:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 00:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:47:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 00:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 00:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:00:43 --> 404 Page Not Found: Order/index
ERROR - 2021-09-18 01:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:01:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 01:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:03:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 01:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:05:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 01:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:48:03 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-18 01:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:56:28 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-18 01:57:03 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-18 01:57:39 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-09-18 01:58:19 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-18 01:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 01:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:00:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-18 02:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:04:56 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-09-18 02:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:05:52 --> 404 Page Not Found: Fwal/index
ERROR - 2021-09-18 02:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:09:36 --> 404 Page Not Found: City/2
ERROR - 2021-09-18 02:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:22:52 --> 404 Page Not Found: Sitemap26932html/index
ERROR - 2021-09-18 02:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:37:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 02:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:47:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:55:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-18 02:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:59:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 02:59:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-18 03:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:05:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 03:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:08:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:15:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 03:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:19:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 03:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:24:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 03:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:24:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 03:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 03:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:26:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 03:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:42:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 03:42:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 03:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:48:12 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-18 03:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:52:38 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-09-18 03:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 03:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-09-18 04:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:01:33 --> 404 Page Not Found: English/index
ERROR - 2021-09-18 04:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:07:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 04:08:21 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-18 04:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:09:35 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-18 04:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:15:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 04:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:15:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 04:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:18:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 04:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:25:24 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 04:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:28:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 04:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:45:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 04:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:50:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 04:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:57:43 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-18 04:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 04:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:06:13 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-18 05:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:17:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 05:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:22:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 05:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:35:16 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-18 05:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:49:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:56:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 05:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:57:47 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-18 05:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 05:59:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 05:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:15:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 06:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:16:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:19:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 06:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:20:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 06:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:23:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 06:23:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 06:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 06:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 06:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:37:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:37:35 --> 404 Page Not Found: Index/login
ERROR - 2021-09-18 06:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:43:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 06:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:44:11 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-18 06:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:48:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 06:49:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 06:49:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 06:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:51:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 06:51:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 06:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:52:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 06:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:58:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 06:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:59:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 06:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 06:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 07:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:02:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:03:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:10:24 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-09-18 07:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:12:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 07:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:13:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 07:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:13:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:16:31 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 07:16:32 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-09-18 07:16:32 --> 404 Page Not Found: Storage/.env
ERROR - 2021-09-18 07:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:18:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:18:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:19:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:20:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:20:05 --> 404 Page Not Found: Maps/ResidentSS
ERROR - 2021-09-18 07:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:31:49 --> 404 Page Not Found: English/index
ERROR - 2021-09-18 07:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:34:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 07:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:37:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:37:41 --> 404 Page Not Found: City/1
ERROR - 2021-09-18 07:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:37:55 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-18 07:37:55 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-18 07:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:43:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:43:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:47:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:47:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:47:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:47:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:48:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:48:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:48:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:49:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:50:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:50:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:51:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 07:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:52:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-18 07:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 07:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 07:59:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:03:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 08:03:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 08:03:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 08:03:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 08:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:11:58 --> 404 Page Not Found: Fwxm/index
ERROR - 2021-09-18 08:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:13:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:17:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:17:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:17:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:19:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:19:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:19:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:20:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:21:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:23:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:23:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:35:55 --> 404 Page Not Found: Video/index
ERROR - 2021-09-18 08:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:40:41 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 08:41:17 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 08:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:46:04 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-18 08:46:05 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-18 08:46:06 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-18 08:46:07 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-18 08:46:07 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-18 08:46:07 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-18 08:46:07 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-18 08:46:07 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-18 08:46:07 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-18 08:46:07 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-18 08:47:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:47:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:47:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:47:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:48:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:48:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:48:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:48:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:48:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:48:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:49:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:49:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:50:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:50:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:52:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:54:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:55:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:56:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 08:57:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 08:59:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:01:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:01:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:02:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:06:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:07:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:07:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:12:37 --> 404 Page Not Found: City/10
ERROR - 2021-09-18 09:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:13:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:13:31 --> 404 Page Not Found: City/16
ERROR - 2021-09-18 09:14:19 --> 404 Page Not Found: City/15
ERROR - 2021-09-18 09:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:15:07 --> 404 Page Not Found: City/2
ERROR - 2021-09-18 09:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:15:44 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-18 09:15:51 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-18 09:15:53 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-18 09:15:56 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-18 09:15:58 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-18 09:16:00 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-18 09:16:03 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-18 09:16:05 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-18 09:16:06 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-18 09:16:11 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-18 09:16:12 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-18 09:16:18 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-18 09:16:19 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-18 09:16:21 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-18 09:16:23 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-09-18 09:16:25 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-09-18 09:16:26 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-09-18 09:16:27 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-18 09:16:29 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-18 09:16:30 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-18 09:16:31 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-18 09:16:32 --> 404 Page Not Found: City/index
ERROR - 2021-09-18 09:16:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:16:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:17:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:17:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:17:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:17:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:17:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:17:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:17:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:17:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:17:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:17:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:18:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:18:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:18:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:19:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:19:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:19:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:20:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:20:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:20:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:20:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:20:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:20:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:21:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:21:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:23:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:24:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:26:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:26:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:27:27 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-18 09:27:28 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-18 09:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:33:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:42:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:42:52 --> 404 Page Not Found: Page/images
ERROR - 2021-09-18 09:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:46:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:48:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:48:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:50:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:52:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:52:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:53:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 09:53:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:53:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:53:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:53:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:53:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:53:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:54:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 09:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:59:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 09:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:10:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:10:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:13:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:17:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:17:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:17:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:17:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:17:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:17:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:18:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:19:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:19:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:19:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:19:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:20:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:20:56 --> 404 Page Not Found: City/1
ERROR - 2021-09-18 10:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:22:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:30:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:38:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:39:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 10:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:41:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 10:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:42:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 10:43:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 10:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 10:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:44:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:47:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:47:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:47:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:47:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:47:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 10:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:48:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:48:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:48:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:48:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 10:49:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:49:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:49:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:49:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:50:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:50:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 10:50:22 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-09-18 10:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:50:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 10:50:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 10:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 10:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:55:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:57:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 10:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 10:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:09:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 11:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 11:09:51 --> 404 Page Not Found: Portal/redlion
ERROR - 2021-09-18 11:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 11:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:10:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 11:10:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 11:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:11:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 11:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:12:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 11:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 11:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:18:23 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-18 11:18:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:19:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:19:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:21:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:21:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:22:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:24:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:24:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:27:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:27:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:28:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-18 11:31:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:35:57 --> 404 Page Not Found: City/1
ERROR - 2021-09-18 11:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:43:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:44:51 --> 404 Page Not Found: City/2
ERROR - 2021-09-18 11:45:15 --> 404 Page Not Found: City/18
ERROR - 2021-09-18 11:45:20 --> 404 Page Not Found: City/19
ERROR - 2021-09-18 11:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:47:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:47:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:47:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:47:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:48:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:48:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:48:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:48:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:48:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:48:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:49:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:49:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:49:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:49:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:50:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:50:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:51:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:51:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:51:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 11:51:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 11:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:52:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:53:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:54:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:54:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:55:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 11:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 11:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:03:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:03:24 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 12:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:08:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-18 12:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:10:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:10:29 --> 404 Page Not Found: Hudson/index
ERROR - 2021-09-18 12:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:17:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:23:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:26:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:27:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:30:28 --> 404 Page Not Found: Login/index
ERROR - 2021-09-18 12:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:35:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:37:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:38:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 12:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:38:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:42:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:45:17 --> 404 Page Not Found: English/index
ERROR - 2021-09-18 12:45:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:46:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:46:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:46:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:46:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:46:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:47:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:47:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:47:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:47:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-18 12:47:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:48:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:48:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:48:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:48:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:49:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:49:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:50:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:50:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:51:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:52:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:52:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 12:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:53:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:53:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:53:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:53:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:54:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:55:03 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-18 12:55:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 12:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 12:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:00:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:00:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:00:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:01:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:01:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:02:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:03:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:05:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:06:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:13:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-18 13:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:17:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:17:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:17:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:17:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:18:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:18:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:18:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:18:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:18:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:19:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:20:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:22:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:22:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:22:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:26:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:34:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:35:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:38:42 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-18 13:40:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:42:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-18 13:43:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-18 13:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:47:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:47:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:47:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:47:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:48:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:49:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:50:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 13:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:51:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:51:47 --> 404 Page Not Found: Haoma/index
ERROR - 2021-09-18 13:51:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:51:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:54:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 13:54:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-18 13:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:57:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 13:58:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:00:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:00:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:13:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:15:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 14:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:16:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 14:17:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-18 14:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:18:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:21:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:22:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:22:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:23:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:24:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:25:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:30:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:31:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 14:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:31:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:32:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:32:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:33:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:33:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:34:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:34:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:34:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:35:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:35:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:35:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:36:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:36:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:36:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:36:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 14:36:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:38:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:40:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:45:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:48:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:48:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:48:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:48:55 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-09-18 14:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:52:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:55:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 14:59:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:59:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:59:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 14:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:02:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 15:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:07:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 15:07:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 15:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:08:42 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-18 15:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:10:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 15:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:11:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 15:11:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 15:11:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 15:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:12:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 15:14:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 15:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:18:39 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-18 15:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:20:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 15:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:28:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 15:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:30:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 15:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:32:27 --> 404 Page Not Found: Video/index
ERROR - 2021-09-18 15:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:36:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 15:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:37:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 15:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:43:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:45:04 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-18 15:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:49:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 15:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:50:16 --> 404 Page Not Found: City/1
ERROR - 2021-09-18 15:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:58:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 15:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:00:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 16:01:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 16:01:58 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-18 16:01:58 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-18 16:01:58 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-18 16:01:58 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-18 16:01:58 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-18 16:01:58 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-18 16:01:59 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-18 16:02:00 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-18 16:02:00 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-18 16:02:00 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-18 16:02:00 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-18 16:02:00 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-18 16:02:00 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-18 16:02:00 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-18 16:02:00 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-18 16:02:00 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-18 16:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:05:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 16:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:05:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 16:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:09:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:10:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 16:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:11:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:13:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 16:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:14:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-18 16:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:16:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 16:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:20:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 16:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:26:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 16:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:29:51 --> 404 Page Not Found: City/2
ERROR - 2021-09-18 16:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:32:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 16:32:47 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-18 16:32:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 16:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:38:55 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 16:38:55 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 16:38:55 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 16:38:57 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 16:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:40:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:41:09 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-09-18 16:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:44:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 16:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:45:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 16:45:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 16:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:53:02 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 16:53:02 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 16:53:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 16:53:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 16:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 16:58:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 16:59:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 17:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:04:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:04:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:06:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 17:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:12:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 17:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:16:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 17:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:20:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 17:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:33:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 17:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:44:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 17:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:49:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 17:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 17:58:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 17:59:32 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 17:59:32 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 17:59:32 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 17:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:02:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:09:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 18:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:12:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 18:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:12:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:17:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 18:18:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 18:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:22:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 18:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:25:02 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-09-18 18:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:25:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 18:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:26:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 18:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:27:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 18:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:37:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:39:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 18:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:42:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 18:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:49:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 18:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 18:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:08:12 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-09-18 19:08:45 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-09-18 19:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:10:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 19:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:11:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:14:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 19:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:27:36 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-18 19:27:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-18 19:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:34:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 19:35:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 19:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:37:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-18 19:37:14 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-18 19:37:15 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-18 19:37:15 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-18 19:37:15 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-18 19:37:15 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-18 19:37:15 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-18 19:37:15 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-18 19:37:15 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-18 19:37:15 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-18 19:37:15 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-18 19:37:15 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-18 19:37:15 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-18 19:37:16 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-18 19:37:16 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-18 19:37:16 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-18 19:37:16 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-18 19:37:16 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-18 19:37:16 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-18 19:37:16 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-18 19:37:16 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-18 19:37:16 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-18 19:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:41:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 19:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:42:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 19:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:46:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 19:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:48:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 19:48:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:53:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 19:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:57:42 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-18 19:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 19:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:00:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:05:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 20:05:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 20:05:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 20:05:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 20:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:12:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:13:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:13:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:14:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:16:43 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 20:16:44 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-09-18 20:16:45 --> 404 Page Not Found: Storage/.env
ERROR - 2021-09-18 20:16:46 --> 404 Page Not Found: Public/.env
ERROR - 2021-09-18 20:16:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:22:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:24:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:28:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:31:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:36:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:36:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:39:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:43:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:46:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 20:46:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:47:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:48:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:49:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:49:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 20:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:52:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:52:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:52:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:53:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:53:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:54:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 20:54:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:54:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:55:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:55:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:56:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:56:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:57:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:57:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 20:59:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:59:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 20:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:00:15 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-18 21:00:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 21:00:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 21:00:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 21:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:02:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:02:42 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 21:02:43 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-09-18 21:02:43 --> 404 Page Not Found: Storage/.env
ERROR - 2021-09-18 21:02:44 --> 404 Page Not Found: Public/.env
ERROR - 2021-09-18 21:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 21:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:07:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 21:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:10:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:14:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:14:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:15:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:15:32 --> 404 Page Not Found: English/index
ERROR - 2021-09-18 21:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:17:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 21:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:33:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:34:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 21:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:36:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:36:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:37:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:41:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:48:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:49:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 21:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:52:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:53:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 21:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:53:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 21:54:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:57:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 21:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 21:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 21:59:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 22:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:01:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 22:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 22:02:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 22:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:08:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:11:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 22:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:19:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 22:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:19:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 22:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:23:27 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-09-18 22:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:25:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-18 22:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:28:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 22:28:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 22:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:29:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 22:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:33:35 --> 404 Page Not Found: City/16
ERROR - 2021-09-18 22:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:37:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 22:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:40:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 22:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:40:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:41:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 22:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:44:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 22:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:46:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:46:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 22:46:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:46:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:46:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:47:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:47:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:47:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:47:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:48:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 22:48:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:48:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:49:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 22:50:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:50:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:52:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:53:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-18 22:53:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-18 22:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:55:20 --> 404 Page Not Found: 404/index.html
ERROR - 2021-09-18 22:55:20 --> 404 Page Not Found: 404/index.html
ERROR - 2021-09-18 22:56:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-18 22:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 22:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:09:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 23:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:09:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 23:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 23:10:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 23:10:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 23:10:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 23:10:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 23:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:11:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 23:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:15:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:19:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 23:19:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 23:20:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 23:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:26:00 --> 404 Page Not Found: Env/index
ERROR - 2021-09-18 23:26:01 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-09-18 23:26:02 --> 404 Page Not Found: Storage/.env
ERROR - 2021-09-18 23:26:02 --> 404 Page Not Found: Public/.env
ERROR - 2021-09-18 23:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:27:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 23:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:32:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 23:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:43:13 --> 404 Page Not Found: Undefined/index
ERROR - 2021-09-18 23:44:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-18 23:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:44:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 23:45:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 23:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:51:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 23:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:53:31 --> 404 Page Not Found: Haoma/index
ERROR - 2021-09-18 23:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:55:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-18 23:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-18 23:59:25 --> 404 Page Not Found: Robotstxt/index
