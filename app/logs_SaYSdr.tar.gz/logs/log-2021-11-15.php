<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-15 00:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 00:12:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 00:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 00:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 00:21:31 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 00:22:56 --> 404 Page Not Found: Article/info
ERROR - 2021-11-15 00:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 00:25:16 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-15 00:25:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 00:32:34 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 00:37:14 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 00:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 00:38:10 --> 404 Page Not Found: Company/view
ERROR - 2021-11-15 00:43:56 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 00:45:25 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-15 00:48:19 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-15 00:50:22 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-15 00:51:08 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 00:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 00:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 01:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 01:14:40 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-15 01:14:40 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-15 01:14:41 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-15 01:14:41 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-15 01:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 01:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 01:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 01:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:11:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 02:11:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 02:11:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 02:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:29:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 02:34:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 02:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:35:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 02:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 02:51:14 --> 404 Page Not Found: News_showasp/index
ERROR - 2021-11-15 03:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:26:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-15 03:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:37:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 03:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:37:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 03:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:49:35 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2021-11-15 03:52:32 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 03:54:40 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 03:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 03:55:06 --> 404 Page Not Found: Jdybsc/index
ERROR - 2021-11-15 03:59:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 04:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 04:29:45 --> 404 Page Not Found: City/1
ERROR - 2021-11-15 04:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 04:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 04:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 05:03:42 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 05:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 05:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 05:21:19 --> 404 Page Not Found: Html-cn/new-products-CQxmJTnWDEvg-1-0-2-1.html
ERROR - 2021-11-15 05:21:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 05:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 05:28:34 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-15 05:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 05:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 05:38:54 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 05:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 05:41:01 --> 404 Page Not Found: Article/info
ERROR - 2021-11-15 05:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 05:51:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 05:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 05:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 05:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 06:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 06:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 06:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 06:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 06:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 06:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 06:29:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 06:29:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 06:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 06:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 06:47:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-15 06:49:32 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-15 06:49:33 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-15 07:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 07:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 07:35:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 07:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 07:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 07:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 07:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 07:46:39 --> 404 Page Not Found: Order/index
ERROR - 2021-11-15 08:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 08:12:05 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-15 08:12:05 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-15 08:15:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 08:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 08:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 08:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 08:25:34 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2021-11-15 08:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 08:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 08:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 08:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 08:50:25 --> 404 Page Not Found: Sitemap17230html/index
ERROR - 2021-11-15 08:51:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 08:51:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 08:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 08:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 08:53:15 --> 404 Page Not Found: Sitemap29327html/index
ERROR - 2021-11-15 09:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:09:53 --> 404 Page Not Found: Sitemap90146html/index
ERROR - 2021-11-15 09:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:13:09 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-11-15 09:13:09 --> 404 Page Not Found: Issmall/index
ERROR - 2021-11-15 09:13:14 --> 404 Page Not Found: Administrator/manifests
ERROR - 2021-11-15 09:13:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 09:13:18 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-11-15 09:13:18 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-11-15 09:13:18 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-11-15 09:13:18 --> 404 Page Not Found: Docs/index
ERROR - 2021-11-15 09:13:20 --> 404 Page Not Found: admin//index
ERROR - 2021-11-15 09:13:20 --> 404 Page Not Found: admin/Template/article_more
ERROR - 2021-11-15 09:13:20 --> 404 Page Not Found: E/master
ERROR - 2021-11-15 09:13:20 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-11-15 09:13:20 --> 404 Page Not Found: Auth/login
ERROR - 2021-11-15 09:13:21 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-11-15 09:13:21 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-11-15 09:13:21 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-11-15 09:13:21 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-11-15 09:13:21 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-11-15 09:13:21 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-11-15 09:13:30 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-11-15 09:13:30 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-11-15 09:13:30 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-11-15 09:13:30 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-11-15 09:13:30 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-11-15 09:13:30 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-11-15 09:13:31 --> 404 Page Not Found: Ids/admin
ERROR - 2021-11-15 09:13:31 --> 404 Page Not Found: Ids/admin
ERROR - 2021-11-15 09:13:31 --> 404 Page Not Found: admin/Inc/xml.xslt
ERROR - 2021-11-15 09:13:31 --> 404 Page Not Found: Addons/theme
ERROR - 2021-11-15 09:13:31 --> 404 Page Not Found: admin/SouthidcEditor/ewebeditor.asp
ERROR - 2021-11-15 09:13:31 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-11-15 09:13:32 --> 404 Page Not Found: Console/include
ERROR - 2021-11-15 09:13:32 --> 404 Page Not Found: Console/auth
ERROR - 2021-11-15 09:13:32 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-11-15 09:13:32 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-11-15 09:13:33 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-11-15 09:13:33 --> 404 Page Not Found: admin/Loginasp/index
ERROR - 2021-11-15 09:13:33 --> 404 Page Not Found: admin/Loginaspx/index
ERROR - 2021-11-15 09:13:33 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-11-15 09:13:33 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-11-15 09:13:33 --> 404 Page Not Found: Licencetxt/index
ERROR - 2021-11-15 09:13:33 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-11-15 09:13:34 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-11-15 09:13:34 --> 404 Page Not Found: System/Login.aspx
ERROR - 2021-11-15 09:13:34 --> 404 Page Not Found: Forums/list.page
ERROR - 2021-11-15 09:13:34 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-11-15 09:13:34 --> 404 Page Not Found: API/DW
ERROR - 2021-11-15 09:13:34 --> 404 Page Not Found: API/DW
ERROR - 2021-11-15 09:13:35 --> 404 Page Not Found: API/DW
ERROR - 2021-11-15 09:13:35 --> 404 Page Not Found: Admin/Common
ERROR - 2021-11-15 09:13:35 --> 404 Page Not Found: API/DW
ERROR - 2021-11-15 09:13:35 --> 404 Page Not Found: API/DW
ERROR - 2021-11-15 09:13:35 --> 404 Page Not Found: Admin/Login.aspx
ERROR - 2021-11-15 09:13:35 --> 404 Page Not Found: Themes/default
ERROR - 2021-11-15 09:13:35 --> 404 Page Not Found: Help/user
ERROR - 2021-11-15 09:13:35 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-11-15 09:13:36 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-11-15 09:13:36 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-11-15 09:13:36 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-11-15 09:13:36 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-11-15 09:13:36 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-11-15 09:13:37 --> 404 Page Not Found: Archiver/index
ERROR - 2021-11-15 09:13:37 --> 404 Page Not Found: Tools/rss.aspx
ERROR - 2021-11-15 09:13:37 --> 404 Page Not Found: Ntalker/lawfirm.aspx
ERROR - 2021-11-15 09:13:37 --> 404 Page Not Found: Searchhtml/index
ERROR - 2021-11-15 09:13:37 --> 404 Page Not Found: Feedasp/index
ERROR - 2021-11-15 09:13:37 --> 404 Page Not Found: Jcms/index.jsp
ERROR - 2021-11-15 09:13:37 --> 404 Page Not Found: Jcms/index_jcms.jsp
ERROR - 2021-11-15 09:13:37 --> 404 Page Not Found: Historytxt/index
ERROR - 2021-11-15 09:13:37 --> 404 Page Not Found: Inc/Templates
ERROR - 2021-11-15 09:13:38 --> 404 Page Not Found: Api/api_user.xml
ERROR - 2021-11-15 09:13:38 --> 404 Page Not Found: Template/home.htm
ERROR - 2021-11-15 09:13:38 --> 404 Page Not Found: System/skins
ERROR - 2021-11-15 09:13:38 --> 404 Page Not Found: System/language
ERROR - 2021-11-15 09:13:38 --> 404 Page Not Found: Datacenter/downloadApp
ERROR - 2021-11-15 09:13:38 --> 404 Page Not Found: Rssaspx/index
ERROR - 2021-11-15 09:13:38 --> 404 Page Not Found: admin//index
ERROR - 2021-11-15 09:13:38 --> 404 Page Not Found: Plug/publish
ERROR - 2021-11-15 09:13:41 --> 404 Page Not Found: Public/about.html
ERROR - 2021-11-15 09:13:41 --> 404 Page Not Found: Help/en
ERROR - 2021-11-15 09:13:41 --> 404 Page Not Found: Images/zh-CN
ERROR - 2021-11-15 09:13:41 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2021-11-15 09:13:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-15 09:13:42 --> 404 Page Not Found: Plus/sitemap.html
ERROR - 2021-11-15 09:13:42 --> 404 Page Not Found: Plus/rssmap.html
ERROR - 2021-11-15 09:13:43 --> 404 Page Not Found: Member/space
ERROR - 2021-11-15 09:13:43 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-11-15 09:13:43 --> 404 Page Not Found: Changelogtxt/index
ERROR - 2021-11-15 09:13:43 --> 404 Page Not Found: Help/index
ERROR - 2021-11-15 09:13:43 --> 404 Page Not Found: M/index
ERROR - 2021-11-15 09:13:43 --> 404 Page Not Found: Ycportal/js
ERROR - 2021-11-15 09:13:43 --> 404 Page Not Found: Include/install_ocx.aspx
ERROR - 2021-11-15 09:13:43 --> 404 Page Not Found: Login/Jeecms.do
ERROR - 2021-11-15 09:13:43 --> 404 Page Not Found: Nobody/mobile.htm
ERROR - 2021-11-15 09:13:43 --> 404 Page Not Found: System/Update.aspx
ERROR - 2021-11-15 09:13:44 --> 404 Page Not Found: Site/Pages
ERROR - 2021-11-15 09:13:44 --> 404 Page Not Found: Archiver/index
ERROR - 2021-11-15 09:13:45 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-11-15 09:13:45 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-11-15 09:13:45 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-11-15 09:13:45 --> 404 Page Not Found: Was/help.jsp
ERROR - 2021-11-15 09:13:46 --> 404 Page Not Found: Was5/web
ERROR - 2021-11-15 09:13:46 --> 404 Page Not Found: Was/main.html
ERROR - 2021-11-15 09:13:48 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-11-15 09:13:49 --> 404 Page Not Found: Weblog/index
ERROR - 2021-11-15 09:13:49 --> 404 Page Not Found: Blog/index
ERROR - 2021-11-15 09:13:49 --> 404 Page Not Found: Forum/index
ERROR - 2021-11-15 09:13:49 --> 404 Page Not Found: Bbs/index
ERROR - 2021-11-15 09:13:49 --> 404 Page Not Found: Wcm/index
ERROR - 2021-11-15 09:13:49 --> 404 Page Not Found: admin/Editor/index
ERROR - 2021-11-15 09:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:21:22 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2021-11-15 09:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:24:15 --> 404 Page Not Found: Sitemap36220html/index
ERROR - 2021-11-15 09:24:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 09:30:32 --> 404 Page Not Found: Sitemap35142html/index
ERROR - 2021-11-15 09:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:32:17 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2021-11-15 09:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:35:09 --> 404 Page Not Found: Sitemap78583html/index
ERROR - 2021-11-15 09:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:50:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:50:04 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2021-11-15 09:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 09:56:57 --> 404 Page Not Found: Sitemap86343html/index
ERROR - 2021-11-15 10:00:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 10:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:06:38 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-15 10:07:06 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-15 10:08:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 10:09:13 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-15 10:09:27 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-15 10:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:10:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 10:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:19:44 --> 404 Page Not Found: Sitemap52624html/index
ERROR - 2021-11-15 10:19:58 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-15 10:19:59 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-15 10:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:20:49 --> 404 Page Not Found: Sitemap24031html/index
ERROR - 2021-11-15 10:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:22:29 --> 404 Page Not Found: Sitemap82177html/index
ERROR - 2021-11-15 10:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:37:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 10:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:50:36 --> 404 Page Not Found: Sitemap42517html/index
ERROR - 2021-11-15 10:52:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 10:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 10:56:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 10:56:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:01:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:02:59 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-15 11:03:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:04:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:04:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:07:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 11:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 11:23:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 11:23:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 11:23:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 11:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 11:27:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 11:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 11:28:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 11:33:14 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 11:33:49 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-11-15 11:35:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:36:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:36:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:36:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:36:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:37:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:37:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:38:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:39:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:39:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 11:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 12:01:51 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-15 12:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 12:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 12:10:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 12:11:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 12:11:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 12:14:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 12:14:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 12:15:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 12:18:22 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-15 12:18:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 12:19:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 12:19:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-15 12:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 12:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 12:24:27 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-15 12:38:59 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 12:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 12:52:55 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 12:54:45 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 12:57:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 13:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 13:02:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 13:02:38 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-15 13:04:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 13:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 13:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 13:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 13:11:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 13:18:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-15 13:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 13:22:38 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 13:28:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 13:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 13:29:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-15 13:35:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 13:35:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 13:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 13:40:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 13:46:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 13:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 13:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 13:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:03:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 14:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:07:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:25:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 14:26:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 14:30:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 14:31:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 14:32:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 14:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:41:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 14:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:50:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 14:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 14:51:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 14:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 14:59:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 15:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:04:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 15:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:09:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 15:10:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 15:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:20:07 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-11-15 15:22:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 15:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:36:58 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 15:39:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 15:39:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 15:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 15:54:13 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 16:00:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 16:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 16:04:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 16:05:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 16:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 16:05:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 16:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 16:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 16:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 16:15:49 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 16:17:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 16:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 16:24:25 --> 404 Page Not Found: Article/index
ERROR - 2021-11-15 16:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 16:28:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 16:31:46 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 16:35:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 16:37:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 16:37:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 16:43:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 16:43:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 16:44:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 16:45:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 16:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 16:55:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 16:56:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:02:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 17:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:07:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 17:09:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:23:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:24:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:24:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 17:31:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:32:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:35:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:44:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:48:21 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-15 17:48:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:49:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:49:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:50:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:50:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:50:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:51:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:51:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 17:58:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 17:59:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 18:00:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 18:00:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 18:01:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 18:01:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 18:04:57 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 18:18:25 --> 404 Page Not Found: City/10
ERROR - 2021-11-15 18:19:56 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-11-15 18:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 18:22:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 18:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 18:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 18:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 18:24:35 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-15 18:24:36 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 18:25:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:25:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:26:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:26:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:26:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:26:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:26:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:26:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:26:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:26:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 18:40:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 18:41:30 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 18:41:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-15 18:43:46 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-15 18:44:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-15 18:54:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-15 18:58:37 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 19:06:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-15 19:08:58 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 19:09:19 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-11-15 19:10:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 19:10:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 19:12:31 --> 404 Page Not Found: Company/view
ERROR - 2021-11-15 19:13:27 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 19:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 19:16:51 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 19:16:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 19:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 19:20:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-15 19:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 19:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 19:28:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 19:29:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-15 19:33:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-15 19:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 19:56:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 19:57:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 20:00:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-15 20:03:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:03:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 20:04:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 20:04:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:04:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:04:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 20:04:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 20:04:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:04:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:05:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 20:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 20:13:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:14:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:14:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:15:05 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 20:15:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:16:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:16:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:16:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:17:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:17:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 20:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 20:21:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-15 20:24:14 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 20:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 20:25:27 --> 404 Page Not Found: Sitemap97179html/index
ERROR - 2021-11-15 20:29:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 20:31:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 20:39:48 --> 404 Page Not Found: Sitemap48655html/index
ERROR - 2021-11-15 20:42:17 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-15 20:44:41 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-15 20:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 20:48:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 20:48:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 20:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 20:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 20:56:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 21:02:48 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 21:05:16 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-15 21:06:34 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-15 21:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 21:18:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:19:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:19:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 21:19:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 21:19:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:19:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:20:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:21:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:21:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:22:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 21:22:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:23:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:23:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:23:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:23:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 21:24:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:24:32 --> 404 Page Not Found: Article/info
ERROR - 2021-11-15 21:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 21:24:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:24:53 --> 404 Page Not Found: News_showasp/index
ERROR - 2021-11-15 21:25:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:25:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:25:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:26:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:26:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 21:29:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 21:37:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 21:52:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 22:06:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 22:06:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 22:09:13 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-15 22:09:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 22:09:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 22:09:51 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 22:09:51 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-15 22:14:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 22:14:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 22:14:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 22:14:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 22:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 22:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 22:19:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 22:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 22:25:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 22:26:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 22:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 22:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 22:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 22:48:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 22:48:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 22:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 22:52:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 22:53:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 22:53:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 22:54:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-15 22:54:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 22:54:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 22:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 23:03:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 23:04:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:09:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:10:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:11:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:12:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:12:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:13:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:18:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:19:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 23:20:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 23:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:22:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:23:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:24:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:25:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:26:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:26:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-15 23:29:37 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-11-15 23:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-15 23:51:10 --> 404 Page Not Found: Sitemap41019html/index
ERROR - 2021-11-15 23:53:16 --> 404 Page Not Found: Robotstxt/index
