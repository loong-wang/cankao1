<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-18 00:03:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 00:06:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 00:06:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 00:08:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 00:09:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 00:09:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 00:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 00:10:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 00:15:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 00:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 00:23:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 00:24:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 00:25:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 00:25:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 00:31:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 00:31:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 00:31:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 00:44:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 00:44:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 00:45:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 00:45:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 00:55:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 00:56:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 01:07:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 01:07:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 01:07:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 01:15:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 01:24:48 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-12-18 01:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 01:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 01:33:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 01:33:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 01:33:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 01:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 01:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 01:58:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 01:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 01:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 02:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 02:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 02:33:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 02:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 02:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 02:51:42 --> 404 Page Not Found: Utf8-net/net
ERROR - 2021-12-18 02:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 03:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 03:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 03:17:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 03:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 03:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 03:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 03:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 03:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 03:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 03:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 04:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 04:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 04:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 04:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 04:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 04:47:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 04:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 04:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 04:50:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 04:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 04:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 04:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 05:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 05:03:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 05:09:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 05:09:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 05:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 05:10:04 --> 404 Page Not Found: Utf8-net/net
ERROR - 2021-12-18 05:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 05:21:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 05:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 05:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 05:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 05:56:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 05:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:02:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:07:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 06:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:18:59 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-12-18 06:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:45:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 06:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 06:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 07:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 07:09:12 --> 404 Page Not Found: Xxgkinfo/index.html
ERROR - 2021-12-18 07:09:59 --> 404 Page Not Found: Weather/101180805
ERROR - 2021-12-18 07:11:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 07:18:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 07:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 07:23:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 07:33:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 07:36:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 07:37:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 07:40:37 --> 404 Page Not Found: Mews/news.asp
ERROR - 2021-12-18 07:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 07:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 07:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 07:57:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 08:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 08:02:02 --> 404 Page Not Found: Utf8-net/net
ERROR - 2021-12-18 08:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 08:18:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 08:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 08:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 08:26:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 08:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 08:33:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 08:35:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 08:37:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 08:37:56 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-18 08:37:57 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-12-18 08:37:57 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-12-18 08:37:57 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-18 08:43:53 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-18 08:43:53 --> 404 Page Not Found: admin//index
ERROR - 2021-12-18 08:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 08:43:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 08:43:54 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-18 08:43:54 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-12-18 08:43:54 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-12-18 08:43:54 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-12-18 08:43:54 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-12-18 08:43:54 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-12-18 08:43:54 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-12-18 08:43:55 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-12-18 08:43:55 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-18 08:43:55 --> 404 Page Not Found: Wcm/index
ERROR - 2021-12-18 08:43:55 --> 404 Page Not Found: Wcm/explicit_not_exist_path
ERROR - 2021-12-18 08:43:55 --> 404 Page Not Found: Wcm/robots.txt
ERROR - 2021-12-18 08:43:55 --> 404 Page Not Found: Wcm/favicon.ico
ERROR - 2021-12-18 08:43:55 --> 404 Page Not Found: Wcm/static
ERROR - 2021-12-18 08:43:55 --> 404 Page Not Found: Wcm/4e5e5d7364f443e28fbf0d3ae744a59a
ERROR - 2021-12-18 08:43:55 --> 404 Page Not Found: Wcm/index
ERROR - 2021-12-18 08:43:55 --> 404 Page Not Found: Wcm/readme.html
ERROR - 2021-12-18 08:43:55 --> 404 Page Not Found: Wcm/license.txt
ERROR - 2021-12-18 08:43:56 --> 404 Page Not Found: Wcm/wp-includes
ERROR - 2021-12-18 08:43:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 08:45:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 08:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 08:56:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 09:19:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 09:20:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 09:20:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 09:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 09:23:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 09:25:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 09:26:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 09:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 09:30:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 09:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 09:40:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 09:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 09:52:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 09:54:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 09:55:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 09:55:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 10:05:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 10:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 10:13:11 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-18 10:13:11 --> 404 Page Not Found: admin//index
ERROR - 2021-12-18 10:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 10:13:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 10:13:12 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-18 10:13:12 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-12-18 10:13:12 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-12-18 10:13:14 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-12-18 10:13:14 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-12-18 10:13:14 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-12-18 10:13:14 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-12-18 10:13:14 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-12-18 10:13:14 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-18 10:13:14 --> 404 Page Not Found: Wcm/index
ERROR - 2021-12-18 10:13:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 10:13:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 10:15:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 10:22:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 10:22:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 10:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 10:25:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 10:26:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 10:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 10:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 10:35:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 10:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 10:37:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 10:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 10:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 10:54:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 10:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 11:00:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 11:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 11:05:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:06:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 11:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 11:33:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:33:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:33:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:34:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 11:34:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 11:34:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 11:35:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 11:37:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 11:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:38:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:38:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:38:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:38:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:38:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:38:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:38:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 11:38:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:38:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:41:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:48:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 11:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 11:54:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:54:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 11:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 12:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 12:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 12:15:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 12:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 12:20:17 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-18 12:20:17 --> 404 Page Not Found: admin//index
ERROR - 2021-12-18 12:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 12:20:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 12:20:17 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-12-18 12:20:17 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-12-18 12:20:17 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-18 12:20:17 --> 404 Page Not Found: Wcm/index
ERROR - 2021-12-18 12:20:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 12:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 12:28:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 12:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 12:49:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 12:54:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 12:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 13:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 13:09:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 13:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 13:13:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 13:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 13:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 13:19:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 13:20:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 13:21:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 13:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 13:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 13:39:03 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-12-18 13:43:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 13:43:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 13:48:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 13:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 13:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 13:55:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 14:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 14:14:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 14:16:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 14:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 14:19:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 14:20:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 14:21:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 14:21:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 14:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 14:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 14:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 14:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 14:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 14:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 14:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 14:49:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 14:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 14:55:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 14:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 14:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 14:58:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 15:06:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 15:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:14:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 15:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:28:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 15:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 15:44:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 15:54:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 15:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 16:05:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 16:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 16:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 16:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 16:32:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 16:34:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 16:34:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 16:34:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 16:34:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 16:34:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 16:34:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 16:34:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 16:36:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 16:36:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 16:36:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 16:37:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 16:37:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 16:37:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 16:37:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 16:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 16:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 16:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 16:44:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 16:44:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 16:46:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 16:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 16:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 17:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 17:25:54 --> 404 Page Not Found: Login/index
ERROR - 2021-12-18 17:27:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 17:28:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 17:28:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 17:29:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 17:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 17:34:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 17:48:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 17:53:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 18:00:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 18:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 18:07:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-18 18:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 18:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 18:17:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 18:17:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 18:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 18:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 18:33:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 18:33:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 18:33:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 18:33:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 18:33:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 18:33:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 18:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 18:44:29 --> 404 Page Not Found: admin/Login/index.html
ERROR - 2021-12-18 18:44:29 --> 404 Page Not Found: Langs/en_US
ERROR - 2021-12-18 18:44:29 --> 404 Page Not Found: admin/Login/index.html
ERROR - 2021-12-18 18:44:30 --> 404 Page Not Found: admin/Login/index.html
ERROR - 2021-12-18 18:44:41 --> 404 Page Not Found: Langs/en_US
ERROR - 2021-12-18 18:44:41 --> 404 Page Not Found: admin/Login/index.html
ERROR - 2021-12-18 18:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 18:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 18:58:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 18:58:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 19:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 19:12:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 19:13:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 19:15:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 19:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 19:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 19:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 19:32:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 19:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 19:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 19:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 19:55:00 --> 404 Page Not Found: Topasp/index
ERROR - 2021-12-18 19:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 19:56:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 19:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 20:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 20:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 20:34:00 --> 404 Page Not Found: City/1
ERROR - 2021-12-18 20:34:02 --> 404 Page Not Found: City/1
ERROR - 2021-12-18 20:34:02 --> 404 Page Not Found: City/1
ERROR - 2021-12-18 20:34:05 --> 404 Page Not Found: City/1
ERROR - 2021-12-18 20:34:09 --> 404 Page Not Found: City/1
ERROR - 2021-12-18 20:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 20:35:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 20:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 20:38:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 20:38:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 20:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 20:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 21:06:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 21:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 21:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 21:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 21:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 21:27:32 --> 404 Page Not Found: Manager/html
ERROR - 2021-12-18 21:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 21:43:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 21:53:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 21:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 22:11:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 22:16:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 22:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 22:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:18:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 22:19:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 22:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:20:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 22:20:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 22:23:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 22:24:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 22:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:28:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 22:30:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 22:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:39:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 22:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:46:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 22:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 22:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 23:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 23:06:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 23:07:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 23:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 23:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 23:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 23:16:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 23:23:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-18 23:24:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 23:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 23:28:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 23:28:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 23:28:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 23:29:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 23:29:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 23:29:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 23:29:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 23:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 23:29:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 23:29:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 23:30:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 23:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 23:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 23:49:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 23:56:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-18 23:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-18 23:57:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-18 23:57:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-18 23:59:19 --> 404 Page Not Found: Data/admin
