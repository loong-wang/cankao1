<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-21 00:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:01:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:01:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:01:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:02:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:06:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 00:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:12:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:12:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:12:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:13:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 00:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:13:48 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-21 00:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:14:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:14:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:14:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:14:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 00:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:15:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:16:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 00:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:17:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:18:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:19:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:19:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:19:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:21:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 00:21:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 00:22:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:24:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:25:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:25:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:25:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:26:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:26:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 00:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:26:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:27:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:27:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:28:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:29:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:30:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 00:30:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:30:32 --> 404 Page Not Found: Article/index
ERROR - 2021-08-21 00:30:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:31:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:31:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:31:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:32:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:34:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:34:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 00:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:36:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:37:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:37:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 00:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:39:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 00:39:12 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-21 00:39:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:41:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:42:20 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-08-21 00:42:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:42:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:44:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:45:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:45:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:45:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:47:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:48:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:49:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:50:08 --> 404 Page Not Found: Haoma/index
ERROR - 2021-08-21 00:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:50:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:50:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:50:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 00:51:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:51:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:52:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:52:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:53:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:54:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:54:53 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-21 00:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:55:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:55:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:56:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:56:36 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-08-21 00:57:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:57:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 00:58:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 00:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:00:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:00:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 01:00:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:01:02 --> 404 Page Not Found: Env/index
ERROR - 2021-08-21 01:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:01:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:01:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:02:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:02:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:03:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:03:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:04:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:04:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:04:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:04:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:05:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:05:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:06:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:06:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:06:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:07:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:07:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:07:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:07:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:07:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:07:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:07:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:07:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:09:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:09:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:10:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:10:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:10:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:10:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:11:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:11:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:12:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:12:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:13:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:14:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:14:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:14:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:14:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:15:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 01:15:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:15:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:17:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:17:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:18:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:18:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 01:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:19:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:19:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:19:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:19:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:20:14 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-21 01:20:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:20:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:20:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:20:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:21:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 01:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:22:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:22:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:22:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:22:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 01:22:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:23:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:24:40 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-21 01:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:29:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:35:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 01:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:37:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 01:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:39:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:40:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:46:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:46:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 01:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:47:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:48:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 01:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 01:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:57:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 01:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 01:58:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 01:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:09:46 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-21 02:10:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 02:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:11:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 02:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:17:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 02:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:21:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 02:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:28:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 02:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:30:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 02:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:32:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 02:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:33:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 02:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:35:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 02:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:35:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 02:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:39:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:41:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 02:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:46:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 02:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:48:05 --> 404 Page Not Found: City/1
ERROR - 2021-08-21 02:48:08 --> 404 Page Not Found: City/16
ERROR - 2021-08-21 02:48:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 02:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:51:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 02:52:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 02:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:58:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 02:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 02:59:37 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-21 02:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:06:33 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-21 03:06:34 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-21 03:06:34 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-21 03:06:34 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-21 03:06:34 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-21 03:06:34 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-21 03:06:34 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-21 03:06:34 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-21 03:06:34 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-21 03:06:34 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-21 03:06:34 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-21 03:06:34 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-21 03:06:35 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-21 03:06:36 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-21 03:06:36 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-21 03:06:36 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-21 03:06:36 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-21 03:06:36 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-21 03:06:36 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-21 03:06:36 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-21 03:06:36 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-21 03:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:08:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 03:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:10:09 --> 404 Page Not Found: 1629486609351986145/index
ERROR - 2021-08-21 03:10:14 --> 404 Page Not Found: Magento_version/index
ERROR - 2021-08-21 03:10:17 --> 404 Page Not Found: RELEASE_NOTEStxt/index
ERROR - 2021-08-21 03:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:10:18 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-08-21 03:10:20 --> 404 Page Not Found: Wp-admin/index
ERROR - 2021-08-21 03:10:21 --> 404 Page Not Found: Feed/index
ERROR - 2021-08-21 03:10:22 --> 404 Page Not Found: INSTALLtxt/index
ERROR - 2021-08-21 03:10:22 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-08-21 03:10:22 --> 404 Page Not Found: Core/CHANGELOG.txt
ERROR - 2021-08-21 03:10:23 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 03:10:27 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 03:10:28 --> 404 Page Not Found: User_data/packages
ERROR - 2021-08-21 03:10:29 --> 404 Page Not Found: Administrator/manifests
ERROR - 2021-08-21 03:10:29 --> 404 Page Not Found: Themes/Frontend
ERROR - 2021-08-21 03:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:13:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 03:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:22:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 03:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:31:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 03:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:32:54 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-21 03:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:36:54 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-21 03:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:41:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 03:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:50:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 03:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:56:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 03:56:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 03:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:58:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 03:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 03:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 04:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-08-21 04:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:08:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 04:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:18:52 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-21 04:20:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:21:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 04:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:31:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:39:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 04:40:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 04:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 04:53:53 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-21 04:56:40 --> 404 Page Not Found: Index/login
ERROR - 2021-08-21 04:57:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 04:59:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 05:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:07:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 05:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:20:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:21:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 05:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:34:27 --> 404 Page Not Found: Vod-read-id-2226html/index
ERROR - 2021-08-21 05:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:46:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 05:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:51:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 05:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 05:59:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 06:01:15 --> 404 Page Not Found: City/1
ERROR - 2021-08-21 06:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:02:12 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-08-21 06:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:02:37 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-08-21 06:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:09:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:09:18 --> 404 Page Not Found: City/10
ERROR - 2021-08-21 06:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:09:42 --> 404 Page Not Found: City/1
ERROR - 2021-08-21 06:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:15:41 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-21 06:15:59 --> 404 Page Not Found: City/16
ERROR - 2021-08-21 06:15:59 --> 404 Page Not Found: City/index
ERROR - 2021-08-21 06:15:59 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-21 06:15:59 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-21 06:15:59 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-08-21 06:15:59 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-21 06:15:59 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-21 06:15:59 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-08-21 06:15:59 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-21 06:15:59 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-21 06:16:00 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-21 06:16:00 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-21 06:16:00 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-21 06:16:00 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-21 06:16:00 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-21 06:16:00 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-21 06:16:00 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-21 06:16:01 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-21 06:16:01 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-21 06:16:01 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-21 06:16:01 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-08-21 06:16:01 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-21 06:16:17 --> 404 Page Not Found: City/15
ERROR - 2021-08-21 06:16:25 --> 404 Page Not Found: City/2
ERROR - 2021-08-21 06:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:22:12 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-08-21 06:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:24:16 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-08-21 06:24:17 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-08-21 06:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:28:57 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-21 06:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:44:43 --> 404 Page Not Found: City/1
ERROR - 2021-08-21 06:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:45:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 06:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:53:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 06:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:56:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 06:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 06:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:04:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:14:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:14:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:14:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:14:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:17:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:22:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:28:06 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-21 07:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:30:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:30:59 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-08-21 07:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:34:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:35:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:37:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:38:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 07:38:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:39:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:39:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:40:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:40:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:44:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:47:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:47:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:48:21 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-21 07:48:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:55:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 07:55:53 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-08-21 07:56:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 07:59:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:05:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:07:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 08:07:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 08:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:09:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:13:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:14:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 08:14:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 08:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:14:09 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-21 08:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:15:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:16:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:20:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:20:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:22:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:22:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:23:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:23:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:27:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:30:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:30:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:34:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:39:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:40:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:44:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:44:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:44:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:46:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 08:46:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 08:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:36 --> 404 Page Not Found: English/index
ERROR - 2021-08-21 08:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:51:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 08:51:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 08:51:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 08:51:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 08:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:55:07 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-21 08:55:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-21 08:55:07 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-21 08:55:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-21 08:55:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-21 08:55:07 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-21 08:55:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-21 08:55:07 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-21 08:55:07 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-21 08:55:07 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-21 08:55:08 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-21 08:55:08 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-21 08:55:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-21 08:55:08 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-21 08:55:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-21 08:55:08 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-21 08:55:08 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-21 08:55:08 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-21 08:55:08 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-21 08:55:08 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-21 08:55:09 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-21 08:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:57:35 --> 404 Page Not Found: 1629507455548226823/index
ERROR - 2021-08-21 08:57:38 --> 404 Page Not Found: Magento_version/index
ERROR - 2021-08-21 08:57:44 --> 404 Page Not Found: RELEASE_NOTEStxt/index
ERROR - 2021-08-21 08:57:47 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-08-21 08:57:48 --> 404 Page Not Found: Wp-admin/index
ERROR - 2021-08-21 08:57:48 --> 404 Page Not Found: Feed/index
ERROR - 2021-08-21 08:57:49 --> 404 Page Not Found: INSTALLtxt/index
ERROR - 2021-08-21 08:57:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 08:57:50 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-08-21 08:57:50 --> 404 Page Not Found: Core/CHANGELOG.txt
ERROR - 2021-08-21 08:57:52 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 08:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:57:59 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 08:58:00 --> 404 Page Not Found: User_data/packages
ERROR - 2021-08-21 08:58:01 --> 404 Page Not Found: Administrator/manifests
ERROR - 2021-08-21 08:58:01 --> 404 Page Not Found: Themes/Frontend
ERROR - 2021-08-21 08:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 08:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:00:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:01:54 --> 404 Page Not Found: City/1
ERROR - 2021-08-21 09:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:04:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:04:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 09:04:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 09:04:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:04:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:05:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:05:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:05:17 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-08-21 09:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:06:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:07:04 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-08-21 09:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:10:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:11:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:11:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:12:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:13:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:16:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:19:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:23:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:26:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 09:26:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 09:26:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 09:26:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 09:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:28:28 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-21 09:28:44 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-21 09:29:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:29:30 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-21 09:29:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:29:44 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-21 09:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:30:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:32:33 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-21 09:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:32:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:33:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:34:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:34:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:34:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:35:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:35:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:36:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:36:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:37:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 09:37:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:39:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:39:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:41:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:44:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:46:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:47:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:48:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 09:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:53:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 09:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:55:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 09:59:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:00:28 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-08-21 10:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:08:40 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-08-21 10:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:08:50 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-08-21 10:08:50 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-08-21 10:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:11:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 10:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:14:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 10:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:15:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 10:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:20:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:20:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:20:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:20:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:20:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 10:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:26:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 10:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:27:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:29:36 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-08-21 10:29:37 --> 404 Page Not Found: Issmall/index
ERROR - 2021-08-21 10:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:29:41 --> 404 Page Not Found: Administrator/manifests
ERROR - 2021-08-21 10:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:30:17 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-08-21 10:30:17 --> 404 Page Not Found: Docs/index
ERROR - 2021-08-21 10:30:18 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-08-21 10:30:18 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-08-21 10:30:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:30:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:30:23 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-21 10:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:30:23 --> 404 Page Not Found: Tools/rss.aspx
ERROR - 2021-08-21 10:30:23 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 10:30:23 --> 404 Page Not Found: admin/Template/article_more
ERROR - 2021-08-21 10:30:24 --> 404 Page Not Found: Auth/login
ERROR - 2021-08-21 10:30:24 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-21 10:30:24 --> 404 Page Not Found: E/master
ERROR - 2021-08-21 10:30:24 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-08-21 10:30:25 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-08-21 10:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:30:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 10:30:49 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-08-21 10:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:31:01 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-08-21 10:31:01 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-21 10:31:01 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-21 10:31:02 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-21 10:31:02 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-21 10:31:02 --> 404 Page Not Found: admin/Inc/xml.xslt
ERROR - 2021-08-21 10:31:03 --> 404 Page Not Found: Feedasp/index
ERROR - 2021-08-21 10:31:04 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-08-21 10:31:04 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-08-21 10:31:05 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-21 10:31:05 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-21 10:31:05 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-08-21 10:31:05 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-08-21 10:31:11 --> 404 Page Not Found: Ntalker/lawfirm.aspx
ERROR - 2021-08-21 10:31:11 --> 404 Page Not Found: Searchhtml/index
ERROR - 2021-08-21 10:31:15 --> 404 Page Not Found: Historytxt/index
ERROR - 2021-08-21 10:31:16 --> 404 Page Not Found: Inc/Templates
ERROR - 2021-08-21 10:31:18 --> 404 Page Not Found: Addons/theme
ERROR - 2021-08-21 10:31:27 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-08-21 10:31:29 --> 404 Page Not Found: Console/include
ERROR - 2021-08-21 10:31:30 --> 404 Page Not Found: Console/auth
ERROR - 2021-08-21 10:31:39 --> 404 Page Not Found: admin/SouthidcEditor/ewebeditor.asp
ERROR - 2021-08-21 10:31:41 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-08-21 10:31:43 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-08-21 10:31:44 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-08-21 10:31:45 --> 404 Page Not Found: admin/Loginaspx/index
ERROR - 2021-08-21 10:31:46 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-08-21 10:31:49 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-08-21 10:31:50 --> 404 Page Not Found: admin/Loginasp/index
ERROR - 2021-08-21 10:31:51 --> 404 Page Not Found: Rssaspx/index
ERROR - 2021-08-21 10:31:53 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-08-21 10:31:54 --> 404 Page Not Found: Licencetxt/index
ERROR - 2021-08-21 10:31:56 --> 404 Page Not Found: Forums/list.page
ERROR - 2021-08-21 10:31:57 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-08-21 10:31:58 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-08-21 10:31:58 --> 404 Page Not Found: System/Login.aspx
ERROR - 2021-08-21 10:31:58 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-08-21 10:31:59 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 10:31:59 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 10:32:00 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 10:32:00 --> 404 Page Not Found: Admin/Common
ERROR - 2021-08-21 10:32:01 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 10:32:01 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 10:32:01 --> 404 Page Not Found: Admin/Login.aspx
ERROR - 2021-08-21 10:32:03 --> 404 Page Not Found: Help/user
ERROR - 2021-08-21 10:32:04 --> 404 Page Not Found: Themes/default
ERROR - 2021-08-21 10:32:07 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-08-21 10:32:07 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-08-21 10:32:07 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-08-21 10:32:08 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-08-21 10:32:08 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-08-21 10:32:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 10:32:11 --> 404 Page Not Found: Plus/sitemap.html
ERROR - 2021-08-21 10:32:11 --> 404 Page Not Found: Plus/rssmap.html
ERROR - 2021-08-21 10:32:12 --> 404 Page Not Found: Member/space
ERROR - 2021-08-21 10:32:12 --> 404 Page Not Found: Help/index
ERROR - 2021-08-21 10:32:12 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-08-21 10:32:12 --> 404 Page Not Found: Changelogtxt/index
ERROR - 2021-08-21 10:32:17 --> 404 Page Not Found: Jcms/index.jsp
ERROR - 2021-08-21 10:32:17 --> 404 Page Not Found: Jcms/index_jcms.jsp
ERROR - 2021-08-21 10:32:17 --> 404 Page Not Found: Api/api_user.xml
ERROR - 2021-08-21 10:32:19 --> 404 Page Not Found: M/index
ERROR - 2021-08-21 10:32:19 --> 404 Page Not Found: Template/home.htm
ERROR - 2021-08-21 10:32:21 --> 404 Page Not Found: System/skins
ERROR - 2021-08-21 10:32:21 --> 404 Page Not Found: System/language
ERROR - 2021-08-21 10:32:24 --> 404 Page Not Found: Login/Jeecms.do
ERROR - 2021-08-21 10:32:25 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 10:32:26 --> 404 Page Not Found: Plug/publish
ERROR - 2021-08-21 10:32:26 --> 404 Page Not Found: System/Update.aspx
ERROR - 2021-08-21 10:32:26 --> 404 Page Not Found: Nobody/mobile.htm
ERROR - 2021-08-21 10:32:27 --> 404 Page Not Found: Public/about.html
ERROR - 2021-08-21 10:32:27 --> 404 Page Not Found: Help/en
ERROR - 2021-08-21 10:32:27 --> 404 Page Not Found: Site/Pages
ERROR - 2021-08-21 10:32:27 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2021-08-21 10:32:28 --> 404 Page Not Found: Images/zh-CN
ERROR - 2021-08-21 10:32:28 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-21 10:32:29 --> 404 Page Not Found: Ycportal/js
ERROR - 2021-08-21 10:32:30 --> 404 Page Not Found: Datacenter/downloadApp
ERROR - 2021-08-21 10:32:30 --> 404 Page Not Found: Include/install_ocx.aspx
ERROR - 2021-08-21 10:32:31 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-08-21 10:32:32 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-21 10:32:32 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-08-21 10:32:33 --> 404 Page Not Found: Was/help.jsp
ERROR - 2021-08-21 10:32:33 --> 404 Page Not Found: Was5/web
ERROR - 2021-08-21 10:32:33 --> 404 Page Not Found: Was/main.html
ERROR - 2021-08-21 10:32:35 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-21 10:32:36 --> 404 Page Not Found: Weblog/index
ERROR - 2021-08-21 10:32:36 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-21 10:32:36 --> 404 Page Not Found: Forum/index
ERROR - 2021-08-21 10:32:36 --> 404 Page Not Found: Bbs/index
ERROR - 2021-08-21 10:32:37 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-21 10:32:37 --> 404 Page Not Found: admin/Editor/index
ERROR - 2021-08-21 10:32:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:33:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 10:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:38:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:39:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 10:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:39:47 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-08-21 10:39:47 --> 404 Page Not Found: Issmall/index
ERROR - 2021-08-21 10:39:47 --> 404 Page Not Found: Administrator/manifests
ERROR - 2021-08-21 10:39:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:39:47 --> 404 Page Not Found: Docs/index
ERROR - 2021-08-21 10:39:48 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-08-21 10:39:48 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-08-21 10:39:48 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-08-21 10:39:48 --> 404 Page Not Found: E/master
ERROR - 2021-08-21 10:39:49 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-08-21 10:39:49 --> 404 Page Not Found: Auth/login
ERROR - 2021-08-21 10:39:49 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-08-21 10:39:49 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-21 10:39:49 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 10:39:50 --> 404 Page Not Found: admin/Template/article_more
ERROR - 2021-08-21 10:39:51 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-21 10:39:51 --> 404 Page Not Found: Tools/rss.aspx
ERROR - 2021-08-21 10:39:51 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-08-21 10:39:51 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-08-21 10:39:51 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-21 10:39:51 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-21 10:39:51 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-08-21 10:39:51 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-08-21 10:39:51 --> 404 Page Not Found: Ntalker/lawfirm.aspx
ERROR - 2021-08-21 10:39:52 --> 404 Page Not Found: Searchhtml/index
ERROR - 2021-08-21 10:39:52 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-21 10:39:52 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-21 10:39:52 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-21 10:39:52 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-21 10:39:52 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-08-21 10:39:53 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-08-21 10:39:53 --> 404 Page Not Found: Feedasp/index
ERROR - 2021-08-21 10:39:53 --> 404 Page Not Found: admin/Inc/xml.xslt
ERROR - 2021-08-21 10:39:53 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-08-21 10:39:53 --> 404 Page Not Found: Console/include
ERROR - 2021-08-21 10:39:53 --> 404 Page Not Found: Console/auth
ERROR - 2021-08-21 10:39:54 --> 404 Page Not Found: Inc/Templates
ERROR - 2021-08-21 10:39:54 --> 404 Page Not Found: Historytxt/index
ERROR - 2021-08-21 10:40:00 --> 404 Page Not Found: admin/SouthidcEditor/ewebeditor.asp
ERROR - 2021-08-21 10:40:00 --> 404 Page Not Found: Addons/theme
ERROR - 2021-08-21 10:40:00 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-08-21 10:40:00 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-08-21 10:40:00 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-08-21 10:40:01 --> 404 Page Not Found: admin/Loginaspx/index
ERROR - 2021-08-21 10:40:01 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-08-21 10:40:01 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-08-21 10:40:01 --> 404 Page Not Found: admin/Loginasp/index
ERROR - 2021-08-21 10:40:01 --> 404 Page Not Found: Help/user
ERROR - 2021-08-21 10:40:01 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-08-21 10:40:01 --> 404 Page Not Found: Themes/default
ERROR - 2021-08-21 10:40:02 --> 404 Page Not Found: Licencetxt/index
ERROR - 2021-08-21 10:40:02 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-08-21 10:40:02 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-08-21 10:40:02 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-08-21 10:40:02 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-08-21 10:40:02 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-08-21 10:40:02 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-08-21 10:40:03 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 10:40:03 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 10:40:03 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 10:40:03 --> 404 Page Not Found: Admin/Common
ERROR - 2021-08-21 10:40:03 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 10:40:03 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 10:40:03 --> 404 Page Not Found: Admin/Login.aspx
ERROR - 2021-08-21 10:40:03 --> 404 Page Not Found: Forums/list.page
ERROR - 2021-08-21 10:40:03 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-08-21 10:40:03 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-08-21 10:40:04 --> 404 Page Not Found: System/Login.aspx
ERROR - 2021-08-21 10:40:04 --> 404 Page Not Found: Rssaspx/index
ERROR - 2021-08-21 10:40:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 10:40:04 --> 404 Page Not Found: Plus/sitemap.html
ERROR - 2021-08-21 10:40:04 --> 404 Page Not Found: Plus/rssmap.html
ERROR - 2021-08-21 10:40:04 --> 404 Page Not Found: Member/space
ERROR - 2021-08-21 10:40:04 --> 404 Page Not Found: Help/index
ERROR - 2021-08-21 10:40:04 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-08-21 10:40:04 --> 404 Page Not Found: Changelogtxt/index
ERROR - 2021-08-21 10:40:05 --> 404 Page Not Found: Jcms/index.jsp
ERROR - 2021-08-21 10:40:05 --> 404 Page Not Found: Jcms/index_jcms.jsp
ERROR - 2021-08-21 10:40:05 --> 404 Page Not Found: Api/api_user.xml
ERROR - 2021-08-21 10:40:05 --> 404 Page Not Found: M/index
ERROR - 2021-08-21 10:40:05 --> 404 Page Not Found: Template/home.htm
ERROR - 2021-08-21 10:40:05 --> 404 Page Not Found: System/skins
ERROR - 2021-08-21 10:40:06 --> 404 Page Not Found: System/language
ERROR - 2021-08-21 10:40:06 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 10:40:06 --> 404 Page Not Found: Plug/publish
ERROR - 2021-08-21 10:40:07 --> 404 Page Not Found: Login/Jeecms.do
ERROR - 2021-08-21 10:40:07 --> 404 Page Not Found: Site/Pages
ERROR - 2021-08-21 10:40:07 --> 404 Page Not Found: Public/about.html
ERROR - 2021-08-21 10:40:07 --> 404 Page Not Found: Help/en
ERROR - 2021-08-21 10:40:07 --> 404 Page Not Found: System/Update.aspx
ERROR - 2021-08-21 10:40:07 --> 404 Page Not Found: Nobody/mobile.htm
ERROR - 2021-08-21 10:40:07 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2021-08-21 10:40:08 --> 404 Page Not Found: Images/zh-CN
ERROR - 2021-08-21 10:40:08 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-21 10:40:08 --> 404 Page Not Found: Ycportal/js
ERROR - 2021-08-21 10:40:08 --> 404 Page Not Found: Datacenter/downloadApp
ERROR - 2021-08-21 10:40:08 --> 404 Page Not Found: Include/install_ocx.aspx
ERROR - 2021-08-21 10:40:09 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-08-21 10:40:09 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-21 10:40:09 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-08-21 10:40:09 --> 404 Page Not Found: Was/help.jsp
ERROR - 2021-08-21 10:40:09 --> 404 Page Not Found: Was5/web
ERROR - 2021-08-21 10:40:09 --> 404 Page Not Found: Was/main.html
ERROR - 2021-08-21 10:40:09 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-21 10:40:10 --> 404 Page Not Found: Weblog/index
ERROR - 2021-08-21 10:40:10 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-21 10:40:10 --> 404 Page Not Found: Forum/index
ERROR - 2021-08-21 10:40:10 --> 404 Page Not Found: Bbs/index
ERROR - 2021-08-21 10:40:10 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-21 10:40:10 --> 404 Page Not Found: admin/Editor/index
ERROR - 2021-08-21 10:40:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:43:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 10:43:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:43:47 --> 404 Page Not Found: City/index
ERROR - 2021-08-21 10:43:53 --> 404 Page Not Found: City/1
ERROR - 2021-08-21 10:44:03 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-21 10:44:10 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-21 10:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:44:29 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-21 10:44:35 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-21 10:44:42 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-21 10:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:44:49 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-08-21 10:44:54 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-21 10:44:58 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-21 10:45:04 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-21 10:45:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 10:45:11 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-21 10:45:16 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-21 10:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:45:21 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-08-21 10:45:27 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-21 10:45:32 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-21 10:45:37 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-21 10:45:51 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-21 10:46:06 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-21 10:46:10 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-21 10:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:46:17 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-21 10:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:46:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 10:46:23 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-21 10:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 10:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:05:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:06:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:06:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:07:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:12:18 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-21 11:12:18 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-21 11:12:18 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-21 11:12:18 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-21 11:12:18 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-21 11:12:18 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-21 11:12:18 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-21 11:12:18 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-21 11:12:18 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-21 11:12:19 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-21 11:12:20 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-21 11:12:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:12:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:13:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:13:12 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-21 11:13:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:13:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:18:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 11:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:19:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:19:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:19:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:19:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:19:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:25:31 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-21 11:28:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:31:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:32:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:39:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:40:11 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-08-21 11:40:19 --> 404 Page Not Found: Issmall/index
ERROR - 2021-08-21 11:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:42:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:43:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:43:56 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-08-21 11:44:17 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-08-21 11:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:44:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:44:34 --> 404 Page Not Found: Docs/index
ERROR - 2021-08-21 11:44:37 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-08-21 11:44:50 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-08-21 11:44:50 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-08-21 11:44:51 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-08-21 11:44:51 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-21 11:44:51 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-21 11:44:51 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 11:44:52 --> 404 Page Not Found: admin/Template/article_more
ERROR - 2021-08-21 11:44:52 --> 404 Page Not Found: Auth/login
ERROR - 2021-08-21 11:44:52 --> 404 Page Not Found: E/master
ERROR - 2021-08-21 11:44:52 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-08-21 11:44:56 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-21 11:44:56 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-08-21 11:44:57 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-08-21 11:44:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:45:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:45:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:45:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:45:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 11:45:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:45:37 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-21 11:45:40 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-21 11:45:41 --> 404 Page Not Found: admin/Inc/xml.xslt
ERROR - 2021-08-21 11:45:41 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-21 11:45:43 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-21 11:45:43 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-08-21 11:45:43 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-08-21 11:46:07 --> 404 Page Not Found: admin/SouthidcEditor/ewebeditor.asp
ERROR - 2021-08-21 11:46:09 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-08-21 11:46:13 --> 404 Page Not Found: Console/include
ERROR - 2021-08-21 11:46:14 --> 404 Page Not Found: Console/auth
ERROR - 2021-08-21 11:46:14 --> 404 Page Not Found: Addons/theme
ERROR - 2021-08-21 11:46:24 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-08-21 11:46:25 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-08-21 11:46:25 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-08-21 11:46:26 --> 404 Page Not Found: admin/Loginaspx/index
ERROR - 2021-08-21 11:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:46:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:47:16 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-08-21 11:47:18 --> 404 Page Not Found: admin/Loginasp/index
ERROR - 2021-08-21 11:47:20 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-08-21 11:47:20 --> 404 Page Not Found: Help/user
ERROR - 2021-08-21 11:47:20 --> 404 Page Not Found: Themes/default
ERROR - 2021-08-21 11:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:47:23 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-08-21 11:47:24 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-08-21 11:47:25 --> 404 Page Not Found: System/Login.aspx
ERROR - 2021-08-21 11:47:25 --> 404 Page Not Found: Forums/list.page
ERROR - 2021-08-21 11:47:28 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-08-21 11:47:28 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-08-21 11:47:29 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-08-21 11:47:30 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-08-21 11:47:33 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-08-21 11:47:33 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-08-21 11:47:33 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 11:47:35 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 11:47:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:47:39 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 11:47:39 --> 404 Page Not Found: Admin/Common
ERROR - 2021-08-21 11:47:39 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 11:47:40 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 11:47:40 --> 404 Page Not Found: Admin/Login.aspx
ERROR - 2021-08-21 11:47:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:48:20 --> 404 Page Not Found: Licencetxt/index
ERROR - 2021-08-21 11:48:21 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-08-21 11:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:48:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 11:49:08 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-21 11:49:09 --> 404 Page Not Found: Tools/rss.aspx
ERROR - 2021-08-21 11:49:10 --> 404 Page Not Found: Ntalker/lawfirm.aspx
ERROR - 2021-08-21 11:49:10 --> 404 Page Not Found: Searchhtml/index
ERROR - 2021-08-21 11:49:10 --> 404 Page Not Found: Feedasp/index
ERROR - 2021-08-21 11:49:11 --> 404 Page Not Found: Jcms/index.jsp
ERROR - 2021-08-21 11:49:12 --> 404 Page Not Found: Jcms/index_jcms.jsp
ERROR - 2021-08-21 11:49:12 --> 404 Page Not Found: Historytxt/index
ERROR - 2021-08-21 11:49:12 --> 404 Page Not Found: Inc/Templates
ERROR - 2021-08-21 11:49:14 --> 404 Page Not Found: Api/api_user.xml
ERROR - 2021-08-21 11:49:21 --> 404 Page Not Found: Template/home.htm
ERROR - 2021-08-21 11:49:26 --> 404 Page Not Found: System/skins
ERROR - 2021-08-21 11:49:26 --> 404 Page Not Found: System/language
ERROR - 2021-08-21 11:49:30 --> 404 Page Not Found: Datacenter/downloadApp
ERROR - 2021-08-21 11:49:35 --> 404 Page Not Found: Rssaspx/index
ERROR - 2021-08-21 11:49:43 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 11:49:43 --> 404 Page Not Found: Plug/publish
ERROR - 2021-08-21 11:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:49:43 --> 404 Page Not Found: Public/about.html
ERROR - 2021-08-21 11:49:52 --> 404 Page Not Found: Help/en
ERROR - 2021-08-21 11:49:52 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2021-08-21 11:49:52 --> 404 Page Not Found: Images/zh-CN
ERROR - 2021-08-21 11:49:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 11:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:50:05 --> 404 Page Not Found: Plus/sitemap.html
ERROR - 2021-08-21 11:50:05 --> 404 Page Not Found: Plus/rssmap.html
ERROR - 2021-08-21 11:50:07 --> 404 Page Not Found: Member/space
ERROR - 2021-08-21 11:50:08 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-08-21 11:50:10 --> 404 Page Not Found: Changelogtxt/index
ERROR - 2021-08-21 11:50:12 --> 404 Page Not Found: Help/index
ERROR - 2021-08-21 11:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:50:16 --> 404 Page Not Found: M/index
ERROR - 2021-08-21 11:50:19 --> 404 Page Not Found: Ycportal/js
ERROR - 2021-08-21 11:50:24 --> 404 Page Not Found: Login/Jeecms.do
ERROR - 2021-08-21 11:50:24 --> 404 Page Not Found: Include/install_ocx.aspx
ERROR - 2021-08-21 11:50:27 --> 404 Page Not Found: System/Update.aspx
ERROR - 2021-08-21 11:50:35 --> 404 Page Not Found: Site/Pages
ERROR - 2021-08-21 11:50:35 --> 404 Page Not Found: Nobody/mobile.htm
ERROR - 2021-08-21 11:50:42 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-21 11:50:48 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-08-21 11:50:49 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-21 11:50:54 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-08-21 11:50:59 --> 404 Page Not Found: Was/help.jsp
ERROR - 2021-08-21 11:51:03 --> 404 Page Not Found: Was5/web
ERROR - 2021-08-21 11:51:03 --> 404 Page Not Found: Was/main.html
ERROR - 2021-08-21 11:51:20 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-21 11:51:21 --> 404 Page Not Found: Weblog/index
ERROR - 2021-08-21 11:51:21 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-21 11:51:21 --> 404 Page Not Found: Forum/index
ERROR - 2021-08-21 11:51:27 --> 404 Page Not Found: Bbs/index
ERROR - 2021-08-21 11:51:29 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-21 11:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:51:38 --> 404 Page Not Found: admin/Editor/index
ERROR - 2021-08-21 11:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:54:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 11:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:56:28 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-21 11:56:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 11:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 11:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:00:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:00:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 12:00:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 12:00:55 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-21 12:00:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 12:01:07 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-21 12:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:08:40 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-21 12:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:13:14 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-08-21 12:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:15:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:15:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 12:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:17:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 12:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 12:19:02 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-21 12:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:29:30 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-21 12:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:32:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 12:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:33:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 12:33:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 12:33:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 12:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:35:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 12:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:35:59 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-21 12:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:45:30 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-21 12:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:46:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:47:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:49:51 --> 404 Page Not Found: SiteServer/Ajax
ERROR - 2021-08-21 12:49:51 --> 404 Page Not Found: SiteFiles/SiteTemplates
ERROR - 2021-08-21 12:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:54:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 12:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 12:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:01:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 13:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:02:11 --> 404 Page Not Found: English/index
ERROR - 2021-08-21 13:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:03:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 13:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:06:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 13:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:08:00 --> 404 Page Not Found: 404/index.html
ERROR - 2021-08-21 13:08:00 --> 404 Page Not Found: 404/index.html
ERROR - 2021-08-21 13:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:08:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 13:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:18:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:18:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:18:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:18:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:18:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:19:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:19:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:19:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:19:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 13:20:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 13:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:20:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 13:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:27:24 --> 404 Page Not Found: Backup/index
ERROR - 2021-08-21 13:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:27:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 13:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:28:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 13:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:30:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 13:31:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 13:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:36:13 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-21 13:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:38:56 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-21 13:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:44:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 13:44:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 13:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:56:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 13:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 13:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:11:41 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-08-21 14:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:14:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 14:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:22:50 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-21 14:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:25:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 14:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:29:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:30:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 14:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:33:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 14:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:36:02 --> 404 Page Not Found: H5/index
ERROR - 2021-08-21 14:36:02 --> 404 Page Not Found: Xy/index
ERROR - 2021-08-21 14:36:02 --> 404 Page Not Found: Otc/index
ERROR - 2021-08-21 14:36:02 --> 404 Page Not Found: Im/index
ERROR - 2021-08-21 14:36:02 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 14:36:02 --> 404 Page Not Found: Homes/index
ERROR - 2021-08-21 14:36:02 --> 404 Page Not Found: Loan/index
ERROR - 2021-08-21 14:36:02 --> 404 Page Not Found: Im/h5
ERROR - 2021-08-21 14:36:04 --> 404 Page Not Found: Step1asp/index
ERROR - 2021-08-21 14:36:04 --> 404 Page Not Found: Site/info
ERROR - 2021-08-21 14:36:05 --> 404 Page Not Found: M/index
ERROR - 2021-08-21 14:36:06 --> 404 Page Not Found: H5/index
ERROR - 2021-08-21 14:36:08 --> 404 Page Not Found: Api/apps
ERROR - 2021-08-21 14:36:09 --> 404 Page Not Found: Mh/phone.do
ERROR - 2021-08-21 14:36:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 14:36:11 --> 404 Page Not Found: Js/a.script
ERROR - 2021-08-21 14:36:12 --> 404 Page Not Found: M/allticker
ERROR - 2021-08-21 14:36:13 --> 404 Page Not Found: FePublicInfo/index
ERROR - 2021-08-21 14:36:13 --> 404 Page Not Found: Api/linkPF
ERROR - 2021-08-21 14:36:13 --> 404 Page Not Found: Im/in
ERROR - 2021-08-21 14:36:13 --> 404 Page Not Found: Apis/api
ERROR - 2021-08-21 14:36:13 --> 404 Page Not Found: Sign/index
ERROR - 2021-08-21 14:36:13 --> 404 Page Not Found: Api/contactWay
ERROR - 2021-08-21 14:36:13 --> 404 Page Not Found: Proxy/settings
ERROR - 2021-08-21 14:36:13 --> 404 Page Not Found: M/ticker
ERROR - 2021-08-21 14:36:15 --> 404 Page Not Found: Bannerdo/index
ERROR - 2021-08-21 14:36:15 --> 404 Page Not Found: Verificationasp/index
ERROR - 2021-08-21 14:36:15 --> 404 Page Not Found: User/allroleinfo
ERROR - 2021-08-21 14:36:15 --> 404 Page Not Found: Index/api
ERROR - 2021-08-21 14:36:17 --> 404 Page Not Found: User/userlist
ERROR - 2021-08-21 14:36:17 --> 404 Page Not Found: Home/Bind
ERROR - 2021-08-21 14:36:19 --> 404 Page Not Found: Anquan/qgga.asp
ERROR - 2021-08-21 14:36:19 --> 404 Page Not Found: Home/Get
ERROR - 2021-08-21 14:36:20 --> 404 Page Not Found: Web/api
ERROR - 2021-08-21 14:36:20 --> 404 Page Not Found: Appxz/index.html
ERROR - 2021-08-21 14:36:20 --> 404 Page Not Found: Mytio/config
ERROR - 2021-08-21 14:36:20 --> 404 Page Not Found: Legal/currency
ERROR - 2021-08-21 14:36:21 --> 404 Page Not Found: Api/content_bottom
ERROR - 2021-08-21 14:36:21 --> 404 Page Not Found: Pc/Lang
ERROR - 2021-08-21 14:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:36:24 --> 404 Page Not Found: Home/GetInitSource
ERROR - 2021-08-21 14:36:25 --> 404 Page Not Found: Index/index
ERROR - 2021-08-21 14:36:25 --> 404 Page Not Found: Api/index
ERROR - 2021-08-21 14:36:25 --> 404 Page Not Found: Api/site
ERROR - 2021-08-21 14:36:25 --> 404 Page Not Found: Promotions/list.mvc
ERROR - 2021-08-21 14:36:25 --> 404 Page Not Found: Api/message
ERROR - 2021-08-21 14:36:26 --> 404 Page Not Found: Content/favicon.ico
ERROR - 2021-08-21 14:36:26 --> 404 Page Not Found: Api/index
ERROR - 2021-08-21 14:36:26 --> 404 Page Not Found: Recruit/download_url
ERROR - 2021-08-21 14:36:26 --> 404 Page Not Found: Home/GetQrCodeInfo
ERROR - 2021-08-21 14:36:26 --> 404 Page Not Found: Room/getRoomBangFans
ERROR - 2021-08-21 14:36:27 --> 404 Page Not Found: Api/v1
ERROR - 2021-08-21 14:36:29 --> 404 Page Not Found: Api/index
ERROR - 2021-08-21 14:36:29 --> 404 Page Not Found: Api/common
ERROR - 2021-08-21 14:36:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 14:36:30 --> 404 Page Not Found: Api/ApiHub
ERROR - 2021-08-21 14:36:30 --> 404 Page Not Found: CscpLoginWeb/app
ERROR - 2021-08-21 14:36:30 --> 404 Page Not Found: Api/user
ERROR - 2021-08-21 14:36:31 --> 404 Page Not Found: Api/Index
ERROR - 2021-08-21 14:36:31 --> 404 Page Not Found: Xianyu/index
ERROR - 2021-08-21 14:36:31 --> 404 Page Not Found: Home/GetAllGameCategory
ERROR - 2021-08-21 14:36:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 14:36:34 --> 404 Page Not Found: Data/json
ERROR - 2021-08-21 14:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 14:36:40 --> 404 Page Not Found: Ajax/index
ERROR - 2021-08-21 14:36:41 --> 404 Page Not Found: Static/mobile
ERROR - 2021-08-21 14:36:41 --> 404 Page Not Found: Api/customerServiceLink
ERROR - 2021-08-21 14:36:41 --> 404 Page Not Found: Client/api
ERROR - 2021-08-21 14:36:41 --> 404 Page Not Found: S_api/basic
ERROR - 2021-08-21 14:36:42 --> 404 Page Not Found: Api/user
ERROR - 2021-08-21 14:36:42 --> 404 Page Not Found: Iframe/rankgiftgotapi
ERROR - 2021-08-21 14:36:43 --> 404 Page Not Found: Api/currency
ERROR - 2021-08-21 14:36:45 --> 404 Page Not Found: N/news
ERROR - 2021-08-21 14:36:46 --> 404 Page Not Found: Home/login
ERROR - 2021-08-21 14:36:47 --> 404 Page Not Found: Market/market-ws
ERROR - 2021-08-21 14:36:47 --> 404 Page Not Found: Static/data
ERROR - 2021-08-21 14:36:47 --> 404 Page Not Found: Mobile/v3
ERROR - 2021-08-21 14:36:47 --> 404 Page Not Found: Wap/trading
ERROR - 2021-08-21 14:36:47 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-08-21 14:36:49 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-08-21 14:36:49 --> 404 Page Not Found: Api/mobile
ERROR - 2021-08-21 14:36:49 --> 404 Page Not Found: Stock/search.html
ERROR - 2021-08-21 14:36:49 --> 404 Page Not Found: Wap/trading
ERROR - 2021-08-21 14:36:49 --> 404 Page Not Found: Infe/rest
ERROR - 2021-08-21 14:36:50 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-08-21 14:36:50 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-08-21 14:36:50 --> 404 Page Not Found: Api/public
ERROR - 2021-08-21 14:36:50 --> 404 Page Not Found: V1/management
ERROR - 2021-08-21 14:36:52 --> 404 Page Not Found: Site/get-hq
ERROR - 2021-08-21 14:36:52 --> 404 Page Not Found: Ws/index
ERROR - 2021-08-21 14:36:52 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-08-21 14:36:52 --> 404 Page Not Found: Wap/Api
ERROR - 2021-08-21 14:36:52 --> 404 Page Not Found: Api/stock
ERROR - 2021-08-21 14:36:53 --> 404 Page Not Found: Ajax/allcoin_a
ERROR - 2021-08-21 14:36:55 --> 404 Page Not Found: S_api/basic
ERROR - 2021-08-21 14:36:55 --> 404 Page Not Found: Static/local
ERROR - 2021-08-21 14:36:55 --> 404 Page Not Found: Infe/rest
ERROR - 2021-08-21 14:36:56 --> 404 Page Not Found: Api/exclude
ERROR - 2021-08-21 14:36:56 --> 404 Page Not Found: Client/api
ERROR - 2021-08-21 14:36:56 --> 404 Page Not Found: Json/configs
ERROR - 2021-08-21 14:36:57 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-08-21 14:36:57 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-08-21 14:36:57 --> 404 Page Not Found: Api/product
ERROR - 2021-08-21 14:36:58 --> 404 Page Not Found: Api/uploads
ERROR - 2021-08-21 14:36:58 --> 404 Page Not Found: Api/wallet
ERROR - 2021-08-21 14:36:58 --> 404 Page Not Found: Api/v1
ERROR - 2021-08-21 14:36:58 --> 404 Page Not Found: Wap/Api
ERROR - 2021-08-21 14:36:58 --> 404 Page Not Found: FriendGroup/list
ERROR - 2021-08-21 14:36:58 --> 404 Page Not Found: Api/config-init
ERROR - 2021-08-21 14:37:00 --> 404 Page Not Found: Api/v
ERROR - 2021-08-21 14:37:00 --> 404 Page Not Found: Base/exchange_article
ERROR - 2021-08-21 14:37:03 --> 404 Page Not Found: Api/uploads
ERROR - 2021-08-21 14:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:39:18 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-21 14:40:05 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-21 14:40:09 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-08-21 14:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:43:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 14:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:44:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 14:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:47:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 14:54:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 14:56:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 14:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 14:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 14:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:07:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:11:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:12:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:12:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:12:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:12:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:12:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:12:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:12:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:16:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:17:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:18:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:22:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:24:12 --> 404 Page Not Found: City/16
ERROR - 2021-08-21 15:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:29:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:34:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:39:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:40:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:41:52 --> 404 Page Not Found: Article/view
ERROR - 2021-08-21 15:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:46:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 15:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:47:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:52:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:53:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 15:53:11 --> 404 Page Not Found: Haoma/index
ERROR - 2021-08-21 15:53:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:54:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 15:56:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 15:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:56:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 15:56:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:57:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 15:58:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 15:58:26 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:26 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:58:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:58:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:59:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:59:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:59:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:59:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:59:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:59:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 15:59:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 15:59:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-21 16:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:03:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 16:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:08:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 16:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:11:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 16:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:12:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 16:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:21:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:26:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 16:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:28:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 16:29:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 16:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:29:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 16:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:40:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 16:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:53:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:55:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 16:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:56:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 16:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 16:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:04:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 17:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 17:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:14:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 17:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:16:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 17:16:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 17:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 17:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:19:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 17:19:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 17:20:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:42:26 --> 404 Page Not Found: Article/view
ERROR - 2021-08-21 17:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:44:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:45:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 17:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:48:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 17:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:49:58 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-21 17:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:49:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 17:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:50:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 17:51:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 17:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:54:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-21 17:55:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-21 17:55:14 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-21 17:55:15 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-21 17:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 17:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:00:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 18:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:02:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 18:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:10:34 --> 404 Page Not Found: City/index
ERROR - 2021-08-21 18:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:13:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:18:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 18:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:25:11 --> 404 Page Not Found: Wp-includes/index
ERROR - 2021-08-21 18:27:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:30:34 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-21 18:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:35:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:36:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 18:36:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:36:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:36:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:37:10 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-21 18:37:10 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-21 18:37:10 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-21 18:37:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:38:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:38:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:40:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:40:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:40:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:40:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:41:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:41:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:42:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:42:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:44:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:45:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:46:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:46:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:48:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:49:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:50:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:50:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:50:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:50:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:50:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:50:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:51:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:51:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:52:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:53:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:54:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:55:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:56:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 18:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 18:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:00:31 --> 404 Page Not Found: English/index
ERROR - 2021-08-21 19:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:02:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:02:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:02:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:03:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:07:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:07:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:07:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:20:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:20:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:20:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:22:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:22:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:22:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:23:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:23:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:23:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:23:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:23:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:24:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:28:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:28:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:28:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:29:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:29:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:29:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:29:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:30:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:30:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:30:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:30:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:30:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:30:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:30:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:30:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:35:31 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-21 19:36:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:36:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 19:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:39:16 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-21 19:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:50:28 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-08-21 19:50:30 --> 404 Page Not Found: Issmall/index
ERROR - 2021-08-21 19:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:51:24 --> 404 Page Not Found: Administrator/manifests
ERROR - 2021-08-21 19:51:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:51:30 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-08-21 19:51:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:51:32 --> 404 Page Not Found: Issmall/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Administrator/manifests
ERROR - 2021-08-21 19:52:26 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Docs/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-21 19:52:27 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-21 19:52:28 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-21 19:52:28 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-21 19:52:28 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-08-21 19:52:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 19:52:38 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-08-21 19:52:38 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 19:52:38 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-08-21 19:52:39 --> 404 Page Not Found: admin/Template/article_more
ERROR - 2021-08-21 19:52:39 --> 404 Page Not Found: Auth/login
ERROR - 2021-08-21 19:52:39 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-21 19:52:39 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-08-21 19:52:40 --> 404 Page Not Found: E/master
ERROR - 2021-08-21 19:52:40 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-08-21 19:52:40 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-08-21 19:52:40 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-08-21 19:52:40 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-08-21 19:52:40 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-21 19:52:41 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-21 19:52:47 --> 404 Page Not Found: Docs/index
ERROR - 2021-08-21 19:52:51 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-08-21 19:52:56 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-08-21 19:52:56 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-08-21 19:52:56 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-21 19:52:57 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-08-21 19:53:00 --> 404 Page Not Found: E/master
ERROR - 2021-08-21 19:53:00 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-21 19:53:00 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-08-21 19:53:05 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-21 19:53:05 --> 404 Page Not Found: Auth/login
ERROR - 2021-08-21 19:53:05 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-08-21 19:53:05 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 19:53:05 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-08-21 19:53:05 --> 404 Page Not Found: admin/Inc/xml.xslt
ERROR - 2021-08-21 19:53:05 --> 404 Page Not Found: admin/Template/article_more
ERROR - 2021-08-21 19:53:05 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-08-21 19:53:05 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-21 19:53:06 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-08-21 19:53:07 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-08-21 19:53:07 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-08-21 19:53:07 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-21 19:53:09 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-21 19:53:11 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-08-21 19:53:11 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-08-21 19:53:13 --> 404 Page Not Found: admin/Inc/xml.xslt
ERROR - 2021-08-21 19:53:22 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-08-21 19:53:22 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-21 19:53:22 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-08-21 19:53:22 --> 404 Page Not Found: Console/include
ERROR - 2021-08-21 19:53:23 --> 404 Page Not Found: Console/auth
ERROR - 2021-08-21 19:53:27 --> 404 Page Not Found: Addons/theme
ERROR - 2021-08-21 19:53:29 --> 404 Page Not Found: admin/SouthidcEditor/ewebeditor.asp
ERROR - 2021-08-21 19:53:29 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-08-21 19:53:30 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-08-21 19:53:41 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-21 19:53:45 --> 404 Page Not Found: Ids/admin
ERROR - 2021-08-21 19:53:46 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-08-21 19:53:47 --> 404 Page Not Found: Console/include
ERROR - 2021-08-21 19:53:48 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-08-21 19:53:48 --> 404 Page Not Found: Console/auth
ERROR - 2021-08-21 19:53:51 --> 404 Page Not Found: admin/Loginasp/index
ERROR - 2021-08-21 19:53:52 --> 404 Page Not Found: admin/Loginaspx/index
ERROR - 2021-08-21 19:53:52 --> 404 Page Not Found: Addons/theme
ERROR - 2021-08-21 19:53:52 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-08-21 19:53:53 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-08-21 19:53:59 --> 404 Page Not Found: admin/SouthidcEditor/ewebeditor.asp
ERROR - 2021-08-21 19:53:59 --> 404 Page Not Found: Forums/list.page
ERROR - 2021-08-21 19:54:01 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-08-21 19:54:01 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-08-21 19:54:01 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-08-21 19:54:01 --> 404 Page Not Found: System/Login.aspx
ERROR - 2021-08-21 19:54:03 --> 404 Page Not Found: Licencetxt/index
ERROR - 2021-08-21 19:54:04 --> 404 Page Not Found: Themes/default
ERROR - 2021-08-21 19:54:05 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-08-21 19:54:06 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-08-21 19:54:06 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-08-21 19:54:06 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 19:54:07 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 19:54:07 --> 404 Page Not Found: admin/Loginasp/index
ERROR - 2021-08-21 19:54:07 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 19:54:10 --> 404 Page Not Found: Admin/Common
ERROR - 2021-08-21 19:54:10 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 19:54:13 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 19:54:14 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-08-21 19:54:14 --> 404 Page Not Found: Admin/Login.aspx
ERROR - 2021-08-21 19:54:21 --> 404 Page Not Found: admin/Loginaspx/index
ERROR - 2021-08-21 19:54:21 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-08-21 19:54:21 --> 404 Page Not Found: Licencetxt/index
ERROR - 2021-08-21 19:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:54:24 --> 404 Page Not Found: Themes/default
ERROR - 2021-08-21 19:54:24 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-08-21 19:54:24 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-08-21 19:54:25 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-08-21 19:54:25 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-08-21 19:54:25 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-08-21 19:54:26 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-08-21 19:54:27 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-08-21 19:54:27 --> 404 Page Not Found: Help/user
ERROR - 2021-08-21 19:54:27 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-08-21 19:54:27 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-08-21 19:54:30 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-08-21 19:54:30 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-08-21 19:54:31 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-21 19:54:31 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-08-21 19:54:31 --> 404 Page Not Found: Tools/rss.aspx
ERROR - 2021-08-21 19:54:31 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-08-21 19:54:31 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 19:54:31 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 19:54:32 --> 404 Page Not Found: Ntalker/lawfirm.aspx
ERROR - 2021-08-21 19:54:32 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 19:54:32 --> 404 Page Not Found: Searchhtml/index
ERROR - 2021-08-21 19:54:32 --> 404 Page Not Found: Admin/Common
ERROR - 2021-08-21 19:54:33 --> 404 Page Not Found: Feedasp/index
ERROR - 2021-08-21 19:54:33 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 19:54:33 --> 404 Page Not Found: API/DW
ERROR - 2021-08-21 19:54:33 --> 404 Page Not Found: Admin/Login.aspx
ERROR - 2021-08-21 19:54:33 --> 404 Page Not Found: Inc/Templates
ERROR - 2021-08-21 19:54:34 --> 404 Page Not Found: Historytxt/index
ERROR - 2021-08-21 19:54:37 --> 404 Page Not Found: Jcms/index.jsp
ERROR - 2021-08-21 19:54:37 --> 404 Page Not Found: Jcms/index_jcms.jsp
ERROR - 2021-08-21 19:54:41 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-08-21 19:54:41 --> 404 Page Not Found: Api/api_user.xml
ERROR - 2021-08-21 19:54:43 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-08-21 19:54:49 --> 404 Page Not Found: System/Login.aspx
ERROR - 2021-08-21 19:54:49 --> 404 Page Not Found: Help/user
ERROR - 2021-08-21 19:54:49 --> 404 Page Not Found: Template/home.htm
ERROR - 2021-08-21 19:54:49 --> 404 Page Not Found: Forums/list.page
ERROR - 2021-08-21 19:54:49 --> 404 Page Not Found: System/skins
ERROR - 2021-08-21 19:54:49 --> 404 Page Not Found: System/language
ERROR - 2021-08-21 19:54:50 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-21 19:54:52 --> 404 Page Not Found: Tools/rss.aspx
ERROR - 2021-08-21 19:54:52 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 19:54:52 --> 404 Page Not Found: Plug/publish
ERROR - 2021-08-21 19:54:52 --> 404 Page Not Found: Feedasp/index
ERROR - 2021-08-21 19:54:52 --> 404 Page Not Found: Ntalker/lawfirm.aspx
ERROR - 2021-08-21 19:54:52 --> 404 Page Not Found: Rssaspx/index
ERROR - 2021-08-21 19:54:52 --> 404 Page Not Found: Searchhtml/index
ERROR - 2021-08-21 19:54:54 --> 404 Page Not Found: Jcms/index.jsp
ERROR - 2021-08-21 19:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:54:57 --> 404 Page Not Found: Datacenter/downloadApp
ERROR - 2021-08-21 19:54:57 --> 404 Page Not Found: Jcms/index_jcms.jsp
ERROR - 2021-08-21 19:55:00 --> 404 Page Not Found: Inc/Templates
ERROR - 2021-08-21 19:55:00 --> 404 Page Not Found: Public/about.html
ERROR - 2021-08-21 19:55:00 --> 404 Page Not Found: Historytxt/index
ERROR - 2021-08-21 19:55:01 --> 404 Page Not Found: Help/en
ERROR - 2021-08-21 19:55:01 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2021-08-21 19:55:03 --> 404 Page Not Found: Api/api_user.xml
ERROR - 2021-08-21 19:55:06 --> 404 Page Not Found: Images/zh-CN
ERROR - 2021-08-21 19:55:06 --> 404 Page Not Found: Template/home.htm
ERROR - 2021-08-21 19:55:07 --> 404 Page Not Found: System/skins
ERROR - 2021-08-21 19:55:07 --> 404 Page Not Found: System/language
ERROR - 2021-08-21 19:55:09 --> 404 Page Not Found: admin//index
ERROR - 2021-08-21 19:55:09 --> 404 Page Not Found: Plug/publish
ERROR - 2021-08-21 19:55:10 --> 404 Page Not Found: Rssaspx/index
ERROR - 2021-08-21 19:55:13 --> 404 Page Not Found: Datacenter/downloadApp
ERROR - 2021-08-21 19:55:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 19:55:25 --> 404 Page Not Found: Plus/sitemap.html
ERROR - 2021-08-21 19:55:25 --> 404 Page Not Found: Public/about.html
ERROR - 2021-08-21 19:55:25 --> 404 Page Not Found: Plus/rssmap.html
ERROR - 2021-08-21 19:55:25 --> 404 Page Not Found: Help/en
ERROR - 2021-08-21 19:55:25 --> 404 Page Not Found: Member/space
ERROR - 2021-08-21 19:55:26 --> 404 Page Not Found: Help/index
ERROR - 2021-08-21 19:55:26 --> 404 Page Not Found: Images/zh-CN
ERROR - 2021-08-21 19:55:27 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2021-08-21 19:55:27 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-08-21 19:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:55:27 --> 404 Page Not Found: Changelogtxt/index
ERROR - 2021-08-21 19:55:27 --> 404 Page Not Found: M/index
ERROR - 2021-08-21 19:55:28 --> 404 Page Not Found: Ycportal/js
ERROR - 2021-08-21 19:55:29 --> 404 Page Not Found: Login/Jeecms.do
ERROR - 2021-08-21 19:55:29 --> 404 Page Not Found: Include/install_ocx.aspx
ERROR - 2021-08-21 19:55:29 --> 404 Page Not Found: System/Update.aspx
ERROR - 2021-08-21 19:55:30 --> 404 Page Not Found: Site/Pages
ERROR - 2021-08-21 19:55:31 --> 404 Page Not Found: Nobody/mobile.htm
ERROR - 2021-08-21 19:55:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-21 19:55:37 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-21 19:55:39 --> 404 Page Not Found: Plus/sitemap.html
ERROR - 2021-08-21 19:55:39 --> 404 Page Not Found: Plus/rssmap.html
ERROR - 2021-08-21 19:55:41 --> 404 Page Not Found: Member/space
ERROR - 2021-08-21 19:55:41 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-08-21 19:55:41 --> 404 Page Not Found: Changelogtxt/index
ERROR - 2021-08-21 19:55:42 --> 404 Page Not Found: Help/index
ERROR - 2021-08-21 19:55:43 --> 404 Page Not Found: M/index
ERROR - 2021-08-21 19:55:46 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-08-21 19:55:46 --> 404 Page Not Found: Ycportal/js
ERROR - 2021-08-21 19:55:47 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-21 19:55:51 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-08-21 19:55:51 --> 404 Page Not Found: Include/install_ocx.aspx
ERROR - 2021-08-21 19:55:51 --> 404 Page Not Found: Login/Jeecms.do
ERROR - 2021-08-21 19:55:51 --> 404 Page Not Found: Was/help.jsp
ERROR - 2021-08-21 19:55:51 --> 404 Page Not Found: System/Update.aspx
ERROR - 2021-08-21 19:55:51 --> 404 Page Not Found: Nobody/mobile.htm
ERROR - 2021-08-21 19:55:51 --> 404 Page Not Found: Was5/web
ERROR - 2021-08-21 19:55:51 --> 404 Page Not Found: Site/Pages
ERROR - 2021-08-21 19:55:51 --> 404 Page Not Found: Was/main.html
ERROR - 2021-08-21 19:56:04 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-21 19:56:05 --> 404 Page Not Found: Archiver/index
ERROR - 2021-08-21 19:56:05 --> 404 Page Not Found: Weblog/index
ERROR - 2021-08-21 19:56:05 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-21 19:56:05 --> 404 Page Not Found: Forum/index
ERROR - 2021-08-21 19:56:05 --> 404 Page Not Found: Bbs/index
ERROR - 2021-08-21 19:56:07 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-21 19:56:07 --> 404 Page Not Found: admin/Editor/index
ERROR - 2021-08-21 19:56:08 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-08-21 19:56:09 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-21 19:56:09 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-08-21 19:56:09 --> 404 Page Not Found: Was/help.jsp
ERROR - 2021-08-21 19:56:09 --> 404 Page Not Found: Was5/web
ERROR - 2021-08-21 19:56:10 --> 404 Page Not Found: Was/main.html
ERROR - 2021-08-21 19:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:56:15 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-21 19:56:15 --> 404 Page Not Found: Weblog/index
ERROR - 2021-08-21 19:56:15 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-21 19:56:15 --> 404 Page Not Found: Forum/index
ERROR - 2021-08-21 19:56:15 --> 404 Page Not Found: Bbs/index
ERROR - 2021-08-21 19:56:15 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-21 19:56:16 --> 404 Page Not Found: admin/Editor/index
ERROR - 2021-08-21 19:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:59:38 --> 404 Page Not Found: Login/index
ERROR - 2021-08-21 19:59:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 19:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:16:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 20:16:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 20:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:19:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:21:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:24:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 20:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:29:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:29:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:29:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:29:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:29:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:29:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:29:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:29:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:29:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:29:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:30:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:30:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:30:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:30:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:30:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:30:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:30:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:30:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:30:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:30:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:30:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:31:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:32:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:33:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:33:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 20:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:43:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 20:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:45:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 20:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:46:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 20:48:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 20:48:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 20:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:50:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 20:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:50:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 20:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:51:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 20:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:51:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 20:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 20:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:04:03 --> 404 Page Not Found: English/index
ERROR - 2021-08-21 21:05:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:05:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:05:55 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-21 21:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:06:59 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-08-21 21:06:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:07:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:07:08 --> 404 Page Not Found: CurrentTime/index
ERROR - 2021-08-21 21:07:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:07:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:07:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:07:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:08:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:10:37 --> 404 Page Not Found: Article/view
ERROR - 2021-08-21 21:10:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 21:10:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:11:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 21:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:14:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:15:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:16:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:21:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 21:21:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 21:21:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 21:21:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 21:21:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 21:21:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 21:21:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 21:21:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 21:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:24:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 21:24:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:27:39 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-08-21 21:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:29:05 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-21 21:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 21:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:30:30 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-08-21 21:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:42:39 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-21 21:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:44:10 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-21 21:44:16 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-08-21 21:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:44:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:48:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 21:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:54:09 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-21 21:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 21:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:02:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:06:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 22:07:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 22:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:09:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 22:09:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 22:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:10:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:10:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 22:10:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-21 22:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:11:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:15:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:20:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:21:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:29:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:33:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:33:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 22:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:33:53 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-21 22:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:38:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:38:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:39:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:43:27 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-21 22:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:44:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 22:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:50:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:51:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:51:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:52:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:52:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:52:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:53:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:53:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:54:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:54:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:55:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:56:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:57:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:57:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 22:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:57:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:57:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:58:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 22:59:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 22:59:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 22:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:00:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:00:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:02:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:02:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 23:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:03:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:03:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:04:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 23:04:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:04:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:04:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 23:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:05:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:06:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:07:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:07:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:08:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:09:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:09:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 23:09:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 23:09:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 23:10:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 23:10:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:10:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 23:11:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 23:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:12:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:12:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:13:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:14:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:14:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:15:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 23:15:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 23:15:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-21 23:15:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:15:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:16:11 --> 404 Page Not Found: Vod-play-id-2338-sid-0-pid-12html/index
ERROR - 2021-08-21 23:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:16:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:16:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:17:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:18:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:19:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:20:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:20:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:21:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:21:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:24:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:25:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:26:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:27:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:27:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:28:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:29:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:29:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:29:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:30:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:32:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:33:34 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-21 23:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:34:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:34:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:34:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:35:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:35:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:35:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:36:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:36:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:37:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:37:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:37:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:37:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:38:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:38:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:38:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 23:38:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:38:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 23:38:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:38:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:38:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-21 23:39:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:49:13 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-08-21 23:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:50:58 --> 404 Page Not Found: City/index
ERROR - 2021-08-21 23:51:02 --> 404 Page Not Found: City/1
ERROR - 2021-08-21 23:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-21 23:58:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-21 23:59:30 --> 404 Page Not Found: Robotstxt/index
