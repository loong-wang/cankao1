<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-18 00:02:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 00:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 00:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 00:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 00:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 00:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 00:08:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 00:13:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 00:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 00:21:54 --> 404 Page Not Found: CurrentTime/index
ERROR - 2021-10-18 00:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 00:30:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 00:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 00:37:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 00:47:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 00:53:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 01:16:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 01:22:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 01:29:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 01:29:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 01:47:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 01:54:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 01:59:53 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-18 01:59:53 --> 404 Page Not Found: admin//index
ERROR - 2021-10-18 01:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 01:59:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 01:59:54 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-10-18 01:59:54 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-10-18 01:59:54 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-10-18 01:59:54 --> 404 Page Not Found: Wcm/index
ERROR - 2021-10-18 02:07:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:08:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:14:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:14:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:15:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:16:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 02:19:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:20:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:20:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 02:21:41 --> 404 Page Not Found: Shell/index
ERROR - 2021-10-18 02:22:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 02:23:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:27:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:28:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:29:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:30:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:36:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:37:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:38:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:38:58 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-10-18 02:39:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:40:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:41:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:46:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 02:47:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 02:48:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 02:48:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 02:48:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 02:49:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 02:49:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 02:53:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 03:00:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 03:05:59 --> 404 Page Not Found: City/1
ERROR - 2021-10-18 03:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 03:14:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 03:16:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 03:17:53 --> 404 Page Not Found: Article/view
ERROR - 2021-10-18 03:19:27 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-18 03:19:27 --> 404 Page Not Found: admin//index
ERROR - 2021-10-18 03:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 03:19:27 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-10-18 03:19:28 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-10-18 03:19:28 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-10-18 03:47:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 03:51:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 03:53:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 03:54:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 03:55:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 03:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 03:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 04:01:03 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt10): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-10-18 04:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 04:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 04:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 04:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 04:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 04:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 04:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 04:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 04:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 04:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 04:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 04:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 04:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 04:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 05:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 05:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 05:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 05:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 05:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 05:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 05:49:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:50:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:52:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 05:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 05:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 05:53:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:54:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:55:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:55:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:56:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 05:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 05:56:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:57:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:58:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:58:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:59:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 05:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 06:00:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:00:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:01:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:01:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:02:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:03:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:04:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:06:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:06:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:07:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:08:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:09:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:09:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:10:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:11:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:11:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:12:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 06:12:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 06:13:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:13:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:14:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:15:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 06:15:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 06:16:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:17:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:18:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:19:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:20:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:20:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:21:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:22:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 06:23:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:24:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:24:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:25:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:26:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:27:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:27:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:28:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:29:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:30:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:31:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:31:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:32:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:33:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:37:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 06:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 06:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 06:53:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 07:12:52 --> 404 Page Not Found: ContactUs/index.jhtml
ERROR - 2021-10-18 07:13:14 --> 404 Page Not Found: Jiaocheng/index
ERROR - 2021-10-18 07:13:29 --> 404 Page Not Found: Setup/index.html
ERROR - 2021-10-18 07:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 07:26:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 07:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 08:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 08:42:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 08:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 08:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 08:44:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 08:48:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 08:49:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 08:50:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 08:50:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 08:50:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 08:50:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 08:50:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 08:53:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 08:56:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 08:57:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 08:59:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 08:59:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 08:59:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 08:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 08:59:41 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-10-18 08:59:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 09:00:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 09:00:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 09:00:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 09:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 09:01:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 09:03:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 09:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 09:07:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 09:08:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 09:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 09:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 09:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 09:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 09:23:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 09:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 09:34:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 09:36:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 09:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 09:40:02 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-10-18 09:40:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 09:40:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 09:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 09:58:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 09:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 10:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 10:13:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 10:22:56 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-18 10:22:56 --> 404 Page Not Found: admin//index
ERROR - 2021-10-18 10:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 10:22:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 10:22:57 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-10-18 10:22:57 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-10-18 10:22:57 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-10-18 10:22:57 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-10-18 10:22:57 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-10-18 10:22:58 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-10-18 10:22:58 --> 404 Page Not Found: Wcm/index
ERROR - 2021-10-18 10:24:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 10:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 10:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 10:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 10:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 10:48:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 10:50:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 11:01:05 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-10-18 11:04:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 11:06:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:07:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:09:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:09:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:10:06 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-10-18 11:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:15:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 11:15:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 11:16:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 11:17:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:19:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:22:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:23:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:27:36 --> 404 Page Not Found: Shell/index
ERROR - 2021-10-18 11:32:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:33:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 11:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 11:44:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:45:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:45:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 11:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 12:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 12:15:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 12:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 12:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 12:44:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 12:45:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 12:45:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 12:48:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 12:49:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 12:52:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 12:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 13:00:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:04:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 13:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:12:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 13:26:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 13:26:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:26:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:27:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:27:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:28:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 13:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 13:54:29 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-10-18 13:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 14:00:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 14:00:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 14:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 14:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 14:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 14:23:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 14:23:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 14:23:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 14:23:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 14:24:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 14:24:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 14:24:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 14:26:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 14:27:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 14:29:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 14:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 14:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 15:04:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 15:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 15:15:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 15:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 15:21:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 15:22:08 --> 404 Page Not Found: City/10
ERROR - 2021-10-18 15:28:20 --> 404 Page Not Found: City/1
ERROR - 2021-10-18 15:31:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:32:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:34:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:34:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:35:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:35:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 15:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 15:37:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 15:39:29 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-18 15:39:29 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-18 15:39:56 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-10-18 15:40:24 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-10-18 15:40:25 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-10-18 15:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:42:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:42:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:42:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:42:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:42:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:42:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:43:51 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-18 15:49:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 15:50:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 15:50:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:50:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 15:50:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 15:50:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 15:51:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 15:51:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 15:52:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 15:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 16:00:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 16:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 16:26:21 --> 404 Page Not Found: City/1
ERROR - 2021-10-18 16:34:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 16:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 16:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 16:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 16:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 16:46:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 16:46:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 16:46:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 16:48:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 16:53:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 16:53:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 16:54:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 16:59:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 17:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 17:04:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 17:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 17:16:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 17:20:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 17:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 17:23:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 17:26:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 17:35:16 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-10-18 17:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 17:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 17:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 18:00:35 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-18 18:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 18:36:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 18:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 18:44:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 18:44:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 18:45:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 18:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 18:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 18:50:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 18:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 18:55:03 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-10-18 18:55:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-18 19:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 19:16:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 19:16:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 19:16:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 19:16:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 19:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 19:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 19:30:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 19:39:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-18 19:52:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 19:52:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 19:52:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 19:52:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 19:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 19:58:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-18 19:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 19:59:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-18 20:02:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-18 20:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 20:20:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 20:23:29 --> 404 Page Not Found: City/2
ERROR - 2021-10-18 20:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 20:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 20:48:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 20:52:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 20:53:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 20:54:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 20:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 20:59:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 21:00:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 21:00:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 21:08:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-18 21:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 21:22:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 21:23:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 21:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 21:33:44 --> 404 Page Not Found: Text4041634564024/index
ERROR - 2021-10-18 21:33:44 --> 404 Page Not Found: Evox/about
ERROR - 2021-10-18 21:33:44 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-10-18 21:46:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 21:46:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 21:47:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 21:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 21:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 21:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 22:00:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:02:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 22:03:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 22:04:24 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-18 22:04:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 22:04:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 22:05:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 22:05:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 22:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 22:09:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-18 22:12:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 22:13:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 22:24:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 22:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 22:35:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:36:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:36:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:36:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:36:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:36:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:36:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:37:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:37:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:37:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:37:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:38:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:39:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:40:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:40:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:40:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:41:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:41:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:41:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:41:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:42:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:42:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:42:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:42:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:42:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:43:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:43:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:43:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:44:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:44:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:45:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:45:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:45:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:45:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:45:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:45:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:45:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:45:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:46:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 22:54:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 22:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 22:57:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 23:02:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:04:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:04:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:04:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:04:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:07:56 --> 404 Page Not Found: Pmd/index
ERROR - 2021-10-18 23:07:56 --> 404 Page Not Found: Mysqladmin/index
ERROR - 2021-10-18 23:07:56 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-10-18 23:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 23:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:13:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:14:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:19:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 23:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 23:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 23:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 23:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 23:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:20:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:21:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:21:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:22:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:22:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:23:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:23:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:23:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:24:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:24:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:24:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:25:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:29:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-18 23:33:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-18 23:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 23:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-18 23:50:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-18 23:57:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
