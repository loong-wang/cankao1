<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-02 00:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:03:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 00:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:10:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 00:11:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 00:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:18:02 --> 404 Page Not Found: TelerikWebUIWebResourceaxd/index
ERROR - 2021-06-02 00:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:20:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 00:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:28:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 00:29:24 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-02 00:29:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 00:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:31:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 00:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:34:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 00:35:11 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-02 00:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:50:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 00:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:52:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 00:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:58:06 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-02 00:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 00:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:05:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 01:06:39 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2021-06-02 01:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:11:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 01:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:11:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 01:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:13:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 01:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:13:58 --> 404 Page Not Found: Article/info
ERROR - 2021-06-02 01:14:06 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-06-02 01:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:15:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 01:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:38:41 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-02 01:38:50 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-02 01:39:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 01:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:43:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:43:28 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-02 01:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:44:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:44:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 01:48:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 01:49:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:51:20 --> 404 Page Not Found: Env/index
ERROR - 2021-06-02 01:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:55:28 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-06-02 01:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 01:59:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:00:54 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-06-02 02:00:54 --> 404 Page Not Found: admin//index
ERROR - 2021-06-02 02:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:00:55 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-06-02 02:00:55 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-06-02 02:00:55 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-06-02 02:00:55 --> 404 Page Not Found: Wcm/index
ERROR - 2021-06-02 02:00:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:05:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 02:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:07:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 02:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:12:31 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-06-02 02:15:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 02:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:19:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 02:20:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 02:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:20:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 02:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:22:51 --> 404 Page Not Found: City/1
ERROR - 2021-06-02 02:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:26:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 02:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:30:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 02:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:38:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 02:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:43:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-02 02:43:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 02:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:46:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 02:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:49:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:52:48 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-02 02:52:52 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 02:52:53 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 02:52:53 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-02 02:52:53 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 02:52:53 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-02 02:52:53 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 02:52:53 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 02:52:53 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-02 02:52:53 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 02:52:53 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 02:52:53 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-02 02:52:53 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 02:52:54 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-02 02:52:54 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-02 02:52:54 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-02 02:52:54 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-02 02:52:54 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 02:52:54 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 02:52:54 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 02:52:54 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-02 02:52:54 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-02 02:52:54 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-02 02:53:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 02:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:56:55 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 02:56:55 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 02:56:55 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-02 02:56:55 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 02:56:55 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 02:56:56 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-02 02:56:56 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 02:56:56 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-02 02:56:56 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 02:56:56 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 02:56:56 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-02 02:56:56 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 02:56:56 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 02:56:56 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-02 02:56:56 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 02:56:56 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-02 02:56:57 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-02 02:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:59:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-02 02:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 02:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:01:48 --> 404 Page Not Found: City/1
ERROR - 2021-06-02 03:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:03:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 03:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:09:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 03:09:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 03:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:11:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 03:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:19:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 03:20:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 03:21:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:33:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:38:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:41:41 --> 404 Page Not Found: Env/index
ERROR - 2021-06-02 03:42:32 --> 404 Page Not Found: Env/index
ERROR - 2021-06-02 03:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:42:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 03:43:41 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-06-02 03:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:50:41 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-02 03:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 03:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:00:38 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-06-02 04:00:38 --> 404 Page Not Found: admin//index
ERROR - 2021-06-02 04:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:00:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 04:00:39 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-06-02 04:00:39 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-06-02 04:00:39 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-06-02 04:00:41 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-06-02 04:00:41 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-06-02 04:00:41 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-06-02 04:00:41 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-06-02 04:00:41 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-06-02 04:00:41 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-06-02 04:00:41 --> 404 Page Not Found: Wcm/index
ERROR - 2021-06-02 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-06-02 04:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:03:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 04:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:04:00 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-02 04:04:05 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-02 04:04:13 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-02 04:04:22 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-02 04:04:30 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-02 04:04:37 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-02 04:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:06:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 04:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:11:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 04:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:13:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 04:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:14:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 04:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:16:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 04:17:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 04:17:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 04:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:20:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:23:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:30:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 04:30:25 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-02 04:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:42:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 04:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:44:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:47:56 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-02 04:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:54:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 04:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:56:05 --> 404 Page Not Found: English/index
ERROR - 2021-06-02 04:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 04:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:05:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 05:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:13:27 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-02 05:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:14:49 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-02 05:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:20:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 05:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:21:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:31:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 05:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:34:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-02 05:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:39:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 05:39:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 05:39:50 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-02 05:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:40:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 05:41:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 05:41:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 05:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:41:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 05:42:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 05:42:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 05:43:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 05:43:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 05:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:44:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 05:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:48:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 05:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:50:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 05:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:53:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 05:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:56:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-02 05:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:57:42 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-02 05:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 05:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:00:23 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-02 06:00:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 06:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:02:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-02 06:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:06:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 06:07:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 06:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:10:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 06:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:17:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 06:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:18:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 06:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:24:07 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 06:24:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 06:24:07 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-02 06:24:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 06:24:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 06:24:07 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-02 06:24:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 06:24:07 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-02 06:24:08 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 06:24:08 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 06:24:08 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-02 06:24:08 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 06:24:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 06:24:08 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-02 06:24:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 06:24:08 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-02 06:24:09 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-02 06:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:26:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:27:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 06:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:29:21 --> 404 Page Not Found: City/1
ERROR - 2021-06-02 06:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:30:31 --> 404 Page Not Found: City/1
ERROR - 2021-06-02 06:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:31:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 06:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:45:42 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-02 06:45:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:47:34 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 06:47:34 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 06:47:34 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-02 06:47:34 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 06:47:34 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 06:47:34 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-02 06:47:35 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 06:47:35 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-02 06:47:35 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 06:47:35 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 06:47:35 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-02 06:47:35 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 06:47:35 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 06:47:35 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-02 06:47:35 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 06:47:35 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-02 06:47:35 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-02 06:47:36 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-02 06:47:37 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-02 06:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:51:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 06:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:57:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 06:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:58:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 06:58:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 06:59:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 06:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 06:59:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 07:00:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 07:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:03:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 07:03:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 07:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:05:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 07:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:06:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 07:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:14:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:24:55 --> 404 Page Not Found: English/index
ERROR - 2021-06-02 07:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:37:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:39:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 07:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:41:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 07:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:48:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 07:48:23 --> 404 Page Not Found: City/1
ERROR - 2021-06-02 07:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:50:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 07:51:43 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-02 07:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:56:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 07:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:57:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 07:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:02:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 08:07:07 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-02 08:07:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 08:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:10:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 08:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:16:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 08:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:21:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 08:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:27:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-02 08:29:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 08:29:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 08:30:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 08:31:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 08:31:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 08:31:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 08:32:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 08:32:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 08:32:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-02 08:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:35:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:35:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:41:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 08:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:46:57 --> 404 Page Not Found: City/index
ERROR - 2021-06-02 08:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:49:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 08:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:50:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 08:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:54:59 --> 404 Page Not Found: Www20210530rar/index
ERROR - 2021-06-02 08:54:59 --> 404 Page Not Found: Wwwxuanhaonet20210530rar/index
ERROR - 2021-06-02 08:54:59 --> 404 Page Not Found: Www_xuanhao_net20210530rar/index
ERROR - 2021-06-02 08:54:59 --> 404 Page Not Found: Wwwxuanhaonet20210530rar/index
ERROR - 2021-06-02 08:54:59 --> 404 Page Not Found: Xuanhaonet20210530rar/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Xuanhao_net20210530rar/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Xuanhaonet20210530rar/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Xuanhao20210530rar/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Www20210530targz/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Wwwxuanhaonet20210530targz/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Www_xuanhao_net20210530targz/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Wwwxuanhaonet20210530targz/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Xuanhaonet20210530targz/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Xuanhao_net20210530targz/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Xuanhaonet20210530targz/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Xuanhao20210530targz/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Www20210530zip/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Wwwxuanhaonet20210530zip/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Www_xuanhao_net20210530zip/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Wwwxuanhaonet20210530zip/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Xuanhaonet20210530zip/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Xuanhao_net20210530zip/index
ERROR - 2021-06-02 08:55:00 --> 404 Page Not Found: Xuanhaonet20210530zip/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Xuanhao20210530zip/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Www2021-05-30rar/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Wwwxuanhaonet2021-05-30rar/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Www_xuanhao_net2021-05-30rar/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Wwwxuanhaonet2021-05-30rar/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Xuanhaonet2021-05-30rar/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Xuanhao_net2021-05-30rar/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Xuanhaonet2021-05-30rar/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Xuanhao2021-05-30rar/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Www2021-05-30targz/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Wwwxuanhaonet2021-05-30targz/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Www_xuanhao_net2021-05-30targz/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Wwwxuanhaonet2021-05-30targz/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Xuanhaonet2021-05-30targz/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Xuanhao_net2021-05-30targz/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Xuanhaonet2021-05-30targz/index
ERROR - 2021-06-02 08:55:01 --> 404 Page Not Found: Xuanhao2021-05-30targz/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Www2021-05-30zip/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Wwwxuanhaonet2021-05-30zip/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Www_xuanhao_net2021-05-30zip/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Wwwxuanhaonet2021-05-30zip/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Xuanhaonet2021-05-30zip/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Xuanhao_net2021-05-30zip/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Xuanhaonet2021-05-30zip/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Xuanhao2021-05-30zip/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Www20210530rar/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Wwwxuanhaonet20210530rar/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Www_xuanhao_net20210530rar/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Wwwxuanhaonet20210530rar/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Xuanhaonet20210530rar/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Xuanhao_net20210530rar/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Xuanhaonet20210530rar/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Xuanhao20210530rar/index
ERROR - 2021-06-02 08:55:02 --> 404 Page Not Found: Www20210530targz/index
ERROR - 2021-06-02 08:55:03 --> 404 Page Not Found: Wwwxuanhaonet20210530targz/index
ERROR - 2021-06-02 08:55:03 --> 404 Page Not Found: Www_xuanhao_net20210530targz/index
ERROR - 2021-06-02 08:55:03 --> 404 Page Not Found: Wwwxuanhaonet20210530targz/index
ERROR - 2021-06-02 08:55:03 --> 404 Page Not Found: Xuanhaonet20210530targz/index
ERROR - 2021-06-02 08:55:03 --> 404 Page Not Found: Xuanhao_net20210530targz/index
ERROR - 2021-06-02 08:55:03 --> 404 Page Not Found: Xuanhaonet20210530targz/index
ERROR - 2021-06-02 08:55:03 --> 404 Page Not Found: Xuanhao20210530targz/index
ERROR - 2021-06-02 08:55:03 --> 404 Page Not Found: Www20210530zip/index
ERROR - 2021-06-02 08:55:03 --> 404 Page Not Found: Wwwxuanhaonet20210530zip/index
ERROR - 2021-06-02 08:55:03 --> 404 Page Not Found: Www_xuanhao_net20210530zip/index
ERROR - 2021-06-02 08:55:03 --> 404 Page Not Found: Wwwxuanhaonet20210530zip/index
ERROR - 2021-06-02 08:55:04 --> 404 Page Not Found: Xuanhaonet20210530zip/index
ERROR - 2021-06-02 08:55:04 --> 404 Page Not Found: Xuanhao_net20210530zip/index
ERROR - 2021-06-02 08:55:04 --> 404 Page Not Found: Xuanhaonet20210530zip/index
ERROR - 2021-06-02 08:55:04 --> 404 Page Not Found: Xuanhao20210530zip/index
ERROR - 2021-06-02 08:55:04 --> 404 Page Not Found: 20210530rar/index
ERROR - 2021-06-02 08:55:04 --> 404 Page Not Found: 20210530targz/index
ERROR - 2021-06-02 08:55:04 --> 404 Page Not Found: 20210530zip/index
ERROR - 2021-06-02 08:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 08:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:00:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 09:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:01:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 09:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:10:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 09:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:17:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 09:17:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 09:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:28:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 09:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:37:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 09:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:39:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 09:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:43:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 09:44:09 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-02 09:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:45:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 09:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:46:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 09:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:50:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:51:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 09:52:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 09:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 09:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:02:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 10:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:05:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 10:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:08:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 10:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:09:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 10:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 10:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:28:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 10:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:37:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 10:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:43:42 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-02 10:43:49 --> 404 Page Not Found: City/index
ERROR - 2021-06-02 10:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:47:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 10:47:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 10:48:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 10:49:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:50:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:54:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 10:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:00:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:04:05 --> 404 Page Not Found: English/index
ERROR - 2021-06-02 11:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:14:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 11:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:17:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 11:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:19:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 11:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:25:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:25:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 11:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:34:15 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-02 11:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:38:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:38:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:38:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:38:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:38:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:38:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:38:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:38:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:38:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:39:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:41:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:54:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 11:54:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 11:54:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:55:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 11:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:56:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 11:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 11:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:04:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:04:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:06:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:07:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:09:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:18:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 12:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:19:53 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 12:19:53 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 12:19:53 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-02 12:19:53 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 12:19:53 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 12:19:53 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-02 12:19:53 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 12:19:53 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 12:19:54 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-02 12:19:55 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-02 12:19:55 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-02 12:19:55 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-02 12:19:55 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 12:19:55 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 12:19:55 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 12:19:55 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-02 12:19:55 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-02 12:19:55 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-02 12:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:26:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:26:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 12:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:28:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:30:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 12:32:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 12:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:33:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:33:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:33:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:37:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 12:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:42:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 12:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:47:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:48:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:48:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:48:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 12:49:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:49:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 12:49:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:50:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:52:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:52:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 12:52:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:53:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:54:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:54:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:54:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:54:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:56:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 12:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:57:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 12:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:58:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 12:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 12:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:00:11 --> 404 Page Not Found: Cart/index
ERROR - 2021-06-02 13:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:04:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 13:06:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 13:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:08:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 13:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:17:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 13:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:19:36 --> 404 Page Not Found: Clientaccesspolicyxml/index
ERROR - 2021-06-02 13:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:21:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 13:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:26:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 13:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:27:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 13:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:30:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 13:30:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 13:31:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 13:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:31:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 13:31:25 --> 404 Page Not Found: English/index
ERROR - 2021-06-02 13:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:36:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 13:36:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 13:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:37:29 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-02 13:37:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 13:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:38:09 --> 404 Page Not Found: Env/index
ERROR - 2021-06-02 13:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:39:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 13:40:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 13:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:45:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 13:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:48:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 13:48:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 13:49:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:53:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 13:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:55:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 13:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:56:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 13:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:57:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 13:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 13:58:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 14:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:09:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 14:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:11:08 --> 404 Page Not Found: All/index
ERROR - 2021-06-02 14:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:13:06 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-02 14:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:15:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 14:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:22:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 14:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:26:03 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-02 14:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:26:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 14:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:30:34 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 14:30:34 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 14:30:34 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-02 14:30:34 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 14:30:34 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 14:30:34 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-02 14:30:34 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 14:30:34 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-02 14:30:34 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 14:30:34 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-02 14:30:35 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-02 14:30:36 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 14:30:36 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 14:30:36 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 14:30:36 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-02 14:30:36 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-02 14:30:36 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-02 14:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:33:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 14:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:34:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 14:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:36:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 14:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:39:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 14:40:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 14:41:08 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-02 14:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:42:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 14:43:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 14:44:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 14:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:51:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 14:51:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 14:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:52:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 14:53:04 --> 404 Page Not Found: Wordpress/wp-admin
ERROR - 2021-06-02 14:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:56:50 --> 404 Page Not Found: City/16
ERROR - 2021-06-02 14:56:50 --> 404 Page Not Found: City/16
ERROR - 2021-06-02 14:56:50 --> 404 Page Not Found: City/16
ERROR - 2021-06-02 14:56:50 --> 404 Page Not Found: City/16
ERROR - 2021-06-02 14:56:50 --> 404 Page Not Found: City/16
ERROR - 2021-06-02 14:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 14:57:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 14:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:02:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 15:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:04:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 15:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:07:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 15:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:09:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:09:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 15:09:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 15:09:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 15:09:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 15:09:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:10:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:10:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:11:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:12:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 15:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:13:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 15:13:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:15:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:27:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 15:27:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 15:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:29:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:32:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 15:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:39:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 15:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:40:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:42:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 15:42:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 15:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:49:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 15:49:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 15:50:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:52:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:52:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:53:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:53:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:53:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:53:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:54:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:54:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:55:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 15:59:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 15:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:04:24 --> 404 Page Not Found: English/index
ERROR - 2021-06-02 16:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:10:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 16:11:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 16:11:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 16:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:11:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 16:11:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 16:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:20:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 16:21:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:32:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 16:33:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 16:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:33:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 16:34:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 16:34:47 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-02 16:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:39:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 16:40:00 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-06-02 16:41:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 16:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:45:48 --> Severity: Warning --> Missing argument 1 for News::show() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 581
ERROR - 2021-06-02 16:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:48:29 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-02 16:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:50:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 16:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:51:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 16:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 16:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:00:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 17:03:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 17:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:11:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:11:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 17:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:13:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 17:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:14:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 17:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:19:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 17:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:24:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 17:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:28:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 17:30:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:32:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:34:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 17:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:35:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 17:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:36:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 17:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:37:59 --> 404 Page Not Found: City/1
ERROR - 2021-06-02 17:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:41:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 17:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:43:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 17:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:45:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 17:46:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 17:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:48:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 17:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:54:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 17:54:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 17:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:55:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 17:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 17:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 17:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 17:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:02:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 18:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:05:07 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-02 18:05:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:05:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:05:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:05:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:05:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 18:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:05:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 18:05:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:06:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:07:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:08:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:08:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:08:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:10:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:10:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:10:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:10:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:10:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:11:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:11:14 --> 404 Page Not Found: English/index
ERROR - 2021-06-02 18:11:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:11:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:11:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 18:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:16:20 --> 404 Page Not Found: Article/view
ERROR - 2021-06-02 18:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:21:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:30:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 18:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:32:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 18:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:35:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-02 18:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:48:02 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-06-02 18:48:02 --> 404 Page Not Found: admin//index
ERROR - 2021-06-02 18:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:48:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 18:48:03 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-06-02 18:48:03 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-06-02 18:48:03 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-06-02 18:48:04 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-06-02 18:48:04 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-06-02 18:48:04 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-06-02 18:48:04 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-06-02 18:48:05 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-06-02 18:48:05 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-06-02 18:48:05 --> 404 Page Not Found: Wcm/index
ERROR - 2021-06-02 18:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:50:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 18:51:21 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-02 18:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:58:46 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 18:58:46 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 18:58:46 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-02 18:58:46 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 18:58:46 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 18:58:46 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 18:58:47 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-02 18:58:48 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-02 18:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 18:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:00:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 19:00:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 19:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:03:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:06:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 19:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 19:07:37 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-02 19:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:22:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 19:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:37:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 19:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:37:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:39:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:39:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:40:00 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 19:40:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 19:40:00 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-02 19:40:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 19:40:00 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 19:40:00 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-02 19:40:00 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 19:40:00 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-02 19:40:00 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 19:40:00 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 19:40:00 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-02 19:40:01 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 19:40:02 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 19:40:02 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 19:40:02 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-02 19:40:02 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-02 19:40:02 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-02 19:40:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:40:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:40:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:40:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:40:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:40:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:40:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:40:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:40:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:41:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:41:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 19:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:46:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 19:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:48:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 19:48:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 19:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:50:07 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 19:50:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 19:50:07 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-02 19:50:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-02 19:50:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 19:50:07 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-02 19:50:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-02 19:50:07 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-02 19:50:07 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 19:50:08 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 19:50:08 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-02 19:50:08 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-02 19:50:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 19:50:08 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-02 19:50:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-02 19:50:08 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-02 19:50:09 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-02 19:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:53:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 19:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:55:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 19:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 19:59:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:00:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 20:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:04:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 20:04:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:05:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 20:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:13:03 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-02 20:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:19:42 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-02 20:19:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 20:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:20:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:22:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 20:22:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:23:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 20:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:25:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:26:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:28:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:28:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:29:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 20:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:35:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:37:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 20:37:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:37:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:38:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 20:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:42:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:42:39 --> 404 Page Not Found: English/index
ERROR - 2021-06-02 20:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:44:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 20:44:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 20:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:56:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 20:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 20:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:01:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 21:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:02:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:02:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 21:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:17:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 21:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:19:05 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-02 21:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:35:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 21:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:37:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 21:38:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 21:38:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 21:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:39:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 21:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:50:11 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-02 21:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 21:58:12 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2021-06-02 21:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:00:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 22:00:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:01:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 22:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:02:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 22:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:04:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 22:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:11:00 --> 404 Page Not Found: Sftp-configjson/index
ERROR - 2021-06-02 22:12:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 22:12:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 22:12:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 22:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:14:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 22:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:22:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 22:22:41 --> 404 Page Not Found: City/index
ERROR - 2021-06-02 22:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:30:30 --> 404 Page Not Found: Nmaplowercheck1622644229/index
ERROR - 2021-06-02 22:30:30 --> 404 Page Not Found: Evox/about
ERROR - 2021-06-02 22:30:40 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-06-02 22:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:39:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 22:39:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:42:39 --> 404 Page Not Found: City/1
ERROR - 2021-06-02 22:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:46:14 --> 404 Page Not Found: City/1
ERROR - 2021-06-02 22:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:48:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 22:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:51:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 22:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:54:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 22:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 22:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:55:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 22:55:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 22:55:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 22:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:55:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 22:56:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 22:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 22:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 22:59:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 22:59:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:00:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:01:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:01:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:01:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:02:04 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-02 23:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:02:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:03:37 --> 404 Page Not Found: City/16
ERROR - 2021-06-02 23:03:43 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-02 23:05:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:05:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 23:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:06:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:06:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:07:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:07:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 23:08:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:09:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:09:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:09:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:10:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:10:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 23:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:14:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:15:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:15:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:15:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:16:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:16:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:17:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:18:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:18:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:18:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:18:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:19:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:19:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:19:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:19:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-02 23:19:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:20:09 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-02 23:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:20:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:25:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 23:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:26:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 23:26:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:39:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:40:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:40:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:40:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-02 23:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:42:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 23:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:44:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 23:45:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:45:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:47:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-02 23:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:54:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-02 23:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-02 23:59:03 --> 404 Page Not Found: Robotstxt/index
