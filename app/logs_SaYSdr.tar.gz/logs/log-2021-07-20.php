<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-20 00:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:02:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 00:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:03:07 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-07-20 00:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:04:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:04:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:04:45 --> 404 Page Not Found: Config/getuser
ERROR - 2021-07-20 00:04:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 00:04:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:05:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:05:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:06:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:07:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 00:07:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:08:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 00:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:11:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 00:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:12:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 00:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:16:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 00:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:16:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 00:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:18:38 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-07-20 00:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:19:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:19:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:19:24 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-20 00:19:24 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-07-20 00:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:19:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:20:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 00:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:20:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 00:21:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 00:21:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 00:24:22 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-07-20 00:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:27:55 --> 404 Page Not Found: City/1
ERROR - 2021-07-20 00:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:32:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 00:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:35:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 00:35:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:36:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:36:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 00:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:39:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 00:40:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 00:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:46:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 00:47:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 00:48:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 00:49:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 00:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:51:42 --> 404 Page Not Found: Env/index
ERROR - 2021-07-20 00:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:52:41 --> 404 Page Not Found: City/index
ERROR - 2021-07-20 00:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:54:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 00:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 00:58:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 00:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:02:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 01:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:12:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 01:12:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 01:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:15:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 01:15:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 01:15:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 01:15:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 01:15:48 --> 404 Page Not Found: Article/index
ERROR - 2021-07-20 01:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:17:57 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-07-20 01:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:21:47 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-20 01:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:22:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 01:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 01:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 01:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:23:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 01:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:25:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 01:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:25:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 01:25:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 01:25:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 01:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 01:26:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 01:26:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 01:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:28:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 01:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:29:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 01:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:32:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 01:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:36:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 01:36:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 01:36:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 01:37:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 01:37:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:40:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 01:40:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:53:41 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 01:53:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 01:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:53:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 01:54:00 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 01:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 01:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:07:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 02:10:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 02:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:11:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:11:37 --> 404 Page Not Found: Portal/redlion
ERROR - 2021-07-20 02:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:12:16 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-20 02:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:17:34 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-07-20 02:17:34 --> 404 Page Not Found: Js/fckeditor
ERROR - 2021-07-20 02:17:34 --> 404 Page Not Found: admin/Fckeditor/editor
ERROR - 2021-07-20 02:17:35 --> 404 Page Not Found: FCKeditor/editor
ERROR - 2021-07-20 02:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:22:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 02:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:22:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 02:23:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 02:24:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 02:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:28:05 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-20 02:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:31:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 02:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:33:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 02:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:36:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 02:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:39:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 02:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:45:09 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-07-20 02:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:51:00 --> 404 Page Not Found: Actuator/health
ERROR - 2021-07-20 02:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:55:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-20 02:57:26 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 02:57:27 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 02:57:28 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 02:57:28 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-20 02:57:28 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-20 02:57:28 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-20 02:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 02:59:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 03:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:04:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 03:07:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 03:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:10:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 03:10:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 03:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:16:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 03:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:26:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 03:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:32:35 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-20 03:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:36:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 03:37:09 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-20 03:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:41:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 03:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:42:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 03:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:48:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 03:48:29 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-20 03:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:54:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 03:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:56:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 03:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:59:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 03:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 03:59:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 03:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-07-20 04:01:26 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-07-20 04:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:05:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 04:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:06:48 --> 404 Page Not Found: City/10
ERROR - 2021-07-20 04:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:09:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 04:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:10:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 04:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:15:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 04:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:39:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 04:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:43:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 04:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:45:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 04:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:47:34 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-07-20 04:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:52:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 04:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:56:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 04:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 04:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:03:40 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-20 05:03:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:06:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:09:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:12:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:17:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:19:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 05:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:24:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 05:25:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 05:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:25:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:26:56 --> 404 Page Not Found: Env/index
ERROR - 2021-07-20 05:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:27:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:28:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:29:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:29:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:29:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:35:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:42:11 --> Severity: Warning --> Missing argument 1 for Taocan::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 181
ERROR - 2021-07-20 05:42:34 --> Severity: Warning --> Missing argument 1 for Taocan::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 101
ERROR - 2021-07-20 05:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:44:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:44:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 05:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:52:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 05:52:35 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 05:52:35 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 05:52:35 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-20 05:52:35 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 05:52:35 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 05:52:35 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-20 05:52:35 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 05:52:35 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-20 05:52:35 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 05:52:36 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 05:52:36 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-20 05:52:36 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 05:52:36 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 05:52:36 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-20 05:52:36 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 05:52:36 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-20 05:52:36 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 05:52:36 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 05:52:36 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-20 05:52:36 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-20 05:52:37 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-20 05:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:56:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 05:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 05:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:01:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 06:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:03:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:07:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 06:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:09:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 06:09:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 06:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:11:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 06:13:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:15:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 06:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:16:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 06:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:16:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:17:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 06:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:18:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:32:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:35:01 --> 404 Page Not Found: Html-en/products-SnEmQNxVDJTz-2-0-2-1.html
ERROR - 2021-07-20 06:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:40:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:40:41 --> 404 Page Not Found: Html-cn/hot-products-CQxmJTnWDEvg-1-0-2-1.html
ERROR - 2021-07-20 06:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:42:48 --> 404 Page Not Found: Previewdo/index
ERROR - 2021-07-20 06:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:50:41 --> 404 Page Not Found: City/16
ERROR - 2021-07-20 06:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:57:54 --> 404 Page Not Found: Config/getuser
ERROR - 2021-07-20 06:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 06:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:03:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:05:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 07:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:16:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 07:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:19:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 07:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:37:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 07:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:42:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 07:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:49:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 07:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:57:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 07:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 07:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:00:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 08:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:05:53 --> 404 Page Not Found: Bsff/index
ERROR - 2021-07-20 08:05:53 --> 404 Page Not Found: 160000/index
ERROR - 2021-07-20 08:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:11:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 08:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:11:53 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-07-20 08:11:55 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-07-20 08:11:56 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-07-20 08:11:57 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-07-20 08:11:58 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-07-20 08:12:01 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-07-20 08:12:05 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-07-20 08:12:06 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-07-20 08:12:09 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-07-20 08:12:10 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-07-20 08:12:11 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-07-20 08:12:12 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-07-20 08:12:13 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-07-20 08:12:17 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-07-20 08:12:18 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-07-20 08:12:19 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-07-20 08:12:19 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-07-20 08:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:15:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 08:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:19:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 08:20:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 08:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:21:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:21:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:21:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:21:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:22:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:22:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:22:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:22:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:22:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 08:23:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:23:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:23:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:23:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:23:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 08:24:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:24:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:24:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:24:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:24:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:24:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:24:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:24:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:24:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 08:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:25:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 08:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:27:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:27:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:27:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:27:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:27:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:27:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:27:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:27:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:28:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:28:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:28:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:28:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:28:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:29:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 08:29:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:29:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:29:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:29:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:29:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 08:29:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:29:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:29:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:29:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:29:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:31:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:31:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:32:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 08:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:39:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:44:33 --> 404 Page Not Found: Env/index
ERROR - 2021-07-20 08:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:48:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:48:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 08:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 08:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:00:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 09:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:01:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:02:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 09:02:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:02:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:02:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 09:04:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:06:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:07:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:07:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:08:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:16:12 --> 404 Page Not Found: Vscode/sftp.json
ERROR - 2021-07-20 09:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:20:30 --> 404 Page Not Found: Indexrss/index
ERROR - 2021-07-20 09:20:30 --> 404 Page Not Found: Indexxml/index
ERROR - 2021-07-20 09:20:30 --> 404 Page Not Found: Feeds/index
ERROR - 2021-07-20 09:20:30 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-07-20 09:20:31 --> 404 Page Not Found: Feed/index
ERROR - 2021-07-20 09:20:31 --> 404 Page Not Found: Indexrdf/index
ERROR - 2021-07-20 09:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:24:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:27:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:28:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:30:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:35:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 09:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:36:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 09:37:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:38:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:39:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:41:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 09:42:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:44:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:45:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:46:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:48:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:48:16 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-20 09:48:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 09:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-20 09:50:04 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-20 09:50:05 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-20 09:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:51:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 09:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:56:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 09:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 09:59:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:02:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:02:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:02:45 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-20 10:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:03:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:03:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:03:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:04:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:04:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:04:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:05:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:05:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:05:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:06:29 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-20 10:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:06:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:08:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:08:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:08:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:09:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:09:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:09:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:10:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:11:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:11:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:11:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:11:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:12:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:13:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:13:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:14:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:14:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:14:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:14:49 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-20 10:15:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:19:13 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 10:19:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:19:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:20:23 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-20 10:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:25:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:26:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:29:08 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-20 10:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:32:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:34:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:35:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:35:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 10:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:36:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:36:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:36:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:36:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:36:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:36:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:37:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:37:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:37:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:37:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:37:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:37:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:37:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 10:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:37:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:41:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 10:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:44:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 10:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:45:59 --> 404 Page Not Found: Script/index
ERROR - 2021-07-20 10:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:48:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:49:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:49:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:51:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:52:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 10:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:52:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 10:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:55:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:56:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:56:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:57:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:57:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 10:57:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:58:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 10:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 10:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:00:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 11:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:02:01 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 11:02:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 11:02:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 11:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:02:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 11:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:09:02 --> 404 Page Not Found: Indexrdf/index
ERROR - 2021-07-20 11:09:02 --> 404 Page Not Found: Indexrss/index
ERROR - 2021-07-20 11:09:02 --> 404 Page Not Found: Feeds/index
ERROR - 2021-07-20 11:09:02 --> 404 Page Not Found: Feed/index
ERROR - 2021-07-20 11:09:02 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-07-20 11:09:03 --> 404 Page Not Found: Indexxml/index
ERROR - 2021-07-20 11:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:10:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:11:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 11:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:13:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 11:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:17:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 11:17:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 11:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:17:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 11:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:31:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 11:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:31:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 11:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:33:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 11:33:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 11:33:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 11:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:36:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 11:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:38:02 --> 404 Page Not Found: Indexrdf/index
ERROR - 2021-07-20 11:38:02 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-07-20 11:38:02 --> 404 Page Not Found: Feed/index
ERROR - 2021-07-20 11:38:02 --> 404 Page Not Found: Indexxml/index
ERROR - 2021-07-20 11:38:03 --> 404 Page Not Found: Indexrss/index
ERROR - 2021-07-20 11:38:04 --> 404 Page Not Found: Feeds/index
ERROR - 2021-07-20 11:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:39:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:39:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 11:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:40:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 11:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:44:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:44:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 11:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:46:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 11:47:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 11:47:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 11:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:49:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 11:50:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 11:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:53:29 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 11:53:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 11:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:54:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 11:54:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 11:54:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 11:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:56:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 11:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 11:59:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:01:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:01:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:02:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:04:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:04:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:04:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:04:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:04:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:04:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:06:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:07:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:08:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:08:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:08:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:13:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:19:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 12:20:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:23:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:31:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:34:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:34:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 12:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:36:29 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-20 12:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:38:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 12:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:39:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 12:40:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:44:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:45:07 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-07-20 12:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:47:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:49:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:52:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:53:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 12:54:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:54:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:55:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:56:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:56:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:58:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:58:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 12:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 12:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:00:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 13:00:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 13:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:02:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 13:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:02:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 13:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:03:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:03:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 13:05:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 13:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:06:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 13:06:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:10:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:14:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 13:14:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 13:14:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 13:14:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 13:14:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:15:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 13:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:17:56 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 13:17:56 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 13:17:56 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-20 13:17:56 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 13:17:56 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 13:17:56 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-20 13:17:56 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 13:17:56 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-20 13:17:56 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 13:17:56 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 13:17:56 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 13:17:57 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 13:17:58 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 13:17:58 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-20 13:17:58 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-20 13:19:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:19:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:22:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 13:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:23:46 --> 404 Page Not Found: Html-en/hot-products-xnQJxLxEQmzH-1--1-1.html
ERROR - 2021-07-20 13:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:28:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:29:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 13:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:30:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 13:31:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:38:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 13:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:44:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:46:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 13:47:01 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-20 13:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:47:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:48:20 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-20 13:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:49:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 13:49:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 13:50:49 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-20 13:51:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 13:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:53:19 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-20 13:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:54:34 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-20 13:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:55:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:56:16 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-20 13:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:56:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:57:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 13:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:57:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 13:58:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 13:59:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 13:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:05:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:06:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:06:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:07:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:07:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:07:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 14:08:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 14:08:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:11:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:12:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 14:12:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:12:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:15:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:16:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:16:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:17:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:18:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:19:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:19:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:20:05 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-20 14:20:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:20:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:20:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:21:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:21:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:22:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:23:07 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-20 14:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:24:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:25:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:25:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:25:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:26:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:27:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:27:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:28:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:28:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:28:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:29:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:29:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:29:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:29:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:30:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:30:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:30:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:31:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:31:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:32:43 --> 404 Page Not Found: Config/getuser
ERROR - 2021-07-20 14:32:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:34:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:35:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:35:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:36:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:36:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:37:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:38:08 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-20 14:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:38:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:38:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-20, 20' at line 6 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_title` LIKE '%188101%' ESCAPE '!'
OR  `hao_user` LIKE '%188101%' ESCAPE '!'
ORDER BY `hao_time` DESC
 LIMIT -20, 20
ERROR - 2021-07-20 14:38:58 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 1234
ERROR - 2021-07-20 14:39:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:39:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:40:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-20, 20' at line 6 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_title` LIKE '%188101%' ESCAPE '!'
OR  `hao_user` LIKE '%188101%' ESCAPE '!'
ORDER BY `hao_time` DESC
 LIMIT -20, 20
ERROR - 2021-07-20 14:40:05 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 1234
ERROR - 2021-07-20 14:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:40:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:40:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:41:23 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 14:41:34 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 14:41:38 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 14:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:43:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:44:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:46:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:46:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:46:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:46:58 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-07-20 14:47:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:47:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 14:48:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:48:36 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-20 14:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:49:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 14:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:49:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:49:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:50:04 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-20 14:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:52:58 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-07-20 14:53:13 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-20 14:53:13 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-20 14:53:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-20 14:53:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-20 14:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:53:31 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-20 14:53:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 14:53:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 14:57:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 14:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:01:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 15:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:05:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:05:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:06:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:07:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:07:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:08:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:09:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:10:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:11:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:11:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 15:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:15:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 15:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:16:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:18:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 15:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:20:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:21:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:22:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 15:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:23:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 15:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:23:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 15:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:23:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:30:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 15:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:31:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:31:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:31:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 15:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:32:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:33:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:34:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:34:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:35:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:35:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:38:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:39:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:40:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 15:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:42:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 15:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:45:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:46:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 15:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:47:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 15:49:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 15:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:55:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 15:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 15:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:00:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 16:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:01:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 16:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:02:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 16:04:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 16:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:06:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 16:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:08:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 16:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:10:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:11:12 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-07-20 16:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:12:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 16:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:18:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 16:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:19:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 16:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:21:20 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-20 16:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:21:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:21:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:21:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:22:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:22:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:23:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 16:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:25:27 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 16:25:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:25:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:28:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 16:29:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 16:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:33:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 16:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:35:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 16:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:41:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:41:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 16:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:42:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:42:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 16:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:49:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:50:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:50:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:51:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 16:51:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:53:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:54:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:54:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:54:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:54:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:55:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:55:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:55:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:57:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 16:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:59:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 16:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 16:59:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 16:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:02:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:04:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:04:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:05:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:08:26 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-20 17:08:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:09:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:10:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:10:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 17:10:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:11:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:11:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:13:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:13:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:14:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:14:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:15:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:15:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:16:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:18:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:19:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 17:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:20:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:20:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 17:20:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:20:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:21:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:21:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:21:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:21:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:22:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:22:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:22:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:22:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:22:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:22:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:22:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:24:00 --> 404 Page Not Found: Html-en/new-products-BExJnSQdumvP-2--2-1.html
ERROR - 2021-07-20 17:24:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:24:53 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-07-20 17:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:26:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:27:32 --> 404 Page Not Found: Html-cn/new-products-CQxmJTnWDEvg-1-0-2-1.html
ERROR - 2021-07-20 17:28:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:28:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:28:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:29:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 17:30:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:30:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:31:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:31:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 17:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:32:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:33:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 17:33:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:34:11 --> 404 Page Not Found: Bag2/index
ERROR - 2021-07-20 17:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:35:04 --> 404 Page Not Found: English/index
ERROR - 2021-07-20 17:35:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 17:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:38:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:39:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 17:39:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 17:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:42:35 --> 404 Page Not Found: Sitemap81819html/index
ERROR - 2021-07-20 17:43:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 17:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:47:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:48:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 17:49:16 --> 404 Page Not Found: Company/view
ERROR - 2021-07-20 17:49:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:49:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:49:52 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-07-20 17:50:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:51:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 17:51:12 --> 404 Page Not Found: News_showasp/index
ERROR - 2021-07-20 17:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:54:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:55:21 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-07-20 17:56:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 17:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:57:29 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-07-20 17:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 17:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:00:59 --> 404 Page Not Found: Company/view
ERROR - 2021-07-20 18:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:03:37 --> 404 Page Not Found: Company/view
ERROR - 2021-07-20 18:04:00 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-07-20 18:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:04:49 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-20 18:04:57 --> 404 Page Not Found: Vod-read-id-2740html/index
ERROR - 2021-07-20 18:05:38 --> 404 Page Not Found: Expensesasp/index
ERROR - 2021-07-20 18:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:06:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 18:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:10:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 18:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:14:33 --> 404 Page Not Found: Article/index
ERROR - 2021-07-20 18:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:15:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 18:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:17:06 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-07-20 18:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:17:27 --> 404 Page Not Found: Article/view
ERROR - 2021-07-20 18:18:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 18:18:12 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-07-20 18:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:18:35 --> 404 Page Not Found: Sitemap74035html/index
ERROR - 2021-07-20 18:19:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 18:19:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 18:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:21:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:22:27 --> 404 Page Not Found: Login/index
ERROR - 2021-07-20 18:22:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:23:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 18:23:17 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-07-20 18:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:31:50 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-07-20 18:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:33:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 18:33:51 --> 404 Page Not Found: Home/tradeInfo
ERROR - 2021-07-20 18:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:38:12 --> 404 Page Not Found: Article/info
ERROR - 2021-07-20 18:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:42:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 18:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:42:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 18:42:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 18:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:51:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 18:51:57 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 18:51:57 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 18:51:57 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-20 18:51:57 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-20 18:51:58 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-20 18:51:59 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-20 18:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:52:46 --> 404 Page Not Found: Vod-search-wd-WWW585CCCCOM-p-1html/index
ERROR - 2021-07-20 18:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:56:46 --> 404 Page Not Found: Order/index
ERROR - 2021-07-20 18:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 18:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:05:04 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2021-07-20 19:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:05:30 --> 404 Page Not Found: Article/view
ERROR - 2021-07-20 19:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:16:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 19:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 19:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:18:48 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 19:18:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 19:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:18:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:19:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:19:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:19:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:19:50 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 19:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:20:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:21:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:21:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:21:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:22:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:23:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:23:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:23:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:24:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:24:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:24:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:25:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:25:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:25:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:25:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:25:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 19:25:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:27:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:27:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:28:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:28:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:28:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:28:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 19:29:26 --> 404 Page Not Found: City/15
ERROR - 2021-07-20 19:29:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:32:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 19:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:36:20 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-07-20 19:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:38:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 19:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:41:07 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2021-07-20 19:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:42:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 19:43:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 19:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:45:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 19:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:46:46 --> 404 Page Not Found: City/1
ERROR - 2021-07-20 19:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:47:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 19:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:49:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 19:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:58:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 19:58:58 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 19:58:58 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 19:58:58 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-20 19:58:58 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-20 19:58:58 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 19:58:58 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-20 19:58:58 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-20 19:58:58 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-20 19:58:58 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 19:58:58 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 19:58:58 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-20 19:58:59 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-20 19:59:00 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-20 19:59:00 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-20 19:59:00 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-20 19:59:00 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-20 19:59:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 19:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 19:59:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 20:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:01:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:01:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 20:02:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 20:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:03:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 20:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 20:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:05:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 20:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:05:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:06:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 20:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:11:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:15:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:16:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 20:17:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:24:33 --> 404 Page Not Found: SiteServer/Ajax
ERROR - 2021-07-20 20:24:33 --> 404 Page Not Found: SiteFiles/SiteTemplates
ERROR - 2021-07-20 20:24:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:24:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:27:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:27:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:28:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:33:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:34:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:36:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:45:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:45:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:48:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 20:49:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:49:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:49:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 20:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:51:47 --> 404 Page Not Found: Apigw/workflow
ERROR - 2021-07-20 20:51:56 --> 404 Page Not Found: Vod/type
ERROR - 2021-07-20 20:51:58 --> 404 Page Not Found: Bam/BizData
ERROR - 2021-07-20 20:51:58 --> 404 Page Not Found: Spa/workflow
ERROR - 2021-07-20 20:52:02 --> 404 Page Not Found: Ekp/km
ERROR - 2021-07-20 20:52:03 --> 404 Page Not Found: Api/front
ERROR - 2021-07-20 20:52:08 --> 404 Page Not Found: Easweb/webviews
ERROR - 2021-07-20 20:52:09 --> 404 Page Not Found: Spa/workflow
ERROR - 2021-07-20 20:52:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:52:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:55:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:56:04 --> 404 Page Not Found: Xxgk/zcfg
ERROR - 2021-07-20 20:56:08 --> 404 Page Not Found: Vodsearch/-------------.html
ERROR - 2021-07-20 20:56:11 --> 404 Page Not Found: Gcbz/RealDetail.aspx
ERROR - 2021-07-20 20:56:16 --> 404 Page Not Found: Shop/order
ERROR - 2021-07-20 20:56:23 --> 404 Page Not Found: CMC2/Home.aspx
ERROR - 2021-07-20 20:56:26 --> 404 Page Not Found: Ouyeelbuy-plms-web/deliveryNote
ERROR - 2021-07-20 20:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:56:45 --> 404 Page Not Found: Displayasp/index
ERROR - 2021-07-20 20:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:56:48 --> 404 Page Not Found: Ebidding/sale
ERROR - 2021-07-20 20:56:51 --> 404 Page Not Found: Learn/DoChoiceExercise
ERROR - 2021-07-20 20:56:51 --> 404 Page Not Found: Sucai/shiliangtubiao
ERROR - 2021-07-20 20:56:52 --> 404 Page Not Found: LearningCenter/HDVideo.aspx
ERROR - 2021-07-20 20:56:53 --> 404 Page Not Found: Movie/vqq
ERROR - 2021-07-20 20:56:53 --> 404 Page Not Found: News/Index
ERROR - 2021-07-20 20:56:54 --> 404 Page Not Found: 2021-05/13
ERROR - 2021-07-20 20:57:03 --> 404 Page Not Found: KNS8/Navi
ERROR - 2021-07-20 20:57:10 --> 404 Page Not Found: Ws/enroll
ERROR - 2021-07-20 20:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 20:57:12 --> 404 Page Not Found: Solution/info
ERROR - 2021-07-20 20:57:13 --> 404 Page Not Found: Jxhghtml/index
ERROR - 2021-07-20 20:57:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:57:49 --> 404 Page Not Found: VIPshipin/index_60.html
ERROR - 2021-07-20 20:57:57 --> 404 Page Not Found: Admin/ExStorage
ERROR - 2021-07-20 20:58:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 20:58:43 --> 404 Page Not Found: Search/search.htm
ERROR - 2021-07-20 20:58:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 20:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:01:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 21:01:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:09:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:10:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:10:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:10:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:10:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:11:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 21:12:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:18:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:18:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:18:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:18:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:18:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:18:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:18:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:18:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:18:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:18:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:18:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:18:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:21:15 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-07-20 21:21:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 21:22:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-20 21:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:28:33 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-20 21:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:34:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 21:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:36:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 21:36:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 21:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:39:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 21:40:22 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-20 21:40:58 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-07-20 21:41:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:42:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:42:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:42:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:42:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:43:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:43:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 21:43:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:43:12 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-20 21:43:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:44:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:44:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:45:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:45:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:47:33 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-20 21:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:49:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 21:49:20 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-20 21:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:50:58 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-20 21:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:51:48 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-20 21:51:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:52:31 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-20 21:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:53:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 21:53:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 21:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:58:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:59:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:59:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:59:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:59:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:59:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 21:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 21:59:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 21:59:56 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 21:59:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 22:01:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 22:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:02:13 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 22:02:13 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 22:02:27 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 22:02:30 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-20 22:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 22:03:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 22:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:05:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 22:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:09:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:14:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 22:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:15:07 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-20 22:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:15:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:17:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 22:17:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:19:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 22:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:20:01 --> 404 Page Not Found: English/index
ERROR - 2021-07-20 22:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:20:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 22:21:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 22:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:22:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 22:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:22:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 22:22:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 22:23:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 22:24:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:26:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:28:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:28:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:29:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 22:30:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 22:30:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 22:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:31:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:33:16 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-20 22:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:35:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:37:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:44:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 22:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:51:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 22:51:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 22:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:54:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:54:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:55:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:58:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 22:58:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 22:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 22:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:02:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 23:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:04:15 --> 404 Page Not Found: Vod-play-id-2607-sid-0-pid-183html/index
ERROR - 2021-07-20 23:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:07:11 --> 404 Page Not Found: Vod-play-id-2753-sid-0-pid-1html/index
ERROR - 2021-07-20 23:08:33 --> 404 Page Not Found: Vod-play-id-2604-sid-0-pid-166html/index
ERROR - 2021-07-20 23:09:27 --> 404 Page Not Found: Vod-play-id-2608-sid-0-pid-82html/index
ERROR - 2021-07-20 23:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:10:53 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-20 23:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:16:37 --> 404 Page Not Found: Article/info
ERROR - 2021-07-20 23:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:22:01 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-20 23:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:24:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 23:26:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:28:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:28:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:28:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:29:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 23:29:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:30:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:32:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:35:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:36:01 --> 404 Page Not Found: Vod-play-id-2778-sid-0-pid-2html/index
ERROR - 2021-07-20 23:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:37:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:42:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 23:44:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 23:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:45:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:45:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:46:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:46:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:46:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:46:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:47:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 23:48:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:48:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:48:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:48:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:48:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:49:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:49:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:49:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:49:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:49:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:49:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:50:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:50:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-20 23:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:50:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:51:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-20 23:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:52:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 23:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:54:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 23:56:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-20 23:56:48 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-20 23:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:58:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-20 23:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-20 23:59:39 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
