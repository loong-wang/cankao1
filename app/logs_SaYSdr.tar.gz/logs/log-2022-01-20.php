<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-20 00:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 00:02:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 00:15:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 00:18:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 00:35:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 00:36:01 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-20 00:37:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 00:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 01:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 01:03:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 01:04:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 01:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 01:23:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 01:25:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 01:38:31 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2022-01-20 01:45:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 02:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 02:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 02:21:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 02:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 02:46:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 02:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 03:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 03:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 03:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 03:46:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 03:54:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 03:55:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 03:55:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 03:56:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 03:57:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 03:57:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 03:58:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 03:58:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 03:59:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 04:00:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 04:00:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 04:01:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 04:01:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 04:02:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 04:03:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 04:04:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 04:07:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 04:09:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 04:09:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 04:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 04:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 04:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 04:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 04:29:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 04:41:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 04:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 05:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 05:13:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 05:16:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 05:18:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 05:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 05:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 05:37:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 05:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 05:39:16 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-20 05:39:16 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-20 05:40:05 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-20 05:40:05 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-20 05:41:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 05:41:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 05:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 05:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 05:46:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 05:47:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 05:47:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 05:47:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 05:47:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 05:47:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 06:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 06:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 06:22:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 06:22:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 06:22:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 06:26:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 06:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 06:32:46 --> 404 Page Not Found: Article/view
ERROR - 2022-01-20 06:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 06:36:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 06:42:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 06:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 06:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 07:07:51 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-01-20 07:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 07:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 07:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 07:28:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 07:28:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 07:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 07:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 07:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 07:33:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 07:34:03 --> 404 Page Not Found: Sdk/index
ERROR - 2022-01-20 07:34:03 --> 404 Page Not Found: Nmaplowercheck1642635233/index
ERROR - 2022-01-20 07:34:04 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-20 07:34:05 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-20 07:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 07:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 07:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 07:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 07:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 08:02:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 08:03:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 08:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 08:08:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 08:11:32 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2022-01-20 08:16:44 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-01-20 08:16:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 08:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 08:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 08:26:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 08:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 08:30:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 08:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 08:40:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 08:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 08:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 09:03:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 09:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 09:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 09:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 09:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 09:20:05 --> 404 Page Not Found: Sdk/index
ERROR - 2022-01-20 09:20:05 --> 404 Page Not Found: Text4041642641605/index
ERROR - 2022-01-20 09:20:05 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-20 09:20:05 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-20 09:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 09:23:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 09:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 09:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 09:46:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 09:48:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 09:51:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 09:52:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 09:53:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 09:54:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 09:57:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:04:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:12:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 10:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 10:15:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:18:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:18:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:19:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:20:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:20:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:22:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 10:31:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 10:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:35:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:37:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 10:39:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 10:41:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:41:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:42:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 10:51:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:53:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 10:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 10:56:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 10:58:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 10:59:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:02:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:02:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:02:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:03:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:06:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 11:13:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 11:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:17:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 11:19:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:22:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:27:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:28:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:28:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:28:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:31:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:31:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:31:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:31:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:32:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:32:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 11:32:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:33:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:33:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:33:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 11:36:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:36:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:37:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 11:39:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:39:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:43:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:43:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:43:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:43:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 11:45:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:50:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 11:59:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 12:00:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 12:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 12:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 12:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 12:41:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 12:42:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 12:42:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 12:43:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 12:43:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 12:44:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 12:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 12:44:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 12:56:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 12:57:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 12:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 13:02:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 13:03:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 13:06:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 13:09:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 13:09:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 13:11:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 13:11:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 13:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 13:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 13:25:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 13:27:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 13:41:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 13:45:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 13:49:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 13:49:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 13:49:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 13:49:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 13:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 14:06:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 14:19:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 14:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 14:26:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 14:27:46 --> 404 Page Not Found: Undefined/index
ERROR - 2022-01-20 14:29:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 14:29:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 14:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 14:45:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 14:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 14:48:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 14:48:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 14:49:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 14:49:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 14:49:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 14:50:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 14:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 14:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 15:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 15:03:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 15:03:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 15:08:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 15:09:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 15:09:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 15:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 15:13:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 15:13:36 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-20 15:14:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 15:14:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 15:15:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 15:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 15:17:48 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2022-01-20 15:19:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 15:20:07 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-20 15:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 15:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 15:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 15:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 15:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 15:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 15:52:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 15:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 15:52:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 15:57:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 15:57:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 15:57:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 15:58:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 16:02:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 16:05:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 16:11:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 16:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 16:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 16:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 16:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 16:38:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 16:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 16:55:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 16:55:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 16:56:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 16:57:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 16:57:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 16:57:52 --> 404 Page Not Found: Login/index
ERROR - 2022-01-20 17:06:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 17:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 17:12:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 17:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 17:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 17:33:50 --> 404 Page Not Found: Text4041642671230/index
ERROR - 2022-01-20 17:33:51 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-20 17:33:51 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-20 17:33:51 --> 404 Page Not Found: Sdk/index
ERROR - 2022-01-20 17:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 17:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 17:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 18:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 18:10:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 18:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 18:17:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 18:17:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 18:18:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-20 18:20:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 18:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 18:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 18:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 18:49:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 18:51:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 18:53:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 18:54:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 19:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 19:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 19:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 19:25:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 19:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 19:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 19:48:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-20 19:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 19:52:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 19:52:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-20 19:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 19:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 19:59:17 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-20 20:00:13 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-20 20:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:09:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-20 20:11:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:11:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 20:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:21:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 20:22:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 20:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 20:25:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 20:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:28:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 20:32:10 --> 404 Page Not Found: Seeyon/thirdpartyController.do
ERROR - 2022-01-20 20:34:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 20:34:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 20:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:37:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 20:38:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 20:39:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 20:39:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 20:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:40:08 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-20 20:42:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 20:43:45 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2022-01-20 20:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:48:57 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-20 20:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 20:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 21:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 21:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 21:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 21:07:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 21:07:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 21:12:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 21:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 21:13:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 21:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 21:19:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 21:19:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 21:20:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 21:20:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 21:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 21:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 21:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 21:42:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 21:43:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 21:44:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 21:50:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 21:51:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 21:51:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 21:52:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 21:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 21:55:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 22:01:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 22:01:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 22:01:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 22:01:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 22:02:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 22:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 22:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 22:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 22:30:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 22:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 22:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 22:55:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 22:55:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-20 22:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 23:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:11:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:19:57 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-20 23:20:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:21:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:21:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:22:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:22:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:22:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:23:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:23:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:23:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:23:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:23:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:23:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:23:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:23:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:24:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:24:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:24:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:29:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 23:35:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-20 23:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-20 23:48:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:48:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:48:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-20 23:50:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
