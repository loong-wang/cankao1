<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-10 00:00:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 00:06:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 00:16:08 --> 404 Page Not Found: Login/index
ERROR - 2021-10-10 00:17:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 00:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 00:23:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 00:25:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 00:25:31 --> 404 Page Not Found: City/10
ERROR - 2021-10-10 00:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 00:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 00:46:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:46:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:46:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:46:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:46:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:46:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:46:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:46:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:49:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:49:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:49:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:49:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:50:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:50:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:50:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:50:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:50:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:50:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:50:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:50:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 00:54:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 00:57:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 01:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 01:10:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 01:12:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 01:12:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 01:17:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:17:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:17:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:17:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:17:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:17:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:17:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:17:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:17:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:17:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:17:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:17:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:18:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:18:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:18:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:18:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:19:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:19:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:19:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:19:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:21:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:21:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:21:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:21:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:22:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:22:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:22:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:22:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:27:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:27:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:27:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:27:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:27:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:27:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:27:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:27:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 01:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 01:34:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 01:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 01:40:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 01:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 01:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 01:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 01:56:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 01:58:27 --> 404 Page Not Found: City/16
ERROR - 2021-10-10 01:58:55 --> 404 Page Not Found: City/16
ERROR - 2021-10-10 01:58:55 --> 404 Page Not Found: City/16
ERROR - 2021-10-10 01:58:55 --> 404 Page Not Found: City/16
ERROR - 2021-10-10 01:58:55 --> 404 Page Not Found: City/16
ERROR - 2021-10-10 02:00:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:01:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:01:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 02:02:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:03:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 02:06:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 02:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 02:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 02:40:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 02:49:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:50:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 02:50:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:51:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:51:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:52:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:52:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:53:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 02:54:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:54:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:57:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:58:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 02:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 02:59:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 03:00:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 03:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 03:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 03:10:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 03:10:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 03:11:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 03:12:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 03:12:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 03:12:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 03:12:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 03:12:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 03:13:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 03:13:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 03:16:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 03:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 03:19:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 03:24:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 03:24:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 03:24:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 03:24:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 03:36:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 03:39:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 03:41:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 03:49:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 03:49:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 03:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 04:00:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 04:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 04:02:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 04:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 04:20:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 04:22:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 04:22:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 04:25:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 04:25:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 04:28:40 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-10-10 04:28:47 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-10-10 04:28:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 04:28:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 04:28:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 04:29:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 04:29:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 04:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 04:29:09 --> 404 Page Not Found: Include/taglib
ERROR - 2021-10-10 04:29:22 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 04:29:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 04:29:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 04:29:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 04:29:44 --> 404 Page Not Found: Data/cache
ERROR - 2021-10-10 04:29:57 --> 404 Page Not Found: Data/cache
ERROR - 2021-10-10 04:30:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 04:30:21 --> 404 Page Not Found: Dede/templets
ERROR - 2021-10-10 04:30:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 04:30:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 04:30:36 --> 404 Page Not Found: Data/cache
ERROR - 2021-10-10 04:30:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 04:32:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 04:38:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 04:39:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 04:48:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 04:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 05:01:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 05:04:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 05:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 05:11:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 05:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 05:24:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 05:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 05:28:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 05:39:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 05:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 05:41:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 05:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 05:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 06:00:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:01:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:02:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:03:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:04:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:17:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:19:38 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-10-10 06:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 06:24:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 06:31:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:32:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:36:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 06:37:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:38:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 06:39:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 06:43:33 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-10 06:43:33 --> 404 Page Not Found: admin//index
ERROR - 2021-10-10 06:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 06:43:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 06:43:34 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-10 06:43:34 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-10-10 06:43:34 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-10-10 06:43:36 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-10-10 06:43:36 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-10-10 06:43:36 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-10-10 06:43:36 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-10-10 06:43:37 --> 404 Page Not Found: User/index
ERROR - 2021-10-10 06:43:37 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-10-10 06:43:37 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-10-10 06:43:37 --> 404 Page Not Found: Wcm/index
ERROR - 2021-10-10 06:43:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 06:47:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:48:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 06:50:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 06:53:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 07:03:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 07:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 07:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 07:06:00 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-10-10 07:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 07:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 07:07:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 07:20:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:22:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 07:23:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:23:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:25:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:26:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:26:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:27:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:28:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:29:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:30:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:30:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:30:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:31:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:33:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 07:49:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 07:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 07:54:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 07:58:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 07:59:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 08:10:25 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-10 08:16:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 08:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 09:10:02 --> 404 Page Not Found: Install/templates
ERROR - 2021-10-10 09:10:02 --> 404 Page Not Found: Templets/default
ERROR - 2021-10-10 09:10:03 --> 404 Page Not Found: Templets/plus
ERROR - 2021-10-10 09:10:03 --> 404 Page Not Found: Templets/plus
ERROR - 2021-10-10 09:10:03 --> 404 Page Not Found: Templets/plus
ERROR - 2021-10-10 09:10:03 --> 404 Page Not Found: Templets/plus
ERROR - 2021-10-10 09:10:03 --> 404 Page Not Found: Templets/plus
ERROR - 2021-10-10 09:10:03 --> 404 Page Not Found: Templets/plus
ERROR - 2021-10-10 09:10:03 --> 404 Page Not Found: Templets/default
ERROR - 2021-10-10 09:10:03 --> 404 Page Not Found: Templets/default
ERROR - 2021-10-10 09:10:03 --> 404 Page Not Found: Templets/default
ERROR - 2021-10-10 09:10:03 --> 404 Page Not Found: Member/templets
ERROR - 2021-10-10 09:10:04 --> 404 Page Not Found: Member/templets
ERROR - 2021-10-10 09:10:04 --> 404 Page Not Found: Member/templets
ERROR - 2021-10-10 09:10:04 --> 404 Page Not Found: Member/templets
ERROR - 2021-10-10 09:10:04 --> 404 Page Not Found: Member/templets
ERROR - 2021-10-10 09:10:04 --> 404 Page Not Found: Member/templets
ERROR - 2021-10-10 09:10:05 --> 404 Page Not Found: Install/sql-dfdata.txt
ERROR - 2021-10-10 09:10:05 --> 404 Page Not Found: Templets/default
ERROR - 2021-10-10 09:10:05 --> 404 Page Not Found: Templets/default
ERROR - 2021-10-10 09:10:05 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:05 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:05 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:05 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:05 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:06 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:06 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:06 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:06 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:06 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:06 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:06 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:06 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:06 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:06 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:07 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:07 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:07 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:07 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:07 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:07 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:07 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:07 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:07 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:07 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:08 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:08 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:08 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:08 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:08 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:08 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:08 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:08 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:08 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:09 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:09 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:09 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:09 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:09 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:09 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:09 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:09 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:09 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:09 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:10 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:10 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:10 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:10 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:10 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:10 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:10 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:10 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:10 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:11 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:11 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:11 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:11 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:11 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:11 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:11 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:11 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:11 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:12 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:12 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:12 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:12 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:12 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:12 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:12 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:12 --> 404 Page Not Found: Include/taglib
ERROR - 2021-10-10 09:10:13 --> 404 Page Not Found: Include/taglib
ERROR - 2021-10-10 09:10:13 --> 404 Page Not Found: Include/taglib
ERROR - 2021-10-10 09:10:13 --> 404 Page Not Found: Include/taglib
ERROR - 2021-10-10 09:10:13 --> 404 Page Not Found: Include/taglib
ERROR - 2021-10-10 09:10:13 --> 404 Page Not Found: Include/taglib
ERROR - 2021-10-10 09:10:13 --> 404 Page Not Found: Templets/system
ERROR - 2021-10-10 09:10:13 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:13 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:13 --> 404 Page Not Found: Member/space
ERROR - 2021-10-10 09:10:13 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-10-10 09:10:14 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-10-10 09:10:14 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-10-10 09:10:14 --> 404 Page Not Found: Dede/templets
ERROR - 2021-10-10 09:10:14 --> 404 Page Not Found: Dede/templets
ERROR - 2021-10-10 09:10:14 --> 404 Page Not Found: Dede/templets
ERROR - 2021-10-10 09:10:15 --> 404 Page Not Found: Dede/templets
ERROR - 2021-10-10 09:10:15 --> 404 Page Not Found: Dede/templets
ERROR - 2021-10-10 09:10:15 --> 404 Page Not Found: Dede/templets
ERROR - 2021-10-10 09:10:15 --> 404 Page Not Found: Dede/templets
ERROR - 2021-10-10 09:10:15 --> 404 Page Not Found: Dede/templets
ERROR - 2021-10-10 09:10:15 --> 404 Page Not Found: Dede/templets
ERROR - 2021-10-10 09:10:15 --> 404 Page Not Found: Install/templates
ERROR - 2021-10-10 09:13:22 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-10 09:20:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 09:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 09:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 09:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 09:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 09:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 09:52:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 09:52:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 09:52:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 09:55:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 10:00:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 10:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 10:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 10:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 10:32:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 10:33:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 10:35:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 10:44:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 10:44:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 10:46:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 10:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 10:49:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 10:51:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 10:54:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 10:54:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 10:58:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 10:59:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 11:00:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 11:17:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 11:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 11:49:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 11:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 11:50:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 11:51:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 11:52:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 11:52:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:01:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:02:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:02:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:03:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:04:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:05:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:07:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:07:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:08:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:09:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:09:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:10:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:10:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:10:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:10:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:10:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 12:13:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 12:23:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 12:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 12:34:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 12:36:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 12:38:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 12:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 12:56:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 13:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 13:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 13:13:08 --> 404 Page Not Found: Index/login
ERROR - 2021-10-10 13:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 13:36:18 --> 404 Page Not Found: Page/images
ERROR - 2021-10-10 13:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 13:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 14:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 14:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 14:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 14:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 15:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 15:20:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 15:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 15:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 15:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 15:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 15:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 15:31:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 15:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 15:37:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 15:40:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:40:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:40:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:41:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:42:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 15:42:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:43:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:43:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:43:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:43:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:45:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:49 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:49 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:45:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:46:01 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:46:01 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:46:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:46:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:46:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:46:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:46:26 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:46:26 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:46:26 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:46:26 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-10 15:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 15:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 15:53:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:53:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:54:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:54:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 15:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:58:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:58:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 15:59:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 16:08:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:09:18 --> 404 Page Not Found: User/index
ERROR - 2021-10-10 16:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 16:12:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 16:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 16:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 16:24:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 16:30:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:31:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:31:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:32:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 16:32:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 16:32:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:33:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:34:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:34:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:35:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 16:38:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:39:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:40:45 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-10-10 16:40:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:41:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:43:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 16:43:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:44:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:44:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:44:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:45:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:45:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:45:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:50:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 16:52:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:54:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:54:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:55:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:55:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:55:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:56:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 16:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 17:23:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 17:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 18:07:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:09:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:10:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:13:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:13:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 18:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:18:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:18:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 18:19:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 18:19:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:20:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 18:21:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 18:22:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:23:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 18:23:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:24:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:28:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:28:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 18:30:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 18:33:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 18:34:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 18:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 18:37:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 18:46:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:46:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:46:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:46:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:48:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 18:48:35 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-10-10 18:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 19:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 19:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 19:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 19:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 19:35:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 19:38:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 19:38:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 19:39:35 --> 404 Page Not Found: User/index
ERROR - 2021-10-10 19:49:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 19:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 19:54:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 20:00:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 20:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 20:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 20:04:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 20:23:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:24:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 20:26:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:34:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 20:35:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:37:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:39:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:39:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:41:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:41:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 20:41:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 20:41:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:41:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:41:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:42:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:42:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:42:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:42:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:42:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:42:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:43:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:43:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:44:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:44:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:44:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:46:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:46:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:47:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 20:47:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:47:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:47:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:48:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:48:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:49:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:49:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:49:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 20:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 20:51:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 20:55:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 20:58:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-10 20:58:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 21:03:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:04:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 21:08:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:09:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 21:09:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:09:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:16:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:16:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:20:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:22:59 --> 404 Page Not Found: Cart/index
ERROR - 2021-10-10 21:35:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:36:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:36:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:36:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 21:37:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:43:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:43:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:44:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:45:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:45:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:47:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:49:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 21:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 21:58:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 22:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 22:03:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 22:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 22:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 22:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 22:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 22:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 22:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 22:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 22:54:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 22:54:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 22:56:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 22:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 23:01:01 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-10-10 23:01:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-10 23:03:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:12:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:12:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:13:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:15:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:15:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:16:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:16:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 23:28:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:31:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:35:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:36:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:37:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:40:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:40:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:45:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:46:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:46:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:46:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:46:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-10 23:55:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:55:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-10 23:56:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-10 23:58:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
