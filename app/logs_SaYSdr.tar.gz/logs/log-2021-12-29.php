<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-29 00:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 00:02:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 00:09:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 00:09:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 00:11:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 00:14:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 00:21:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 00:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 00:28:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 00:39:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 00:41:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 00:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 00:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 00:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 00:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 00:47:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 00:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 01:02:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 01:02:50 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-12-29 01:05:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 01:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 01:11:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 01:15:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 01:15:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 01:18:48 --> 404 Page Not Found: City/10
ERROR - 2021-12-29 01:19:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 01:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 01:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 01:25:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 01:25:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 01:30:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 01:32:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 01:35:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 01:42:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 01:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 02:03:44 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-29 02:03:44 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-29 02:03:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 02:03:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:03:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:03:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:03:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 02:03:47 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-29 02:03:47 --> 404 Page Not Found: Member/space
ERROR - 2021-12-29 02:03:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:03:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:03:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 02:03:48 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 02:03:49 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 02:03:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:03:51 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-29 02:03:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:03:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:03:51 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 02:03:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 02:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 02:21:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 02:25:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 02:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 02:41:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:47:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 02:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 02:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 02:57:44 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-29 02:57:44 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-29 02:57:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 02:57:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:57:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:57:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:57:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 02:57:44 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-29 02:57:46 --> 404 Page Not Found: Member/space
ERROR - 2021-12-29 02:57:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:57:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:57:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 02:57:46 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 02:57:46 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 02:57:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:57:48 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-29 02:57:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:57:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:57:48 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 02:57:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 02:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:15:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 03:15:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 03:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:40:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 03:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 03:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:51:10 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-12-29 03:51:49 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-29 03:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:55:30 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-29 03:55:30 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-29 03:55:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 03:55:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 03:55:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 03:55:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 03:55:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 03:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 03:55:32 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-29 03:55:32 --> 404 Page Not Found: Member/space
ERROR - 2021-12-29 03:55:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 03:55:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 03:55:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 03:55:34 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 03:55:35 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 03:55:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 03:55:38 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-29 03:55:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 03:55:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 03:55:38 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 03:55:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 04:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 04:08:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 04:08:31 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-29 04:08:35 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-29 04:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 04:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 04:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 04:20:07 --> 404 Page Not Found: Mobile/v3
ERROR - 2021-12-29 04:21:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 04:29:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-29 04:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 04:38:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 04:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 04:47:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 04:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 04:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 04:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 04:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 04:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 05:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 05:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 05:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 05:18:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 05:30:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 05:32:34 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-12-29 05:32:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 05:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 05:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 05:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 05:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 05:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 05:50:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 05:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 06:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 06:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 06:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 06:17:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 06:24:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 06:24:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 06:30:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 06:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 06:50:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 07:02:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 07:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 07:11:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 07:11:20 --> 404 Page Not Found: Gczfw/index
ERROR - 2021-12-29 07:16:50 --> 404 Page Not Found: Jsgc/gbp
ERROR - 2021-12-29 07:16:54 --> 404 Page Not Found: Wap/web
ERROR - 2021-12-29 07:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 07:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 07:32:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 07:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 07:47:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 07:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 07:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 07:54:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 08:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 08:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 08:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 08:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 08:31:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 08:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 08:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 08:43:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 08:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 08:45:44 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-29 08:46:09 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-29 08:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 08:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 08:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 09:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 09:07:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 09:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 09:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 09:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 09:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 09:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 09:20:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 09:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 09:33:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 09:34:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 09:36:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 09:41:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 09:43:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 09:43:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 09:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 09:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 09:44:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 09:44:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 09:44:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 09:46:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 09:46:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-29 09:47:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 09:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 09:50:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 09:50:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 09:55:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 09:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 10:00:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 10:01:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 10:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 10:09:46 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-29 10:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 10:20:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 10:33:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 10:36:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 10:37:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 10:38:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 10:40:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 10:40:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 10:40:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 10:40:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 10:41:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 10:45:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 10:48:02 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-29 10:49:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 10:52:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 10:53:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 10:54:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 10:55:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 10:55:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 10:55:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 10:55:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 10:55:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 10:56:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 10:56:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 10:56:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 11:03:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 11:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 11:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 11:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:17:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 11:22:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:23:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:27:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:27:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:36:01 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-29 11:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 11:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 11:42:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:42:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 11:43:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:43:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:48:52 --> 404 Page Not Found: Core/favicon.ico
ERROR - 2021-12-29 11:49:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 11:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 11:52:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:56:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 11:57:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 11:59:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:01:43 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-12-29 12:02:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 12:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 12:08:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 12:10:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 12:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 12:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 12:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:23:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 12:35:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:35:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:36:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 12:36:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:37:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:38:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 12:38:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:38:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:38:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 12:39:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 12:45:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 12:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 12:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 12:55:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:55:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:55:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:57:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 12:57:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 13:09:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 13:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:13:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:14:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 13:14:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 13:15:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:15:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 13:23:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:25:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:26:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:26:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:26:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:26:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:26:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:27:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:27:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:28:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:28:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:29:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:29:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:29:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:29:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:32:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:32:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:34:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:34:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:35:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:35:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:35:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:35:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 13:35:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 13:36:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:36:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:36:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:37:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:37:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:37:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:37:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 13:38:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 13:38:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:38:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:39:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:39:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:39:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:39:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:39:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:39:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:39:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:39:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:39:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:39:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:40:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:40:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:40:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:40:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:40:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:40:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:40:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:41:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:41:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:41:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:41:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:41:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:41:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:41:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:41:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:42:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:42:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:42:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:42:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:43:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:43:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:43:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:43:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:43:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:43:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:43:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:43:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:44:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:44:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:44:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:44:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:44:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:44:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 13:45:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:45:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:45:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:45:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:46:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:46:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:46:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:46:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:47:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:47:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:47:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:47:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:47:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:47:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:47:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:48:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:48:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:48:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:48:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:48:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:48:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:48:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:48:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:49:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:49:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:49:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:50:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:50:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:50:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:50:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:50:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:50:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:50:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:50:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:51:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:51:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:51:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:51:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:51:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:51:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:52:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:52:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:52:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:52:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:52:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:52:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:52:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:52:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:53:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:53:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:53:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:53:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:53:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:53:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:54:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 13:54:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 13:54:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 13:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 14:00:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 14:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:01:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:02:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 14:02:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:02:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 14:03:14 --> 404 Page Not Found: Sdk/index
ERROR - 2021-12-29 14:03:14 --> 404 Page Not Found: Text4041640757794/index
ERROR - 2021-12-29 14:03:14 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-12-29 14:03:15 --> 404 Page Not Found: Evox/about
ERROR - 2021-12-29 14:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 14:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:07:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:07:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 14:07:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 14:11:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 14:11:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 14:11:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 14:13:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 14:13:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 14:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:35:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 14:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 14:41:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:42:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:42:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:42:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:43:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:43:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 14:43:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:43:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:44:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:47:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 14:47:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 14:48:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:49:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:49:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:52:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 14:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:56:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:56:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:56:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:58:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 14:58:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 14:58:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 14:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 15:01:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 15:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 15:07:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 15:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 15:11:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 15:12:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 15:13:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:13:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 15:16:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:16:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 15:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 15:28:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 15:35:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 15:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 15:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 15:39:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:39:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:45:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 15:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 15:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 15:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 15:53:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:53:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:57:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:57:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:58:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:58:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 15:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:02:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 16:08:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 16:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 16:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 16:25:27 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-29 16:25:27 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-29 16:25:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 16:25:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 16:25:27 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-29 16:25:28 --> 404 Page Not Found: Member/space
ERROR - 2021-12-29 16:25:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 16:25:28 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 16:25:28 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 16:25:31 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-29 16:25:31 --> 404 Page Not Found: Member/space
ERROR - 2021-12-29 16:25:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 16:25:32 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 16:25:33 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 16:25:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:33 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-29 16:25:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:25:33 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 16:25:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 16:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:26:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:28:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:28:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:28:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:28:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:28:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:28:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 16:35:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 16:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 16:53:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 16:58:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:58:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 16:58:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:00:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:01:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 17:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 17:05:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:05:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:06:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 17:08:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 17:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:10:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:10:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:10:36 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-29 17:10:37 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-29 17:10:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 17:10:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:10:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:10:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:10:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 17:10:38 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-29 17:10:39 --> 404 Page Not Found: Member/space
ERROR - 2021-12-29 17:10:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:10:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:10:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 17:10:39 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 17:10:39 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 17:10:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:10:40 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-29 17:10:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:10:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:10:40 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 17:10:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:11:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:11:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:11:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:12:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:17:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:17:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:30:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:30:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:31:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:32:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 17:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 17:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 17:46:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 17:52:42 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-29 17:52:43 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-29 17:52:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 17:52:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:52:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:52:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:52:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 17:52:45 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-29 17:52:45 --> 404 Page Not Found: Member/space
ERROR - 2021-12-29 17:52:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:52:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:52:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 17:52:47 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 17:52:47 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 17:52:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:52:47 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-29 17:52:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:52:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:52:48 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-29 17:52:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 17:53:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 18:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 18:13:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 18:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 18:26:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 18:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 18:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 18:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 18:52:17 --> 404 Page Not Found: City/10
ERROR - 2021-12-29 18:56:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 18:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 18:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 18:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 18:58:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 18:58:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 19:10:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 19:10:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 19:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 19:16:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 19:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 19:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 19:27:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 19:27:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 19:27:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 19:28:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 19:28:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 19:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 19:35:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 19:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 19:38:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 19:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 19:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 19:52:15 --> 404 Page Not Found: Console/login
ERROR - 2021-12-29 19:52:15 --> 404 Page Not Found: Console/login
ERROR - 2021-12-29 19:52:15 --> 404 Page Not Found: Console/LoginForm.jsp
ERROR - 2021-12-29 19:52:15 --> 404 Page Not Found: Console/Login.jsp
ERROR - 2021-12-29 19:52:15 --> 404 Page Not Found: Loginjsp/index
ERROR - 2021-12-29 19:52:15 --> 404 Page Not Found: LoginFormjsp/index
ERROR - 2021-12-29 19:52:15 --> 404 Page Not Found: Solr/admin
ERROR - 2021-12-29 19:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 19:55:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 20:00:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 20:03:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 20:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 20:06:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 20:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 20:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 20:18:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 20:29:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 20:29:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 20:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 20:32:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 20:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 20:38:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 20:40:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 20:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 20:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 20:50:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 20:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 20:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 20:56:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 20:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:20:23 --> 404 Page Not Found: City/index
ERROR - 2021-12-29 21:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:36:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 21:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:36:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 21:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 21:44:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 21:46:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 21:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 21:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 21:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 21:47:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 21:48:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 21:48:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 21:48:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 21:49:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 21:51:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 21:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 22:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 22:09:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 22:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 22:11:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 22:12:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:13:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:14:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:14:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:15:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:15:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:18:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:18:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 22:18:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:18:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-29 22:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 22:22:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:22:52 --> 404 Page Not Found: Nmaplowercheck1640787771/index
ERROR - 2021-12-29 22:22:52 --> 404 Page Not Found: Evox/about
ERROR - 2021-12-29 22:22:52 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-12-29 22:23:04 --> 404 Page Not Found: Sdk/index
ERROR - 2021-12-29 22:23:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:24:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:25:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 22:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 22:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:29:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 22:30:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 22:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 22:34:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 22:45:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 22:45:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 22:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 22:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 22:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 22:58:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:00:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 23:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:14:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 23:15:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 23:19:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 23:22:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-29 23:27:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 23:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:32:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 23:32:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 23:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:35:44 --> 404 Page Not Found: City/10
ERROR - 2021-12-29 23:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:40:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 23:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 23:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 23:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 23:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 23:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 23:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-29 23:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:44:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 23:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 23:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:53:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-29 23:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-29 23:57:30 --> 404 Page Not Found: Robotstxt/index
