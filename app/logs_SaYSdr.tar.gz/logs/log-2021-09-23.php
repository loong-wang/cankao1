<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-23 00:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:00:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 00:01:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:02:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:02:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 00:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:03:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 00:03:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:03:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 00:04:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:05:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:07:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:08:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:09:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:10:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:11:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:11:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:12:09 --> 404 Page Not Found: Text4041632327128/index
ERROR - 2021-09-23 00:12:09 --> 404 Page Not Found: Evox/about
ERROR - 2021-09-23 00:12:09 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-09-23 00:12:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:12:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:13:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:15:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:16:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:18:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:19:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:19:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:19:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:20:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 00:21:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 00:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:28:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:28:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:28:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:30:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:32:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:33:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:34:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:36:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:37:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:37:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:40:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 00:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:42:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:45:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 00:45:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:47:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:47:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:48:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:48:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:49:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:50:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:51:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 00:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:51:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:52:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:53:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 00:53:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:53:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:53:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 00:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:54:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:56:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:57:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:58:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:59:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 00:59:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 00:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:01:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:01:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:02:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:03:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:03:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:03:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:04:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 01:05:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:06:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 01:09:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:09:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 01:10:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:11:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 01:11:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 01:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:13:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:13:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:16:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:18:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 01:19:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-23 01:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:22:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:22:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 01:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:23:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:23:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:25:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 01:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:25:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:26:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:27:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 01:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:29:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:30:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:36:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 01:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:37:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 01:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:37:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:38:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:39:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:39:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:41:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:41:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:43:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:44:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:45:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:46:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 01:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:48:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:49:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:54:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 01:54:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 01:57:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 01:58:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 02:00:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:04:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:05:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:07:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:07:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:09:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:13:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 02:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:15:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:16:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:17:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:18:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:24:09 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-09-23 02:24:09 --> 404 Page Not Found: Feed/index
ERROR - 2021-09-23 02:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:24:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:26:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:27:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:27:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:30:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:31:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:32:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:33:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:35:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 02:35:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:37:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:38:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:45:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:48:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 02:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:48:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 02:49:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 02:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:50:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 02:50:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 02:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:53:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:54:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:55:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:55:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 02:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:55:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:56:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:57:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:57:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 02:57:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:59:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 02:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 02:59:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 02:59:56 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-23 03:00:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:00:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:01:37 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-23 03:01:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:02:30 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-23 03:02:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:04:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:05:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 03:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:08:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 03:08:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:09:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:09:59 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-23 03:10:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:13:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:14:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 03:14:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:15:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:18:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 03:18:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:20:01 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-23 03:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:24:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:26:34 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-23 03:26:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 03:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:27:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:27:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 03:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:29:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:30:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:30:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 03:32:18 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-23 03:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:33:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:34:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:37:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:37:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:38:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:39:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:40:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:40:31 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-23 03:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:44:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:44:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:46:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:48:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:49:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-23 03:49:42 --> Severity: Warning --> Missing argument 1 for Taocan::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 181
ERROR - 2021-09-23 03:49:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:49:49 --> Severity: Warning --> Missing argument 1 for Taocan::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 101
ERROR - 2021-09-23 03:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:53:54 --> 404 Page Not Found: City/1
ERROR - 2021-09-23 03:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 03:58:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:59:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 03:59:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 03:59:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:01:02 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-09-23 04:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:01:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:03:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 04:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:03:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:04:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 04:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:04:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:06:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:06:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 04:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:08:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 04:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:11:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:12:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:12:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 04:13:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 04:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:14:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 04:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:16:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:18:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:18:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:20:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:22:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:23:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:23:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:24:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:25:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:28:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:28:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:30:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:30:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:31:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:34:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:35:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 04:36:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 04:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:37:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 04:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:38:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:39:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:40:01 --> 404 Page Not Found: City/16
ERROR - 2021-09-23 04:40:01 --> 404 Page Not Found: City/16
ERROR - 2021-09-23 04:40:01 --> 404 Page Not Found: City/16
ERROR - 2021-09-23 04:40:01 --> 404 Page Not Found: City/16
ERROR - 2021-09-23 04:40:01 --> 404 Page Not Found: City/16
ERROR - 2021-09-23 04:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:41:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 04:42:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 04:43:25 --> 404 Page Not Found: Env/index
ERROR - 2021-09-23 04:43:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:45:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:45:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 04:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:50:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:52:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 04:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:52:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:53:14 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-23 04:53:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:53:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:53:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 04:54:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 04:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:57:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 04:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 04:59:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:01:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:02:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 05:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:04:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:05:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:06:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:08:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 05:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:08:40 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-23 05:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:09:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:10:17 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-23 05:10:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:11:23 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-23 05:13:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:17:16 --> 404 Page Not Found: News_showasp/index
ERROR - 2021-09-23 05:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:18:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 05:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:20:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:21:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:21:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 05:21:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:22:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:24:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:25:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 05:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:25:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 05:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:26:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:26:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 05:26:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:28:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:28:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:29:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:30:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:32:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:33:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:33:27 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-23 05:33:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 05:33:33 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-23 05:33:43 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-23 05:33:57 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-23 05:34:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:34:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:34:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:38:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:39:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:40:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:41:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 05:41:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:43:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:43:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 05:44:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:44:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:45:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 05:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:50:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:52:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:53:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:54:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:54:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:54:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:55:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:55:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:56:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:57:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 05:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:57:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:57:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 05:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 05:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:00:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:02:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:04:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:05:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:06:01 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-23 06:06:03 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-23 06:06:04 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-23 06:06:05 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-23 06:06:05 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-23 06:06:06 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-23 06:06:07 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-23 06:06:08 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-09-23 06:06:08 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-23 06:06:09 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-23 06:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:06:10 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-23 06:06:11 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-23 06:06:11 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-23 06:06:12 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-23 06:06:13 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-23 06:06:14 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-09-23 06:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:07:45 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-09-23 06:09:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:09:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:11:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:12:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:12:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:12:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 06:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:14:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:16:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:16:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 06:16:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 06:17:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:18:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:19:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:20:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:24:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:24:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:26:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:26:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:27:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:29:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:31:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:32:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:36:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:39:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:41:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:41:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:44:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:45:39 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-23 06:45:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:46:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:47:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:49:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:49:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:51:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:53:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:54:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:54:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:55:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 06:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:56:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:56:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:59:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:59:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 06:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 06:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:00:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:00:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 07:01:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:03:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 07:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:05:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:05:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 07:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:07:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:09:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 07:09:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:11:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:11:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 07:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:12:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 07:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:18:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:18:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:19:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:20:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 07:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:21:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 07:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:22:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:24:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:25:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:26:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:28:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:30:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:32:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:32:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:34:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 07:35:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 07:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:36:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:38:33 --> 404 Page Not Found: English/index
ERROR - 2021-09-23 07:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:40:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:41:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:42:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:44:16 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-23 07:44:16 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-23 07:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:45:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:47:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:47:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:47:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:47:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:51:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 07:51:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 07:52:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 07:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:53:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 07:53:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 07:53:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 07:53:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 07:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 07:53:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 07:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:55:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:55:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:56:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:59:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 07:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 07:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 08:00:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:01:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 08:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:01:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 08:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:02:01 --> 404 Page Not Found: City/1
ERROR - 2021-09-23 08:02:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:07:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:08:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:08:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 08:08:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 08:09:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:09:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 08:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 08:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:10:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:10:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:14:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:15:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 08:15:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 08:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:17:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:18:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 08:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:19:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:20:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:20:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 08:20:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:25:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:25:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 08:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:27:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:27:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:29:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 08:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:32:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:33:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:34:26 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-23 08:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:37:32 --> 404 Page Not Found: Env/index
ERROR - 2021-09-23 08:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:43:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:45:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:45:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:49:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:50:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:50:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:55:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 08:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:56:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 08:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 08:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:03:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 09:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:04:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 09:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:05:03 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-23 09:05:03 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-23 09:05:03 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-23 09:05:03 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-23 09:05:03 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-23 09:05:03 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-23 09:05:03 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-23 09:05:03 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-23 09:05:03 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-23 09:05:03 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-23 09:05:03 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-23 09:05:04 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-23 09:05:05 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-23 09:05:05 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-23 09:05:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-23 09:05:05 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-23 09:05:05 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-23 09:05:05 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-23 09:05:05 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-23 09:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:05:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 09:05:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:05:58 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-23 09:06:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:06:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 09:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 09:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:07:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:07:31 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-23 09:07:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:10:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 09:11:12 --> 404 Page Not Found: City/10
ERROR - 2021-09-23 09:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:12:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 09:13:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:14:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 09:15:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:15:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:15:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:17:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 09:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:17:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 09:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:20:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:26:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:27:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:28:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:29:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:30:47 --> 404 Page Not Found: Sitemap87198html/index
ERROR - 2021-09-23 09:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:31:03 --> 404 Page Not Found: Previewdo/index
ERROR - 2021-09-23 09:31:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 09:31:25 --> 404 Page Not Found: Previewdo/index
ERROR - 2021-09-23 09:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:32:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:33:38 --> 404 Page Not Found: City/1
ERROR - 2021-09-23 09:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:47:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:50:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:51:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 09:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:52:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 09:52:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:53:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:54:36 --> 404 Page Not Found: Haoma/index
ERROR - 2021-09-23 09:54:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:55:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 09:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:57:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 09:59:20 --> 404 Page Not Found: Html-en/products--3-0-2-2.html
ERROR - 2021-09-23 09:59:27 --> 404 Page Not Found: Vod-play-id-2779-sid-0-pid-4html/index
ERROR - 2021-09-23 09:59:31 --> 404 Page Not Found: Vod-play-id-2608-sid-0-pid-205html/index
ERROR - 2021-09-23 09:59:34 --> 404 Page Not Found: Vod-play-id-2785-sid-0-pid-19html/index
ERROR - 2021-09-23 09:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:59:35 --> 404 Page Not Found: Vod-play-id-2226-sid-0-pid-9html/index
ERROR - 2021-09-23 09:59:42 --> 404 Page Not Found: Vod-play-id-2682-sid-0-pid-202html/index
ERROR - 2021-09-23 09:59:44 --> 404 Page Not Found: Vod-play-id-2612-sid-0-pid-26html/index
ERROR - 2021-09-23 09:59:47 --> 404 Page Not Found: Vod-play-id-2729-sid-0-pid-96html/index
ERROR - 2021-09-23 09:59:53 --> 404 Page Not Found: Vod-play-id-2606-sid-0-pid-125html/index
ERROR - 2021-09-23 09:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 09:59:57 --> 404 Page Not Found: Vod-play-id-2742-sid-0-pid-15html/index
ERROR - 2021-09-23 10:00:08 --> 404 Page Not Found: Vod-play-id-2786-sid-0-pid-20html/index
ERROR - 2021-09-23 10:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:00:12 --> 404 Page Not Found: Sitemap31910html/index
ERROR - 2021-09-23 10:00:16 --> 404 Page Not Found: Vod-play-id-2661-sid-0-pid-171html/index
ERROR - 2021-09-23 10:00:18 --> 404 Page Not Found: Vod-play-id-2228-sid-0-pid-164html/index
ERROR - 2021-09-23 10:00:25 --> 404 Page Not Found: Vod-play-id-2778-sid-0-pid-4html/index
ERROR - 2021-09-23 10:00:31 --> 404 Page Not Found: Vod-play-id-2607-sid-0-pid-38html/index
ERROR - 2021-09-23 10:00:33 --> 404 Page Not Found: Vod-play-id-2226-sid-0-pid-136html/index
ERROR - 2021-09-23 10:00:38 --> 404 Page Not Found: Vod-play-id-2597-sid-0-pid-4html/index
ERROR - 2021-09-23 10:00:41 --> 404 Page Not Found: Vod-play-id-2346-sid-0-pid-47html/index
ERROR - 2021-09-23 10:00:44 --> 404 Page Not Found: Vod-play-id-2661-sid-0-pid-109html/index
ERROR - 2021-09-23 10:00:48 --> 404 Page Not Found: Vod-search-wd-%E5%B4%94%E9%92%9F%E8%AE%AD-p-1html/index
ERROR - 2021-09-23 10:00:51 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-25html/index
ERROR - 2021-09-23 10:00:53 --> 404 Page Not Found: Vod-play-id-2606-sid-0-pid-15html/index
ERROR - 2021-09-23 10:00:55 --> 404 Page Not Found: Vod-play-id-2226-sid-0-pid-94html/index
ERROR - 2021-09-23 10:00:56 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-19html/index
ERROR - 2021-09-23 10:00:59 --> 404 Page Not Found: Vod-play-id-2736-sid-0-pid-12html/index
ERROR - 2021-09-23 10:01:01 --> 404 Page Not Found: Vod-play-id-2709-sid-0-pid-17html/index
ERROR - 2021-09-23 10:01:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:01:10 --> 404 Page Not Found: Vod-play-id-2311-sid-0-pid-14html/index
ERROR - 2021-09-23 10:01:14 --> 404 Page Not Found: Vod-play-id-2226-sid-0-pid-192html/index
ERROR - 2021-09-23 10:01:22 --> 404 Page Not Found: Vod-play-id-2421-sid-0-pid-107html/index
ERROR - 2021-09-23 10:01:24 --> 404 Page Not Found: Vod-play-id-2597-sid-0-pid-98html/index
ERROR - 2021-09-23 10:01:26 --> 404 Page Not Found: Vod-play-id-2309-sid-0-pid-6html/index
ERROR - 2021-09-23 10:01:34 --> 404 Page Not Found: Vod-play-id-2607-sid-0-pid-208html/index
ERROR - 2021-09-23 10:01:49 --> 404 Page Not Found: Vod-play-id-2739-sid-0-pid-28html/index
ERROR - 2021-09-23 10:01:51 --> 404 Page Not Found: Vod-play-id-2704-sid-0-pid-61html/index
ERROR - 2021-09-23 10:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:02:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:02:06 --> 404 Page Not Found: Vod-play-id-2743-sid-0-pid-8html/index
ERROR - 2021-09-23 10:02:15 --> 404 Page Not Found: Vod-play-id-2743-sid-0-pid-37html/index
ERROR - 2021-09-23 10:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:02:20 --> 404 Page Not Found: Vod-play-id-2603-sid-0-pid-178html/index
ERROR - 2021-09-23 10:02:32 --> 404 Page Not Found: Vod-play-id-2604-sid-0-pid-1html/index
ERROR - 2021-09-23 10:02:34 --> 404 Page Not Found: Vod-play-id-2682-sid-0-pid-122html/index
ERROR - 2021-09-23 10:02:36 --> 404 Page Not Found: Vod-play-id-2680-sid-0-pid-165html/index
ERROR - 2021-09-23 10:02:39 --> 404 Page Not Found: Vod-play-id-2682-sid-0-pid-167html/index
ERROR - 2021-09-23 10:02:40 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-122html/index
ERROR - 2021-09-23 10:02:47 --> 404 Page Not Found: Vod-play-id-2669-sid-0-pid-59html/index
ERROR - 2021-09-23 10:02:49 --> 404 Page Not Found: Vod-play-id-2671-sid-0-pid-9html/index
ERROR - 2021-09-23 10:02:59 --> 404 Page Not Found: Vod-search-wd-%E6%9D%A8%E9%94%A6%E9%BA%9F-p-1html/index
ERROR - 2021-09-23 10:03:11 --> 404 Page Not Found: Vod-play-id-2675-sid-0-pid-1html/index
ERROR - 2021-09-23 10:03:17 --> 404 Page Not Found: Vod-play-id-2612-sid-0-pid-42html/index
ERROR - 2021-09-23 10:03:19 --> 404 Page Not Found: Vod-search-wd-%E5%B2%A9%E7%94%B0%E5%85%89%E5%A4%AE-p-1html/index
ERROR - 2021-09-23 10:03:21 --> 404 Page Not Found: Vod-play-id-2669-sid-0-pid-15html/index
ERROR - 2021-09-23 10:03:23 --> 404 Page Not Found: Vod-play-id-2320-sid-0-pid-29html/index
ERROR - 2021-09-23 10:03:26 --> 404 Page Not Found: Vod-search-wd-NormanLear-p-1html/index
ERROR - 2021-09-23 10:03:34 --> 404 Page Not Found: Vod-play-id-2721-sid-0-pid-4html/index
ERROR - 2021-09-23 10:03:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:07:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:09:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:12:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:14:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:14:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:16:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:18:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:21:38 --> 404 Page Not Found: Index/login
ERROR - 2021-09-23 10:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:23:30 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-23 10:23:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:23:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:29:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:40:08 --> 404 Page Not Found: ReportServer/index
ERROR - 2021-09-23 10:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 10:44:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 10:44:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 10:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:48:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 10:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:51:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 10:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:53:27 --> 404 Page Not Found: Sitemap91737html/index
ERROR - 2021-09-23 10:53:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 10:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:54:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 10:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:56:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 10:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:56:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 10:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 10:59:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:02:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:05:07 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-23 11:05:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 11:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:06:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:06:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:07:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:07:30 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-23 11:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:07:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:07:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:07:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:08:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:08:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:11:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:12:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:13:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 11:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:13:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:13:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:14:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:14:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:14:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:14:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:15:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:15:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:15:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-23 11:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:18:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:18:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:18:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:18:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:18:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:18:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:18:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:18:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:18:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:19:32 --> 404 Page Not Found: City/16
ERROR - 2021-09-23 11:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:34:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 11:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:40:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 11:40:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:43:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 11:43:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:43:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:43:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 11:43:56 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:43:56 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:01 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:01 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:11 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:11 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:16 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:16 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:26 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:26 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:44:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:44:41 --> 404 Page Not Found: English/index
ERROR - 2021-09-23 11:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:45:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:45:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 11:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:46:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:46:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 11:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:50:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 11:51:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:51:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:51:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:51:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:51:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:51:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:52:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:54:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 11:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:55:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:55:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:56:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:56:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 11:57:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 11:57:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 11:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:03:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-23 12:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:12:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 12:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:24:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:24:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:24:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:24:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:24:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:24:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:25:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:25:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:26:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:26:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:26:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:26:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:26:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:27:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:27:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:27:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:27:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:27:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:27:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:27:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:28:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:28:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:28:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:28:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:28:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:32:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:32:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:32:31 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-09-23 12:32:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:33:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:33:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:33:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:33:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:34:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:35:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:36:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 12:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:44:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 12:44:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 12:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:50:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 12:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:55:19 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-86html/index
ERROR - 2021-09-23 12:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:56:48 --> 404 Page Not Found: Vod-play-id-2608-sid-0-pid-190html/index
ERROR - 2021-09-23 12:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:57:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 12:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 12:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:01:02 --> 404 Page Not Found: Vod-play-id-2390-sid-0-pid-109html/index
ERROR - 2021-09-23 13:01:07 --> 404 Page Not Found: Vod-search-wd-%E9%A9%AC%E7%89%B9%C2%B7%E8%8E%B1%E6%96%AF%E5%88%87%E5%B0%94-p-1html/index
ERROR - 2021-09-23 13:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:01:08 --> 404 Page Not Found: Vod-play-id-2628-sid-0-pid-1html/index
ERROR - 2021-09-23 13:01:12 --> 404 Page Not Found: Vod-play-id-2604-sid-0-pid-49html/index
ERROR - 2021-09-23 13:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:14:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 13:14:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 13:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 13:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:24:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:27:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:27:57 --> 404 Page Not Found: Sitemap99468html/index
ERROR - 2021-09-23 13:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:31:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 13:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:37:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 13:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:00:45 --> 404 Page Not Found: City/10
ERROR - 2021-09-23 14:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:04:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 14:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:06:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 14:06:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 14:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:12:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 14:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:13:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 14:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:18:15 --> 404 Page Not Found: English/index
ERROR - 2021-09-23 14:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:20:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:21:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:22:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:22:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:23:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:23:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:23:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:24:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:25:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:25:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:26:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:26:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:27:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:27:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:27:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:27:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:28:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:28:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:28:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:28:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:28:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:29:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:29:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:29:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:30:35 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-23 14:30:35 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-23 14:30:35 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-23 14:30:35 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-23 14:30:35 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-23 14:30:35 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-23 14:30:36 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-23 14:30:37 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-23 14:30:37 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-23 14:30:37 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-23 14:30:37 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-23 14:30:37 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-23 14:30:37 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-23 14:30:37 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-23 14:30:37 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-23 14:30:37 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-23 14:30:37 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-23 14:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:31:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:32:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:33:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:49:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:49:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:50:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 14:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:50:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 14:51:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 14:51:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:49 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:49 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:54 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:54 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:51:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:52:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:52:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 14:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:54:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 14:54:38 --> 404 Page Not Found: Solr/index
ERROR - 2021-09-23 14:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:58:04 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-09-23 14:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 14:59:21 --> 404 Page Not Found: City/16
ERROR - 2021-09-23 14:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:00:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 15:00:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 15:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:03:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:06:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 15:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:08:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 15:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:12:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 15:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:13:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:20:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 15:22:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:22:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:22:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:22:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:22:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:22:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:22:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:22:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:25:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 15:26:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 15:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:29:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:32:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:33:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:33:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 15:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:48:57 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-23 15:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:49:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 15:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:51:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:51:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:51:23 --> 404 Page Not Found: Sitemap47290html/index
ERROR - 2021-09-23 15:51:26 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:51:26 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:51:31 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:51:31 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:51:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:51:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:51:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:51:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:51:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:51:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:54:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:55:20 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-23 15:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:56:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:56:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:56:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:56:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:56:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:56:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:56:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:56:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:56:30 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-09-23 15:56:31 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-09-23 15:56:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:56:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:56:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:56:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 15:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 15:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:00:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:00:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:00:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:04:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:04:25 --> 404 Page Not Found: Env/index
ERROR - 2021-09-23 16:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:06:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 16:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:11:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:18:26 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-23 16:19:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:20:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:20:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:21:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:25:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:25:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:25:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:27:18 --> 404 Page Not Found: Env/index
ERROR - 2021-09-23 16:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:28:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:43:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 16:44:26 --> 404 Page Not Found: City/16
ERROR - 2021-09-23 16:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:49:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:49:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:49:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:49:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:49:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:49:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:49:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:49:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:49:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:50:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 16:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:50:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:52:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:52:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:53:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:53:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:53:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:53:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 16:54:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:54:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:55:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:55:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:56:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:56:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:57:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:57:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 16:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:59:02 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 16:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 16:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:00:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:00:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:00:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:01:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:04:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:04:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 17:05:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:05:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:06:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 17:06:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:07:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:08:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:08:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 17:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:08:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:08:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:08:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:08:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:08:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:09:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:09:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:09:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:09:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:09:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:11:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:11:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:11:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:11:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:13:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:13:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:13:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:13:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:14:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:14:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:14:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:14:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:16 --> 404 Page Not Found: English/index
ERROR - 2021-09-23 17:15:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:15:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:23:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 17:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:24:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 17:25:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 17:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:26:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 17:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:27:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 17:27:54 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-23 17:27:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:31:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 17:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:34:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:34:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 17:35:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 17:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:37:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:41:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:41:30 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-23 17:41:30 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-23 17:41:31 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-23 17:41:32 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-23 17:42:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 17:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:43:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 17:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:47:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:48:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:49:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 17:50:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 17:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:53:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 17:53:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 17:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:54:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:54:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:54:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:54:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:54:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:55:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 17:57:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:58:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:58:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:58:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:58:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:59:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:59:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:59:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 17:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 17:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:06:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 18:06:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 18:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:08:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 18:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:09:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:11:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 18:11:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:11:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:11:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:11:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:12:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:12:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:12:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:12:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:12:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:12:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:12:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:12:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:12:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:12:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-23 18:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:14:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:15:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 18:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:17:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:17:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:27:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 18:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:33:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:35:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:36:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 18:37:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 18:37:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 18:37:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 18:37:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:37:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 18:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:38:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:39:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 18:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:48:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 18:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:49:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 18:50:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 18:50:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 18:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 18:56:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 18:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:03:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:06:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:07:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 19:08:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 19:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:10:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 19:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:11:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 19:11:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 19:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:13:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:18:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:18:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:22:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:22:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 19:23:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:24:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:26:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:26:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:27:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:27:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:29:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:30:11 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-23 19:30:29 --> 404 Page Not Found: Sites/default
ERROR - 2021-09-23 19:30:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 19:30:40 --> 404 Page Not Found: admin/Controller/extension
ERROR - 2021-09-23 19:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:32:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:34:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:35:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 19:35:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 19:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:54:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:58:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:58:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 19:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 19:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:03:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:04:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:05:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:07:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:07:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:12:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 20:12:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 20:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:15:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:15:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:16:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:19:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:20:47 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-23 20:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:21:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:23:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 20:23:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:25:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:28:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 20:29:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:32:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:33:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 20:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:38:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:39:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:43:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:44:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:46:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:46:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:47:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:48:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:50:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:54:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:54:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 20:54:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 20:54:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 20:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 20:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 20:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 20:56:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 20:57:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 20:57:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 20:57:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 20:57:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 20:58:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 20:58:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 21:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:01:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:03:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:04:00 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-23 21:04:02 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-23 21:04:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:04:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:05:06 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-09-23 21:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:06:06 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-09-23 21:07:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:07:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:08:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:08:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:11:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:11:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:12 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:12:24 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:24 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:24 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:24 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:24 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:24 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:12:24 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-23 21:13:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:13:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:15:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 21:17:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:18:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 21:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:20:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:20:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:21:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:22:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:22:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 21:23:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:23:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 21:23:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:23:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:23:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:24:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:26:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:27:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:27:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:28:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:30:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:30:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:30:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:32:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:33:31 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-23 21:34:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:35:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:35:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:36:42 --> 404 Page Not Found: English/index
ERROR - 2021-09-23 21:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:41:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 21:42:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 21:42:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 21:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:43:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:44:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 21:45:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 21:45:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:45:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 21:47:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:50:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:52:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:53:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 21:53:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:55:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:56:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:57:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:57:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 21:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 21:59:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 21:59:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 22:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:00:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:13:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:16:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 22:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 22:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:24:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:25:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:26:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:26:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:27:40 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-09-23 22:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:28:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 22:30:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:30:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 22:30:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:31:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:33:11 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-09-23 22:33:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:33:13 --> 404 Page Not Found: Issmall/index
ERROR - 2021-09-23 22:33:14 --> 404 Page Not Found: Test_for_404/index
ERROR - 2021-09-23 22:33:14 --> 404 Page Not Found: Web-console/index
ERROR - 2021-09-23 22:33:18 --> 404 Page Not Found: Admin-console/index
ERROR - 2021-09-23 22:33:18 --> 404 Page Not Found: Manager/status
ERROR - 2021-09-23 22:33:18 --> 404 Page Not Found: Manager/html
ERROR - 2021-09-23 22:33:25 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-09-23 22:33:32 --> 404 Page Not Found: Blog/index
ERROR - 2021-09-23 22:33:32 --> 404 Page Not Found: Forum/index
ERROR - 2021-09-23 22:33:32 --> 404 Page Not Found: Bbs/index
ERROR - 2021-09-23 22:33:44 --> 404 Page Not Found: Wcm/index
ERROR - 2021-09-23 22:33:53 --> 404 Page Not Found: admin/Editor/index
ERROR - 2021-09-23 22:34:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 22:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 22:35:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:36:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:37:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 22:37:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:37:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 22:37:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:39:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:39:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:39:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:39:47 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-23 22:40:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:45:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:46:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-23 22:47:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:48:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:49:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:49:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:50:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:51:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:51:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:53:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-23 22:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:54:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 22:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:56:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:57:33 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-23 22:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:58:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 22:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 22:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:00:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:01:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:01:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:03:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:04:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:09:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:11:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:11:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:11:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:11:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:24:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:26:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:27:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:28:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:28:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:29:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:29:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:29:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:29:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:30:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:30:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:30:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:30:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:31:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:31:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:31:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:36:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:37:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-23 23:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:39:46 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-23 23:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:47:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:47:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:47:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:49:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 23:49:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:50:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:50:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-23 23:50:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:50:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:50:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:51:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:51:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:51:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:52:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:52:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:52:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:53:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:54:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:56:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-23 23:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-23 23:59:48 --> 404 Page Not Found: Robotstxt/index
