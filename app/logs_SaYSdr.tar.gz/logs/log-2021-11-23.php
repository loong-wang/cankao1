<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-23 00:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 00:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 00:25:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 00:25:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 00:26:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 00:26:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 00:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 00:35:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 00:35:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 00:36:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 00:36:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 00:36:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 00:38:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 00:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 00:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 01:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 01:12:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 01:27:01 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-11-23 01:37:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 01:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 01:47:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 01:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 01:51:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 01:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 01:51:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 01:54:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 01:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 01:58:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 02:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:05:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 02:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:05:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 02:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:21:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:24:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:24:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:24:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:25:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:25:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:25:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:26:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:34:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:34:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 02:34:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 02:35:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:35:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:36:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:36:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:36:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:37:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:37:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:37:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:37:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:38:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:38:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:38:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:38:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:38:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:38:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:38:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:39:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:39:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:39:35 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-11-23 02:39:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:40:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:40:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:40:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:41:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:41:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:42:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:42:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:43:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:43:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:44:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:44:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:44:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:45:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:46:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:53:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 02:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:56:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 02:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 02:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 03:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 03:10:49 --> 404 Page Not Found: City/1
ERROR - 2021-11-23 03:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 03:19:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 03:20:24 --> 404 Page Not Found: City/16
ERROR - 2021-11-23 03:24:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 03:29:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 03:38:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:38:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:39:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 03:40:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:40:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:41:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:42:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:42:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:43:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:47:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 03:47:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:48:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:48:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:48:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:49:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 03:50:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 03:55:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:55:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 03:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 03:57:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:58:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:58:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:59:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 03:59:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 03:59:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:00:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:00:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:00:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:01:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:01:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:02:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:02:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:03:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:06:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:15:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 04:18:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:20:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 04:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 04:27:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 04:30:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:30:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 04:32:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:34:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:39:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:40:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 04:41:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:43:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:44:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:44:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:47:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:48:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:48:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 04:49:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:50:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:50:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 04:50:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 04:52:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:53:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:54:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:54:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:56:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 04:57:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:57:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 04:58:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 04:58:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 05:00:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 05:00:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 05:01:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 05:03:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 05:03:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 05:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 05:12:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 05:13:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 05:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 05:15:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 05:20:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 05:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 05:24:03 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-23 05:28:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 05:30:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 05:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 05:33:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 05:37:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 05:38:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 05:40:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 05:45:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 05:47:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 05:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 05:50:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 05:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 06:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 06:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 06:21:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 06:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 06:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 06:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 06:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 06:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 06:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 07:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 07:25:28 --> 404 Page Not Found: New/index
ERROR - 2021-11-23 07:25:59 --> 404 Page Not Found: 14492/index
ERROR - 2021-11-23 07:26:12 --> 404 Page Not Found: Zt/jixujiaoyu
ERROR - 2021-11-23 07:26:34 --> 404 Page Not Found: N1/2021
ERROR - 2021-11-23 07:27:29 --> 404 Page Not Found: Book/201809
ERROR - 2021-11-23 07:27:39 --> 404 Page Not Found: Ks/pljmok.htm
ERROR - 2021-11-23 07:27:51 --> 404 Page Not Found: Dispbbs-hyzx-e96125887html/index
ERROR - 2021-11-23 07:28:27 --> 404 Page Not Found: Dpool/blog
ERROR - 2021-11-23 07:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 07:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 07:46:54 --> 404 Page Not Found: 404/index.html
ERROR - 2021-11-23 07:46:54 --> 404 Page Not Found: 404/index.html
ERROR - 2021-11-23 07:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 07:57:59 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-23 07:58:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 08:00:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 08:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 08:39:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:40:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:41:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:41:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:41:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:41:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 08:42:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 08:42:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 08:42:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:42:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:43:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:43:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:43:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:43:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:43:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:43:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:43:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:43:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:43:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:44:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 08:44:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:44:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:45:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 08:58:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 08:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 08:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 09:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 09:16:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:17:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:18:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:19:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 09:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 09:22:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 09:22:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 09:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:22:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 09:26:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 09:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:27:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 09:27:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 09:28:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 09:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 09:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 09:46:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:46:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:46:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:47:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 09:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 09:53:07 --> 404 Page Not Found: Vod-play-id-2228-sid-0-pid-60html/index
ERROR - 2021-11-23 09:55:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:55:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:56:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:58:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 09:58:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 09:58:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 09:58:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 09:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 09:59:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 10:03:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 10:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 10:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 10:04:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 10:05:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 10:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 10:14:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 10:15:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 10:16:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 10:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 10:17:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 10:18:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 10:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 10:24:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 10:30:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 10:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 10:51:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 10:57:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 10:58:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 10:58:22 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-23 10:58:22 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-23 11:00:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:01:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:07:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:08:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:09:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:10:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:10:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:10:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:11:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:13:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 11:14:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 11:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 11:18:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:19:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:19:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:19:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:19:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:20:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:24:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:27:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 11:28:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:28:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:28:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:29:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:33:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 11:35:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 11:37:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 11:40:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:41:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 11:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 11:41:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 11:41:29 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-11-23 11:42:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 11:55:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 11:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 11:56:19 --> 404 Page Not Found: Vod-play-id-2680-sid-0-pid-123html/index
ERROR - 2021-11-23 11:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-11-23 12:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 12:06:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 12:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 12:07:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 12:07:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 12:07:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 12:08:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 12:16:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 12:16:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 12:18:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 12:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 12:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 12:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 12:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 12:49:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 12:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 12:54:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 12:58:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 12:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 13:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 13:17:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 13:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 13:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 13:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 13:46:45 --> 404 Page Not Found: Article/index
ERROR - 2021-11-23 13:53:25 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-11-23 13:57:00 --> 404 Page Not Found: Websitebakzip/index
ERROR - 2021-11-23 13:57:00 --> 404 Page Not Found: Public_htmlzip/index
ERROR - 2021-11-23 13:57:00 --> 404 Page Not Found: Public_htmltargz/index
ERROR - 2021-11-23 13:57:00 --> 404 Page Not Found: Websitebakrar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Websitebaktargz/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Chengxuzip/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Chengxurar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Chengxutargz/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Flashxprar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Flashxpzip/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Rootrar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Webrar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Bakrar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Ftprar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Ftp1rar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Leapftprar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Roottargz/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Ftptargz/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Ftp1targz/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Leapftptargz/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Rootzip/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Webzip/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Bakzip/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Ftpzip/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Ftp1zip/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Leapftpzip/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-11-23 13:57:01 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-11-23 13:57:02 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-11-23 13:57:02 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-11-23 13:57:02 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-11-23 13:57:02 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-11-23 13:57:02 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-11-23 13:57:02 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-11-23 13:57:02 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-11-23 13:57:02 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-11-23 13:58:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 14:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:04:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 14:06:58 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-23 14:13:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 14:14:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 14:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:20:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:20:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:20:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:28:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 14:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:41:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:45:51 --> 404 Page Not Found: Explore/projects
ERROR - 2021-11-23 14:47:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:49:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:49:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:52:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 14:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 14:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 15:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 15:00:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:00:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:02:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 15:11:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 15:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 15:16:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 15:19:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 15:21:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 15:23:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:23:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:24:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 15:26:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:26:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:27:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:27:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 15:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 15:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 15:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 15:56:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 16:07:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 16:08:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:09:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:09:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:09:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:09:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:10:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:12:45 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-11-23 16:12:48 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-11-23 16:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 16:20:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:23:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:23:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:24:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:24:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:25:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:26:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:26:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:27:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 16:27:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 16:27:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:28:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:28:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:29:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 16:32:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 16:35:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:36:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 16:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 16:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 16:49:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:51:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:52:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 16:52:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:01:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 17:06:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:07:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:08:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 17:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:11:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 17:11:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:12:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:19:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:22:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:28:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-23 17:29:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:31:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 17:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 17:43:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 17:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 17:52:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 17:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 17:57:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 17:57:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 17:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 18:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 18:00:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:01:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:03:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 18:12:52 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-23 18:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 18:21:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:21:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 18:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 18:33:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 18:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 18:36:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:37:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:37:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:44:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:44:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:45:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:45:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:46:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:46:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:46:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:47:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:47:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:48:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:48:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:48:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:49:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:49:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 18:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 18:50:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:51:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:51:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:51:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:52:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:52:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:52:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:53:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:53:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:53:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:53:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:53:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:53:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:54:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:54:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:54:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:54:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:55:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:55:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:56:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:56:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:56:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:57:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:58:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:58:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:58:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:58:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:59:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:59:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:59:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:59:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 18:59:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 18:59:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:00:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:00:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:00:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:00:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:01:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:01:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:01:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:02:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:02:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:03:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:03:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:03:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:04:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:04:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:05:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:05:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:06:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:06:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:07:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 19:15:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:15:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:17:53 --> 404 Page Not Found: City/16
ERROR - 2021-11-23 19:17:55 --> 404 Page Not Found: City/16
ERROR - 2021-11-23 19:17:55 --> 404 Page Not Found: City/16
ERROR - 2021-11-23 19:17:55 --> 404 Page Not Found: City/16
ERROR - 2021-11-23 19:17:55 --> 404 Page Not Found: City/16
ERROR - 2021-11-23 19:18:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:19:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:20:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:21:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:22:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:23:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:24:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 19:24:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 19:24:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 19:26:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:27:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:27:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:28:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:28:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:29:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:29:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:30:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 19:31:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:39:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 19:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 19:43:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:43:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:48:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 19:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 19:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 20:06:15 --> 404 Page Not Found: Company/view
ERROR - 2021-11-23 20:17:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 20:20:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 20:21:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 20:23:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 20:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 20:24:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 20:25:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 20:26:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 20:27:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 20:27:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 20:27:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 20:29:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 20:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 20:40:23 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-23 20:40:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 20:41:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 20:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 20:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 20:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 20:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 21:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 21:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 21:10:06 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-23 21:10:06 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-23 21:10:06 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-23 21:10:06 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-23 21:18:22 --> 404 Page Not Found: Article/view
ERROR - 2021-11-23 21:22:36 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-23 21:23:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 21:23:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 21:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 21:27:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 21:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 21:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 21:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 21:45:56 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-23 21:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 21:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 21:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 21:51:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 21:53:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 21:53:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 21:55:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 21:55:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 21:55:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 21:56:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 22:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:29:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 22:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 22:33:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:37:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:39:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:39:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:39:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:39:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-23 22:40:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:40:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 22:40:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:40:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:45:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:46:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:48:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:48:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:50:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 22:52:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 22:53:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-23 23:12:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 23:12:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 23:13:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 23:13:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 23:13:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 23:13:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 23:13:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 23:13:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-23 23:13:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-23 23:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 23:15:06 --> 404 Page Not Found: Sitemap16912html/index
ERROR - 2021-11-23 23:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 23:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 23:39:55 --> 404 Page Not Found: Sitemap92256html/index
ERROR - 2021-11-23 23:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 23:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 23:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-23 23:59:35 --> 404 Page Not Found: Robotstxt/index
