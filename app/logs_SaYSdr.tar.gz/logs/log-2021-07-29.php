<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-29 00:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:02:11 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-29 00:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:09:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 00:09:16 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-29 00:09:43 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-29 00:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:10:29 --> 404 Page Not Found: City/1
ERROR - 2021-07-29 00:12:18 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-29 00:13:03 --> 404 Page Not Found: English/index
ERROR - 2021-07-29 00:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:16:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 00:16:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:22:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:24:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-29 00:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:24:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-29 00:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:28:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:34:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 00:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:37:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:37:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:37:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 00:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:48:19 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-29 00:51:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 00:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:55:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 00:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 00:59:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 01:00:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:01:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:02:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:02:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:04:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:09:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:10:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:11:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 01:12:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:13:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:13:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:14:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:14:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:14:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:14:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:14:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:14:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:15:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:17:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 01:18:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 01:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:21:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:22:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:25:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:27:37 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-07-29 01:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:28:39 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-07-29 01:30:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:31:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:35:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:35:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:35:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:35:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 01:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:44:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 01:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:57:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 01:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 01:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:08:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:13:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 02:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:15:14 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-07-29 02:15:17 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-07-29 02:15:17 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-07-29 02:15:18 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-07-29 02:15:18 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-07-29 02:15:20 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-07-29 02:15:20 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-07-29 02:15:21 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-07-29 02:15:21 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-07-29 02:15:22 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-07-29 02:15:22 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-07-29 02:15:23 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-07-29 02:15:24 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-07-29 02:15:24 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-07-29 02:15:25 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-07-29 02:15:25 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-07-29 02:15:26 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-07-29 02:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:18:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:22:56 --> 404 Page Not Found: Config/getuser
ERROR - 2021-07-29 02:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:25:41 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-29 02:25:41 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-29 02:25:42 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 02:25:43 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-29 02:25:44 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-29 02:25:44 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-29 02:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:27:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:49:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 02:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:55:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 02:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:55:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-29 02:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 02:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:14:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 03:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:20:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 03:20:10 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-29 03:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:22:48 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-29 03:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:24:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 03:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:25:29 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-29 03:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:26:28 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-29 03:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:29:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 03:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:35:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 03:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:38:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 03:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:40:32 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-07-29 03:46:03 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-07-29 03:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:49:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 03:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 03:59:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 04:00:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 04:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-07-29 04:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:02:07 --> 404 Page Not Found: Env/index
ERROR - 2021-07-29 04:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:05:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 04:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:36:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 04:36:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 04:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:47:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:50:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-29 04:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:52:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-29 04:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:55:19 --> 404 Page Not Found: City/1
ERROR - 2021-07-29 04:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 04:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:07:59 --> 404 Page Not Found: Env/index
ERROR - 2021-07-29 05:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:27:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 05:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:33:32 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-29 05:33:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 05:33:32 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-29 05:33:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 05:33:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 05:33:32 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-29 05:33:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-29 05:33:33 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-29 05:33:34 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-29 05:33:34 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-29 05:33:34 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-29 05:33:34 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 05:33:34 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 05:33:34 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-29 05:33:34 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-29 05:33:34 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-29 05:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:41:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:43:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 05:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:49:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:55:42 --> 404 Page Not Found: City/10
ERROR - 2021-07-29 05:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 05:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:03:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 06:04:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 06:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:29:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:33:53 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-29 06:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:39:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 06:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:54:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 06:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:02:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 07:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:05:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:07:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:07:50 --> 404 Page Not Found: English/index
ERROR - 2021-07-29 07:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 07:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:09:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 07:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:12:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 07:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:20:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:23:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:41:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 07:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:43:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:46:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 07:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 07:59:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 07:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:22:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:23:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 08:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:26:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:32:53 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-29 08:33:10 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-29 08:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:39:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 08:40:01 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-29 08:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:40:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 08:42:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 08:42:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 08:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:44:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 08:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:47:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:51:54 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-29 08:51:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 08:51:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 08:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:55:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 08:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:56:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 08:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 08:57:13 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-29 08:57:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 08:57:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 08:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:02:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 09:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:07:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 09:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:09:53 --> 404 Page Not Found: City/10
ERROR - 2021-07-29 09:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:13:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 09:13:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:13:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 09:13:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 09:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:19:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:19:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:19:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:19:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:20:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:21:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:22:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:23:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:23:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:23:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:24:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:25:00 --> 404 Page Not Found: City/1
ERROR - 2021-07-29 09:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:27:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 09:27:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:35:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 09:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:39:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 09:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:41:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 09:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:43:51 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-29 09:43:56 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-29 09:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:45:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 09:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:50:09 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-29 09:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:50:38 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-29 09:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:52:24 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-29 09:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:52:58 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-29 09:54:32 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-29 09:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:57:13 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-29 09:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 09:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:00:42 --> 404 Page Not Found: Portal/redlion
ERROR - 2021-07-29 10:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:02:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 10:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:06:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:07:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:13:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:13:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:16:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 10:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:17:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 10:18:18 --> 404 Page Not Found: Actuator/health
ERROR - 2021-07-29 10:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:19:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 10:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:22:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:28:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:28:49 --> 404 Page Not Found: Haoma/index
ERROR - 2021-07-29 10:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:31:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:33:06 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-29 10:33:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:33:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:33:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:33:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:34:00 --> 404 Page Not Found: ReportServer/index
ERROR - 2021-07-29 10:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:40:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:40:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 10:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:56:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 10:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:09:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:09:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:11:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 11:11:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 11:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:19:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:20:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:20:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:32:44 --> 404 Page Not Found: City/1
ERROR - 2021-07-29 11:33:10 --> 404 Page Not Found: City/1
ERROR - 2021-07-29 11:33:10 --> 404 Page Not Found: City/1
ERROR - 2021-07-29 11:33:26 --> 404 Page Not Found: City/1
ERROR - 2021-07-29 11:33:42 --> 404 Page Not Found: City/1
ERROR - 2021-07-29 11:34:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 11:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:39:40 --> 404 Page Not Found: Env/index
ERROR - 2021-07-29 11:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:45:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 11:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:51:19 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-29 11:51:52 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-29 11:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:53:49 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-29 11:54:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:57:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:57:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:58:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:58:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 11:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 11:59:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:00:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:00:52 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-29 12:01:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:02:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:04:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:05:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:06:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:06:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:16:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 12:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:18:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 12:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:20:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:36:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 12:36:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:37:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:37:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 12:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:39:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 12:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:49:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:49:06 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-29 12:49:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:49:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 12:49:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-29 12:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:50:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:52:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 12:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:53:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 12:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 12:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:00:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:04:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 13:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:09:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 13:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:20:43 --> 404 Page Not Found: Env/index
ERROR - 2021-07-29 13:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:28:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 13:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:33:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 13:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:34:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 13:35:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 13:35:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 13:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:46:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:50:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-29 13:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 13:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:53:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 13:54:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 13:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 13:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:06:25 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-29 14:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:12:45 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 14:12:45 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-29 14:12:45 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 14:12:45 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 14:12:45 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-29 14:12:45 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 14:12:45 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-29 14:12:45 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 14:12:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 14:12:46 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-29 14:12:47 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-07-29 14:12:47 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 14:12:47 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-29 14:12:47 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-29 14:12:47 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-29 14:12:47 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-29 14:12:47 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-29 14:12:47 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 14:12:47 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 14:12:47 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-29 14:12:47 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-29 14:12:47 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-29 14:12:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 14:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:13:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 14:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:14:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 14:15:17 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-07-29 14:17:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 14:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:28:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:40:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 14:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:41:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:43:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 14:44:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 14:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:44:58 --> 404 Page Not Found: City/1
ERROR - 2021-07-29 14:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:48:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 14:49:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 14:49:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 14:49:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 14:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:54:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 14:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:02:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 15:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:05:32 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-29 15:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:14:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 15:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:14:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 15:15:49 --> 404 Page Not Found: Js/common.js%20
ERROR - 2021-07-29 15:16:22 --> 404 Page Not Found: Js/common.js%20
ERROR - 2021-07-29 15:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:19:39 --> 404 Page Not Found: Js/common.js%20
ERROR - 2021-07-29 15:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:36:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 15:36:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 15:36:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 15:37:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:37:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 15:38:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 15:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:40:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 15:41:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 15:41:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 15:42:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 15:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:43:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 15:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:55:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 15:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 15:57:22 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-29 15:58:26 --> 404 Page Not Found: English/index
ERROR - 2021-07-29 15:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:00:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-29 16:04:04 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 16:04:05 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-29 16:04:05 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 16:04:05 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 16:04:05 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-29 16:04:05 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 16:04:05 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 16:04:05 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-29 16:04:05 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 16:04:06 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-29 16:04:06 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-29 16:04:06 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-29 16:04:06 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-29 16:04:06 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-29 16:04:06 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 16:04:06 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 16:04:06 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-29 16:04:06 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-29 16:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:05:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 16:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:11:28 --> 404 Page Not Found: City/index
ERROR - 2021-07-29 16:11:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:12:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:15:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-29 16:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:18:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 16:19:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 16:19:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 16:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:21:51 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-07-29 16:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:22:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:22:21 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-29 16:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:22:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:22:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:23:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:23:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 16:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:24:29 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-29 16:24:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:26:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:26:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:30:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:30:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:30:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:33:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:38:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:38:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-29 16:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:39:13 --> 404 Page Not Found: City/1
ERROR - 2021-07-29 16:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:40:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 16:41:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 16:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:41:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:41:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 16:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:44:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:46:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:46:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:47:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:47:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:47:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:48:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:49:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 16:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:55:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 16:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:57:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:57:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 16:58:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:58:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:58:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:59:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 16:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 16:59:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:00:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:00:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:00:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:01:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:02:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:02:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:02:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 17:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:07:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:12:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:15:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:16:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:20:18 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-07-29 17:20:19 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-07-29 17:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:26:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 17:28:27 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-29 17:28:28 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-29 17:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:30:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:30:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:31:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:32:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:32:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:32:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:33:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:34:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:34:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:36:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:37:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 17:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:42:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 17:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:45:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:50:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 17:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:54:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 17:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:02:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 18:02:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 18:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:02:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:02:50 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-29 18:03:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 18:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:12:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 18:12:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 18:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:15:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 18:15:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 18:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 18:16:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 18:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:28:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:32:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 18:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:36:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 18:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:50:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 18:50:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 18:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 18:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:54:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 18:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 18:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:02:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 19:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:18:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 19:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:20:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:20:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 19:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:22:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 19:22:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 19:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:23:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 19:23:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 19:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:23:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 19:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:23:35 --> 404 Page Not Found: City/15
ERROR - 2021-07-29 19:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:24:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 19:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:24:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 19:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:25:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 19:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:33:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 19:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:40:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 19:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:44:11 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-29 19:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:45:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 19:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:54:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:58:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 19:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 19:59:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 20:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:02:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 20:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:02:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 20:02:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 20:02:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 20:02:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 20:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:03:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 20:03:41 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-29 20:03:41 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 20:03:41 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-29 20:03:41 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-29 20:03:41 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 20:03:41 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 20:03:42 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-29 20:03:43 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-29 20:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:13:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 20:13:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 20:13:38 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-07-29 20:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:16:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 20:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:17:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 20:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:20:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:22:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 20:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:26:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 20:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:29:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 20:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:30:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 20:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:31:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 20:32:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 20:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:34:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 20:34:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 20:36:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 20:36:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 20:37:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:42:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 20:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:50:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 20:51:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 20:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:55:28 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-29 20:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 20:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:07:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-29 21:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:09:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 21:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:12:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 21:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:22:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 21:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:25:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 21:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:30:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:32:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 21:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:35:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 21:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:36:13 --> 404 Page Not Found: Solr/index
ERROR - 2021-07-29 21:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:39:07 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-29 21:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:46:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 21:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:51:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 21:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:54:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 21:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 21:55:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 21:56:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 21:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 21:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:56:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 21:56:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 21:57:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 21:57:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 21:57:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 21:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 21:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:02:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 22:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:06:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 22:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:19:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 22:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:22:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:22:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:22:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:22:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:22:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:22:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:22:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:22:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:22:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:22:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:22:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:22:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 22:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:23:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:23:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:23:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:23:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:24:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:24:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:24:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:24:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:33:31 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-29 22:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:45:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 22:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:54:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:56:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 22:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 22:58:32 --> 404 Page Not Found: Env/index
ERROR - 2021-07-29 22:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:01:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-29 23:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:08:31 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-29 23:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:10:47 --> 404 Page Not Found: City/16
ERROR - 2021-07-29 23:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:13:22 --> 404 Page Not Found: User/index
ERROR - 2021-07-29 23:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:16:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 23:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:21:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 23:21:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-29 23:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:21:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:24:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 23:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:26:34 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-29 23:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:30:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 23:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:40:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 23:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:44:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-29 23:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:47:47 --> 404 Page Not Found: City/10
ERROR - 2021-07-29 23:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:54:01 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-07-29 23:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 23:54:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 23:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:55:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 23:55:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 23:56:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 23:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:56:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 23:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:56:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-29 23:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-29 23:58:38 --> 404 Page Not Found: Robotstxt/index
