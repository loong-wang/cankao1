<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-03 00:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 00:08:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 00:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 00:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 00:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 00:28:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 00:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 00:31:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 00:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 00:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 00:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 00:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 00:53:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-03 00:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 01:01:27 --> 404 Page Not Found: City/1
ERROR - 2021-12-03 01:06:16 --> 404 Page Not Found: City/2
ERROR - 2021-12-03 01:06:26 --> 404 Page Not Found: City/18
ERROR - 2021-12-03 01:06:28 --> 404 Page Not Found: City/19
ERROR - 2021-12-03 01:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 01:39:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-03 01:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 01:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 01:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 02:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 02:11:39 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-12-03 02:24:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:24:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:24:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:25:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:25:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:25:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:25:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:25:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:25:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:25:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:25:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:26:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:26:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 02:33:25 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-03 02:33:25 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-03 02:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 02:39:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 02:41:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:42:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:42:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:42:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:42:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 02:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 02:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 03:09:17 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-12-03 03:16:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 03:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 03:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 03:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 03:38:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:38:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:39:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:40:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 03:40:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 03:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 03:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 03:46:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 03:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 03:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 04:00:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:01:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:01:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:01:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:02:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 04:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 04:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 04:08:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:08:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:09:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:10:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 04:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 04:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 04:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 04:41:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 04:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 04:43:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 04:49:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 04:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 05:01:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 05:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 05:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 05:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 05:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 05:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 05:23:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 05:23:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 05:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 05:28:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 05:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 05:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 06:16:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 06:16:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 06:26:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 06:26:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 06:27:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 06:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 06:34:11 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-12-03 06:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 06:34:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 06:34:12 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-12-03 06:34:12 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-12-03 06:34:12 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-03 06:41:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 06:41:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 06:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 06:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 06:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 06:52:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 06:52:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 06:53:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 06:53:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 06:53:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 06:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 07:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 07:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 07:28:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 07:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 07:35:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-03 07:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 07:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 08:13:46 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-03 08:34:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 08:53:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 08:53:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:17:56 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-03 09:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 09:30:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:30:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:30:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:30:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 09:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 09:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 09:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 09:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 09:47:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:49:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:52:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 09:56:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 09:56:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 09:57:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 09:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 10:05:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 10:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:10:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:14:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:15:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:17:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 10:22:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:23:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:35:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-03 10:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 10:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 10:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 10:51:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:53:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:54:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:54:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:54:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 10:55:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 11:00:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 11:03:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 11:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 11:29:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 11:32:41 --> 404 Page Not Found: City/16
ERROR - 2021-12-03 11:33:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 11:36:25 --> 404 Page Not Found: City/1
ERROR - 2021-12-03 11:37:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-03 11:40:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 11:40:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 11:47:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-03 12:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 12:01:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 12:28:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 12:28:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 12:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 12:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 12:39:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 12:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 12:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 13:02:57 --> 404 Page Not Found: Zxasp/index
ERROR - 2021-12-03 13:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 13:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 13:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 13:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 13:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 13:49:08 --> 404 Page Not Found: Zasp/index
ERROR - 2021-12-03 14:05:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 14:21:26 --> 404 Page Not Found: City/1
ERROR - 2021-12-03 14:26:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:26:36 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-12-03 14:26:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:27:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 14:27:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:27:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:28:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:29:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:29:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:29:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:31:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 14:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 14:34:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 14:34:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:34:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:34:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 14:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 14:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 14:50:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:50:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 14:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 14:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 14:56:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:57:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:57:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 14:58:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 14:59:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 15:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 15:00:49 --> 404 Page Not Found: Test_404_page/index
ERROR - 2021-12-03 15:00:52 --> 404 Page Not Found: Issmall/index
ERROR - 2021-12-03 15:01:11 --> 404 Page Not Found: Administrator/manifests
ERROR - 2021-12-03 15:01:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 15:01:19 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-12-03 15:01:19 --> 404 Page Not Found: Fckeditor/license.txt
ERROR - 2021-12-03 15:01:22 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2021-12-03 15:01:22 --> 404 Page Not Found: Docs/index
ERROR - 2021-12-03 15:01:24 --> 404 Page Not Found: Maintloginjsp/index
ERROR - 2021-12-03 15:01:24 --> 404 Page Not Found: Ckfinder/ckfinder.html
ERROR - 2021-12-03 15:01:24 --> 404 Page Not Found: Ckfinder/install.txt
ERROR - 2021-12-03 15:01:24 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-12-03 15:01:25 --> 404 Page Not Found: Ckeditor/ckfinder
ERROR - 2021-12-03 15:01:25 --> 404 Page Not Found: admin//index
ERROR - 2021-12-03 15:01:25 --> 404 Page Not Found: admin/Template/article_more
ERROR - 2021-12-03 15:01:26 --> 404 Page Not Found: Auth/login
ERROR - 2021-12-03 15:01:27 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-12-03 15:01:28 --> 404 Page Not Found: E/master
ERROR - 2021-12-03 15:01:28 --> 404 Page Not Found: Master/login.aspx
ERROR - 2021-12-03 15:01:47 --> 404 Page Not Found: admin/Inc/xml.xslt
ERROR - 2021-12-03 15:01:49 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-12-03 15:01:49 --> 404 Page Not Found: CuteSoft_Client/CuteEditor
ERROR - 2021-12-03 15:01:50 --> 404 Page Not Found: Ids/admin
ERROR - 2021-12-03 15:01:50 --> 404 Page Not Found: Ids/admin
ERROR - 2021-12-03 15:01:50 --> 404 Page Not Found: Siteserver/upgrade
ERROR - 2021-12-03 15:01:50 --> 404 Page Not Found: Siteserver/login.aspx
ERROR - 2021-12-03 15:01:51 --> 404 Page Not Found: Indexcgi/index
ERROR - 2021-12-03 15:01:51 --> 404 Page Not Found: Cgi/index.cgi
ERROR - 2021-12-03 15:01:52 --> 404 Page Not Found: admin/SouthidcEditor/ewebeditor.asp
ERROR - 2021-12-03 15:01:54 --> 404 Page Not Found: Addons/theme
ERROR - 2021-12-03 15:01:54 --> 404 Page Not Found: App/login.jsp
ERROR - 2021-12-03 15:01:55 --> 404 Page Not Found: Console/include
ERROR - 2021-12-03 15:01:55 --> 404 Page Not Found: Console/auth
ERROR - 2021-12-03 15:01:56 --> 404 Page Not Found: Helpnew/faq
ERROR - 2021-12-03 15:01:57 --> 404 Page Not Found: READMEtxt/index
ERROR - 2021-12-03 15:02:11 --> 404 Page Not Found: Docs/DOCUMENTATION.txt
ERROR - 2021-12-03 15:02:12 --> 404 Page Not Found: Inc/playerKinds.xml
ERROR - 2021-12-03 15:02:12 --> 404 Page Not Found: admin/Loginaspx/index
ERROR - 2021-12-03 15:02:13 --> 404 Page Not Found: Erroraspx/index
ERROR - 2021-12-03 15:02:14 --> 404 Page Not Found: admin/Loginasp/index
ERROR - 2021-12-03 15:02:17 --> 404 Page Not Found: Examples/index.html
ERROR - 2021-12-03 15:02:18 --> 404 Page Not Found: Examples/file-manager.html
ERROR - 2021-12-03 15:02:19 --> 404 Page Not Found: Plugins/filemanager
ERROR - 2021-12-03 15:02:19 --> 404 Page Not Found: Aspnet/README.txt
ERROR - 2021-12-03 15:02:20 --> 404 Page Not Found: Examples/readonly.html
ERROR - 2021-12-03 15:02:21 --> 404 Page Not Found: Whir_system/login.aspx
ERROR - 2021-12-03 15:02:21 --> 404 Page Not Found: Whir_system/module
ERROR - 2021-12-03 15:02:22 --> 404 Page Not Found: System/Login.aspx
ERROR - 2021-12-03 15:02:23 --> 404 Page Not Found: Help/user
ERROR - 2021-12-03 15:02:24 --> 404 Page Not Found: Themes/default
ERROR - 2021-12-03 15:02:34 --> 404 Page Not Found: Forums/list.page
ERROR - 2021-12-03 15:02:34 --> 404 Page Not Found: DeptWebsiteActiondo/index
ERROR - 2021-12-03 15:02:35 --> 404 Page Not Found: User/Login.aspx
ERROR - 2021-12-03 15:02:35 --> 404 Page Not Found: API/DW
ERROR - 2021-12-03 15:02:36 --> 404 Page Not Found: API/DW
ERROR - 2021-12-03 15:02:36 --> 404 Page Not Found: API/DW
ERROR - 2021-12-03 15:02:36 --> 404 Page Not Found: Admin/Common
ERROR - 2021-12-03 15:02:36 --> 404 Page Not Found: API/DW
ERROR - 2021-12-03 15:02:37 --> 404 Page Not Found: API/DW
ERROR - 2021-12-03 15:02:37 --> 404 Page Not Found: Admin/Login.aspx
ERROR - 2021-12-03 15:02:38 --> 404 Page Not Found: Licencetxt/index
ERROR - 2021-12-03 15:02:40 --> 404 Page Not Found: Archiver/index
ERROR - 2021-12-03 15:02:40 --> 404 Page Not Found: Tools/rss.aspx
ERROR - 2021-12-03 15:02:40 --> 404 Page Not Found: Ntalker/lawfirm.aspx
ERROR - 2021-12-03 15:02:41 --> 404 Page Not Found: Searchhtml/index
ERROR - 2021-12-03 15:02:43 --> 404 Page Not Found: Feedasp/index
ERROR - 2021-12-03 15:02:44 --> 404 Page Not Found: Inc/Templates
ERROR - 2021-12-03 15:02:44 --> 404 Page Not Found: Jcms/index.jsp
ERROR - 2021-12-03 15:02:45 --> 404 Page Not Found: Jcms/index_jcms.jsp
ERROR - 2021-12-03 15:02:45 --> 404 Page Not Found: Historytxt/index
ERROR - 2021-12-03 15:02:48 --> 404 Page Not Found: Api/api_user.xml
ERROR - 2021-12-03 15:02:50 --> 404 Page Not Found: Template/home.htm
ERROR - 2021-12-03 15:02:50 --> 404 Page Not Found: System/skins
ERROR - 2021-12-03 15:02:51 --> 404 Page Not Found: System/language
ERROR - 2021-12-03 15:02:52 --> 404 Page Not Found: Rssaspx/index
ERROR - 2021-12-03 15:02:53 --> 404 Page Not Found: Datacenter/downloadApp
ERROR - 2021-12-03 15:02:54 --> 404 Page Not Found: admin//index
ERROR - 2021-12-03 15:02:54 --> 404 Page Not Found: Plug/publish
ERROR - 2021-12-03 15:02:57 --> 404 Page Not Found: Public/about.html
ERROR - 2021-12-03 15:02:58 --> 404 Page Not Found: Help/en
ERROR - 2021-12-03 15:02:58 --> 404 Page Not Found: Images/zh-CN
ERROR - 2021-12-03 15:02:59 --> 404 Page Not Found: Images/favicon.ico
ERROR - 2021-12-03 15:03:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 15:03:03 --> 404 Page Not Found: Plus/sitemap.html
ERROR - 2021-12-03 15:03:03 --> 404 Page Not Found: Plus/rssmap.html
ERROR - 2021-12-03 15:03:03 --> 404 Page Not Found: Member/space
ERROR - 2021-12-03 15:03:03 --> 404 Page Not Found: CHANGELOGtxt/index
ERROR - 2021-12-03 15:03:03 --> 404 Page Not Found: Changelogtxt/index
ERROR - 2021-12-03 15:03:03 --> 404 Page Not Found: Help/index
ERROR - 2021-12-03 15:03:04 --> 404 Page Not Found: M/index
ERROR - 2021-12-03 15:03:04 --> 404 Page Not Found: Ycportal/js
ERROR - 2021-12-03 15:03:04 --> 404 Page Not Found: Login/Jeecms.do
ERROR - 2021-12-03 15:03:04 --> 404 Page Not Found: Include/install_ocx.aspx
ERROR - 2021-12-03 15:03:04 --> 404 Page Not Found: Site/Pages
ERROR - 2021-12-03 15:03:05 --> 404 Page Not Found: Nobody/mobile.htm
ERROR - 2021-12-03 15:03:05 --> 404 Page Not Found: System/Update.aspx
ERROR - 2021-12-03 15:03:08 --> 404 Page Not Found: Archiver/index
ERROR - 2021-12-03 15:03:13 --> 404 Page Not Found: Wp-content/index
ERROR - 2021-12-03 15:03:14 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-12-03 15:03:14 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-12-03 15:03:15 --> 404 Page Not Found: Was/help.jsp
ERROR - 2021-12-03 15:03:15 --> 404 Page Not Found: Was5/web
ERROR - 2021-12-03 15:03:15 --> 404 Page Not Found: Was/main.html
ERROR - 2021-12-03 15:03:18 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-12-03 15:03:19 --> 404 Page Not Found: Weblog/index
ERROR - 2021-12-03 15:03:20 --> 404 Page Not Found: Blog/index
ERROR - 2021-12-03 15:03:20 --> 404 Page Not Found: Forum/index
ERROR - 2021-12-03 15:03:20 --> 404 Page Not Found: Bbs/index
ERROR - 2021-12-03 15:03:21 --> 404 Page Not Found: Wcm/index
ERROR - 2021-12-03 15:03:21 --> 404 Page Not Found: admin/Editor/index
ERROR - 2021-12-03 15:04:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:05:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:14:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 15:14:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 15:20:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 15:20:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 15:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 15:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 15:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 15:31:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:32:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:34:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 15:37:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-03 15:39:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:39:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:40:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:40:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:40:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:41:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 15:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:45:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 15:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 15:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 15:47:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:48:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:48:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:48:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:48:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:49:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:49:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:51:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:51:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:52:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:52:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:52:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:53:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:54:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:54:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:54:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:54:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:55:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:55:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:55:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:55:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 15:55:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:56:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 15:57:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 15:57:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:57:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 15:57:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 15:57:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 16:04:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:05:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:08:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 16:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 16:10:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:10:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 16:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 16:13:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:14:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 16:14:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:14:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 16:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 16:19:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:21:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 16:27:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-03 16:28:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 16:39:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 16:39:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 16:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 16:45:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:46:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:46:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:48:40 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-12-03 16:50:46 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-12-03 16:50:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:51:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:55:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:55:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 16:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:02:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 17:02:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:06:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:07:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 17:08:32 --> Severity: error --> 11111 test 1
ERROR - 2021-12-03 17:11:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:11:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:12:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:13:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:19:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:20:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:20:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:21:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:21:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:25:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 17:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 17:35:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 17:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 17:51:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 17:59:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:03:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:04:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 18:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:06:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:09:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:16:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:16:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:19:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 18:19:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 18:19:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:19:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 18:20:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 18:21:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 18:23:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:23:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:25:35 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-12-03 18:25:58 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-12-03 18:26:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 18:29:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 18:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:33:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 18:33:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 18:36:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:39:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:39:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:43:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:46:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 18:53:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:53:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 18:56:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 18:59:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:00:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:00:52 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-12-03 19:03:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:05:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 19:10:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 19:10:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 19:10:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:12:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 19:12:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 19:12:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 19:12:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 19:13:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:15:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 19:16:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:16:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:18:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 19:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 19:19:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 19:20:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:23:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 19:30:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 19:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 19:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 19:33:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:36:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:40:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:40:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 19:46:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 19:46:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:46:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:50:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:53:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 19:58:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 19:59:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-03 19:59:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 20:08:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:08:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:09:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:09:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 20:12:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:12:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:13:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:13:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:15:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:16:07 --> 404 Page Not Found: City/15
ERROR - 2021-12-03 20:19:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:19:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:20:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:21:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:26:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:27:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:27:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:27:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:27:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:28:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:28:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:28:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:29:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:29:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:30:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:36:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 20:40:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:41:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:45:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:45:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 20:46:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:57:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 20:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 21:01:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 21:06:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:11:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:12:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:19:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:20:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:20:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:21:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:22:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:22:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:22:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:22:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-03 21:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:23:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:24:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:28:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 21:29:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 21:29:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 21:29:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 21:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 21:31:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 21:38:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 21:41:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:42:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:43:31 --> 404 Page Not Found: admin//index
ERROR - 2021-12-03 21:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 21:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 21:50:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:51:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 21:53:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 21:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 21:54:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 22:06:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:12:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:15:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:17:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 22:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 22:25:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-03 22:27:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:31:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:32:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:32:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:33:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:33:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:33:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:34:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:34:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:37:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:39:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:43:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 22:46:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:46:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:47:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:47:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:47:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:47:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:48:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 22:48:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:48:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:48:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:48:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:49:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:49:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:49:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:49:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:50:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:50:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:51:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:52:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:52:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 22:53:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:53:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:58:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 22:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 23:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-03 23:06:53 --> 404 Page Not Found: Article/view
ERROR - 2021-12-03 23:12:28 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-12-03 23:13:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:17:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:18:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:19:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:19:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:19:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:19:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:20:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:20:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:20:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:21:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:22:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:23:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:23:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:23:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:23:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:23:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:24:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:24:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:24:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:24:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:24:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:25:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:25:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:26:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:26:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:27:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:27:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:27:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:27:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:28:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:31:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:43:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:49:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:52:10 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-12-03 23:52:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:55:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-03 23:55:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 23:58:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-03 23:59:33 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
