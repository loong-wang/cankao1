<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-17 00:18:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 00:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 00:19:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 00:26:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 00:26:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 00:26:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 00:31:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 00:38:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 01:07:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Member/space
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 01:17:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 01:17:18 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-17 01:17:18 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-17 01:17:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 01:17:18 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-17 01:17:19 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 01:17:19 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 01:17:19 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-17 01:17:19 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 01:23:38 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2022-01-17 01:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 01:31:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 01:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 01:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 01:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 01:44:04 --> 404 Page Not Found: City/1
ERROR - 2022-01-17 01:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 02:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 02:13:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 02:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 02:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 02:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 02:25:24 --> 404 Page Not Found: All/index
ERROR - 2022-01-17 02:31:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 02:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 02:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 03:07:06 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-01-17 03:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 03:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 03:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 03:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 03:42:55 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-17 03:42:55 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-17 03:42:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 03:42:55 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 03:42:55 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 03:42:55 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 03:42:55 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 03:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 03:42:55 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-17 03:42:55 --> 404 Page Not Found: Member/space
ERROR - 2022-01-17 03:42:55 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 03:42:56 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 03:42:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 03:42:56 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-17 03:42:56 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-17 03:42:57 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 03:42:57 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-17 03:42:58 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 03:43:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 03:43:00 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-17 03:43:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 03:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 03:43:57 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2022-01-17 04:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 04:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 04:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 04:16:25 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2022-01-17 04:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 04:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 04:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 04:38:21 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2022-01-17 04:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 04:53:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 05:04:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 05:06:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 05:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 05:12:33 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-01-17 05:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 05:20:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 05:20:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 05:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 05:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 05:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 05:38:35 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2022-01-17 05:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 05:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 05:58:15 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-01-17 06:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 06:08:59 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2022-01-17 06:13:38 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2022-01-17 06:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 06:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 06:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 06:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 06:51:36 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-17 06:51:36 --> 404 Page Not Found: admin//index
ERROR - 2022-01-17 06:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 06:51:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 06:51:37 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-17 06:51:37 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-01-17 06:51:37 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-01-17 06:51:39 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-01-17 06:51:39 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-01-17 06:51:39 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-01-17 06:51:39 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-17 06:51:39 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-17 06:51:39 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-17 06:51:39 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-17 06:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 06:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 07:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 07:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 07:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 07:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 08:02:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:02:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 08:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 08:21:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 08:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 08:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 08:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 08:27:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:30:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 08:46:44 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2022-01-17 08:47:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 08:49:27 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2022-01-17 08:55:10 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2022-01-17 09:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 09:04:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 09:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 09:20:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 09:22:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 09:33:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 09:38:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 09:40:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 09:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 09:52:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 09:54:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 10:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:03:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 10:19:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 10:24:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 10:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:45:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-01-17 10:46:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 10:47:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 10:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:52:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 10:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 10:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:00:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 11:12:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 11:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:26:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:29:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 11:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 11:32:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 11:38:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 11:38:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 12:01:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 12:03:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 12:07:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 12:17:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 12:19:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 12:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 12:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 12:26:57 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2022-01-17 12:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 12:32:52 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 12:34:50 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 12:41:48 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 12:43:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 12:47:26 --> 404 Page Not Found: City/1
ERROR - 2022-01-17 12:51:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 12:51:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 12:51:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 12:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 13:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 13:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 13:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 13:19:56 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 13:33:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 13:33:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 13:34:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 13:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 13:38:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 13:38:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 13:38:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 13:38:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 13:38:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 13:38:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 13:38:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 13:38:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 13:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 13:41:34 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-17 13:41:34 --> 404 Page Not Found: admin//index
ERROR - 2022-01-17 13:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 13:41:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 13:41:36 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-17 13:41:36 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-01-17 13:41:36 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-01-17 13:41:37 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-01-17 13:41:37 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-01-17 13:41:37 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-01-17 13:41:37 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-17 13:41:37 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-17 13:41:37 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-17 13:41:37 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-17 13:46:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 13:57:21 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 13:59:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 13:59:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 13:59:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 13:59:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 13:59:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-17 14:03:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 14:03:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:03:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:03:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:03:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:03:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:03:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:04:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:05:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 14:05:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 14:05:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:10:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 14:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 14:24:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 14:24:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 14:25:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 14:25:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 14:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:26:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:26:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:26:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:27:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:28:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:28:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 14:36:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 14:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 14:37:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 14:47:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 14:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 14:55:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:55:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:56:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:57:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:57:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:58:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:58:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 14:59:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 15:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:09:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:10:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:10:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:12:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:12:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:13:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:14:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:14:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 15:15:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:17:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 15:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 15:19:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 15:35:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 15:39:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 15:39:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 15:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 16:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 16:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 16:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 16:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 16:17:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 16:21:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 16:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 16:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 16:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 16:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 16:36:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 16:36:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 16:36:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 16:47:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 16:47:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 16:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 16:50:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 16:51:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 17:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 17:24:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 17:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 17:29:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 17:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 17:42:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 17:43:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 17:43:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 17:43:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 17:54:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 17:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 18:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 18:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 18:17:53 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-17 18:17:53 --> 404 Page Not Found: admin//index
ERROR - 2022-01-17 18:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 18:17:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 18:17:53 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-17 18:17:53 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-17 18:17:54 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-17 18:17:54 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-17 18:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 18:23:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:24:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:25:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 18:26:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:26:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:26:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:27:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:28:54 --> 404 Page Not Found: admin//index
ERROR - 2022-01-17 18:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 18:28:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 18:28:54 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-17 18:28:54 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-17 18:28:54 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-17 18:28:55 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-17 18:29:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:29:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:30:00 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-17 18:30:00 --> 404 Page Not Found: admin//index
ERROR - 2022-01-17 18:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 18:30:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 18:30:00 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-17 18:30:00 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-17 18:30:00 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-17 18:30:00 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-17 18:32:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:33:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-17 18:34:37 --> Severity: Warning --> Missing argument 1 for Kefu::show() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 359
ERROR - 2022-01-17 18:34:57 --> 404 Page Not Found: City/1
ERROR - 2022-01-17 18:34:59 --> 404 Page Not Found: City/1
ERROR - 2022-01-17 18:34:59 --> 404 Page Not Found: City/1
ERROR - 2022-01-17 18:35:02 --> 404 Page Not Found: City/1
ERROR - 2022-01-17 18:35:05 --> 404 Page Not Found: City/1
ERROR - 2022-01-17 18:35:53 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-17 18:35:53 --> 404 Page Not Found: admin//index
ERROR - 2022-01-17 18:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 18:35:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 18:35:55 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-17 18:35:55 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-01-17 18:35:55 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-01-17 18:35:56 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-01-17 18:35:56 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-01-17 18:35:56 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-01-17 18:35:56 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-17 18:35:57 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-17 18:35:57 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-17 18:35:57 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-17 18:35:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:39:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 18:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 19:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 19:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 19:15:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 19:21:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 19:25:35 --> 404 Page Not Found: City/9
ERROR - 2022-01-17 19:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 19:29:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 19:29:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 19:29:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 19:30:25 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-01-17 19:30:25 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-01-17 19:30:26 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2022-01-17 19:30:26 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2022-01-17 19:30:26 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-01-17 19:30:26 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2022-01-17 19:30:42 --> 404 Page Not Found: City/1
ERROR - 2022-01-17 19:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 19:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 19:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 19:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 19:45:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 19:53:17 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-17 19:54:02 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-17 19:54:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 19:55:07 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-17 19:56:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 20:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 20:09:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:11:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:11:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:11:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:13:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:15:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 20:16:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:16:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 20:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 20:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 20:23:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 20:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 20:30:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 20:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 20:31:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:32:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 20:33:24 --> 404 Page Not Found: English/index
ERROR - 2022-01-17 20:43:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:43:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:44:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:45:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 20:45:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 20:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 20:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 20:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 20:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 21:01:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 21:02:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 21:09:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:10:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:10:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:11:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:11:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:11:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:11:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 21:11:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:12:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 21:19:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 21:19:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 21:19:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 21:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 21:21:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 21:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 21:22:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:24:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 21:26:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 21:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 21:35:22 --> 404 Page Not Found: Config/aspcms_config.asp
ERROR - 2022-01-17 21:35:22 --> 404 Page Not Found: Config/aspcms_config.asp
ERROR - 2022-01-17 21:39:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:45:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 21:46:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 21:48:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:49:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:50:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 21:51:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:51:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 21:51:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 21:51:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 21:51:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:51:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 21:52:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 21:56:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 22:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 22:04:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-17 22:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 22:06:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:07:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 22:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:10:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:10:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 22:11:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 22:17:27 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-01-17 22:20:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:20:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:20:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:20:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 22:20:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 22:21:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:27:58 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-01-17 22:28:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 22:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 22:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 22:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 22:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 22:44:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:44:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:47:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 22:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 22:59:26 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-01-17 22:59:26 --> 404 Page Not Found: admin//index
ERROR - 2022-01-17 22:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 22:59:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 22:59:27 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-01-17 22:59:27 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-01-17 22:59:27 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-17 22:59:27 --> 404 Page Not Found: Wcm/index
ERROR - 2022-01-17 23:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 23:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 23:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 23:04:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 23:05:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-17 23:06:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:06:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:06:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:06:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:06:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:06:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:06:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:06:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:08:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:08:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:17:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 23:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 23:25:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:34:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 23:48:04 --> 404 Page Not Found: English/index
ERROR - 2022-01-17 23:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-17 23:57:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-17 23:58:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
