<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-14 00:00:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:00:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:00:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:01:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:01:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:01:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:02:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:02:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:02:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:02:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:02:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:02:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:02:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:03:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:03:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 00:04:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:05:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:06:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:06:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:07:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 00:08:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 00:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:15:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:19:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:29:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:31:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:32:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:32:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:33:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:34:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:34:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:35:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:35:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:35:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:35:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:35:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:35:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:36:08 --> 404 Page Not Found: Ask/index
ERROR - 2022-02-14 00:39:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:40:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 00:52:35 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 01:00:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 01:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 01:21:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-14 01:22:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-14 01:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 01:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 01:33:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 01:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 01:34:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 01:37:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-14 01:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 01:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 01:53:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 01:53:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 01:54:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 01:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 02:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 02:12:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:12:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:16:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:18:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 02:23:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:23:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 02:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 02:29:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 02:29:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 02:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 02:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 02:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 02:58:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 02:58:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 03:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 03:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 03:19:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 03:27:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 03:29:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 03:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 03:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 03:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 03:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 03:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 03:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 03:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 03:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 04:12:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-14 04:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 04:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 04:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 04:24:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 04:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 04:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 04:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 04:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 04:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 04:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 04:52:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 04:55:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 05:08:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 05:13:37 --> 404 Page Not Found: App/views
ERROR - 2022-02-14 05:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 05:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 05:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 05:39:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 05:39:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 05:42:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 05:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 05:51:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 05:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 05:52:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 05:52:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 05:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 06:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 06:01:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-14 06:07:51 --> 404 Page Not Found: Boaform/admin
ERROR - 2022-02-14 06:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 06:16:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-14 06:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 06:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 06:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 06:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 06:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 06:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 06:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 07:00:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 07:00:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 07:11:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-14 07:16:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-14 07:27:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 07:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 07:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 07:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 07:41:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 07:49:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 07:52:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 07:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 07:53:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 08:00:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:06:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 08:06:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 08:07:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 08:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 08:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 08:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 08:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 08:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 08:34:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:34:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 08:34:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:34:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:35:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:36:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:36:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:37:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:37:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:37:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 08:37:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:37:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 08:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 08:56:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:56:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 08:57:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 08:59:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:19:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:20:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:20:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:22:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:22:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:22:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:42:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:44:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:44:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 09:44:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:45:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:45:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:46:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:46:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:46:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:46:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:47:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:47:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:48:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 09:52:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 09:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 10:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 10:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 10:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 10:12:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 10:25:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 10:26:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 10:26:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 10:26:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 10:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 10:32:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 10:32:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 10:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 10:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 10:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 10:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 10:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 10:52:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 10:54:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 10:56:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 10:59:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 11:10:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 11:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 11:22:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:33:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:34:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:34:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:36:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:37:21 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-14 11:37:21 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-14 11:37:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 11:37:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 11:37:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 11:37:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 11:37:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 11:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 11:37:24 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-14 11:37:25 --> 404 Page Not Found: Member/space
ERROR - 2022-02-14 11:37:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 11:37:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 11:37:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 11:37:30 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-14 11:37:30 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-14 11:37:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 11:37:31 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-14 11:37:33 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 11:37:33 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 11:37:33 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-14 11:37:33 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 11:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 11:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 11:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 11:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 11:56:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:57:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:57:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:57:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:57:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:58:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:58:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:59:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 11:59:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:00:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:07:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 12:15:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:16:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:16:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:16:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:19:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:20:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:20:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:25:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 12:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 12:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 12:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 12:40:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 12:40:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 12:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 12:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 12:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 12:54:56 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 12:54:58 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 12:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 12:55:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:56:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:57:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 12:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 12:59:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 13:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 13:06:10 --> 404 Page Not Found: Sdk/index
ERROR - 2022-02-14 13:06:10 --> 404 Page Not Found: Text4041644815170/index
ERROR - 2022-02-14 13:06:10 --> 404 Page Not Found: Evox/about
ERROR - 2022-02-14 13:06:11 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-02-14 13:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 13:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 13:07:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 13:14:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 13:16:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-14 13:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 13:31:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 13:31:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 13:31:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 13:31:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 13:32:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 13:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 13:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 13:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 13:47:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 13:48:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 13:50:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 13:52:34 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 13:57:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 13:59:47 --> 404 Page Not Found: City/10
ERROR - 2022-02-14 14:01:21 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 14:03:22 --> 404 Page Not Found: City/1
ERROR - 2022-02-14 14:14:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 14:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 14:17:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 14:19:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 14:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 14:25:11 --> 404 Page Not Found: Management/Login.Asp
ERROR - 2022-02-14 14:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 14:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 14:35:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 14:39:58 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-14 14:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 14:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 14:50:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 14:50:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 14:51:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 14:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 14:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 14:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 14:58:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:00:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:02:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:03:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:05:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:05:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:05:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:06:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 15:08:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:08:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:09:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:11:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:11:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:16:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:16:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:17:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:17:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:17:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:24:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:24:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:24:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:26:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:27:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:27:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:31:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:46:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:46:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:46:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 15:46:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 15:47:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:47:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 15:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:47:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 15:48:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 15:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:49:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 15:49:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 15:49:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 15:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 15:51:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 15:56:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 15:56:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 16:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:00:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 16:00:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 16:03:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 16:05:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 16:07:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:11:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:11:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:11:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 16:15:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:16:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:19:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 16:19:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 16:21:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:24:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:27:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:27:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 16:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 16:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 16:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 16:35:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:36:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:38:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 16:38:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:38:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 16:38:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 16:38:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:40:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:42:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:43:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 16:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 16:48:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:50:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:51:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:52:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:52:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:52:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 16:56:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:56:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 16:58:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 16:59:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:01:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 17:04:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:07:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:09:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:11:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:15:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:17:58 --> 404 Page Not Found: Login/index
ERROR - 2022-02-14 17:18:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:19:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:19:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 17:21:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 17:28:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:29:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:30:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:30:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:33:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:37:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:39:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:40:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:41:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:43:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:43:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 17:45:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:45:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:46:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:46:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:47:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:47:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:47:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:48:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:48:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:48:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:49:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:49:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:49:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:50:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:52:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:52:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:53:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:55:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 17:56:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:56:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:57:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:57:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 17:58:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:00:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 18:01:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:02:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 18:05:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 18:05:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 18:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 18:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 18:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 18:13:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:17:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 18:21:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 18:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 18:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 18:29:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:29:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:29:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:30:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:30:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:31:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 18:37:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:41:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 18:50:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 18:50:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:50:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:51:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:52:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 18:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 18:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 19:03:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:03:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:03:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:03:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:04:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:13:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 19:13:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 19:16:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 19:22:47 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2022-02-14 19:24:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 19:25:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:28:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:29:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:29:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:30:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:31:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 19:31:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:31:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:32:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 19:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:35:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:35:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:37:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:37:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:39:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:39:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:40:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:41:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 19:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 19:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 19:50:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:50:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:51:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:51:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 19:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 20:03:45 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2022-02-14 20:07:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-14 20:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 20:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 20:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 20:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 20:37:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 20:37:41 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-14 20:38:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 20:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 20:42:44 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2022-02-14 20:45:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:47:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:49:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:50:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:53:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:54:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:55:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 20:56:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 20:56:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:56:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:56:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:57:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:58:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:58:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:58:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 20:59:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 20:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 21:00:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 21:02:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:09:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 21:09:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:11:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 21:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 21:19:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-14 21:22:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:24:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:24:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:27:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:31:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 21:31:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:32:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:36:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:41:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 21:41:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 21:41:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 21:41:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 21:42:46 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Member/space
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 21:42:47 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-14 21:42:48 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-14 21:42:48 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 21:42:48 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-14 21:42:49 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 21:42:49 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 21:42:50 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-14 21:42:50 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 21:42:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:43:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:43:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:43:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:44:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:45:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:45:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:45:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 21:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 21:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 21:54:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 21:55:49 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2022-02-14 21:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 22:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 22:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 22:12:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 22:14:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 22:15:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 22:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 22:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 22:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 22:38:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 22:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 22:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 22:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 22:56:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 22:59:09 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-14 23:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 23:06:22 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-14 23:06:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-14 23:07:33 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-14 23:07:33 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-14 23:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 23:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 23:08:43 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2022-02-14 23:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 23:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 23:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 23:22:56 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-14 23:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 23:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-14 23:49:52 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2022-02-14 23:52:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 23:53:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 23:56:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-14 23:57:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
