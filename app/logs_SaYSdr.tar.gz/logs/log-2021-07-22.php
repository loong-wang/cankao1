<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-22 00:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:00:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:01:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:02:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:02:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:03:45 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-07-22 00:03:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:04:50 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-22 00:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:06:36 --> 404 Page Not Found: Cgi-bin/jarrewrite.sh
ERROR - 2021-07-22 00:06:39 --> 404 Page Not Found: Cgi-bin/jarrewrite.sh
ERROR - 2021-07-22 00:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:08:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:11:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:11:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 00:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:12:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:16:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:16:59 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-22 00:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:18:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 00:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:19:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 00:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:20:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:23:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 00:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:25:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 00:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:27:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:28:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:28:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:31:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 00:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:33:18 --> 404 Page Not Found: Html-en/new-products-xnQJxLxEQmzH-3-0-1-1.html
ERROR - 2021-07-22 00:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:35:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:37:45 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 00:37:45 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-22 00:37:46 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 00:37:47 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 00:37:47 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-22 00:37:47 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 00:37:47 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-22 00:37:47 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-22 00:37:47 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-22 00:37:47 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-22 00:37:47 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 00:37:47 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 00:37:47 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 00:37:48 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-22 00:37:48 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-22 00:37:48 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-22 00:37:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:38:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:39:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:43:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:43:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:43:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:44:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:44:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 00:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:46:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 00:46:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 00:47:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:48:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 00:48:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 00:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:49:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 00:50:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 00:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:55:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:55:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:55:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:56:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:56:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:57:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:57:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:58:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 00:59:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 00:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:00:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:00:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:01:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:01:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:03:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:04:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:04:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:05:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:05:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:06:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 01:06:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:07:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:09:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:10:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:11:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:11:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 01:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:15:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:15:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 01:15:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:15:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:15:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:17:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:18:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 01:18:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:18:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:18:38 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-22 01:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:21:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:22:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:22:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:23:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:23:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:24:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:24:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:25:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:25:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:26:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:26:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 01:26:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:26:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:31:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:32:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 01:32:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 01:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:38:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:40:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:40:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:42:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:44:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:45:34 --> 404 Page Not Found: Afficheasp/index
ERROR - 2021-07-22 01:45:34 --> 404 Page Not Found: Afficheasp/index
ERROR - 2021-07-22 01:46:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:48:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:48:53 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-07-22 01:48:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:49:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:49:13 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-07-22 01:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:49:38 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-07-22 01:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:49:50 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-07-22 01:49:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 01:50:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:54:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 01:55:37 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-07-22 01:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:57:36 --> 404 Page Not Found: Config/getuser
ERROR - 2021-07-22 01:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 01:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:04:26 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-22 02:04:57 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-22 02:05:24 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-22 02:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:06:17 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-22 02:06:45 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-22 02:07:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:07:39 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-22 02:07:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:08:07 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-22 02:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:08:17 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2021-07-22 02:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:08:20 --> 404 Page Not Found: Sitemap62912html/index
ERROR - 2021-07-22 02:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:08:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:09:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:10:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:10:20 --> 404 Page Not Found: Sitemap83112html/index
ERROR - 2021-07-22 02:10:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:11:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 02:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:12:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:13:12 --> 404 Page Not Found: Sitemap66020html/index
ERROR - 2021-07-22 02:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:13:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:14:06 --> 404 Page Not Found: Article/index
ERROR - 2021-07-22 02:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:14:56 --> 404 Page Not Found: Sitemap69228html/index
ERROR - 2021-07-22 02:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:15:37 --> 404 Page Not Found: Sitemap10665html/index
ERROR - 2021-07-22 02:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:15:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:16:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:16:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:24:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:24:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:25:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:25:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:25:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:31:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 02:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:35:26 --> 404 Page Not Found: admin/Index/index
ERROR - 2021-07-22 02:35:26 --> 404 Page Not Found: Market/market-ws
ERROR - 2021-07-22 02:35:31 --> 404 Page Not Found: H5/index
ERROR - 2021-07-22 02:35:31 --> 404 Page Not Found: Web/api
ERROR - 2021-07-22 02:35:33 --> 404 Page Not Found: Room/getRoomBangFans
ERROR - 2021-07-22 02:35:33 --> 404 Page Not Found: Home/loadmymanager
ERROR - 2021-07-22 02:35:33 --> 404 Page Not Found: Room/1002
ERROR - 2021-07-22 02:35:34 --> 404 Page Not Found: Account/login
ERROR - 2021-07-22 02:35:34 --> 404 Page Not Found: Index/login
ERROR - 2021-07-22 02:35:34 --> 404 Page Not Found: Base/exchange_article
ERROR - 2021-07-22 02:35:35 --> 404 Page Not Found: Legal/currency
ERROR - 2021-07-22 02:35:35 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-07-22 02:35:35 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-07-22 02:35:35 --> 404 Page Not Found: S_api/basic
ERROR - 2021-07-22 02:35:36 --> 404 Page Not Found: S_api/basic
ERROR - 2021-07-22 02:35:36 --> 404 Page Not Found: Api/user
ERROR - 2021-07-22 02:35:37 --> 404 Page Not Found: User/userlist
ERROR - 2021-07-22 02:35:37 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-07-22 02:35:37 --> 404 Page Not Found: Api/content_bottom
ERROR - 2021-07-22 02:35:37 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-07-22 02:35:37 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-07-22 02:35:37 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-07-22 02:35:37 --> 404 Page Not Found: Mobile/v3
ERROR - 2021-07-22 02:35:37 --> 404 Page Not Found: V1/management
ERROR - 2021-07-22 02:35:38 --> 404 Page Not Found: Xianyu/index
ERROR - 2021-07-22 02:35:38 --> 404 Page Not Found: Xy/index
ERROR - 2021-07-22 02:35:40 --> 404 Page Not Found: M/ticker
ERROR - 2021-07-22 02:35:40 --> 404 Page Not Found: M/allticker
ERROR - 2021-07-22 02:35:41 --> 404 Page Not Found: Pc/Lang
ERROR - 2021-07-22 02:35:41 --> 404 Page Not Found: Home/Bind
ERROR - 2021-07-22 02:35:41 --> 404 Page Not Found: Ajax/allcoin_a
ERROR - 2021-07-22 02:35:42 --> 404 Page Not Found: Recruit/download_url
ERROR - 2021-07-22 02:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:35:45 --> 404 Page Not Found: Infe/rest
ERROR - 2021-07-22 02:35:45 --> 404 Page Not Found: N/news
ERROR - 2021-07-22 02:35:45 --> 404 Page Not Found: Home/GetAllGameCategory
ERROR - 2021-07-22 02:35:45 --> 404 Page Not Found: Infe/rest
ERROR - 2021-07-22 02:35:47 --> 404 Page Not Found: Static/local
ERROR - 2021-07-22 02:35:50 --> 404 Page Not Found: Home/GetQrCodeInfo
ERROR - 2021-07-22 02:35:51 --> 404 Page Not Found: Mh/phone.do
ERROR - 2021-07-22 02:35:51 --> 404 Page Not Found: FePublicInfo/index
ERROR - 2021-07-22 02:35:52 --> 404 Page Not Found: Wap/trading
ERROR - 2021-07-22 02:35:53 --> 404 Page Not Found: Api/v1
ERROR - 2021-07-22 02:35:57 --> 404 Page Not Found: Wap/trading
ERROR - 2021-07-22 02:35:57 --> 404 Page Not Found: Api/ApiHub
ERROR - 2021-07-22 02:35:58 --> 404 Page Not Found: Front/User
ERROR - 2021-07-22 02:36:00 --> 404 Page Not Found: Front/FctPage
ERROR - 2021-07-22 02:36:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 02:36:06 --> 404 Page Not Found: Ajax/index
ERROR - 2021-07-22 02:36:07 --> 404 Page Not Found: CscpLoginWeb/app
ERROR - 2021-07-22 02:36:11 --> 404 Page Not Found: admin//index
ERROR - 2021-07-22 02:36:11 --> 404 Page Not Found: Verificationasp/index
ERROR - 2021-07-22 02:36:11 --> 404 Page Not Found: Step1asp/index
ERROR - 2021-07-22 02:36:11 --> 404 Page Not Found: Home/Get
ERROR - 2021-07-22 02:36:16 --> 404 Page Not Found: Site/get-hq
ERROR - 2021-07-22 02:36:16 --> 404 Page Not Found: Ws/index
ERROR - 2021-07-22 02:36:16 --> 404 Page Not Found: Mtjahtml/index
ERROR - 2021-07-22 02:36:19 --> 404 Page Not Found: Api/uploads
ERROR - 2021-07-22 02:36:21 --> 404 Page Not Found: Api/v
ERROR - 2021-07-22 02:36:21 --> 404 Page Not Found: Static/data
ERROR - 2021-07-22 02:36:22 --> 404 Page Not Found: Homes/index
ERROR - 2021-07-22 02:36:22 --> 404 Page Not Found: Promotions/list.mvc
ERROR - 2021-07-22 02:36:27 --> 404 Page Not Found: Homes/index
ERROR - 2021-07-22 02:36:30 --> 404 Page Not Found: Sign/index
ERROR - 2021-07-22 02:36:31 --> 404 Page Not Found: H5/index
ERROR - 2021-07-22 02:36:31 --> 404 Page Not Found: Wap/Api
ERROR - 2021-07-22 02:36:32 --> 404 Page Not Found: Home/login
ERROR - 2021-07-22 02:36:33 --> 404 Page Not Found: Api/wallet
ERROR - 2021-07-22 02:36:33 --> 404 Page Not Found: Wap/Api
ERROR - 2021-07-22 02:36:33 --> 404 Page Not Found: Anquan/qgga.asp
ERROR - 2021-07-22 02:36:37 --> 404 Page Not Found: Index/index
ERROR - 2021-07-22 02:36:37 --> 404 Page Not Found: Api/message
ERROR - 2021-07-22 02:36:37 --> 404 Page Not Found: Api/product
ERROR - 2021-07-22 02:36:38 --> 404 Page Not Found: Base/goexjs
ERROR - 2021-07-22 02:36:38 --> 404 Page Not Found: Api/v1
ERROR - 2021-07-22 02:36:38 --> 404 Page Not Found: Api/stock
ERROR - 2021-07-22 02:36:38 --> 404 Page Not Found: Static/mobile
ERROR - 2021-07-22 02:36:38 --> 404 Page Not Found: Api/currency
ERROR - 2021-07-22 02:36:39 --> 404 Page Not Found: Content/favicon.ico
ERROR - 2021-07-22 02:36:39 --> 404 Page Not Found: Api/apps
ERROR - 2021-07-22 02:36:39 --> 404 Page Not Found: Market/getStockBaseInfo
ERROR - 2021-07-22 02:36:40 --> 404 Page Not Found: Index/api
ERROR - 2021-07-22 02:36:40 --> 404 Page Not Found: Stock/search.html
ERROR - 2021-07-22 02:36:41 --> 404 Page Not Found: Loan/index
ERROR - 2021-07-22 02:36:41 --> 404 Page Not Found: Api/exclude
ERROR - 2021-07-22 02:36:44 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-07-22 02:36:44 --> 404 Page Not Found: Api/contactWay
ERROR - 2021-07-22 02:36:44 --> 404 Page Not Found: FriendGroup/list
ERROR - 2021-07-22 02:36:45 --> 404 Page Not Found: Api/v1
ERROR - 2021-07-22 02:36:45 --> 404 Page Not Found: Mytio/config
ERROR - 2021-07-22 02:36:46 --> 404 Page Not Found: Api/user
ERROR - 2021-07-22 02:36:46 --> 404 Page Not Found: Site/info
ERROR - 2021-07-22 02:36:46 --> 404 Page Not Found: Api/common
ERROR - 2021-07-22 02:36:49 --> 404 Page Not Found: Im/in
ERROR - 2021-07-22 02:36:49 --> 404 Page Not Found: Appxz/index.html
ERROR - 2021-07-22 02:36:49 --> 404 Page Not Found: Api/linkPF
ERROR - 2021-07-22 02:36:51 --> 404 Page Not Found: M/index
ERROR - 2021-07-22 02:36:53 --> 404 Page Not Found: Portal/index
ERROR - 2021-07-22 02:36:53 --> 404 Page Not Found: Home/GetInitSource
ERROR - 2021-07-22 02:36:54 --> 404 Page Not Found: Api/mobile
ERROR - 2021-07-22 02:36:54 --> 404 Page Not Found: Home/main
ERROR - 2021-07-22 02:36:59 --> 404 Page Not Found: Api/index
ERROR - 2021-07-22 02:37:00 --> 404 Page Not Found: Api/config-init
ERROR - 2021-07-22 02:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:41:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:41:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:41:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:41:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:41:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:41:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:42:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:42:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:42:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:42:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:42:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:42:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:42:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:43:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:43:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:43:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:43:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:43:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:43:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:43:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:44:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:44:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:44:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:44:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:45:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:45:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:45:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:45:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:45:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:45:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:45:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:45:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:45:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:45:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:45:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:45:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 02:46:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:46:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:46:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:46:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:46:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:46:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:46:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:46:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:46:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:46:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:47:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:47:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:47:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:47:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:47:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:47:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:48:18 --> 404 Page Not Found: Vod-search-wd-%E5%B0%8F%E9%87%8E%E5%A4%A7%E8%BC%94-p-1html/index
ERROR - 2021-07-22 02:48:19 --> 404 Page Not Found: Vod-play-id-2376-sid-0-pid-128html/index
ERROR - 2021-07-22 02:48:20 --> 404 Page Not Found: Vod-play-id-2280-sid-0-pid-46html/index
ERROR - 2021-07-22 02:48:23 --> 404 Page Not Found: Vod-play-id-2226-sid-0-pid-74html/index
ERROR - 2021-07-22 02:48:25 --> 404 Page Not Found: Vod-play-id-2346-sid-0-pid-136html/index
ERROR - 2021-07-22 02:48:25 --> 404 Page Not Found: Vod-search-wd-%E5%BC%A0%E7%BB%8D%E5%88%9A-p-1html/index
ERROR - 2021-07-22 02:48:29 --> 404 Page Not Found: Vod-play-id-2323-sid-0-pid-8html/index
ERROR - 2021-07-22 02:48:29 --> 404 Page Not Found: Vod-play-id-2736-sid-0-pid-3html/index
ERROR - 2021-07-22 02:48:30 --> 404 Page Not Found: Vod-play-id-2607-sid-0-pid-129html/index
ERROR - 2021-07-22 02:48:31 --> 404 Page Not Found: Vod-play-id-2608-sid-0-pid-255html/index
ERROR - 2021-07-22 02:48:31 --> 404 Page Not Found: Vod-play-id-2671-sid-0-pid-27html/index
ERROR - 2021-07-22 02:48:37 --> 404 Page Not Found: Vod-play-id-2675-sid-0-pid-92html/index
ERROR - 2021-07-22 02:48:40 --> 404 Page Not Found: Vod-play-id-2279-sid-0-pid-85html/index
ERROR - 2021-07-22 02:48:40 --> 404 Page Not Found: Vod-play-id-2704-sid-0-pid-115html/index
ERROR - 2021-07-22 02:48:46 --> 404 Page Not Found: Vod-play-id-2309-sid-0-pid-21html/index
ERROR - 2021-07-22 02:48:48 --> 404 Page Not Found: Vod-play-id-2682-sid-0-pid-46html/index
ERROR - 2021-07-22 02:48:50 --> 404 Page Not Found: Vod-play-id-2609-sid-0-pid-50html/index
ERROR - 2021-07-22 02:48:51 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-92html/index
ERROR - 2021-07-22 02:48:53 --> 404 Page Not Found: Vod-play-id-2804-sid-0-pid-34html/index
ERROR - 2021-07-22 02:48:53 --> 404 Page Not Found: Vod-play-id-2741-sid-0-pid-4html/index
ERROR - 2021-07-22 02:48:56 --> 404 Page Not Found: Vod-play-id-2668-sid-0-pid-48html/index
ERROR - 2021-07-22 02:48:58 --> 404 Page Not Found: Vod-play-id-2609-sid-0-pid-87html/index
ERROR - 2021-07-22 02:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:49:01 --> 404 Page Not Found: Vod-play-id-2660-sid-0-pid-116html/index
ERROR - 2021-07-22 02:49:06 --> 404 Page Not Found: Vod-play-id-2792-sid-0-pid-3html/index
ERROR - 2021-07-22 02:49:06 --> 404 Page Not Found: Vod-play-id-2729-sid-0-pid-147html/index
ERROR - 2021-07-22 02:49:08 --> 404 Page Not Found: Vod-play-id-2661-sid-0-pid-125html/index
ERROR - 2021-07-22 02:49:09 --> 404 Page Not Found: Vod-play-id-2680-sid-0-pid-156html/index
ERROR - 2021-07-22 02:49:09 --> 404 Page Not Found: Vod-play-id-2320-sid-0-pid-10html/index
ERROR - 2021-07-22 02:49:11 --> 404 Page Not Found: Vod-search-wd-%E5%8C%85%E6%96%87%E5%A9%A7-p-1html/index
ERROR - 2021-07-22 02:49:11 --> 404 Page Not Found: Vod-search-wd-%E9%87%91%E5%A6%AE%E5%BC%97%C2%B7%E5%8F%A4%E5%BE%B7%E6%B8%A9-p-1html/index
ERROR - 2021-07-22 02:49:16 --> 404 Page Not Found: Vod-play-id-2675-sid-0-pid-132html/index
ERROR - 2021-07-22 02:49:17 --> 404 Page Not Found: Vod-play-id-2311-sid-0-pid-58html/index
ERROR - 2021-07-22 02:49:18 --> 404 Page Not Found: Vod-play-id-2612-sid-0-pid-84html/index
ERROR - 2021-07-22 02:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:49:18 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-22 02:49:21 --> 404 Page Not Found: Vod-play-id-2671-sid-0-pid-210html/index
ERROR - 2021-07-22 02:49:22 --> 404 Page Not Found: Vod-play-id-2809-sid-0-pid-4html/index
ERROR - 2021-07-22 02:49:23 --> 404 Page Not Found: Vod-play-id-2704-sid-0-pid-179html/index
ERROR - 2021-07-22 02:49:24 --> 404 Page Not Found: Vod-play-id-2604-sid-0-pid-61html/index
ERROR - 2021-07-22 02:49:25 --> 404 Page Not Found: Vod-play-id-2804-sid-0-pid-16html/index
ERROR - 2021-07-22 02:49:25 --> 404 Page Not Found: Vod-play-id-2671-sid-0-pid-162html/index
ERROR - 2021-07-22 02:49:26 --> 404 Page Not Found: Vod-play-id-2421-sid-0-pid-5html/index
ERROR - 2021-07-22 02:49:28 --> 404 Page Not Found: Vod-play-id-2609-sid-0-pid-25html/index
ERROR - 2021-07-22 02:49:30 --> 404 Page Not Found: Vod-play-id-2346-sid-0-pid-59html/index
ERROR - 2021-07-22 02:49:30 --> 404 Page Not Found: Vod-play-id-2588-sid-0-pid-11html/index
ERROR - 2021-07-22 02:49:30 --> 404 Page Not Found: Vod-play-id-2603-sid-0-pid-207html/index
ERROR - 2021-07-22 02:49:31 --> 404 Page Not Found: Vod-play-id-2680-sid-0-pid-185html/index
ERROR - 2021-07-22 02:49:37 --> 404 Page Not Found: Vod-play-id-2604-sid-0-pid-96html/index
ERROR - 2021-07-22 02:49:39 --> 404 Page Not Found: Vod-play-id-2795-sid-0-pid-28html/index
ERROR - 2021-07-22 02:49:40 --> 404 Page Not Found: Vod-play-id-2603-sid-0-pid-35html/index
ERROR - 2021-07-22 02:49:41 --> 404 Page Not Found: Vod-play-id-2311-sid-0-pid-22html/index
ERROR - 2021-07-22 02:49:43 --> 404 Page Not Found: Vod-play-id-2682-sid-0-pid-89html/index
ERROR - 2021-07-22 02:49:44 --> 404 Page Not Found: Vod-play-id-2376-sid-0-pid-15html/index
ERROR - 2021-07-22 02:49:45 --> 404 Page Not Found: Vod-play-id-2624-sid-0-pid-3html/index
ERROR - 2021-07-22 02:49:47 --> 404 Page Not Found: Vod-play-id-2623-sid-0-pid-6html/index
ERROR - 2021-07-22 02:49:48 --> 404 Page Not Found: Vod-play-id-2605-sid-0-pid-72html/index
ERROR - 2021-07-22 02:49:50 --> 404 Page Not Found: Vod-play-id-2376-sid-0-pid-10html/index
ERROR - 2021-07-22 02:49:52 --> 404 Page Not Found: Vod-play-id-2603-sid-0-pid-204html/index
ERROR - 2021-07-22 02:49:53 --> 404 Page Not Found: Vod-play-id-2675-sid-0-pid-107html/index
ERROR - 2021-07-22 02:49:56 --> 404 Page Not Found: Vod-search-wd-%E6%92%92%E8%B4%9D%E5%AE%81-p-1html/index
ERROR - 2021-07-22 02:49:58 --> 404 Page Not Found: Vod-read-id-2412html/index
ERROR - 2021-07-22 02:50:00 --> 404 Page Not Found: Vod-search-wd-%E6%88%B7%E6%9D%BE%E9%81%A5-p-1html/index
ERROR - 2021-07-22 02:50:03 --> 404 Page Not Found: Vod-play-id-2743-sid-0-pid-74html/index
ERROR - 2021-07-22 02:50:06 --> 404 Page Not Found: Vod-play-id-2608-sid-0-pid-80html/index
ERROR - 2021-07-22 02:50:07 --> 404 Page Not Found: Vod-play-id-2774-sid-0-pid-5html/index
ERROR - 2021-07-22 02:50:08 --> 404 Page Not Found: Vod-play-id-2376-sid-0-pid-121html/index
ERROR - 2021-07-22 02:50:10 --> 404 Page Not Found: Vod-play-id-2709-sid-0-pid-166html/index
ERROR - 2021-07-22 02:50:11 --> 404 Page Not Found: Vod-search-wd-%E5%A4%8F%E8%8F%9C-p-1html/index
ERROR - 2021-07-22 02:50:11 --> 404 Page Not Found: Vod-play-id-2430-sid-0-pid-6html/index
ERROR - 2021-07-22 02:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:52:35 --> 404 Page Not Found: English/index
ERROR - 2021-07-22 02:53:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:53:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:53:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:53:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:54:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:56:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 02:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 02:59:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 02:59:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:06:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:08:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:11:13 --> 404 Page Not Found: 10/10000
ERROR - 2021-07-22 03:11:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:12:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:12:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:12:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:12:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:12:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:18:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 03:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:22:25 --> 404 Page Not Found: City/10
ERROR - 2021-07-22 03:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:23:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 03:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:31:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 03:31:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 03:31:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 03:31:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 03:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:35:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 03:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:39:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:39:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:39:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:39:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:40:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:41:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:43:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:44:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:46:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 03:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:47:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:47:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:49:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:49:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:49:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:49:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:49:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:49:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 03:50:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 03:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:52:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 03:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 03:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-07-22 04:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:03:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 04:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:11:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 04:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:14:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 04:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:18:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 04:18:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 04:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:21:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 04:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:26:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 04:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:31:20 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-07-22 04:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:32:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 04:32:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 04:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:38:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 04:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:44:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 04:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:46:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 04:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:54:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 04:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 04:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:01:29 --> 404 Page Not Found: Old/wp-admin
ERROR - 2021-07-22 05:01:40 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2021-07-22 05:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:06:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:08:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 05:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:15:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:16:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 05:17:33 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 05:17:33 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-22 05:17:34 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-22 05:17:35 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-22 05:17:36 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-22 05:19:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:19:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:20:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:25:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 05:25:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 05:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:32:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:34:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 05:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:34:42 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-07-22 05:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:41:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 05:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:42:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:50:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:50:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:50:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:50:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:50:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:51:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:52:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:53:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 05:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 05:56:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 05:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:02:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 06:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:06:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 06:06:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 06:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:11:44 --> 404 Page Not Found: City/10
ERROR - 2021-07-22 06:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:13:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 06:14:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 06:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:18:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:21:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 06:21:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 06:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:24:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 06:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:25:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 06:27:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 06:27:18 --> 404 Page Not Found: City/1
ERROR - 2021-07-22 06:27:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 06:28:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 06:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:28:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 06:29:48 --> 404 Page Not Found: City/1
ERROR - 2021-07-22 06:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:33:55 --> 404 Page Not Found: City/10
ERROR - 2021-07-22 06:34:49 --> 404 Page Not Found: City/16
ERROR - 2021-07-22 06:34:52 --> 404 Page Not Found: City/15
ERROR - 2021-07-22 06:35:00 --> 404 Page Not Found: City/16
ERROR - 2021-07-22 06:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:36:35 --> 404 Page Not Found: City/2
ERROR - 2021-07-22 06:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:45:55 --> 404 Page Not Found: Html-cn/hot-products-CQxmJTnWDEvg-1-0-2-1.html
ERROR - 2021-07-22 06:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:46:16 --> 404 Page Not Found: Previewdo/index
ERROR - 2021-07-22 06:46:27 --> 404 Page Not Found: Html-en/products-SnEmQNxVDJTz-2-0-2-1.html
ERROR - 2021-07-22 06:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:49:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 06:50:19 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-22 06:50:19 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-22 06:50:19 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-22 06:50:19 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-22 06:50:19 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-22 06:51:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 06:51:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 06:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:51:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 06:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:55:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 06:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:57:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 06:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 06:58:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 06:58:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 07:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:00:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 07:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:01:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:04:31 --> 404 Page Not Found: 10/10000
ERROR - 2021-07-22 07:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:10:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:12:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:17:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:20:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:21:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:23:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 07:24:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:24:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 07:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:26:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:30:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 07:30:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 07:30:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 07:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:31:41 --> 404 Page Not Found: Flu/403.html
ERROR - 2021-07-22 07:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:33:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:38:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 07:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:51:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:52:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:52:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:52:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:52:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:53:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:53:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 07:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:54:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 07:55:57 --> 404 Page Not Found: Env/index
ERROR - 2021-07-22 07:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:56:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 07:57:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 07:57:16 --> 404 Page Not Found: Env/index
ERROR - 2021-07-22 07:57:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 07:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 07:57:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 07:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:00:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 08:00:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:02:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:04:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 08:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:08:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 08:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:19:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:20:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 08:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:22:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:22:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:22:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 08:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:25:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:25:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:28:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:28:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:28:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:28:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:30:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 08:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:31:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 08:32:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:32:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:33:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:35:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:35:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:37:38 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 08:37:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 08:37:38 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-22 08:37:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 08:37:39 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 08:37:39 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-22 08:37:39 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 08:37:39 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-22 08:37:39 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 08:37:39 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 08:37:39 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-22 08:37:39 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 08:37:40 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 08:37:41 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-22 08:37:41 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-22 08:37:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 08:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:38:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:38:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:39:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 08:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:46:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:47:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:51:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 08:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:53:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 08:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:54:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:56:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 08:56:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 08:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:57:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 08:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 08:57:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 08:57:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 08:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:01:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:06:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 09:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:09:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 09:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:10:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 09:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:11:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:15:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 09:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:18:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 09:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:19:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 09:20:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:21:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:22:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:23:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:24:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:24:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:26:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:27:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:28:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:29:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:29:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:31:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:33:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 09:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:38:50 --> 404 Page Not Found: English/index
ERROR - 2021-07-22 09:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:38:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:41:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 09:41:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:41:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:42:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:44:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:45:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:46:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:50:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:50:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:51:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 09:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:51:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:51:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:52:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 09:52:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 09:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:54:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:55:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:56:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:56:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:56:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:56:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:57:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:59:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 09:59:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 09:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 09:59:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 10:00:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:01:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 10:01:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 10:02:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 10:02:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 10:02:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:09:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:09:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:10:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:11:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:11:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:12:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 10:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:13:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 10:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:14:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 10:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:16:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 10:17:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:18:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 10:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:18:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 10:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:20:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 10:20:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:21:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 10:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:22:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 10:25:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 10:25:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 10:26:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 10:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:26:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 10:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:28:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:28:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 10:28:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 10:28:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:29:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:30:10 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session41471d9973da51cc8d6754945956cac57ff33df6): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-22 10:30:10 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiondc04722dde64c4dd6098bdbc81c66dd3a44d181e): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-22 10:30:10 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session1d7c2b2a97a26df380ab08b160ca33ab36be6363): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-22 10:30:10 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionc49de71907f1c28b23b0883d25b70ce0e56f2656): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-22 10:30:10 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session9c745e37d5ff3af50e8e16dff6fe6cbb0bf0c7b5): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-22 10:30:10 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session6e9b6906b6055b4717b8c484cb17450faa872aee): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-22 10:30:10 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session706a66da37d240f3e5c92a128d959706c892b1fc): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-22 10:30:10 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session814785fd15a49a0f8dc160423012bcbe5cd42f69): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-22 10:30:10 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session2ededbeef88aa741e9804e28c7426db9122cb515): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-22 10:30:10 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiond7abbd0f6953b371eaa505e8fcd36256bd309828): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-22 10:30:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 10:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:31:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:31:26 --> 404 Page Not Found: ReportServer/index
ERROR - 2021-07-22 10:31:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:32:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:32:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:33:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:33:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:35:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:36:09 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-22 10:36:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:36:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:46:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:46:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 10:46:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 10:47:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:47:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:48:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:49:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:50:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 10:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:52:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:53:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 10:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:55:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 10:56:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 10:57:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:58:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 10:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:59:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 10:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:02:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 11:02:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 11:02:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 11:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:02:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:03:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:03:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:04:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:05:25 --> 404 Page Not Found: City/9
ERROR - 2021-07-22 11:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:09:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:10:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:10:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:12:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:13:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 11:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:13:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:16:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 11:17:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:17:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 11:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:18:33 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-22 11:18:34 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-22 11:18:45 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-22 11:19:02 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-07-22 11:19:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-22 11:19:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-22 11:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:20:05 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-07-22 11:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:21:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 11:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:21:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:25:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 11:26:29 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-22 11:26:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 11:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:26:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-22 11:26:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-22 11:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:28:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:28:50 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-07-22 11:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:29:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 11:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:29:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:29:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:31:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-22 11:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:33:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:34:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:35:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 11:35:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 11:35:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 11:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:38:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-20, 20' at line 6 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_title` LIKE '%60010%' ESCAPE '!'
OR  `hao_user` LIKE '%60010%' ESCAPE '!'
ORDER BY `hao_time` DESC
 LIMIT -20, 20
ERROR - 2021-07-22 11:38:25 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 1234
ERROR - 2021-07-22 11:38:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-20, 20' at line 6 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_title` LIKE '%60010%' ESCAPE '!'
OR  `hao_user` LIKE '%60010%' ESCAPE '!'
ORDER BY `hao_time` DESC
 LIMIT -20, 20
ERROR - 2021-07-22 11:38:34 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 1234
ERROR - 2021-07-22 11:39:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:40:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:40:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:40:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:41:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 11:41:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:41:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:41:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:41:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:41:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:41:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:46:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 11:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:48:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 11:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:53:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 11:53:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 11:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:57:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 11:57:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:57:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 11:58:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 11:58:06 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-22 11:58:35 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-22 11:58:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 11:59:00 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-22 11:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 11:59:30 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-22 12:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:00:30 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-22 12:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:00:53 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-22 12:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:01:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:01:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:02:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:02:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:02:48 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-22 12:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:07:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:08:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:08:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:11:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:12:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:12:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:12:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:17:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:20:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 12:20:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:20:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:21:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:21:53 --> 404 Page Not Found: Env/index
ERROR - 2021-07-22 12:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:26:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:27:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:28:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:28:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:28:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:30:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:33:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:35:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:35:56 --> 404 Page Not Found: City/1
ERROR - 2021-07-22 12:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:37:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:38:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:38:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:39:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:39:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:39:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:42:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:42:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:43:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:43:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:43:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:44:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:50:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:50:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:51:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 12:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:53:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:54:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:55:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:55:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 12:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 12:58:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:58:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 12:59:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 12:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:02:42 --> 404 Page Not Found: admin/Editor/asp
ERROR - 2021-07-22 13:02:42 --> 404 Page Not Found: admin/Editor/asp
ERROR - 2021-07-22 13:02:42 --> 404 Page Not Found: Editor/asp
ERROR - 2021-07-22 13:02:43 --> 404 Page Not Found: Editor/asp
ERROR - 2021-07-22 13:02:43 --> 404 Page Not Found: Editor/upload_json.asp
ERROR - 2021-07-22 13:02:43 --> 404 Page Not Found: Editor/upload_json.asp
ERROR - 2021-07-22 13:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:07:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 13:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:08:23 --> 404 Page Not Found: English/index
ERROR - 2021-07-22 13:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:11:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 13:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:11:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 13:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:15:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:17:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 13:17:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 13:18:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 13:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:18:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 13:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:19:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 13:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:21:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 13:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:21:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 13:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:25:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 13:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 13:27:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 13:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:27:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 13:27:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 13:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:28:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 13:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:30:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 13:30:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 13:30:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 13:30:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 13:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:40:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 13:40:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 13:40:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 13:40:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 13:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-22 13:41:18 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 13:41:19 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 13:41:20 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 13:41:20 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-22 13:41:20 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-22 13:41:20 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-22 13:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:44:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 13:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:46:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 13:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:46:54 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-07-22 13:46:56 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-07-22 13:46:56 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-07-22 13:46:57 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-07-22 13:46:58 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-07-22 13:46:58 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-07-22 13:46:59 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-07-22 13:47:00 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-07-22 13:47:09 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-07-22 13:47:10 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-07-22 13:47:10 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-07-22 13:47:17 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-07-22 13:47:18 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-07-22 13:47:19 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-07-22 13:47:22 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-07-22 13:47:23 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-07-22 13:47:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 13:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:50:28 --> 404 Page Not Found: Login/index
ERROR - 2021-07-22 13:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:52:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 13:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:54:38 --> 404 Page Not Found: Env/index
ERROR - 2021-07-22 13:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 13:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:04:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 14:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:05:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:05:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:06:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:06:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:07:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:07:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:07:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:08:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:08:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:08:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:08:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:08:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:09:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:10:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:10:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:11:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:11:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:12:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:12:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:15:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:15:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:15:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:16:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:16:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:16:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:16:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:17:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:17:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:17:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:18:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:18:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:18:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:18:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:18:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:19:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:20:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:20:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:20:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:20:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:20:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:21:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:21:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:22:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:22:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:22:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:23:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:23:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:23:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:24:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:24:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:24:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:24:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:24:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:25:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:25:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:25:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:25:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:26:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:26:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:26:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:26:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:26:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:27:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:28:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:28:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:28:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:30:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:31:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:31:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:32:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:32:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:33:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:33:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:35:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:35:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:35:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:36:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:36:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:37:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:37:49 --> 404 Page Not Found: Vod-play-id-2279-sid-0-pid-68html/index
ERROR - 2021-07-22 14:38:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:38:56 --> 404 Page Not Found: Html-en/hot-products-xnQJxLxEQmzH-1--1-1.html
ERROR - 2021-07-22 14:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:39:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:40:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:43:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:43:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:43:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:44:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:46:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:47:17 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 14:47:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 14:47:17 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-22 14:47:18 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-22 14:47:19 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-22 14:47:20 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-22 14:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:49:25 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-07-22 14:50:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:52:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:53:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:53:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 14:53:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:53:31 --> 404 Page Not Found: City/10
ERROR - 2021-07-22 14:53:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:54:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:54:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:54:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:54:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:55:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 14:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:57:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:57:44 --> 404 Page Not Found: City/16
ERROR - 2021-07-22 14:57:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:58:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:58:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:58:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:58:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:59:06 --> 404 Page Not Found: City/15
ERROR - 2021-07-22 14:59:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:59:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 14:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 14:59:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:00:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:00:28 --> 404 Page Not Found: City/2
ERROR - 2021-07-22 15:00:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:00:55 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-22 15:00:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:01:05 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-22 15:01:07 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-22 15:01:12 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-22 15:01:15 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-22 15:01:17 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-22 15:01:21 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-22 15:01:24 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-22 15:01:26 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-22 15:01:40 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-22 15:01:42 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-22 15:01:51 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-22 15:01:54 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-22 15:01:56 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-07-22 15:01:58 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-07-22 15:02:00 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-07-22 15:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:02:03 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-22 15:02:05 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-22 15:02:07 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-22 15:02:25 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-22 15:02:26 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-22 15:02:29 --> 404 Page Not Found: City/index
ERROR - 2021-07-22 15:02:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 15:02:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 15:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:05:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:11:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:14:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:14:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:15:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:16:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:16:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:16:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:17:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:18:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:18:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:18:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 15:21:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 15:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:23:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 15:23:49 --> 404 Page Not Found: English/index
ERROR - 2021-07-22 15:24:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:24:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:24:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:25:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:25:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 15:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:25:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:25:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 15:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:26:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:31:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 15:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:32:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:34:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:35:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 15:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:37:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:37:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:37:44 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-22 15:37:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 15:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:38:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:38:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 15:38:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:38:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 15:38:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:39:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:40:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:40:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 15:40:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:41:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 15:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:44:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:44:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:45:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:46:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:47:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 15:47:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:49:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:50:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 15:50:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:50:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 15:51:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:52:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:52:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:52:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:53:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:53:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:53:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:53:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:57:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:57:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 15:58:41 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-22 15:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 15:59:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 15:59:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 15:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:01:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 16:01:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:02:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:08:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:11:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 16:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:12:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:13:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:13:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:14:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:18:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:20:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 16:21:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:22:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:23:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:25:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:25:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:25:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:26:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 16:27:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 16:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:28:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:28:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:29:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 16:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:30:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:31:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 16:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:31:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 16:31:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:31:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:33:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:33:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:34:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:38:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:38:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:40:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 16:41:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:41:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:41:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:41:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:49:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:50:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:51:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:52:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:52:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:53:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:53:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:54:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:54:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:55:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:55:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:55:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:55:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:55:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:55:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:55:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:55:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:55:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 16:56:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 16:56:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 16:57:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 16:57:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 16:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:57:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:57:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:57:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:57:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 16:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 16:58:38 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-22 17:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:04:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 17:05:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:11:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:13:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 17:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:15:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:15:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:16:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:16:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:16:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:16:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:16:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 17:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:20:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:20:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:21:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:24:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:24:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:24:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:24:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:29:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:33:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:33:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:33:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:33:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:33:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:33:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:33:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:33:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:34:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:34:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:34:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:34:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 17:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:39:20 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-22 17:39:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:40:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:50:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 17:50:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 17:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:50:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:50:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 17:52:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 17:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:54:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 17:55:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 17:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:57:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 17:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 17:59:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:07:19 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-22 18:07:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:09:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:09:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 18:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:12:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:15:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:15:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:15:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:16:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:16:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:16:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:17:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:17:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:17:59 --> 404 Page Not Found: Html-en/new-products-BExJnSQdumvP-2--2-1.html
ERROR - 2021-07-22 18:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:22:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:22:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 18:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:23:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:24:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:25:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:25:43 --> 404 Page Not Found: Html-cn/new-products-CQxmJTnWDEvg-1-0-2-1.html
ERROR - 2021-07-22 18:25:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:26:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:26:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:26:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:27:31 --> 404 Page Not Found: City/1
ERROR - 2021-07-22 18:27:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 18:27:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:28:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:28:10 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-22 18:28:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:28:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 18:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:29:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 18:29:37 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-22 18:29:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 18:30:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 18:30:39 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-22 18:32:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 18:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:33:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:41:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:41:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:46:54 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-22 18:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:50:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 18:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:57:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 18:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 18:59:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 19:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:04:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 19:06:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 19:07:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:11:05 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-22 19:11:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 19:11:15 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-22 19:11:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 19:11:30 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-22 19:11:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 19:11:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 19:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:13:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 19:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:16:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 19:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:18:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 19:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:20:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 19:20:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 19:22:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 19:22:20 --> 404 Page Not Found: 10/10000
ERROR - 2021-07-22 19:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:22:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 19:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:24:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 19:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:27:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 19:27:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 19:28:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 19:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:28:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 19:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:33:09 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-22 19:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:33:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 19:36:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 19:37:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:44:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 19:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:46:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 19:48:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 19:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:55:47 --> 404 Page Not Found: Web/ptz.html
ERROR - 2021-07-22 19:55:50 --> 404 Page Not Found: Web/ptz.html
ERROR - 2021-07-22 19:55:52 --> 404 Page Not Found: Web/ptz.html
ERROR - 2021-07-22 19:55:53 --> 404 Page Not Found: Web/ptz.html
ERROR - 2021-07-22 19:55:54 --> 404 Page Not Found: Web/ptz.html
ERROR - 2021-07-22 19:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:56:44 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-22 19:56:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 19:57:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 19:57:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 19:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:01:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 20:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:02:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 20:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:04:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 20:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:10:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 20:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:11:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 20:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:13:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 20:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:14:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 20:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:14:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 20:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:15:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 20:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:19:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 20:20:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:23:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 20:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:25:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 20:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:26:12 --> 404 Page Not Found: 10/10000
ERROR - 2021-07-22 20:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:26:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 20:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:31:12 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-22 20:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:33:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 20:33:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 20:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:34:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 20:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:44:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 20:46:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 20:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:51:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 20:52:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 20:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:54:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 20:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 20:57:15 --> 404 Page Not Found: Lavery_Edit/Admin_Login.asp
ERROR - 2021-07-22 20:57:16 --> 404 Page Not Found: admin/Lavery_Edit/Admin_Login.asp
ERROR - 2021-07-22 20:57:16 --> 404 Page Not Found: Manage/lavery_Edit
ERROR - 2021-07-22 20:57:17 --> 404 Page Not Found: Cms/lavery_Edit
ERROR - 2021-07-22 20:58:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 20:59:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:00:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:02:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 21:03:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:03:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 21:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:04:11 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 21:04:11 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 21:04:11 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-22 21:04:11 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 21:04:11 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-22 21:04:12 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 21:04:13 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 21:04:13 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-22 21:04:13 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 21:04:13 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-22 21:04:13 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-22 21:04:13 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-22 21:04:13 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-22 21:04:13 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 21:04:14 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 21:04:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 21:04:14 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-22 21:04:14 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-22 21:04:14 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-22 21:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:07:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 21:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:07:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:09:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:10:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:11:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:12:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:13:53 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 21:13:53 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 21:13:54 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-22 21:13:55 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-22 21:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:17:30 --> 404 Page Not Found: City/index
ERROR - 2021-07-22 21:18:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 21:18:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 21:18:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 21:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:22:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 21:22:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 21:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:24:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:25:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:25:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:26:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 21:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:27:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 21:28:57 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-22 21:29:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:29:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 21:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:35:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 21:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:37:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:41:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 21:42:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:51:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 21:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:52:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:52:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:53:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:53:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:53:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 21:53:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:54:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:54:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:54:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:54:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:54:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:54:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:55:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:55:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:56:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:57:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 21:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 21:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 21:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:00:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 22:00:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:00:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 22:01:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:02:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 22:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:04:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 22:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:04:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:06:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:07:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:08:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:08:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:09:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:09:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:09:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:09:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 22:09:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 22:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:10:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:10:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:11:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:11:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:12:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:12:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:12:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 22:12:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:13:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:13:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 22:14:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:14:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 22:14:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:16:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:17:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 22:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:17:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:17:53 --> 404 Page Not Found: Backup/wp-admin
ERROR - 2021-07-22 22:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:19:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:19:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:20:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 22:21:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 22:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:22:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:24:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:25:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:26:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:26:16 --> 404 Page Not Found: English/index
ERROR - 2021-07-22 22:26:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 22:26:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:27:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 22:29:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 22:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:29:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 22:29:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:30:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 22:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:31:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:34:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 22:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:36:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 22:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:37:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 22:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:38:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 22:39:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:40:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 22:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:52:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 22:54:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 22:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:56:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 22:59:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 23:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:00:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:01:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 23:01:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 23:01:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 23:01:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 23:01:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 23:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:03:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:06:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:07:32 --> 404 Page Not Found: City/1
ERROR - 2021-07-22 23:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:09:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 23:09:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:09:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:13:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 23:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:14:04 --> 404 Page Not Found: Env/index
ERROR - 2021-07-22 23:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:18:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:22:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:24:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:25:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:27:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 23:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:29:22 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-22 23:29:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:32:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 23:32:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 23:32:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 23:32:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-22 23:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:34:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 23:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:36:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:37:02 --> 404 Page Not Found: Env/index
ERROR - 2021-07-22 23:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:40:41 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-22 23:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:41:42 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-22 23:42:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:42:40 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-22 23:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:43:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:43:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 23:43:37 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-22 23:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:44:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:44:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:44:37 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-22 23:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:45:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:45:32 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-22 23:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:46:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:46:31 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-22 23:47:57 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-22 23:48:26 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-22 23:48:31 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-07-22 23:48:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:48:55 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-07-22 23:49:23 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-22 23:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:49:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-22 23:50:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:50:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:52:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:52:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:52:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:52:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 23:53:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:54:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-22 23:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:57:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-22 23:58:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-22 23:58:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-22 23:59:13 --> 404 Page Not Found: Robotstxt/index
