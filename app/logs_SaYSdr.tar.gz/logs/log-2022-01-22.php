<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-22 00:00:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 00:08:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 00:09:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 00:10:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 00:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 00:16:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 00:16:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 00:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 00:23:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 00:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 00:35:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 00:36:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 00:38:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 00:38:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 00:42:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 00:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 00:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 00:56:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 00:57:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 00:58:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 00:59:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 00:59:27 --> 404 Page Not Found: Static/admin
ERROR - 2022-01-22 01:01:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 01:02:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 01:03:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 01:05:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 01:06:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 01:11:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 01:17:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 01:18:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 01:36:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 01:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 01:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 01:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 01:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 01:44:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 01:59:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 02:00:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 02:05:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 02:08:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 02:09:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 02:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 02:13:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 02:13:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 02:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 02:25:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 02:26:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 02:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 02:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 02:45:40 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 02:57:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 03:06:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 03:10:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 03:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 03:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 03:17:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 03:19:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 03:19:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 03:20:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 03:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 03:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 03:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 03:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 04:00:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 04:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 04:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 04:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 04:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 04:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 04:17:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 04:24:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 04:25:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 04:27:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 04:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 04:30:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 04:32:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 04:34:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 04:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 04:40:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 04:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 04:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 05:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 05:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 05:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 05:25:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 05:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 05:25:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 05:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 05:33:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 05:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 05:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 05:54:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 05:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:22:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:33:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 06:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:49:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 06:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:55:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 06:57:06 --> 404 Page Not Found: Static/admin
ERROR - 2022-01-22 06:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 06:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 07:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 07:13:10 --> 404 Page Not Found: Xxgk/index
ERROR - 2022-01-22 07:18:07 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-22 07:18:48 --> 404 Page Not Found: Expensesasp/index
ERROR - 2022-01-22 07:19:06 --> 404 Page Not Found: Detail/index
ERROR - 2022-01-22 07:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 07:19:25 --> 404 Page Not Found: Category/qingchunxiaoyuanxiaoyuanchunai
ERROR - 2022-01-22 07:19:37 --> 404 Page Not Found: Book/752540
ERROR - 2022-01-22 07:20:03 --> 404 Page Not Found: A/03504.html
ERROR - 2022-01-22 07:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 07:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 07:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 07:30:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 07:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 07:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 07:50:06 --> 404 Page Not Found: Static/admin
ERROR - 2022-01-22 08:07:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 08:13:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-01-22 08:20:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 08:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 08:23:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 08:23:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 08:25:49 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 08:27:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 08:28:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 08:29:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 08:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 08:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 08:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 08:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 08:55:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 08:55:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 08:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 08:56:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 08:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 08:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 09:07:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 09:07:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 09:07:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 09:07:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 09:07:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 09:08:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 09:09:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 09:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 09:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 09:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 09:17:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 09:17:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 09:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 09:19:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 09:21:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 09:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 09:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 09:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 09:42:21 --> 404 Page Not Found: Static/admin
ERROR - 2022-01-22 09:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 09:47:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 09:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 09:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 10:04:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 10:12:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:14:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:15:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:15:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:15:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:18:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:18:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 10:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 10:23:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:23:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:23:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:24:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:25:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:25:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:25:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:26:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:26:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:26:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:27:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:32:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:33:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:38:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:39:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 10:43:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:46:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 10:46:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 10:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 10:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 11:03:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 11:04:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 11:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 11:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 11:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 11:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 11:25:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 11:37:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 11:45:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 11:47:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 11:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 11:58:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 12:02:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 12:02:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 12:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 12:12:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 12:17:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 12:17:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 12:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 12:24:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 12:29:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 12:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 12:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 12:57:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 13:00:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 13:10:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 13:10:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 13:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 13:20:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 13:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 13:41:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 13:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 13:50:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 13:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 13:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 14:05:28 --> 404 Page Not Found: Index/index
ERROR - 2022-01-22 14:08:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 14:16:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:16:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 14:20:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 14:20:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:22:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:23:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:23:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:24:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:24:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:24:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:25:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:33:30 --> 404 Page Not Found: City/1
ERROR - 2022-01-22 14:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 14:39:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 14:49:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:49:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:51:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:52:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:53:44 --> 404 Page Not Found: Env/index
ERROR - 2022-01-22 14:54:16 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-22 14:54:16 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-22 14:54:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:54:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:55:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:56:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:56:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:56:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:57:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 14:57:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:57:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:57:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:57:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:58:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:58:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:58:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:58:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:58:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:59:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:59:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:59:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 14:59:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:00:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:01:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:02:40 --> 404 Page Not Found: City/1
ERROR - 2022-01-22 15:02:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:03:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:03:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:03:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:03:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:04:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:04:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:04:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:05:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:06:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:07:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:09:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:09:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:11:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 15:15:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 15:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 15:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 15:50:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:51:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 15:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 16:03:40 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 16:14:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 16:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 16:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 16:26:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 16:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 16:31:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 16:32:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 16:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 16:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 16:42:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 16:54:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 16:58:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 17:04:36 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-01-22 17:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 17:06:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 17:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 17:12:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 17:17:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:17:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 17:18:54 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2022-01-22 17:19:57 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2022-01-22 17:20:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:21:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:21:32 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2022-01-22 17:21:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:22:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:24:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 17:24:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 17:26:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:27:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:28:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 17:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:29:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:29:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:30:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:30:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:32:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:33:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 17:33:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 17:36:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:37:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:38:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 17:38:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:40:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:41:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:41:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:42:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:42:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:43:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:44:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:45:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:46:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:47:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:48:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:48:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:49:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:50:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:51:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:51:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:52:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:53:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:54:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:55:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:56:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:57:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 17:58:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 18:08:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 18:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 18:15:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 18:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 18:19:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 18:21:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 18:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 18:23:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 18:23:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 18:34:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 18:34:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 18:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 18:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 18:52:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 19:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 19:23:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 19:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:24:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 19:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:38:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 19:38:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 19:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:45:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 19:45:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 19:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:50:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 19:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:02:55 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 20:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:08:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:30:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 20:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:43:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:43:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:44:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:44:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:45:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:45:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:48:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:49:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:53:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:53:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 20:54:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:55:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:56:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:56:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:56:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:57:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:57:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:58:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 20:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 21:01:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 21:03:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:04:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:04:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:04:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:05:08 --> 404 Page Not Found: Static/admin
ERROR - 2022-01-22 21:05:11 --> 404 Page Not Found: Haoma/static
ERROR - 2022-01-22 21:05:14 --> 404 Page Not Found: Login/index
ERROR - 2022-01-22 21:05:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:06:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:06:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:09:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:09:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:10:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:10:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 21:10:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:13:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 21:19:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 21:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 21:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 21:31:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 21:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 21:36:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 21:40:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 21:41:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 21:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 21:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 21:41:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 21:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 21:47:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-22 21:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 22:01:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:02:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:06:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 22:08:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:09:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 22:10:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:11:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:11:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 22:11:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:11:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:12:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:14:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:14:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:15:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:15:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:15:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:16:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:16:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:16:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:17:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:18:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:18:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:18:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:18:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:20:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 22:32:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:32:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:36:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:36:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:36:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:37:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:38:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:43:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:43:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:43:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 22:47:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:49:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 22:49:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 22:52:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 23:07:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 23:08:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:08:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 23:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:11:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 23:17:12 --> 404 Page Not Found: Inc/AspCms_AdvJs.asp
ERROR - 2022-01-22 23:17:12 --> 404 Page Not Found: Inc/AspCms_AdvJs.asp
ERROR - 2022-01-22 23:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 23:18:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:18:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:19:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:22:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:22:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:23:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:23:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:24:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:24:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:30:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 23:31:16 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-22 23:33:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:35:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:36:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-22 23:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-22 23:41:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:41:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:41:54 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-22 23:42:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 23:48:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:49:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-22 23:53:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:57:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:59:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-22 23:59:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
