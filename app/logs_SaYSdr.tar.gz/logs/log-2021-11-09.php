<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-09 00:02:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:03:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:04:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:04:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:04:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:04:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:05:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 00:05:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:09:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:14:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:16:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:18:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:19:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:22:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 00:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 00:48:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 01:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 01:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 01:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 01:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 01:54:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 01:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 02:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 02:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 02:43:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 02:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 03:01:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 03:23:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 03:36:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 03:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 03:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 03:42:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 03:47:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 03:56:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 04:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 04:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 04:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 04:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 04:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 04:31:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 04:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 04:37:54 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-11-09 04:41:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 04:44:43 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-11-09 04:51:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 04:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 04:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 05:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 05:21:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 05:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 05:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 05:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 05:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 05:51:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 05:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 05:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 05:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 05:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 06:01:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 06:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 06:01:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 06:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 06:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 06:16:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 06:19:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 06:20:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 06:21:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 06:31:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-09 06:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 07:06:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-09 07:07:32 --> 404 Page Not Found: 404/index.html
ERROR - 2021-11-09 07:07:32 --> 404 Page Not Found: 404/index.html
ERROR - 2021-11-09 07:09:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 07:10:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 07:11:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 07:11:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 07:11:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 07:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 07:25:50 --> 404 Page Not Found: C153125/products
ERROR - 2021-11-09 07:26:17 --> 404 Page Not Found: Pagedo/index
ERROR - 2021-11-09 07:26:42 --> 404 Page Not Found: Q/GRj5w4
ERROR - 2021-11-09 07:26:47 --> 404 Page Not Found: E/20110311
ERROR - 2021-11-09 07:27:07 --> 404 Page Not Found: Bbs/thread-16011885-0.html
ERROR - 2021-11-09 07:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 07:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 07:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 07:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 08:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 08:02:17 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-11-09 08:07:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 08:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 08:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 08:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 08:45:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 08:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 08:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 09:06:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 09:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 09:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 09:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 09:25:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-09 09:27:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 09:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 09:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 09:51:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 09:51:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 09:57:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 09:57:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 10:18:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 10:19:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 10:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 10:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 10:47:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 10:47:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 10:49:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 10:49:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 10:54:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 10:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 11:03:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 11:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 11:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 11:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 11:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 11:34:55 --> 404 Page Not Found: AltibaseIntSearch/common
ERROR - 2021-11-09 11:42:53 --> Severity: Warning --> Missing argument 1 for Taocan::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 21
ERROR - 2021-11-09 11:50:53 --> 404 Page Not Found: Ui/login.html
ERROR - 2021-11-09 12:02:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-09 12:05:26 --> 404 Page Not Found: Api/v1
ERROR - 2021-11-09 12:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 12:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 12:11:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 12:12:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 12:12:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 12:14:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 12:53:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 12:54:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 12:56:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 12:56:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 13:06:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:12:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:19:54 --> Severity: Warning --> Missing argument 1 for Taocan::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 181
ERROR - 2021-11-09 13:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 13:31:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:31:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:32:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:37:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:40:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:41:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 13:41:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:41:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:42:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 13:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 13:57:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 14:03:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:04:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 14:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 14:09:02 --> 404 Page Not Found: Ncsitxt/index
ERROR - 2021-11-09 14:09:02 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-11-09 14:10:29 --> 404 Page Not Found: City/1
ERROR - 2021-11-09 14:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 14:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 14:21:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:21:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:21:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:21:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:22:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:23:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:23:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:24:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:24:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:24:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 14:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:36:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:37:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:37:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:37:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:38:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:43:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:43:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:44:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:44:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 14:44:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 14:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:44:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 14:45:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 14:45:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 14:45:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 14:45:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:45:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 14:45:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:45:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:45:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 14:46:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 14:56:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:57:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 14:58:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:58:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:58:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 14:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 15:01:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:02:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:02:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:05:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 15:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 15:17:23 --> 404 Page Not Found: City/16
ERROR - 2021-11-09 15:21:44 --> 404 Page Not Found: City/1
ERROR - 2021-11-09 15:26:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 15:29:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:30:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:30:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:31:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:31:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:32:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:33:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:34:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:52:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-09 15:56:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:57:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:57:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 15:58:39 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-11-09 15:59:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:00:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:00:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:09:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 16:15:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 16:18:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-09 16:20:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 16:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 16:22:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:24:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:25:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:26:03 --> 404 Page Not Found: AltibaseIntSearch/common
ERROR - 2021-11-09 16:27:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:28:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:31:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 16:33:59 --> 404 Page Not Found: Ui/login.html
ERROR - 2021-11-09 16:34:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:35:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:46:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:46:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:46:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:46:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 16:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 16:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 16:57:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:58:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 16:59:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 17:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 17:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 17:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 17:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 17:17:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:23:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 17:29:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:30:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 17:30:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:30:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:30:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:30:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:30:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:30:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:30:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:30:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:30:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:30:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:30:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:31:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:31:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:31:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 17:31:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 18:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 18:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 18:20:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 18:22:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 18:22:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 18:23:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 18:25:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 18:31:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 18:33:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 18:35:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 18:42:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 18:42:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 18:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 18:58:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 19:22:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 19:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 19:27:53 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-11-09 19:33:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 19:34:03 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-11-09 19:35:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 19:35:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 19:36:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 19:36:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 19:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 19:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 19:51:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 19:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 19:55:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 19:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 19:59:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 20:00:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 20:01:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 20:01:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 20:02:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 20:02:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 20:02:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 20:03:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 20:03:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 20:03:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 20:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 20:06:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 20:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 20:11:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 20:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 20:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 20:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 20:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 20:27:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 20:27:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 20:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 20:55:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 20:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 21:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 21:18:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 21:20:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 21:20:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 21:21:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 21:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 21:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 21:26:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 21:31:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 21:37:06 --> 404 Page Not Found: Index/login
ERROR - 2021-11-09 21:53:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 22:17:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 22:17:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 22:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 22:40:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-09 22:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 22:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 22:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 22:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 23:01:53 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-11-09 23:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 23:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 23:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 23:25:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 23:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 23:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-09 23:51:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 23:51:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 23:52:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 23:52:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 23:52:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 23:52:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 23:52:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 23:52:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 23:52:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 23:54:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-09 23:57:28 --> 404 Page Not Found: Robotstxt/index
