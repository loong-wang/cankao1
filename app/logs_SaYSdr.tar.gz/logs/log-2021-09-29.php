<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-29 00:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 00:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 00:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 00:18:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 00:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 00:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 00:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 00:34:31 --> 404 Page Not Found: 1rar/index
ERROR - 2021-09-29 00:34:31 --> 404 Page Not Found: 1zip/index
ERROR - 2021-09-29 00:34:31 --> 404 Page Not Found: 2rar/index
ERROR - 2021-09-29 00:34:31 --> 404 Page Not Found: 2zip/index
ERROR - 2021-09-29 00:34:35 --> 404 Page Not Found: 3rar/index
ERROR - 2021-09-29 00:34:35 --> 404 Page Not Found: 3zip/index
ERROR - 2021-09-29 00:34:35 --> 404 Page Not Found: 4rar/index
ERROR - 2021-09-29 00:34:35 --> 404 Page Not Found: 4zip/index
ERROR - 2021-09-29 00:34:35 --> 404 Page Not Found: 5rar/index
ERROR - 2021-09-29 00:34:35 --> 404 Page Not Found: 5zip/index
ERROR - 2021-09-29 00:34:35 --> 404 Page Not Found: 6rar/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 6zip/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 7rar/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 7zip/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 8rar/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 8zip/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 9rar/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 9zip/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 1targz/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 17z/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 2targz/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 27z/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 3targz/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 37z/index
ERROR - 2021-09-29 00:34:36 --> 404 Page Not Found: 4targz/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: 47z/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: 5targz/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: 57z/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: 6targz/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: 67z/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: 7targz/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: 77z/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: 8targz/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: 87z/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: 9targz/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: 97z/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: Fuwuqirar/index
ERROR - 2021-09-29 00:34:37 --> 404 Page Not Found: Fuwuqizip/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Wwwrootbakrar/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Wwwrootbakzip/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Wwwbakrar/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Wwwbakzip/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Webbakrar/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Webbakzip/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-29 00:34:38 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-29 00:34:39 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-29 00:34:39 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-29 00:34:39 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-29 00:34:39 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-29 00:34:39 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-29 00:34:39 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-29 00:34:39 --> 404 Page Not Found: Wwwxuanhaonetbakrar/index
ERROR - 2021-09-29 00:34:39 --> 404 Page Not Found: Wwwxuanhaonetbakzip/index
ERROR - 2021-09-29 00:34:39 --> 404 Page Not Found: Www_xuanhao_netbakrar/index
ERROR - 2021-09-29 00:34:39 --> 404 Page Not Found: Www_xuanhao_netbakzip/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Wwwxuanhaonetbakrar/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Wwwxuanhaonetbakzip/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Xuanhaonetbakrar/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Xuanhaonetbakzip/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Xuanhaobakrar/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Xuanhaobakzip/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Dbrar/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Dbzip/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Wzrar/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Wzzip/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Fdsarar/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Fdsazip/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Wangzhanrar/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Wangzhanzip/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Rootrar/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Rootzip/index
ERROR - 2021-09-29 00:34:40 --> 404 Page Not Found: Adminrar/index
ERROR - 2021-09-29 00:34:41 --> 404 Page Not Found: Adminzip/index
ERROR - 2021-09-29 00:34:41 --> 404 Page Not Found: Datarar/index
ERROR - 2021-09-29 00:34:41 --> 404 Page Not Found: Datazip/index
ERROR - 2021-09-29 00:34:41 --> 404 Page Not Found: Ggrar/index
ERROR - 2021-09-29 00:34:41 --> 404 Page Not Found: Ggzip/index
ERROR - 2021-09-29 00:34:41 --> 404 Page Not Found: Viprar/index
ERROR - 2021-09-29 00:34:41 --> 404 Page Not Found: Vipzip/index
ERROR - 2021-09-29 00:34:42 --> 404 Page Not Found: Databackrar/index
ERROR - 2021-09-29 00:34:42 --> 404 Page Not Found: Databackzip/index
ERROR - 2021-09-29 00:34:42 --> 404 Page Not Found: Databackuprar/index
ERROR - 2021-09-29 00:34:42 --> 404 Page Not Found: Databackupzip/index
ERROR - 2021-09-29 00:34:42 --> 404 Page Not Found: Hdocsrar/index
ERROR - 2021-09-29 00:34:42 --> 404 Page Not Found: Hdocszip/index
ERROR - 2021-09-29 00:34:42 --> 404 Page Not Found: Releasezip/index
ERROR - 2021-09-29 00:34:43 --> 404 Page Not Found: Templaterar/index
ERROR - 2021-09-29 00:34:43 --> 404 Page Not Found: Templatezip/index
ERROR - 2021-09-29 00:34:43 --> 404 Page Not Found: Arar/index
ERROR - 2021-09-29 00:34:43 --> 404 Page Not Found: Azip/index
ERROR - 2021-09-29 00:34:43 --> 404 Page Not Found: Brar/index
ERROR - 2021-09-29 00:34:43 --> 404 Page Not Found: Bzip/index
ERROR - 2021-09-29 00:34:43 --> 404 Page Not Found: Testrar/index
ERROR - 2021-09-29 00:34:43 --> 404 Page Not Found: Testzip/index
ERROR - 2021-09-29 00:34:44 --> 404 Page Not Found: Barar/index
ERROR - 2021-09-29 00:34:44 --> 404 Page Not Found: Bazip/index
ERROR - 2021-09-29 00:34:50 --> 404 Page Not Found: Beifenrar/index
ERROR - 2021-09-29 00:34:51 --> 404 Page Not Found: Beifenzip/index
ERROR - 2021-09-29 00:34:51 --> 404 Page Not Found: Bfrar/index
ERROR - 2021-09-29 00:34:51 --> 404 Page Not Found: Bfzip/index
ERROR - 2021-09-29 00:34:51 --> 404 Page Not Found: Bakrar/index
ERROR - 2021-09-29 00:34:51 --> 404 Page Not Found: Bakzip/index
ERROR - 2021-09-29 00:34:51 --> 404 Page Not Found: Ebakrar/index
ERROR - 2021-09-29 00:34:51 --> 404 Page Not Found: Ebakzip/index
ERROR - 2021-09-29 00:34:51 --> 404 Page Not Found: Backrar/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Backzip/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Mysqlrar/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Mysqlzip/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Backupdatarar/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Backupdatazip/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Backup_datarar/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Backup_datazip/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Wwwrootbaktargz/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Wwwbaktargz/index
ERROR - 2021-09-29 00:34:52 --> 404 Page Not Found: Webbaktargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Wwwxuanhaonetbaktargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Www_xuanhao_netbaktargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Wwwxuanhaonetbaktargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Xuanhaonetbaktargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Xuanhaobaktargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Dbtargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Wztargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Fdsatargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Wangzhantargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Roottargz/index
ERROR - 2021-09-29 00:34:53 --> 404 Page Not Found: Admintargz/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Datatargz/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Ggtargz/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Viptargz/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Databacktargz/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Databackuptargz/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Hdocstargz/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Releasetargz/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Templatetargz/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Atargz/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Bbak/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Testtargz/index
ERROR - 2021-09-29 00:34:54 --> 404 Page Not Found: Batargz/index
ERROR - 2021-09-29 00:34:57 --> 404 Page Not Found: Beifentargz/index
ERROR - 2021-09-29 00:34:57 --> 404 Page Not Found: Bftargz/index
ERROR - 2021-09-29 00:34:57 --> 404 Page Not Found: Baktargz/index
ERROR - 2021-09-29 00:34:58 --> 404 Page Not Found: Ebaktargz/index
ERROR - 2021-09-29 00:34:58 --> 404 Page Not Found: Backtargz/index
ERROR - 2021-09-29 00:34:58 --> 404 Page Not Found: Mysqltargz/index
ERROR - 2021-09-29 00:34:58 --> 404 Page Not Found: Backupdatatargz/index
ERROR - 2021-09-29 00:34:58 --> 404 Page Not Found: Backup_datatargz/index
ERROR - 2021-09-29 00:34:58 --> 404 Page Not Found: Xuanhaobak7z/index
ERROR - 2021-09-29 00:34:58 --> 404 Page Not Found: Db7z/index
ERROR - 2021-09-29 00:34:58 --> 404 Page Not Found: Wz7z/index
ERROR - 2021-09-29 00:34:58 --> 404 Page Not Found: Fdsa7z/index
ERROR - 2021-09-29 00:34:58 --> 404 Page Not Found: Wangzhan7z/index
ERROR - 2021-09-29 00:34:58 --> 404 Page Not Found: Root7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: Admin7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: Data7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: Gg7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: Vip7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: Databack7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: Databackup7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: Hdocs7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: Release7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: Template7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: A7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: B7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: Test7z/index
ERROR - 2021-09-29 00:34:59 --> 404 Page Not Found: Ba7z/index
ERROR - 2021-09-29 00:35:02 --> 404 Page Not Found: Beifen7z/index
ERROR - 2021-09-29 00:35:02 --> 404 Page Not Found: Bf7z/index
ERROR - 2021-09-29 00:35:02 --> 404 Page Not Found: Bak7z/index
ERROR - 2021-09-29 00:35:02 --> 404 Page Not Found: Ebak7z/index
ERROR - 2021-09-29 00:35:02 --> 404 Page Not Found: Back7z/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Mysql7z/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Backupdata7z/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Backup_data7z/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Wfphprar/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Wfphpzip/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Wfphp7z/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Wfphptargz/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Order7z/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Ordertargz/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Orderrar/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Orderzip/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Zzfhworderrar/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Zzfhworderzip/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Zzfhworder7z/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Zzfhwordertargz/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Wforderrar/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Wforderzip/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Wforder7z/index
ERROR - 2021-09-29 00:35:03 --> 404 Page Not Found: Wfordertargz/index
ERROR - 2021-09-29 00:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 00:41:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 00:45:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 00:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 00:51:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 01:11:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 01:16:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 01:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 01:45:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 01:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 01:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 01:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 01:55:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-29 02:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 02:19:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 02:22:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 02:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 03:13:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 03:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 03:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 03:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 03:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 03:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 03:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 03:46:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 03:48:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 03:48:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 03:48:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 03:48:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 03:48:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 03:48:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 03:49:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 04:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 04:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 04:47:06 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-29 04:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 05:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 05:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 05:29:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 05:35:56 --> 404 Page Not Found: City/10
ERROR - 2021-09-29 05:43:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 05:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 05:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 05:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 05:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 05:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 06:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 06:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 06:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 06:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 06:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 06:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 06:44:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 06:44:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 06:44:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 06:44:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 06:44:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 06:44:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 06:44:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 06:44:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 06:46:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 06:55:35 --> 404 Page Not Found: Install/templates
ERROR - 2021-09-29 06:55:36 --> 404 Page Not Found: Templets/default
ERROR - 2021-09-29 06:55:36 --> 404 Page Not Found: Templets/plus
ERROR - 2021-09-29 06:55:36 --> 404 Page Not Found: Templets/plus
ERROR - 2021-09-29 06:55:36 --> 404 Page Not Found: Templets/plus
ERROR - 2021-09-29 06:55:36 --> 404 Page Not Found: Templets/plus
ERROR - 2021-09-29 06:55:37 --> 404 Page Not Found: Templets/plus
ERROR - 2021-09-29 06:55:37 --> 404 Page Not Found: Templets/plus
ERROR - 2021-09-29 06:55:37 --> 404 Page Not Found: Templets/default
ERROR - 2021-09-29 06:55:37 --> 404 Page Not Found: Templets/default
ERROR - 2021-09-29 06:55:37 --> 404 Page Not Found: Templets/default
ERROR - 2021-09-29 06:55:37 --> 404 Page Not Found: Member/templets
ERROR - 2021-09-29 06:55:37 --> 404 Page Not Found: Member/templets
ERROR - 2021-09-29 06:55:37 --> 404 Page Not Found: Member/templets
ERROR - 2021-09-29 06:55:37 --> 404 Page Not Found: Member/templets
ERROR - 2021-09-29 06:55:37 --> 404 Page Not Found: Member/templets
ERROR - 2021-09-29 06:55:38 --> 404 Page Not Found: Member/templets
ERROR - 2021-09-29 06:55:38 --> 404 Page Not Found: Install/sql-dfdata.txt
ERROR - 2021-09-29 06:55:38 --> 404 Page Not Found: Templets/default
ERROR - 2021-09-29 06:55:38 --> 404 Page Not Found: Templets/default
ERROR - 2021-09-29 06:55:38 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:39 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:39 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:39 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:39 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:39 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:39 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:39 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:39 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:39 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:40 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:40 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:40 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:40 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:40 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:40 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:40 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:40 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:40 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:40 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:41 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:41 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:41 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:41 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:41 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:41 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:41 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:41 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:41 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:41 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:42 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:42 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:42 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:42 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:42 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:42 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:42 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:42 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:42 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:42 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:43 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:43 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:43 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:43 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:43 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:43 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:43 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:43 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:43 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:43 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:44 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:44 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:44 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:44 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:44 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:44 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:44 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:44 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:44 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:45 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:45 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:45 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:45 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:45 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:45 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:45 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:45 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:45 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:46 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:46 --> 404 Page Not Found: Include/taglib
ERROR - 2021-09-29 06:55:46 --> 404 Page Not Found: Include/taglib
ERROR - 2021-09-29 06:55:46 --> 404 Page Not Found: Include/taglib
ERROR - 2021-09-29 06:55:46 --> 404 Page Not Found: Include/taglib
ERROR - 2021-09-29 06:55:46 --> 404 Page Not Found: Include/taglib
ERROR - 2021-09-29 06:55:46 --> 404 Page Not Found: Include/taglib
ERROR - 2021-09-29 06:55:46 --> 404 Page Not Found: Templets/system
ERROR - 2021-09-29 06:55:47 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:47 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:47 --> 404 Page Not Found: Member/space
ERROR - 2021-09-29 06:55:47 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-09-29 06:55:47 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-09-29 06:55:47 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-09-29 06:55:48 --> 404 Page Not Found: Dede/templets
ERROR - 2021-09-29 06:55:48 --> 404 Page Not Found: Dede/templets
ERROR - 2021-09-29 06:55:48 --> 404 Page Not Found: Dede/templets
ERROR - 2021-09-29 06:55:48 --> 404 Page Not Found: Dede/templets
ERROR - 2021-09-29 06:55:48 --> 404 Page Not Found: Dede/templets
ERROR - 2021-09-29 06:55:48 --> 404 Page Not Found: Dede/templets
ERROR - 2021-09-29 06:55:48 --> 404 Page Not Found: Dede/templets
ERROR - 2021-09-29 06:55:48 --> 404 Page Not Found: Dede/templets
ERROR - 2021-09-29 06:55:49 --> 404 Page Not Found: Dede/templets
ERROR - 2021-09-29 06:55:49 --> 404 Page Not Found: Install/templates
ERROR - 2021-09-29 07:00:02 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-09-29 07:00:03 --> 404 Page Not Found: admin//index
ERROR - 2021-09-29 07:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 07:00:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 07:00:04 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-09-29 07:00:05 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-09-29 07:00:05 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-09-29 07:00:06 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-09-29 07:00:06 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-09-29 07:00:06 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-09-29 07:00:06 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-09-29 07:00:07 --> 404 Page Not Found: User/index
ERROR - 2021-09-29 07:00:07 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-09-29 07:00:07 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-09-29 07:00:07 --> 404 Page Not Found: Wcm/index
ERROR - 2021-09-29 07:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 07:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 07:54:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 07:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 08:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 08:20:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 08:28:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 08:29:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 08:52:40 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-29 09:00:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-29 09:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 09:09:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 09:09:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 09:13:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 09:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 09:14:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 09:19:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 09:19:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 09:19:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 09:21:57 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-29 09:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 09:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 09:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 09:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 09:44:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 09:44:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 09:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 09:48:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 09:48:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 09:49:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 09:51:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 09:52:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 09:55:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 09:55:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 09:58:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 09:59:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:00:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 10:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 10:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 10:14:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:14:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:14:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:15:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:16:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:16:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:16:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:17:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 10:30:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 10:32:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:33:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:35:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:36:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 10:44:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:44:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:46:34 --> 404 Page Not Found: Nmaplowercheck1632883593/index
ERROR - 2021-09-29 10:46:34 --> 404 Page Not Found: Evox/about
ERROR - 2021-09-29 10:46:34 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-09-29 10:46:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:47:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 10:48:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:49:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:50:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:50:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:50:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:50:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:51:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:52:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 10:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 11:01:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 11:10:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 11:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 11:10:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 11:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 11:15:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 11:23:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 11:23:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 11:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 11:24:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 11:24:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 11:25:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-29 11:27:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 11:27:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 11:30:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 11:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 11:50:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-29 11:52:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 11:52:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 11:54:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 11:56:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 11:56:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 12:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 12:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 12:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 12:14:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 12:14:19 --> 404 Page Not Found: Login/index
ERROR - 2021-09-29 12:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 12:19:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 12:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 12:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 12:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 12:32:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 12:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 12:34:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 12:38:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 12:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 12:41:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 12:41:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 12:42:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-29 12:43:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 12:43:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 12:44:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 12:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 12:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 12:54:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 12:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 12:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 13:00:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 13:11:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:11:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 13:12:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:13:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 13:15:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-29 13:15:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 13:16:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:16:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:17:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:17:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:17:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:18:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:18:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 13:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 13:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 13:32:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 13:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 13:46:06 --> 404 Page Not Found: Index/login
ERROR - 2021-09-29 13:53:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 13:57:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:57:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:57:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:57:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:57:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:58:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:58:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:58:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:59:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:59:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:59:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:59:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:59:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 13:59:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 14:00:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 14:00:28 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-09-29 14:00:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 14:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 14:09:30 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-09-29 14:09:30 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-09-29 14:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 14:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 14:15:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 14:16:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 14:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 14:17:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 14:21:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 14:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 14:24:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 14:27:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 14:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 14:36:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 14:50:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 14:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 15:00:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:01:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:02:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:02:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:03:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:04:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:04:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:04:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:04:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:04:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:05:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 15:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 15:08:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:08:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:09:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:10:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:10:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:10:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 15:11:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:12:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:12:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:13:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:13:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:13:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:14:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:14:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-29 15:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 15:15:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:15:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:16:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:16:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:16:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:16:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:18:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:18:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 15:18:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:18:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:19:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:19:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:19:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:20:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:20:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:20:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 15:20:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:20:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:20:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:21:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:21:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:21:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:21:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:22:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:22:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 15:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:24:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:24:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:25:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:25:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:26:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 15:34:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:34:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:34:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:34:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:35:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:37:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:38:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 15:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 15:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 15:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 16:02:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 16:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 16:12:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 16:14:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 16:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 16:25:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 16:31:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-29 16:32:45 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-29 16:33:04 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-29 16:33:43 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-29 16:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 16:52:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 16:52:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 16:52:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 16:53:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 16:53:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 16:53:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 16:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 17:00:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-29 17:04:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 17:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 17:09:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 17:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 17:10:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 17:10:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 17:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 17:43:20 --> 404 Page Not Found: City/1
ERROR - 2021-09-29 17:44:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 17:45:14 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-29 17:45:14 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-29 17:45:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 17:48:26 --> 404 Page Not Found: City/10
ERROR - 2021-09-29 17:48:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 17:49:00 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-29 17:49:53 --> 404 Page Not Found: City/16
ERROR - 2021-09-29 17:50:09 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-29 17:50:12 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-29 17:50:12 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-29 17:50:12 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-09-29 17:50:12 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-29 17:50:12 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-09-29 17:50:12 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-09-29 17:50:14 --> 404 Page Not Found: City/15
ERROR - 2021-09-29 17:50:14 --> 404 Page Not Found: City/2
ERROR - 2021-09-29 17:57:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 18:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 18:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 18:13:13 --> 404 Page Not Found: City/10
ERROR - 2021-09-29 18:13:35 --> 404 Page Not Found: City/10
ERROR - 2021-09-29 18:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 18:20:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 18:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 18:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 18:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 18:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 18:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 19:00:08 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-29 19:02:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 19:24:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 19:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 19:36:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 19:36:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 19:38:21 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-09-29 19:38:21 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-09-29 19:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 19:41:52 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-09-29 19:42:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 19:43:15 --> 404 Page Not Found: City/16
ERROR - 2021-09-29 19:47:04 --> 404 Page Not Found: City/16
ERROR - 2021-09-29 19:48:36 --> 404 Page Not Found: City/16
ERROR - 2021-09-29 19:49:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 19:49:16 --> 404 Page Not Found: City/16
ERROR - 2021-09-29 19:50:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 19:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 19:56:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 19:56:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 19:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 20:04:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 20:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 20:07:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:19:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:21:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:21:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:23:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:23:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:24:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:27:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:28:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 20:29:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:37:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 20:37:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:37:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 20:37:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 20:40:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:45:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:47:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:48:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:49:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 20:49:31 --> 404 Page Not Found: City/10
ERROR - 2021-09-29 20:49:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 21:06:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 21:13:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 21:17:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 21:19:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 21:20:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 21:20:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 21:20:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 21:20:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:20:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 21:21:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 21:23:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 21:25:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:27:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 21:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 21:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 21:31:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 21:31:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:35:35 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-29 21:41:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:45:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 21:47:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 21:49:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:49:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:49:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:50:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:50:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:50:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:50:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:50:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:51:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 21:51:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 21:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:52:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-09-29 21:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 21:56:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:00:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 22:02:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:03:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:03:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:03:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:04:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:04:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:04:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:04:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 22:05:17 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-09-29 22:05:43 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-29 22:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:07:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:08:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:08:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:08:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:08:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:09:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:09:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:09:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:09:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 22:15:21 --> 404 Page Not Found: Article/view
ERROR - 2021-09-29 22:15:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-29 22:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 22:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 23:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 23:26:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 23:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 23:28:00 --> 404 Page Not Found: Dayrui/Fcms
ERROR - 2021-09-29 23:28:01 --> 404 Page Not Found: Comp/portalRouter
ERROR - 2021-09-29 23:28:01 --> 404 Page Not Found: Services/platform
ERROR - 2021-09-29 23:28:02 --> 404 Page Not Found: Public/ui
ERROR - 2021-09-29 23:28:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 23:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 23:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 23:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 23:51:26 --> 404 Page Not Found: Dayrui/Fcms
ERROR - 2021-09-29 23:51:26 --> 404 Page Not Found: Comp/portalRouter
ERROR - 2021-09-29 23:51:26 --> 404 Page Not Found: Services/platform
ERROR - 2021-09-29 23:51:27 --> 404 Page Not Found: Public/ui
ERROR - 2021-09-29 23:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-29 23:53:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-29 23:57:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-09-29 23:57:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
