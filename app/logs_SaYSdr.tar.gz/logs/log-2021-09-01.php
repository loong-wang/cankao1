<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-01 00:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:02:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:03:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:03:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:03:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:03:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:04:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:06:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:14:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 00:14:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 00:14:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 00:14:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 00:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:16:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-01 00:16:23 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-01 00:16:23 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-01 00:16:24 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-01 00:16:24 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-01 00:16:24 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-01 00:16:24 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-01 00:16:24 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-01 00:16:24 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-01 00:16:24 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-01 00:16:24 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-01 00:16:25 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-01 00:16:26 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-01 00:16:26 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-01 00:16:26 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-01 00:16:26 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-01 00:16:26 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-01 00:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:19:57 --> 404 Page Not Found: SiteServer/Ajax
ERROR - 2021-09-01 00:19:57 --> 404 Page Not Found: SiteFiles/SiteTemplates
ERROR - 2021-09-01 00:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:35:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:39:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 00:39:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 00:39:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 00:39:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:39:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:40:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 00:40:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 00:40:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:40:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 00:40:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 00:41:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:41:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 00:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:45:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:45:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 00:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:46:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 00:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:52:00 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 00:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:54:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:56:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 00:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 00:57:17 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-01 00:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:01:21 --> 404 Page Not Found: Nmaplowercheck1630429269/index
ERROR - 2021-09-01 01:01:21 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-09-01 01:01:21 --> 404 Page Not Found: Evox/about
ERROR - 2021-09-01 01:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:05:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:16 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:16 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:16 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:16 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:16 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:16 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:16 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:16 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:16 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:18 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:20 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:11:43 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-01 01:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:20:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:28 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:29 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:29 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:29 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:29 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:29 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:29 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:29 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:29 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:30 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:30 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 01:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:36:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 01:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 01:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:10:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 02:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:22:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:39:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 02:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:43:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 02:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 02:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:24:41 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-01 03:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:46:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:55:22 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-01 03:55:22 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-01 03:55:22 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-01 03:55:22 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-01 03:55:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-01 03:55:22 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-01 03:55:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-01 03:55:22 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-01 03:55:22 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-01 03:55:23 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-01 03:55:24 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-01 03:55:24 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-01 03:55:24 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-01 03:55:24 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-01 03:55:24 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-01 03:55:24 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-01 03:55:24 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-01 03:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 03:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:01:02 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-09-01 04:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:03:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 04:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:04:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:10:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 04:10:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 04:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:14:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:16:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:27:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-01 04:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:34:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 04:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:53:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 04:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 04:59:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 05:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:04:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 05:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:18:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 05:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:21:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 05:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:49:15 --> 404 Page Not Found: City/16
ERROR - 2021-09-01 05:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:50:50 --> 404 Page Not Found: City/1
ERROR - 2021-09-01 05:50:55 --> 404 Page Not Found: City/1
ERROR - 2021-09-01 05:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:54:15 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 05:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 05:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:00:00 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-01 06:00:11 --> 404 Page Not Found: Sites/default
ERROR - 2021-09-01 06:00:19 --> 404 Page Not Found: admin/Controller/extension
ERROR - 2021-09-01 06:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:04:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 06:05:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:11:08 --> 404 Page Not Found: English/index
ERROR - 2021-09-01 06:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:24:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:24:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 06:24:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 06:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:26:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 06:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:28:04 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-01 06:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:32:51 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-01 06:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:54:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 06:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:02:41 --> 404 Page Not Found: City/1
ERROR - 2021-09-01 07:03:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 07:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:16:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 07:16:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 07:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:22:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:41:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 07:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:49:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 07:49:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 07:49:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 07:49:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 07:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:52:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 07:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:53:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 07:54:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 07:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:00:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 08:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:03:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 08:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:06:01 --> 404 Page Not Found: 1sql/index
ERROR - 2021-09-01 08:06:03 --> 404 Page Not Found: 123sql/index
ERROR - 2021-09-01 08:06:04 --> 404 Page Not Found: 2020sql/index
ERROR - 2021-09-01 08:06:05 --> 404 Page Not Found: 2021sql/index
ERROR - 2021-09-01 08:06:06 --> 404 Page Not Found: A_checkoutssql/index
ERROR - 2021-09-01 08:06:07 --> 404 Page Not Found: Administratorssql/index
ERROR - 2021-09-01 08:06:08 --> 404 Page Not Found: Adminsql/index
ERROR - 2021-09-01 08:06:09 --> 404 Page Not Found: Adminssql/index
ERROR - 2021-09-01 08:06:09 --> 404 Page Not Found: Apisql/index
ERROR - 2021-09-01 08:06:11 --> 404 Page Not Found: Asql/index
ERROR - 2021-09-01 08:06:13 --> 404 Page Not Found: Backsql/index
ERROR - 2021-09-01 08:06:14 --> 404 Page Not Found: Backtxt/index
ERROR - 2021-09-01 08:06:15 --> 404 Page Not Found: Backup/backup.sql
ERROR - 2021-09-01 08:06:15 --> 404 Page Not Found: Backup/bd.sql
ERROR - 2021-09-01 08:06:16 --> 404 Page Not Found: Backup/database.sql
ERROR - 2021-09-01 08:06:17 --> 404 Page Not Found: Backup/dbdump.sql
ERROR - 2021-09-01 08:06:18 --> 404 Page Not Found: Backup/gdxuanhaonet.sql
ERROR - 2021-09-01 08:06:19 --> 404 Page Not Found: Backup/dump.sql
ERROR - 2021-09-01 08:06:20 --> 404 Page Not Found: Backup/localhost.sql
ERROR - 2021-09-01 08:06:21 --> 404 Page Not Found: Backup/mysql.sql
ERROR - 2021-09-01 08:06:22 --> 404 Page Not Found: Backup/order.sql
ERROR - 2021-09-01 08:06:23 --> 404 Page Not Found: Backup/orders.sql
ERROR - 2021-09-01 08:06:24 --> 404 Page Not Found: Backup/payment.sql
ERROR - 2021-09-01 08:06:26 --> 404 Page Not Found: Backup/payments.sql
ERROR - 2021-09-01 08:06:27 --> 404 Page Not Found: Backup/shop.sql
ERROR - 2021-09-01 08:06:27 --> 404 Page Not Found: Backup/xuanhao.sql
ERROR - 2021-09-01 08:06:28 --> 404 Page Not Found: Backups/order.sql
ERROR - 2021-09-01 08:06:29 --> 404 Page Not Found: Backups/orders.sql
ERROR - 2021-09-01 08:06:30 --> 404 Page Not Found: Backups/payment.sql
ERROR - 2021-09-01 08:06:30 --> 404 Page Not Found: Backups/payments.sql
ERROR - 2021-09-01 08:06:32 --> 404 Page Not Found: _backupsql/index
ERROR - 2021-09-01 08:06:33 --> 404 Page Not Found: Backupsql/index
ERROR - 2021-09-01 08:06:34 --> 404 Page Not Found: Backuptxt/index
ERROR - 2021-09-01 08:06:35 --> 404 Page Not Found: Backups/shop.sql
ERROR - 2021-09-01 08:06:36 --> 404 Page Not Found: Backupssql/index
ERROR - 2021-09-01 08:06:37 --> 404 Page Not Found: Backups/store.sql
ERROR - 2021-09-01 08:06:38 --> 404 Page Not Found: Backup/store.sql
ERROR - 2021-09-01 08:06:39 --> 404 Page Not Found: Basesql/index
ERROR - 2021-09-01 08:06:40 --> 404 Page Not Found: Bdsql/index
ERROR - 2021-09-01 08:06:41 --> 404 Page Not Found: Billingsql/index
ERROR - 2021-09-01 08:06:42 --> 404 Page Not Found: Bitcoinsql/index
ERROR - 2021-09-01 08:06:43 --> 404 Page Not Found: Cardsql/index
ERROR - 2021-09-01 08:06:44 --> 404 Page Not Found: Cardssql/index
ERROR - 2021-09-01 08:06:45 --> 404 Page Not Found: Checkoutsql/index
ERROR - 2021-09-01 08:06:45 --> 404 Page Not Found: Checkoutssql/index
ERROR - 2021-09-01 08:06:46 --> 404 Page Not Found: Configsql/index
ERROR - 2021-09-01 08:06:47 --> 404 Page Not Found: Credit_cardsql/index
ERROR - 2021-09-01 08:06:49 --> 404 Page Not Found: Creditcardsql/index
ERROR - 2021-09-01 08:06:50 --> 404 Page Not Found: Credit_cardssql/index
ERROR - 2021-09-01 08:06:51 --> 404 Page Not Found: Creditcardssql/index
ERROR - 2021-09-01 08:06:52 --> 404 Page Not Found: Database/gdxuanhaonet.sql
ERROR - 2021-09-01 08:06:52 --> 404 Page Not Found: Database/order.sql
ERROR - 2021-09-01 08:06:53 --> 404 Page Not Found: Database/orders.sql
ERROR - 2021-09-01 08:06:54 --> 404 Page Not Found: Database/payment.sql
ERROR - 2021-09-01 08:06:55 --> 404 Page Not Found: Database/payments.sql
ERROR - 2021-09-01 08:06:56 --> 404 Page Not Found: Database/shop.sql
ERROR - 2021-09-01 08:06:57 --> 404 Page Not Found: Database/xuanhao.sql
ERROR - 2021-09-01 08:06:58 --> 404 Page Not Found: Databasesql/index
ERROR - 2021-09-01 08:06:59 --> 404 Page Not Found: Database/store.sql
ERROR - 2021-09-01 08:07:00 --> 404 Page Not Found: Datasql/index
ERROR - 2021-09-01 08:07:01 --> 404 Page Not Found: Datatxt/index
ERROR - 2021-09-01 08:07:01 --> 404 Page Not Found: Datenbankensql/index
ERROR - 2021-09-01 08:07:02 --> 404 Page Not Found: Dbasesql/index
ERROR - 2021-09-01 08:07:04 --> 404 Page Not Found: Dbasetxt/index
ERROR - 2021-09-01 08:07:05 --> 404 Page Not Found: Db/backup.sql
ERROR - 2021-09-01 08:07:06 --> 404 Page Not Found: Db_backupsql/index
ERROR - 2021-09-01 08:07:07 --> 404 Page Not Found: Dbbackup/store.sql
ERROR - 2021-09-01 08:07:07 --> 404 Page Not Found: Db/bd.sql
ERROR - 2021-09-01 08:07:08 --> 404 Page Not Found: Db/database.sql
ERROR - 2021-09-01 08:07:09 --> 404 Page Not Found: Db/dbdump.sql
ERROR - 2021-09-01 08:07:10 --> 404 Page Not Found: Db/gdxuanhaonet.sql
ERROR - 2021-09-01 08:07:11 --> 404 Page Not Found: Dbdumpsql/index
ERROR - 2021-09-01 08:07:13 --> 404 Page Not Found: Db/dump.sql
ERROR - 2021-09-01 08:07:14 --> 404 Page Not Found: Db/localhost.sql
ERROR - 2021-09-01 08:07:15 --> 404 Page Not Found: Db_mysqlsql/index
ERROR - 2021-09-01 08:07:16 --> 404 Page Not Found: Db/mysql.sql
ERROR - 2021-09-01 08:07:17 --> 404 Page Not Found: Db/order.sql
ERROR - 2021-09-01 08:07:17 --> 404 Page Not Found: Db/orders.sql
ERROR - 2021-09-01 08:07:18 --> 404 Page Not Found: Db/payment.sql
ERROR - 2021-09-01 08:07:19 --> 404 Page Not Found: Db/payments.sql
ERROR - 2021-09-01 08:07:20 --> 404 Page Not Found: Db/shop.sql
ERROR - 2021-09-01 08:07:21 --> 404 Page Not Found: Db/xuanhao.sql
ERROR - 2021-09-01 08:07:22 --> 404 Page Not Found: Dbsql/index
ERROR - 2021-09-01 08:07:23 --> 404 Page Not Found: Dbtxt/index
ERROR - 2021-09-01 08:07:23 --> 404 Page Not Found: Db/store.sql
ERROR - 2021-09-01 08:07:24 --> 404 Page Not Found: Gdxuanhaonetsql/index
ERROR - 2021-09-01 08:07:25 --> 404 Page Not Found: Dump/backup.sql
ERROR - 2021-09-01 08:07:26 --> 404 Page Not Found: Dump/bd.sql
ERROR - 2021-09-01 08:07:27 --> 404 Page Not Found: Dump/database.sql
ERROR - 2021-09-01 08:07:28 --> 404 Page Not Found: Dump/dbdump.sql
ERROR - 2021-09-01 08:07:29 --> 404 Page Not Found: Dump/gdxuanhaonet.sql
ERROR - 2021-09-01 08:07:30 --> 404 Page Not Found: Dump/dump.sql
ERROR - 2021-09-01 08:07:30 --> 404 Page Not Found: Dump/localhost.sql
ERROR - 2021-09-01 08:07:31 --> 404 Page Not Found: Dump/mysql.sql
ERROR - 2021-09-01 08:07:32 --> 404 Page Not Found: Dump/order.sql
ERROR - 2021-09-01 08:07:33 --> 404 Page Not Found: Dump/orders.sql
ERROR - 2021-09-01 08:07:34 --> 404 Page Not Found: Dump/payment.sql
ERROR - 2021-09-01 08:07:34 --> 404 Page Not Found: Dump/payments.sql
ERROR - 2021-09-01 08:07:35 --> 404 Page Not Found: Dump/shop.sql
ERROR - 2021-09-01 08:07:36 --> 404 Page Not Found: Dump/xuanhao.sql
ERROR - 2021-09-01 08:07:37 --> 404 Page Not Found: Dumps/order.sql
ERROR - 2021-09-01 08:07:39 --> 404 Page Not Found: Dumps/orders.sql
ERROR - 2021-09-01 08:07:40 --> 404 Page Not Found: Dumps/payment.sql
ERROR - 2021-09-01 08:07:41 --> 404 Page Not Found: Dumps/payments.sql
ERROR - 2021-09-01 08:07:42 --> 404 Page Not Found: Dumpsql/index
ERROR - 2021-09-01 08:07:43 --> 404 Page Not Found: Dumptxt/index
ERROR - 2021-09-01 08:07:44 --> 404 Page Not Found: Dumps/shop.sql
ERROR - 2021-09-01 08:07:45 --> 404 Page Not Found: Dumps/store.sql
ERROR - 2021-09-01 08:07:46 --> 404 Page Not Found: Dump/store.sql
ERROR - 2021-09-01 08:07:47 --> 404 Page Not Found: Exportsql/index
ERROR - 2021-09-01 08:07:48 --> 404 Page Not Found: Gatewaysql/index
ERROR - 2021-09-01 08:07:49 --> 404 Page Not Found: Homesql/index
ERROR - 2021-09-01 08:07:49 --> 404 Page Not Found: Keyssql/index
ERROR - 2021-09-01 08:07:52 --> 404 Page Not Found: Localhostsql/index
ERROR - 2021-09-01 08:07:52 --> 404 Page Not Found: Mainsql/index
ERROR - 2021-09-01 08:07:53 --> 404 Page Not Found: Migrationsql/index
ERROR - 2021-09-01 08:07:54 --> 404 Page Not Found: Mysql/backup.sql
ERROR - 2021-09-01 08:07:55 --> 404 Page Not Found: Mysql/bd.sql
ERROR - 2021-09-01 08:07:56 --> 404 Page Not Found: Mysql/database.sql
ERROR - 2021-09-01 08:07:57 --> 404 Page Not Found: Mysql/dbdump.sql
ERROR - 2021-09-01 08:07:57 --> 404 Page Not Found: Mysql/gdxuanhaonet.sql
ERROR - 2021-09-01 08:07:59 --> 404 Page Not Found: Mysql/dump.sql
ERROR - 2021-09-01 08:07:59 --> 404 Page Not Found: Mysqldumpsql/index
ERROR - 2021-09-01 08:08:00 --> 404 Page Not Found: Mysql/localhost.sql
ERROR - 2021-09-01 08:08:01 --> 404 Page Not Found: Mysql/mysql.sql
ERROR - 2021-09-01 08:08:02 --> 404 Page Not Found: Mysql/order.sql
ERROR - 2021-09-01 08:08:03 --> 404 Page Not Found: Mysql/orders.sql
ERROR - 2021-09-01 08:08:03 --> 404 Page Not Found: Mysql/payment.sql
ERROR - 2021-09-01 08:08:05 --> 404 Page Not Found: Mysql/payments.sql
ERROR - 2021-09-01 08:08:06 --> 404 Page Not Found: Mysql/shop.sql
ERROR - 2021-09-01 08:08:06 --> 404 Page Not Found: Mysql/xuanhao.sql
ERROR - 2021-09-01 08:08:07 --> 404 Page Not Found: Mysqlsql/index
ERROR - 2021-09-01 08:08:08 --> 404 Page Not Found: Mysql/store.sql
ERROR - 2021-09-01 08:08:09 --> 404 Page Not Found: Oldsql/index
ERROR - 2021-09-01 08:08:10 --> 404 Page Not Found: Ordersql/index
ERROR - 2021-09-01 08:08:11 --> 404 Page Not Found: Orderssql/index
ERROR - 2021-09-01 08:08:13 --> 404 Page Not Found: Orderstxt/index
ERROR - 2021-09-01 08:08:13 --> 404 Page Not Found: Oscommercesql/index
ERROR - 2021-09-01 08:08:14 --> 404 Page Not Found: OsCommercesql/index
ERROR - 2021-09-01 08:08:15 --> 404 Page Not Found: Passwordssql/index
ERROR - 2021-09-01 08:08:16 --> 404 Page Not Found: Paymentsql/index
ERROR - 2021-09-01 08:08:17 --> 404 Page Not Found: Paymentssql/index
ERROR - 2021-09-01 08:08:18 --> 404 Page Not Found: Paymentstxt/index
ERROR - 2021-09-01 08:08:19 --> 404 Page Not Found: Public_htmlsql/index
ERROR - 2021-09-01 08:08:19 --> 404 Page Not Found: Savesql/index
ERROR - 2021-09-01 08:08:20 --> 404 Page Not Found: Securitysql/index
ERROR - 2021-09-01 08:08:21 --> 404 Page Not Found: Serversql/index
ERROR - 2021-09-01 08:08:22 --> 404 Page Not Found: Shopsql/index
ERROR - 2021-09-01 08:08:24 --> 404 Page Not Found: Shoptxt/index
ERROR - 2021-09-01 08:08:25 --> 404 Page Not Found: Xuanhaosql/index
ERROR - 2021-09-01 08:08:26 --> 404 Page Not Found: Sitesql/index
ERROR - 2021-09-01 08:08:27 --> 404 Page Not Found: Sql/backup.sql
ERROR - 2021-09-01 08:08:27 --> 404 Page Not Found: Sql/bd.sql
ERROR - 2021-09-01 08:08:28 --> 404 Page Not Found: Sql/database.sql
ERROR - 2021-09-01 08:08:29 --> 404 Page Not Found: Sql/dbdump.sql
ERROR - 2021-09-01 08:08:30 --> 404 Page Not Found: Sql/gdxuanhaonet.sql
ERROR - 2021-09-01 08:08:32 --> 404 Page Not Found: Sql/dump.sql
ERROR - 2021-09-01 08:08:33 --> 404 Page Not Found: Sql/localhost.sql
ERROR - 2021-09-01 08:08:33 --> 404 Page Not Found: Sql/mysql.sql
ERROR - 2021-09-01 08:08:34 --> 404 Page Not Found: Sql/order.sql
ERROR - 2021-09-01 08:08:35 --> 404 Page Not Found: Sql/orders.sql
ERROR - 2021-09-01 08:08:36 --> 404 Page Not Found: Sql/payment.sql
ERROR - 2021-09-01 08:08:38 --> 404 Page Not Found: Sql/payments.sql
ERROR - 2021-09-01 08:08:39 --> 404 Page Not Found: Sql/shop.sql
ERROR - 2021-09-01 08:08:40 --> 404 Page Not Found: Sql/xuanhao.sql
ERROR - 2021-09-01 08:08:40 --> 404 Page Not Found: Sqlsql/index
ERROR - 2021-09-01 08:08:41 --> 404 Page Not Found: Sql/store.sql
ERROR - 2021-09-01 08:08:42 --> 404 Page Not Found: Storesql/index
ERROR - 2021-09-01 08:08:43 --> 404 Page Not Found: Storetxt/index
ERROR - 2021-09-01 08:08:44 --> 404 Page Not Found: Tempsql/index
ERROR - 2021-09-01 08:08:46 --> 404 Page Not Found: Tmpsql/index
ERROR - 2021-09-01 08:08:47 --> 404 Page Not Found: Testsql/index
ERROR - 2021-09-01 08:08:48 --> 404 Page Not Found: Uploadsql/index
ERROR - 2021-09-01 08:08:48 --> 404 Page Not Found: Updatesql/index
ERROR - 2021-09-01 08:08:50 --> 404 Page Not Found: Userssql/index
ERROR - 2021-09-01 08:08:51 --> 404 Page Not Found: Walletsql/index
ERROR - 2021-09-01 08:08:52 --> 404 Page Not Found: Websql/index
ERROR - 2021-09-01 08:08:52 --> 404 Page Not Found: Wordpresssql/index
ERROR - 2021-09-01 08:08:54 --> 404 Page Not Found: Wpsql/index
ERROR - 2021-09-01 08:08:55 --> 404 Page Not Found: Wwwrootsql/index
ERROR - 2021-09-01 08:08:56 --> 404 Page Not Found: Wwwsql/index
ERROR - 2021-09-01 08:08:57 --> 404 Page Not Found: Wp-content/uploads
ERROR - 2021-09-01 08:08:58 --> 404 Page Not Found: admin/Backup/index
ERROR - 2021-09-01 08:08:59 --> 404 Page Not Found: admin/Backups/index
ERROR - 2021-09-01 08:08:59 --> 404 Page Not Found: admin/Files/index
ERROR - 2021-09-01 08:09:00 --> 404 Page Not Found: admin/Mysql/index
ERROR - 2021-09-01 08:09:01 --> 404 Page Not Found: admin/Upload/index
ERROR - 2021-09-01 08:09:02 --> 404 Page Not Found: admin/Uploaded/index
ERROR - 2021-09-01 08:09:03 --> 404 Page Not Found: admin/Uploads/index
ERROR - 2021-09-01 08:09:04 --> 404 Page Not Found: Archive/index
ERROR - 2021-09-01 08:09:05 --> 404 Page Not Found: Backup/index
ERROR - 2021-09-01 08:09:05 --> 404 Page Not Found: Backup/index
ERROR - 2021-09-01 08:09:06 --> 404 Page Not Found: Backup/index
ERROR - 2021-09-01 08:09:07 --> 404 Page Not Found: BACKUP/index
ERROR - 2021-09-01 08:09:08 --> 404 Page Not Found: Backup/bitcoin
ERROR - 2021-09-01 08:09:08 --> 404 Page Not Found: Backups/index
ERROR - 2021-09-01 08:09:09 --> 404 Page Not Found: Backups/index
ERROR - 2021-09-01 08:09:10 --> 404 Page Not Found: Backups/index
ERROR - 2021-09-01 08:09:11 --> 404 Page Not Found: Bak/index
ERROR - 2021-09-01 08:09:12 --> 404 Page Not Found: Bitcoin/index
ERROR - 2021-09-01 08:09:12 --> 404 Page Not Found: Bitcoin/index
ERROR - 2021-09-01 08:09:13 --> 404 Page Not Found: Database/index
ERROR - 2021-09-01 08:09:14 --> 404 Page Not Found: Db_backup/index
ERROR - 2021-09-01 08:09:15 --> 404 Page Not Found: Dbbackup/index
ERROR - 2021-09-01 08:09:16 --> 404 Page Not Found: Db_backups/index
ERROR - 2021-09-01 08:09:17 --> 404 Page Not Found: Dbbackups/index
ERROR - 2021-09-01 08:09:17 --> 404 Page Not Found: Db/index
ERROR - 2021-09-01 08:09:18 --> 404 Page Not Found: Db_dump/index
ERROR - 2021-09-01 08:09:20 --> 404 Page Not Found: Dbdump/index
ERROR - 2021-09-01 08:09:21 --> 404 Page Not Found: Db_dumps/index
ERROR - 2021-09-01 08:09:22 --> 404 Page Not Found: Dbdumps/index
ERROR - 2021-09-01 08:09:23 --> 404 Page Not Found: Dump/index
ERROR - 2021-09-01 08:09:24 --> 404 Page Not Found: Dump/index
ERROR - 2021-09-01 08:09:25 --> 404 Page Not Found: Dumps/index
ERROR - 2021-09-01 08:09:25 --> 404 Page Not Found: Export/index
ERROR - 2021-09-01 08:09:26 --> 404 Page Not Found: Files/index
ERROR - 2021-09-01 08:09:28 --> 404 Page Not Found: Includes/database
ERROR - 2021-09-01 08:09:28 --> 404 Page Not Found: Includes/database
ERROR - 2021-09-01 08:09:29 --> 404 Page Not Found: Log/index
ERROR - 2021-09-01 08:09:30 --> 404 Page Not Found: Logs/index
ERROR - 2021-09-01 08:09:30 --> 404 Page Not Found: Mariadb/index
ERROR - 2021-09-01 08:09:31 --> 404 Page Not Found: Mysql_backup/index
ERROR - 2021-09-01 08:09:32 --> 404 Page Not Found: Mysqlbackup/index
ERROR - 2021-09-01 08:09:33 --> 404 Page Not Found: Mysql_backups/index
ERROR - 2021-09-01 08:09:33 --> 404 Page Not Found: Mysqlbackups/index
ERROR - 2021-09-01 08:09:35 --> 404 Page Not Found: Mysql_dump/index
ERROR - 2021-09-01 08:09:35 --> 404 Page Not Found: Mysqldump/index
ERROR - 2021-09-01 08:09:36 --> 404 Page Not Found: Mysql_dumps/index
ERROR - 2021-09-01 08:09:37 --> 404 Page Not Found: Mysqldumps/index
ERROR - 2021-09-01 08:09:38 --> 404 Page Not Found: Mysql/index
ERROR - 2021-09-01 08:09:39 --> 404 Page Not Found: Old_files/index
ERROR - 2021-09-01 08:09:40 --> 404 Page Not Found: Oldfiles/index
ERROR - 2021-09-01 08:09:41 --> 404 Page Not Found: Old/index
ERROR - 2021-09-01 08:09:42 --> 404 Page Not Found: Pmadumps/index
ERROR - 2021-09-01 08:09:42 --> 404 Page Not Found: Pma/index
ERROR - 2021-09-01 08:09:43 --> 404 Page Not Found: Saved/index
ERROR - 2021-09-01 08:09:44 --> 404 Page Not Found: Save/index
ERROR - 2021-09-01 08:09:45 --> 404 Page Not Found: Sql/backup
ERROR - 2021-09-01 08:09:46 --> 404 Page Not Found: Sql/backups
ERROR - 2021-09-01 08:09:47 --> 404 Page Not Found: Sql_dumps/index
ERROR - 2021-09-01 08:09:47 --> 404 Page Not Found: Sql/index
ERROR - 2021-09-01 08:09:48 --> 404 Page Not Found: Sql/sql
ERROR - 2021-09-01 08:09:49 --> 404 Page Not Found: Uploaded/index
ERROR - 2021-09-01 08:09:51 --> 404 Page Not Found: Upload/index
ERROR - 2021-09-01 08:09:51 --> 404 Page Not Found: Var/backups
ERROR - 2021-09-01 08:09:52 --> 404 Page Not Found: Wallet/index
ERROR - 2021-09-01 08:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:15:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 08:15:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-01 08:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:19:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 08:19:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 08:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:20:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 08:20:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 08:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:43:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-01 08:43:23 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-01 08:43:23 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-01 08:43:23 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-01 08:43:23 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-01 08:43:23 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-01 08:43:23 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-01 08:43:24 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-01 08:43:24 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-01 08:43:24 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-01 08:43:24 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-01 08:43:24 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-01 08:43:24 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-01 08:43:24 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-01 08:43:24 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-01 08:43:24 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-01 08:43:24 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-01 08:43:25 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-01 08:43:26 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-01 08:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:47:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 08:47:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 08:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:50:19 --> 404 Page Not Found: English/index
ERROR - 2021-09-01 08:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:50:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 08:51:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 08:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:54:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 08:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:05:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 09:05:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 09:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:11:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 09:11:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 09:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:20:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 09:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:26:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 09:26:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 09:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:03 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:04 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:04 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:04 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:04 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:08 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:30:09 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 09:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:33:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 09:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 09:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:02:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 10:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:04:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 10:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:04:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 10:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:05:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 10:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 10:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:05:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 10:06:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 10:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:12:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:12:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:12:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:12:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:12:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:07 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:09 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:09 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:09 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:09 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:09 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:09 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:09 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:09 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:09 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:10 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:10 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:11 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:11 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:11 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:11 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:11 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:11 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:11 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:11 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:11 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:12 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:12 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:12 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:12 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:12 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:12 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:12 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:12 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:12 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:12 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:12 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:12 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:12 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:13 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:13 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:13 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:13 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:13 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:13 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:13 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:13 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:13 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:13 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:13 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:13 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:13 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:14 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:15 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:15 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:15 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:15 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:15 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:15 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:15 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:15 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:15 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:15 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:15 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:15 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:15 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:16 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:16 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:16 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:16 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:16 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:16 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:16 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:16 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:16 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:16 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:16 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:17 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:17 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:18 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:18 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:19 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:19 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:19 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:19 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:19 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:19 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:19 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:19 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:19 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:19 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:19 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:19 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:19 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:19 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:19 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:19 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:19 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:20 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:20 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:20 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:20 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:20 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:20 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:20 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:20 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:20 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:20 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:20 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:20 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:20 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:20 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:20 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:20 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:20 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:21 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:21 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:21 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:22 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:22 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:22 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:22 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:22 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:22 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:22 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:22 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:23 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:24 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:24 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:24 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:24 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:24 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:24 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:24 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:24 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:24 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:25 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:25 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:25 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:25 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:25 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:25 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:25 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:26 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:26 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:26 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:26 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:26 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:26 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:26 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:27 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:27 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:27 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:27 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:27 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:27 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:27 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:27 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:27 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:27 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:27 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:28 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:28 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:28 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:28 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:28 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:29 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:29 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:29 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:29 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:29 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:29 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:29 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:30 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:30 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:31 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:31 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:31 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:31 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:31 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:31 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:31 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:31 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:31 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:31 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:31 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:31 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:31 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:32 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:32 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:32 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:32 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:32 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:32 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:32 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:33 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:33 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:34 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:34 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:34 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:34 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:34 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:34 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:34 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:34 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:34 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:34 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:34 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:34 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:34 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:34 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:34 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:34 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:34 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:35 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:35 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:35 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:36 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:36 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:36 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:36 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:36 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:36 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:36 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:36 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:36 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:36 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:36 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:36 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:36 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:37 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:37 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:37 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:37 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:37 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:37 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:37 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:37 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:37 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:37 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:37 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:13:38 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:38 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:38 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:38 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:38 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:13:38 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:13:38 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:13:38 --> Unable to connect to the database
ERROR - 2021-09-01 10:13:38 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:13:38 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:20:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:20:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:20:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:20:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:20:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:20:06 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:20:06 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:20:06 --> Unable to connect to the database
ERROR - 2021-09-01 10:20:06 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:20:06 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:20:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:20:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:20:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:20:16 --> Unable to connect to the database
ERROR - 2021-09-01 10:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:20:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:20:16 --> SeverERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:33:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:34:06 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:33:56 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-01 10:35:46 --> Unable to select database: xuanhao_net
ERROR - 2021-09-01 10:35:46 --> Unable to connect to the database
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-01 10:35:46 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-01 10:35:48 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/cityt159): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 279
ERROR - 2021-09-01 10:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:37:05 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-09-01 10:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:46:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:49:04 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-09-01 10:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:50:49 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-09-01 10:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:57:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 10:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:00:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 11:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:03:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 11:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:09:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:10:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:22:25 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-01 11:22:26 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-01 11:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:23:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:25:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:26:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:29:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 11:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:35:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:38:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:40:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:40:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:41:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:41:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:41:52 --> 404 Page Not Found: Env/index
ERROR - 2021-09-01 11:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:45:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:47:46 --> 404 Page Not Found: English/index
ERROR - 2021-09-01 11:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:48:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:49:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:50:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 11:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 11:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:02:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:04:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:05:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:06:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:06:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:06:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:06:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:07:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:07:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:08:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:09:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:09:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:10:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:10:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:11:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:11:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:11:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 12:11:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:12:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 12:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:13:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:14:55 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-09-01 12:15:11 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-01 12:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:17:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:17:56 --> 404 Page Not Found: City/9
ERROR - 2021-09-01 12:18:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:18:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:19:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:19:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:20:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:20:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:20:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:21:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:21:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 12:21:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:22:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:22:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:23:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:23:22 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-01 12:23:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:25:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:25:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:25:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:27:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:28:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 12:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:34:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 12:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:38:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 12:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:43:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:48:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:55:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:55:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:56:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 12:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:57:23 --> 404 Page Not Found: Management/Login.Asp
ERROR - 2021-09-01 12:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 12:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:00:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 13:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:17:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 13:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:23:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 13:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:26:42 --> 404 Page Not Found: Nmaplowercheck1630474000/index
ERROR - 2021-09-01 13:26:43 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-09-01 13:26:46 --> 404 Page Not Found: Evox/about
ERROR - 2021-09-01 13:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:29:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-01 13:31:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 13:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:31:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 13:31:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 13:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:34:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 13:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:34:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:34:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:34:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:34:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:34:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:34:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:34:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:34:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:34:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:34:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:35:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:35:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-09-01 13:35:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 13:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:36:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 13:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:41:09 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-01 13:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:45:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:48:44 --> 404 Page Not Found: Management/Login.Asp
ERROR - 2021-09-01 13:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:50:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-01 13:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:53:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-01 13:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:57:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-01 13:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:58:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 13:59:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 14:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:02:21 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-01 14:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:02:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 14:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:02:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 14:04:23 --> 404 Page Not Found: City/16
ERROR - 2021-09-01 14:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:18:01 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-01 14:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 14:22:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 14:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:22:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:22:30 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-01 14:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:24:34 --> 404 Page Not Found: Company/view
ERROR - 2021-09-01 14:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:26:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 14:27:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 14:29:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 14:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:29:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 14:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:35:13 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-09-01 14:35:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:38:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 14:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:40:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 14:40:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 14:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:52:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 14:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 14:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:00:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:04:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 15:04:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:11:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 15:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:13:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 15:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:19:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:19:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:20:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:20:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:20:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:21:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:21:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:21:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:21:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:27:42 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-01 15:27:43 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-01 15:28:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:28:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:28:55 --> 404 Page Not Found: Wp-includes/index
ERROR - 2021-09-01 15:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:29:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:29:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:32:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:33:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:34:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:35:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:40:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 15:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:43:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:43:26 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-09-01 15:43:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:44:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:44:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:44:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:44:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:44:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:45:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:45:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:45:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:46:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:46:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:47:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:47:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:47:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:47:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:47:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 15:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 15:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:02:41 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-01 16:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-01 16:05:49 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-01 16:05:50 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-01 16:05:51 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-01 16:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 16:08:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 16:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:09:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 16:09:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 16:10:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 16:11:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 16:11:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 16:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:13:14 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-01 16:13:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:25:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 16:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:27:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:33:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:33:59 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-01 16:34:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 16:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:37:23 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-01 16:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:40:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:41:15 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-01 16:41:17 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-01 16:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:55:25 --> Severity: Warning --> Missing argument 2 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-01 16:55:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-01 16:57:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 16:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 16:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:06:26 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-09-01 17:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:13:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 17:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:15:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 17:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:20:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-01 17:20:54 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-01 17:20:55 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-01 17:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:27:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:27:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 17:27:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:27:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:28:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 17:30:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 17:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:32:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 17:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:34:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 17:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:41:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 17:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:43:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 17:44:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 17:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:49:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 17:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:56:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 17:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:56:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 17:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 17:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 18:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:05:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 18:06:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 18:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:17:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 18:18:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 18:18:41 --> 404 Page Not Found: 10/all
ERROR - 2021-09-01 18:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:19:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 18:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:27:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 18:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:37:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:39:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:40:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 18:40:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 18:40:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 18:41:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 18:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:42:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-01 18:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:45:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 18:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:50:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 18:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:54:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 18:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:55:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 18:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 18:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:00:35 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-01 19:00:54 --> 404 Page Not Found: Sites/default
ERROR - 2021-09-01 19:01:01 --> 404 Page Not Found: admin/Controller/extension
ERROR - 2021-09-01 19:02:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:02:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:02:12 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-09-01 19:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:02:15 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-09-01 19:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:08:58 --> 404 Page Not Found: City/16
ERROR - 2021-09-01 19:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:20:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:20:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:21:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:22:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:22:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:24:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 19:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:26:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:27:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:27:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:27:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:27:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:28:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:28:31 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-01 19:28:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:29:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 19:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:41:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:51:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 19:51:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 19:51:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 19:51:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 19:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:54:42 --> 404 Page Not Found: Undefined/index
ERROR - 2021-09-01 19:54:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:58:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:58:43 --> 404 Page Not Found: English/index
ERROR - 2021-09-01 19:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 19:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:01:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 20:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:03:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:05:31 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-09-01 20:05:50 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-09-01 20:06:16 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-09-01 20:06:27 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-09-01 20:07:05 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-09-01 20:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:11:54 --> 404 Page Not Found: Searchasp/index
ERROR - 2021-09-01 20:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:17:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 20:17:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 20:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:26:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 20:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:33:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:35:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 20:35:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 20:36:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 20:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:37:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 20:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:42:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 20:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:46:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:46:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 20:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:48:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 20:49:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 20:49:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 20:49:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 20:51:12 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-01 20:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:51:30 --> 404 Page Not Found: Sites/default
ERROR - 2021-09-01 20:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:51:40 --> 404 Page Not Found: admin/Controller/extension
ERROR - 2021-09-01 20:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:55:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 20:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:56:17 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-01 20:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:59:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 20:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:02:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:06:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 21:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:07:47 --> 404 Page Not Found: Login/index
ERROR - 2021-09-01 21:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:13:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 21:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:18:40 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-01 21:18:40 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-01 21:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:20:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 21:20:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 21:20:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 21:20:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 21:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:29:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 21:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:30:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 21:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:32:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 21:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:36:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 21:38:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 21:38:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 21:41:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 21:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:44:12 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-09-01 21:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:46:15 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-09-01 21:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:46:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 21:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:52:03 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-01 21:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 21:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 22:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:00:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 22:01:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 22:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:06:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:07:31 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-01 22:07:32 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-01 22:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:10:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 22:14:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:16:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 22:16:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 22:16:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 22:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:17:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:19:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 22:19:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 22:19:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 22:19:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-01 22:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:30:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 22:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:33:23 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-01 22:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:43:51 --> 404 Page Not Found: City/17
ERROR - 2021-09-01 22:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:44:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 22:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 22:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:01:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 23:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:10:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 23:10:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 23:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:11:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-01 23:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:19:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-01 23:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:28:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 23:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:37:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:56:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-01 23:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-01 23:59:34 --> 404 Page Not Found: Robotstxt/index
