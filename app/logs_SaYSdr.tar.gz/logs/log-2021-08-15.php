<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-15 00:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:00:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 00:01:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 00:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:08:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 00:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:22:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:23:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 00:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:25:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-15 00:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 00:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:31:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 00:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:33:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 00:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:37:56 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-15 00:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:47:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:55:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 00:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:58:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 00:59:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 00:59:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 00:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 00:59:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 00:59:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 01:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:01:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 01:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:04:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 01:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:06:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:18:54 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-15 01:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:23:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 01:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:27:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 01:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:29:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 01:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:32:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 01:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:35:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 01:36:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 01:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:36:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 01:36:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 01:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:42:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 01:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:56:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 01:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:59:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 01:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 01:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:03:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:04:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-15 02:05:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 02:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:21:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:24:57 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-08-15 02:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:29:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 02:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:31:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 02:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:32:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 02:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:35:40 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-15 02:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:38:10 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-15 02:38:10 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-15 02:38:10 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-15 02:38:10 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-15 02:38:10 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-15 02:38:11 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-15 02:38:12 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-15 02:38:12 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-15 02:38:12 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-15 02:38:12 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-15 02:38:12 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-15 02:38:12 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-15 02:38:12 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-15 02:38:12 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-15 02:38:12 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-15 02:38:12 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-15 02:38:12 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-15 02:38:13 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-15 02:38:13 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-15 02:38:13 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-15 02:38:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 02:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:39:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 02:39:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 02:39:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 02:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:43:01 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-15 02:43:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 02:43:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 02:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:45:16 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-15 02:45:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 02:45:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 02:45:48 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-15 02:46:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 02:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:52:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 02:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:53:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 02:54:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:58:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 02:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 02:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:04:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 03:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:09:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 03:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:10:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 03:12:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 03:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:13:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 03:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:16:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 03:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:29:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-15 03:30:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 03:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:32:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 03:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:35:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 03:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:37:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 03:38:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 03:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:40:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 03:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:41:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 03:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:43:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 03:44:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 03:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:50:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:54:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 03:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:58:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 03:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 03:59:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 04:00:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-08-15 04:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:03:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 04:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:05:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 04:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:09:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 04:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:10:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 04:13:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:20:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 04:20:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 04:21:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 04:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:23:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-15 04:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:26:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 04:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:27:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 04:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:27:21 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-08-15 04:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:32:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 04:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:36:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 04:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:37:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:39:00 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-15 04:40:40 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-08-15 04:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:43:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 04:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:44:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 04:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:46:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:47:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 04:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:48:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 04:48:21 --> 404 Page Not Found: admin/Fckeditor/editor
ERROR - 2021-08-15 04:48:21 --> 404 Page Not Found: Js/fckeditor
ERROR - 2021-08-15 04:48:21 --> 404 Page Not Found: Fckeditor/editor
ERROR - 2021-08-15 04:48:21 --> 404 Page Not Found: FCKeditor/editor
ERROR - 2021-08-15 04:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:48:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 04:50:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 04:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:54:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 04:54:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 04:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 04:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:00:37 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-15 05:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:02:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 05:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:07:02 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-15 05:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:10:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 05:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:10:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 05:11:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 05:11:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 05:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:16:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 05:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:20:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:20:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 05:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:20:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 05:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 05:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:22:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 05:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:26:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 05:26:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 05:27:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 05:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:28:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 05:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:29:00 --> 404 Page Not Found: Env/index
ERROR - 2021-08-15 05:29:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 05:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:35:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:40:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 05:41:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 05:41:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 05:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:54:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 05:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:56:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 05:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:58:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 05:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 05:59:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 06:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:01:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 06:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:07:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 06:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:09:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 06:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:10:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 06:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:11:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 06:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:11:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 06:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:15:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 06:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:17:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:20:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 06:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:21:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 06:22:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 06:22:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 06:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:28:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 06:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:30:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 06:32:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 06:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:39:18 --> 404 Page Not Found: English/index
ERROR - 2021-08-15 06:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:44:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 06:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:48:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 06:49:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 06:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:56:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 06:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 06:59:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 07:03:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 07:03:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 07:03:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 07:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:05:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 07:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:12:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 07:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:16:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 07:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:18:55 --> 404 Page Not Found: Index/login
ERROR - 2021-08-15 07:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:22:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 07:25:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 07:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:35:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:48:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 07:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:51:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 07:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:54:10 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-15 07:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:58:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 07:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 07:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:01:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 08:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:04:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 08:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:14:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 08:14:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 08:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:17:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:18:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 08:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:19:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 08:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:21:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 08:21:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 08:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:26:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 08:26:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 08:26:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 08:26:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 08:26:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 08:26:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 08:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:32:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 08:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:34:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 08:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:37:02 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-08-15 08:37:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 08:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:37:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 08:37:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 08:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:38:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 08:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:41:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 08:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:55:22 --> 404 Page Not Found: English/index
ERROR - 2021-08-15 08:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:57:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 08:57:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 08:57:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 08:57:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 08:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:58:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 08:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 08:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:00:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 09:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:01:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 09:01:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 09:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:01:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 09:02:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:02:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:03:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:03:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:03:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 09:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 09:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 09:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 09:11:03 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-15 09:11:05 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-15 09:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:14:48 --> 404 Page Not Found: City/index
ERROR - 2021-08-15 09:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:19:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 09:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:24:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 09:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:26:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 09:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:27:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:28:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 09:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:34:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:35:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:35:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:35:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:36:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:47:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:48:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:48:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:49:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:49:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 09:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:49:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:49:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:50:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:50:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:55:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 09:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:58:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 09:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 09:59:55 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-15 10:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:03:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 10:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:04:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 10:05:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 10:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:07:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 10:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:09:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 10:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:15:54 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-15 10:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:18:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 10:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:21:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 10:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:22:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:23:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 10:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:24:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 10:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 10:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:34:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 10:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:35:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-15 10:36:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 10:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 10:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:40:07 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-15 10:40:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-15 10:40:07 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-15 10:40:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-15 10:40:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-15 10:40:07 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-15 10:40:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-15 10:40:07 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-15 10:40:07 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-15 10:40:07 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-15 10:40:08 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-15 10:40:09 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-15 10:40:09 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-15 10:40:09 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-15 10:40:09 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-15 10:40:09 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-15 10:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:48:54 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-15 10:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:49:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:50:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 10:51:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 10:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:55:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 10:55:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 10:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:57:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 10:57:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 10:57:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 10:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 10:59:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 10:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:00:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:00:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:01:27 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-15 11:01:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 11:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:02:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:02:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 11:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:02:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:03:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 11:03:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:03:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:03:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:04:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:04:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:04:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:05:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:05:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:06:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 11:06:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:12:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:12:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:12:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:12:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:12:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:13:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:13:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:13:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:13:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:13:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:13:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:15:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:15:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:16:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:17:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:19:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:20:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:20:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:20:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:21:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:21:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:21:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:22:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 11:23:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:23:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:23:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:23:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:23:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:23:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:23:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:23:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 11:23:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:23:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:24:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:24:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:25:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:25:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:25:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 11:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:28:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:29:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:32:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:34:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-15 11:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:37:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 11:38:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:39:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:42:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:44:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 11:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:46:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 11:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:50:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 11:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:55:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 11:59:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 11:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:00:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 12:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:02:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 12:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:06:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:08:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 12:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:09:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 12:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:13:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 12:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:15:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 12:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:17:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 12:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:20:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 12:21:15 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-15 12:21:15 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-15 12:21:15 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-15 12:21:15 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-15 12:21:15 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-15 12:21:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-15 12:21:17 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-15 12:21:17 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-15 12:21:17 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-15 12:21:17 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-15 12:21:17 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-15 12:21:17 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-15 12:21:17 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-15 12:21:17 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-15 12:21:17 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-15 12:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 12:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:24:24 --> 404 Page Not Found: English/index
ERROR - 2021-08-15 12:27:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 12:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:33:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:35:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:36:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 12:37:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 12:37:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 12:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:44:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 12:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:45:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 12:59:06 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-15 13:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:03:11 --> 404 Page Not Found: 1/10000
ERROR - 2021-08-15 13:03:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:03:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 13:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:09:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:09:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:10:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:10:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:10:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:11:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:11:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:12:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:12:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:12:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 13:12:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:12:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:12:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:12:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:13:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:13:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:13:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:13:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:13:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:14:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:14:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:15:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:16:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 13:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:16:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:17:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:18:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:18:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:19:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:19:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:19:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:20:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 13:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:24:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:24:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:24:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 13:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:27:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:27:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:28:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:29:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:29:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:29:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:30:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:30:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:30:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:30:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:30:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:31:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:31:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:31:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:31:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:31:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:31:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:32:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:32:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:32:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:32:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:32:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:32:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:33:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:33:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:33:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:33:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:33:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:33:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:33:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 13:33:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:34:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:34:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 13:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:37:59 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-08-15 13:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:45:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 13:46:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 13:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:51:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 13:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:54:55 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-08-15 13:54:56 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-08-15 13:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:55:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 13:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:56:09 --> 404 Page Not Found: Nice%20ports%2C/Tri%6Eity.txt%2ebak
ERROR - 2021-08-15 13:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 13:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:03:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 14:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:13:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:14:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:14:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:15:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:15:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:15:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:16:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:16:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:17:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:17:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 14:18:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 14:19:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 14:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:22:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 14:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:28:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 14:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:29:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 14:30:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:30:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 14:30:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:30:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:30:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:30:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:30:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:30:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:30:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:30:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:31:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:33:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 14:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:38:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 14:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:42:41 --> 404 Page Not Found: English/index
ERROR - 2021-08-15 14:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:44:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 14:44:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 14:45:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:48:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 14:49:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:50:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:50:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:50:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:51:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 14:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:52:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 14:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:54:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:55:36 --> 404 Page Not Found: Old/index
ERROR - 2021-08-15 14:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:58:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 14:58:50 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-08-15 15:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:02:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 15:02:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 15:02:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 15:03:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 15:03:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 15:03:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 15:04:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 15:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:04:58 --> 404 Page Not Found: Wp/index
ERROR - 2021-08-15 15:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:08:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 15:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:09:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:09:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:12:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 15:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:13:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:13:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:14:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:15:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:15:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:15:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:16:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:16:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:16:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:17:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:17:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:18:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:18:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:18:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:19:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:19:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:19:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:19:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:19:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:19:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:20:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:20:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:25:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:25:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 15:26:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:27:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:29:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:29:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 15:29:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:31:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:32:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:32:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:32:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 15:32:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:33:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:33:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:34:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:35:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:37:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 15:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:39:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:42:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:42:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:45:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:46:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:50:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 15:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:52:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 15:52:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 15:52:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 15:52:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 15:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:55:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:56:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 15:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:58:30 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-15 15:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 15:59:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 16:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:07:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:08:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 16:08:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 16:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:16:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:16:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 16:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:17:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:17:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:18:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 16:18:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:19:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:19:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:20:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:28:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 16:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:37:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 16:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:42:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:42:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:42:46 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-15 16:42:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:42:59 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-15 16:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:43:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:43:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:43:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 16:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:48:55 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-15 16:48:55 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-15 16:48:55 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-15 16:48:56 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-15 16:48:57 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-15 16:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:50:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 16:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 16:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:08:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 17:08:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:08:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 17:08:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:08:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:08:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:09:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:10:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:11:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:11:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:14:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:15:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:15:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:15:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 17:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:22:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:22:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:26:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-15 17:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:38:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 17:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:40:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:41:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 17:42:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 17:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:44:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 17:44:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 17:47:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:54:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 17:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:57:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 17:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 17:59:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:00:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:04:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:05:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:11:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:11:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:12:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:15:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 18:15:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:17:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:19:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 18:19:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:19:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 18:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:21:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 18:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:25:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 18:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:28:25 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-15 18:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:32:15 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-08-15 18:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:34:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:35:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:35:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:36:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 18:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:38:23 --> 404 Page Not Found: Wx/ZFpass.asp
ERROR - 2021-08-15 18:38:23 --> 404 Page Not Found: Jsonpublic/selectAddtion.asp
ERROR - 2021-08-15 18:38:23 --> 404 Page Not Found: Index/index
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Case/index
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Template/Home
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Api/v1
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Cngzjs/index
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Index/index
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: 11txt/index
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Goip/cron.htm
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Lateronasp/index
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Views/bank
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Smb_scheduler/cdr.htm
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Web/api
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: User/Reg
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Trade/quote
ERROR - 2021-08-15 18:38:24 --> 404 Page Not Found: Loan/SubmitLogin
ERROR - 2021-08-15 18:38:25 --> 404 Page Not Found: Erm/help
ERROR - 2021-08-15 18:38:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 18:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:53:01 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-15 18:53:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 18:54:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 18:54:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:56:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 18:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:57:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 18:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 18:59:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:00:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:00:45 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-15 19:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:02:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:03:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:04:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:05:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 19:05:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:05:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 19:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:07:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-15 19:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:09:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:10:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:11:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:12:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 19:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:14:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:17:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 19:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:19:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:20:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:21:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:22:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:23:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:24:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:25:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:26:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 19:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:27:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:29:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 19:30:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-15 19:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:32:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-15 19:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:32:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:34:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 19:35:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 19:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:37:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 19:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:39:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:39:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 19:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:40:30 --> 404 Page Not Found: English/index
ERROR - 2021-08-15 19:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:43:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 19:45:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:47:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:55:16 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-15 19:55:16 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-15 19:55:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-15 19:55:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-15 19:55:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 19:56:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 19:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:58:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 19:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 19:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:02:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 20:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:05:06 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-15 20:05:06 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-15 20:05:07 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-15 20:05:08 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-15 20:05:09 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-15 20:05:09 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-15 20:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:19:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:20:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:20:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:21:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:21:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:21:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:21:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:21:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:21:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:21:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:21:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:22:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:22:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:22:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:23:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:23:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:25:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 20:26:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 20:27:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 20:27:52 --> 404 Page Not Found: admin/Help/zh_cn
ERROR - 2021-08-15 20:27:57 --> 404 Page Not Found: admin/Ecshopfilesmd5/index
ERROR - 2021-08-15 20:27:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:29:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 20:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:32:23 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-08-15 20:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:41:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 20:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:44:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 20:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:47:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 20:47:26 --> 404 Page Not Found: City/9
ERROR - 2021-08-15 20:47:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 20:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:52:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:54:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:55:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:56:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 20:56:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 20:57:17 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-15 20:57:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 20:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 20:59:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 20:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:00:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:05:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:09:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:10:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:11:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:13:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 21:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:22:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:23:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 21:23:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:26:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 21:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:33:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:33:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 21:34:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:34:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:34:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:38:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:39:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:42:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:42:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:46:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:51:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:57:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 21:57:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 21:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:08:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 22:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:09:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:09:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:10:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:10:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:10:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:10:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:11:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:12:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:12:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:13:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 22:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:13:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 22:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:14:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:15:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:20:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:26:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 22:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:35:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 22:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:37:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 22:37:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 22:40:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 22:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:41:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 22:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:46:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 22:46:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 22:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:47:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:47:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:48:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:48:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:48:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 22:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:48:51 --> 404 Page Not Found: admin/Help/zh_cn
ERROR - 2021-08-15 22:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:49:02 --> 404 Page Not Found: admin/Ecshopfilesmd5/index
ERROR - 2021-08-15 22:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:50:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:51:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:52:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:53:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 22:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:54:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:55:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:56:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 22:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 22:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 22:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:00:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-15 23:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:05:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:06:24 --> 404 Page Not Found: City/10
ERROR - 2021-08-15 23:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:09:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 23:09:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 23:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:12:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 23:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:14:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 23:14:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 23:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:16:45 --> 404 Page Not Found: Undefined/index
ERROR - 2021-08-15 23:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:19:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 23:20:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 23:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:23:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 23:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:25:49 --> 404 Page Not Found: City/1
ERROR - 2021-08-15 23:25:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 23:27:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 23:27:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 23:27:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 23:27:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-15 23:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:42:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 23:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:46:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-15 23:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:48:22 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-08-15 23:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:54:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-15 23:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-15 23:59:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
