<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-13 00:00:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 00:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:02:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 00:03:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 00:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:06:54 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-13 00:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:14:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 00:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:19:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 00:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:23:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 00:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:29:40 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-13 00:29:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 00:31:07 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-06-13 00:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:32:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 00:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:37:14 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-13 00:38:22 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-13 00:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:39:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 00:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:53:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 00:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:57:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 00:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 00:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:10:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:11:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 01:12:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:18:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 01:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:20:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 01:21:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:23:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:30:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:34:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:40:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:42:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 01:42:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:44:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:45:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:45:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 01:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:46:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 01:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:50:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:55:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:55:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 01:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 01:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:01:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 02:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:03:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 02:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:09:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 02:10:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 02:10:13 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 02:10:14 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-13 02:10:15 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-13 02:10:15 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-13 02:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:16:34 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-06-13 02:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:30:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:35:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 02:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:36:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 02:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:39:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 02:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:48:38 --> 404 Page Not Found: City/10
ERROR - 2021-06-13 02:49:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 02:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:55:24 --> 404 Page Not Found: City/index
ERROR - 2021-06-13 02:55:29 --> 404 Page Not Found: City/1
ERROR - 2021-06-13 02:55:32 --> 404 Page Not Found: City/10
ERROR - 2021-06-13 02:55:36 --> 404 Page Not Found: City/15
ERROR - 2021-06-13 02:55:42 --> 404 Page Not Found: City/16
ERROR - 2021-06-13 02:55:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 02:55:47 --> 404 Page Not Found: City/2
ERROR - 2021-06-13 02:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:57:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 02:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 02:59:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 02:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:00:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 03:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:04:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 03:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:10:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 03:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:13:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 03:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:20:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 03:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:21:08 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-06-13 03:21:09 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-06-13 03:21:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 03:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:22:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 03:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:23:15 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-13 03:23:41 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-13 03:23:43 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 03:23:43 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 03:23:43 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 03:23:43 --> 404 Page Not Found: Wwwxuanhaonet7z/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Www_xuanhao_net7z/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Wwwxuanhaonet7z/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Wwwxuanhaonet1rar/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Wwwxuanhaonet1zip/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Wwwxuanhaonet1targz/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Wwwxuanhaonet17z/index
ERROR - 2021-06-13 03:23:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhaonet7z/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhao7z/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhao1rar/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhao1zip/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhao1targz/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhao17z/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhaowwwzip/index
ERROR - 2021-06-13 03:23:45 --> 404 Page Not Found: Xuanhaowwwrar/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Xuanhaowwwtargz/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Xuanhaowww7z/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Xuanhaowebrar/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Xuanhaowebzip/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Xuanhaowebtargz/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Xuanhaoweb7z/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Xuanhaowwwrootzip/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Xuanhaowwwrootrar/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Xuanhaowwwroottargz/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Xuanhaowwwroot7z/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 03:23:46 --> 404 Page Not Found: Www7z/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Webtar7z/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Www1zip/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Www1rar/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Www1targz/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Www17z/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Web1rar/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Web1zip/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Web1targz/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Web17z/index
ERROR - 2021-06-13 03:23:47 --> 404 Page Not Found: Wwwroot1rar/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Wwwroot1zip/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Wwwroot1targz/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Wwwroot17z/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Wwwroot7z/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Websiterar/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Websitezip/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Websitetargz/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Website17z/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Website1rar/index
ERROR - 2021-06-13 03:23:48 --> 404 Page Not Found: Website1zip/index
ERROR - 2021-06-13 03:23:49 --> 404 Page Not Found: Website1targz/index
ERROR - 2021-06-13 03:23:49 --> 404 Page Not Found: Website17z/index
ERROR - 2021-06-13 03:23:49 --> 404 Page Not Found: Yuanmazip/index
ERROR - 2021-06-13 03:23:49 --> 404 Page Not Found: Yuanmarar/index
ERROR - 2021-06-13 03:23:49 --> 404 Page Not Found: Yuanmatargz/index
ERROR - 2021-06-13 03:23:49 --> 404 Page Not Found: Yuanma7z/index
ERROR - 2021-06-13 03:23:50 --> 404 Page Not Found: Beifenrar/index
ERROR - 2021-06-13 03:23:50 --> 404 Page Not Found: Beifenzip/index
ERROR - 2021-06-13 03:23:50 --> 404 Page Not Found: Beifentargz/index
ERROR - 2021-06-13 03:23:50 --> 404 Page Not Found: Beifen7z/index
ERROR - 2021-06-13 03:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:30:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 03:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:34:09 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-06-13 03:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:38:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 03:38:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 03:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:43:26 --> 404 Page Not Found: Base/exchange_article
ERROR - 2021-06-13 03:43:31 --> 404 Page Not Found: H5/index
ERROR - 2021-06-13 03:43:31 --> 404 Page Not Found: Web/api
ERROR - 2021-06-13 03:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:43:51 --> 404 Page Not Found: M/ticker
ERROR - 2021-06-13 03:43:56 --> 404 Page Not Found: S_api/basic
ERROR - 2021-06-13 03:43:57 --> 404 Page Not Found: Room/1002
ERROR - 2021-06-13 03:43:57 --> 404 Page Not Found: Account/login
ERROR - 2021-06-13 03:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:44:06 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-06-13 03:44:16 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-06-13 03:44:21 --> 404 Page Not Found: Xy/index
ERROR - 2021-06-13 03:44:21 --> 404 Page Not Found: Data/json
ERROR - 2021-06-13 03:44:23 --> 404 Page Not Found: Pc/Lang
ERROR - 2021-06-13 03:44:27 --> 404 Page Not Found: Home/GetQrCodeInfo
ERROR - 2021-06-13 03:44:27 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-13 03:44:34 --> 404 Page Not Found: FePublicInfo/index
ERROR - 2021-06-13 03:45:13 --> 404 Page Not Found: Front/User
ERROR - 2021-06-13 03:45:16 --> 404 Page Not Found: Mtjahtml/index
ERROR - 2021-06-13 03:45:18 --> 404 Page Not Found: Home/login
ERROR - 2021-06-13 03:45:21 --> 404 Page Not Found: Ws/index
ERROR - 2021-06-13 03:45:24 --> 404 Page Not Found: admin//index
ERROR - 2021-06-13 03:45:27 --> 404 Page Not Found: Ajax/index
ERROR - 2021-06-13 03:45:41 --> 404 Page Not Found: Homes/index
ERROR - 2021-06-13 03:45:58 --> 404 Page Not Found: Api/wallet
ERROR - 2021-06-13 03:45:58 --> 404 Page Not Found: H5/index
ERROR - 2021-06-13 03:45:58 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-13 03:45:58 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-13 03:45:59 --> 404 Page Not Found: Sign/index
ERROR - 2021-06-13 03:46:05 --> 404 Page Not Found: Index/index
ERROR - 2021-06-13 03:46:09 --> 404 Page Not Found: Index/register.html
ERROR - 2021-06-13 03:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:46:17 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-06-13 03:46:20 --> 404 Page Not Found: Market/getStockBaseInfo
ERROR - 2021-06-13 03:46:22 --> 404 Page Not Found: Index/api
ERROR - 2021-06-13 03:46:24 --> 404 Page Not Found: Api/mobile
ERROR - 2021-06-13 03:46:24 --> 404 Page Not Found: Api/index
ERROR - 2021-06-13 03:46:24 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-13 03:46:24 --> 404 Page Not Found: Loan/index
ERROR - 2021-06-13 03:46:24 --> 404 Page Not Found: Api/exclude
ERROR - 2021-06-13 03:46:24 --> 404 Page Not Found: Api/user
ERROR - 2021-06-13 03:46:24 --> 404 Page Not Found: Kkrps/im_group
ERROR - 2021-06-13 03:46:25 --> 404 Page Not Found: FriendGroup/list
ERROR - 2021-06-13 03:46:25 --> 404 Page Not Found: Im/in
ERROR - 2021-06-13 03:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:46:25 --> 404 Page Not Found: Api/common
ERROR - 2021-06-13 03:46:26 --> 404 Page Not Found: Api/user
ERROR - 2021-06-13 03:46:26 --> 404 Page Not Found: Portal/index
ERROR - 2021-06-13 03:46:26 --> 404 Page Not Found: Appxz/index.html
ERROR - 2021-06-13 03:46:26 --> 404 Page Not Found: Home/main
ERROR - 2021-06-13 03:46:29 --> 404 Page Not Found: Stock/search.html
ERROR - 2021-06-13 03:46:35 --> 404 Page Not Found: Api/config-init
ERROR - 2021-06-13 03:47:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 03:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:49:15 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-13 03:49:37 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-13 03:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:50:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 03:50:26 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-13 03:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 03:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:01:02 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-06-13 04:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:06:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 04:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:10:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 04:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:16:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 04:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:24:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 04:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:27:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 04:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:30:50 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-13 04:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:31:16 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-13 04:31:16 --> 404 Page Not Found: OLD/wp-admin
ERROR - 2021-06-13 04:31:22 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-13 04:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:31:42 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-13 04:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:32:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 04:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:32:52 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-13 04:32:56 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-13 04:33:17 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-13 04:33:38 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-13 04:33:59 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-13 04:34:21 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-13 04:34:42 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-13 04:34:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 04:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:35:07 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-13 04:35:28 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-13 04:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:36:45 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-13 04:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:37:43 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-13 04:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:39:10 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-13 04:39:32 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-13 04:39:53 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-13 04:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:43:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:43:28 --> 404 Page Not Found: Backup/wp-admin
ERROR - 2021-06-13 04:43:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:43:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:43:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:43:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:43:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:43:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:43:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:44:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:44:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:48:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:49:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:49:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:49:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:49:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:49:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:49:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:49:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:49:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:49:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:50:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:51:24 --> 404 Page Not Found: Old/wp-admin
ERROR - 2021-06-13 04:52:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:52:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:52:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:52:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:52:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:52:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:52:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:52:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:53:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:54:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:54:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:54:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:54:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:54:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 04:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 04:56:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:56:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:56:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:56:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 04:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:00:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 05:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:03:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 05:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:05:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 05:05:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 05:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:07:08 --> 404 Page Not Found: Wp/wp-admin
ERROR - 2021-06-13 05:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:17:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 05:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:20:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 05:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:31:17 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-13 05:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:37:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 05:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:49:51 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-13 05:52:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 05:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:55:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 05:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 05:59:45 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-13 06:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:02:04 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-13 06:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:11:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:15:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 06:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:16:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 06:16:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 06:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 06:18:17 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-13 06:18:18 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 06:18:18 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-13 06:18:18 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 06:18:18 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 06:18:18 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-13 06:18:18 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-13 06:18:19 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-13 06:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:18:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 06:20:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 06:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:27:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:27:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 06:27:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 06:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:35:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 06:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:39:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 06:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:45:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 06:45:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:46:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 06:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:49:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 06:51:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 06:51:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 06:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:54:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 06:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:05:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:05:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 07:06:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:06:25 --> 404 Page Not Found: Env/index
ERROR - 2021-06-13 07:06:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:06:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:06:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:07:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:07:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:07:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:10:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 07:10:37 --> 404 Page Not Found: Web/208
ERROR - 2021-06-13 07:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:11:34 --> 404 Page Not Found: Book/4232.html
ERROR - 2021-06-13 07:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:12:33 --> 404 Page Not Found: Allnewsasp/index
ERROR - 2021-06-13 07:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:14:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:17:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:17:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:18:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:19:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:20:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:20:06 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-06-13 07:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:24:01 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 07:24:01 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 07:24:02 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-13 07:24:03 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-13 07:24:04 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-13 07:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:27:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 07:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:28:03 --> 404 Page Not Found: City/index
ERROR - 2021-06-13 07:28:07 --> 404 Page Not Found: City/1
ERROR - 2021-06-13 07:28:09 --> 404 Page Not Found: City/10
ERROR - 2021-06-13 07:28:15 --> 404 Page Not Found: City/15
ERROR - 2021-06-13 07:28:17 --> 404 Page Not Found: City/16
ERROR - 2021-06-13 07:28:20 --> 404 Page Not Found: City/2
ERROR - 2021-06-13 07:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:34:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:34:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:35:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:37:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:39:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 07:39:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 07:39:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 07:39:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 07:39:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 07:39:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 07:40:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 07:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:43:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 07:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:48:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 07:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:51:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 07:52:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 07:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 07:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Www20210611rar/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Wwwxuanhaonet20210611rar/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Www_xuanhao_net20210611rar/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Wwwxuanhaonet20210611rar/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Xuanhaonet20210611rar/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Xuanhao_net20210611rar/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Xuanhaonet20210611rar/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Xuanhao20210611rar/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Www20210611targz/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Wwwxuanhaonet20210611targz/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Www_xuanhao_net20210611targz/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Wwwxuanhaonet20210611targz/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Xuanhaonet20210611targz/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Xuanhao_net20210611targz/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Xuanhaonet20210611targz/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Xuanhao20210611targz/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Www20210611zip/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Wwwxuanhaonet20210611zip/index
ERROR - 2021-06-13 08:03:28 --> 404 Page Not Found: Www_xuanhao_net20210611zip/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Wwwxuanhaonet20210611zip/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Xuanhaonet20210611zip/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Xuanhao_net20210611zip/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Xuanhaonet20210611zip/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Xuanhao20210611zip/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Www2021-06-11rar/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Wwwxuanhaonet2021-06-11rar/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Www_xuanhao_net2021-06-11rar/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Wwwxuanhaonet2021-06-11rar/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Xuanhaonet2021-06-11rar/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Xuanhao_net2021-06-11rar/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Xuanhaonet2021-06-11rar/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Xuanhao2021-06-11rar/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Www2021-06-11targz/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Wwwxuanhaonet2021-06-11targz/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Www_xuanhao_net2021-06-11targz/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Wwwxuanhaonet2021-06-11targz/index
ERROR - 2021-06-13 08:03:29 --> 404 Page Not Found: Xuanhaonet2021-06-11targz/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Xuanhao_net2021-06-11targz/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Xuanhaonet2021-06-11targz/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Xuanhao2021-06-11targz/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Www2021-06-11zip/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Wwwxuanhaonet2021-06-11zip/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Www_xuanhao_net2021-06-11zip/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Wwwxuanhaonet2021-06-11zip/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Xuanhaonet2021-06-11zip/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Xuanhao_net2021-06-11zip/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Xuanhaonet2021-06-11zip/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Xuanhao2021-06-11zip/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Www20210611rar/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Wwwxuanhaonet20210611rar/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Www_xuanhao_net20210611rar/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Wwwxuanhaonet20210611rar/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Xuanhaonet20210611rar/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Xuanhao_net20210611rar/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Xuanhaonet20210611rar/index
ERROR - 2021-06-13 08:03:30 --> 404 Page Not Found: Xuanhao20210611rar/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Www20210611targz/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Wwwxuanhaonet20210611targz/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Www_xuanhao_net20210611targz/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Wwwxuanhaonet20210611targz/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Xuanhaonet20210611targz/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Xuanhao_net20210611targz/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Xuanhaonet20210611targz/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Xuanhao20210611targz/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Www20210611zip/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Wwwxuanhaonet20210611zip/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Www_xuanhao_net20210611zip/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Wwwxuanhaonet20210611zip/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Xuanhaonet20210611zip/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Xuanhao_net20210611zip/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Xuanhaonet20210611zip/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: Xuanhao20210611zip/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: 20210611rar/index
ERROR - 2021-06-13 08:03:31 --> 404 Page Not Found: 20210611targz/index
ERROR - 2021-06-13 08:03:32 --> 404 Page Not Found: 20210611zip/index
ERROR - 2021-06-13 08:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:05:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 08:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:06:26 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-13 08:06:44 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-13 08:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:07:23 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-13 08:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:14:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 08:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:23:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 08:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:23:53 --> 404 Page Not Found: City/index
ERROR - 2021-06-13 08:23:55 --> 404 Page Not Found: City/1
ERROR - 2021-06-13 08:24:28 --> 404 Page Not Found: City/10
ERROR - 2021-06-13 08:24:31 --> 404 Page Not Found: City/15
ERROR - 2021-06-13 08:24:35 --> 404 Page Not Found: City/16
ERROR - 2021-06-13 08:24:39 --> 404 Page Not Found: City/2
ERROR - 2021-06-13 08:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:29:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 08:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:34:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 08:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:36:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 08:36:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 08:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:41:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 08:41:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 08:42:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 08:42:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 08:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:44:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 08:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:58:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 08:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 08:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:03:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:05:46 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-13 09:05:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 09:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:06:12 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-13 09:06:15 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-13 09:06:26 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-13 09:06:37 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-13 09:06:42 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-13 09:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:07:20 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-13 09:07:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 09:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:07:45 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-13 09:07:49 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-13 09:08:07 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-13 09:08:23 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-13 09:08:39 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-13 09:08:54 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-13 09:09:13 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-13 09:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:09:29 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-13 09:09:53 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-13 09:10:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 09:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:11:13 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-13 09:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:12:01 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-13 09:12:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 09:12:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 09:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:13:17 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-13 09:13:36 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-13 09:13:52 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-13 09:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:17:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:17:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 09:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:18:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:24:28 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-13 09:24:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 09:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:30:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 09:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:33:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 09:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:34:30 --> 404 Page Not Found: Semaltcom/index
ERROR - 2021-06-13 09:34:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 09:35:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 09:35:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 09:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:36:33 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-13 09:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:36:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 09:36:53 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-13 09:36:57 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-13 09:37:12 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-13 09:38:14 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-13 09:38:16 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-13 09:38:33 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-13 09:38:48 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-13 09:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:39:04 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-13 09:39:21 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-13 09:39:40 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-13 09:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:40:11 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-13 09:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:40:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 09:40:37 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-13 09:41:41 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-13 09:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:42:36 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-13 09:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:44:09 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-13 09:44:25 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-13 09:44:43 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-13 09:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:50:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 09:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:54:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 09:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:55:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 09:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 09:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:56:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 09:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 09:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:00:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:01:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:11:24 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-13 10:11:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:11:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:11:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:12:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:16:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 10:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:21:51 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 10:21:51 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 10:21:51 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-13 10:21:51 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 10:21:51 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 10:21:51 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-13 10:21:51 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 10:21:51 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-13 10:21:51 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 10:21:51 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 10:21:51 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-13 10:21:52 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-13 10:21:53 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-13 10:21:53 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-13 10:21:53 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 10:21:53 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 10:21:53 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 10:21:53 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-13 10:21:53 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-13 10:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:24:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:25:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:25:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:25:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:25:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:28:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 10:28:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 10:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:29:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:29:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:29:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:29:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:29:43 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-06-13 10:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:31:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:32:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:32:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:34:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:35:00 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-13 10:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:35:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:36:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:36:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:37:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:37:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:44:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 10:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:47:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:48:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:51:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:52:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:52:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:52:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:52:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:52:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:52:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:52:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:52:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:52:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:55:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 10:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 10:57:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 10:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:00:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 11:00:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 11:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:08:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 11:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:14:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 11:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:15:33 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-13 11:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:20:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 11:20:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 11:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:22:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 11:22:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 11:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:23:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 11:23:19 --> 404 Page Not Found: English/index
ERROR - 2021-06-13 11:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:27:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 11:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:30:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 11:30:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 11:30:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 11:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:33:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 11:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:36:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:37:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 11:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:41:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 11:41:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 11:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:43:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 11:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:54:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 11:55:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 11:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 11:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:12:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:12:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:13:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 12:15:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 12:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:20:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 12:21:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 12:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:22:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 12:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:24:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 12:26:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:26:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:26:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:26:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 12:26:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 12:26:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 12:26:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 12:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:26:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:29:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:29:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:29:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:29:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 12:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:32:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:35:41 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-13 12:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:36:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 12:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:39:24 --> 404 Page Not Found: Images/Nxrs4tAtO
ERROR - 2021-06-13 12:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:44:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:45:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 12:45:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 12:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:53:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 12:53:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 12:53:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 12:53:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 12:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 12:59:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 13:00:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 13:01:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:01:49 --> 404 Page Not Found: Vod-detail-id-22504html/index
ERROR - 2021-06-13 13:01:56 --> 404 Page Not Found: Article/detail
ERROR - 2021-06-13 13:01:56 --> 404 Page Not Found: House/hs_open.asp
ERROR - 2021-06-13 13:02:05 --> 404 Page Not Found: Qynews/detail
ERROR - 2021-06-13 13:02:05 --> 404 Page Not Found: W/32
ERROR - 2021-06-13 13:02:05 --> 404 Page Not Found: O/devopsflowid
ERROR - 2021-06-13 13:02:06 --> 404 Page Not Found: Sys/attachment
ERROR - 2021-06-13 13:02:06 --> 404 Page Not Found: Xxoo888/r.html
ERROR - 2021-06-13 13:02:06 --> 404 Page Not Found: Info/1051
ERROR - 2021-06-13 13:02:06 --> 404 Page Not Found: Zhcn/Productdetail.aspx
ERROR - 2021-06-13 13:02:07 --> 404 Page Not Found: Page/12
ERROR - 2021-06-13 13:02:07 --> 404 Page Not Found: Login/index
ERROR - 2021-06-13 13:02:07 --> 404 Page Not Found: Enstyle/search_%E7%83%AD%E6%B0%B4%E5%99%A8_1.html
ERROR - 2021-06-13 13:02:07 --> 404 Page Not Found: 35cun/index
ERROR - 2021-06-13 13:02:09 --> 404 Page Not Found: Zportal/loginForWeb
ERROR - 2021-06-13 13:02:22 --> 404 Page Not Found: Sosososo20201022/index
ERROR - 2021-06-13 13:02:22 --> 404 Page Not Found: Front/czda
ERROR - 2021-06-13 13:02:22 --> 404 Page Not Found: HTML/2015
ERROR - 2021-06-13 13:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:02:22 --> 404 Page Not Found: Publicity_csqzf/cxjshjbh
ERROR - 2021-06-13 13:02:22 --> 404 Page Not Found: Erp/bookfile
ERROR - 2021-06-13 13:02:26 --> 404 Page Not Found: Js/a
ERROR - 2021-06-13 13:02:32 --> 404 Page Not Found: Auth/realms
ERROR - 2021-06-13 13:02:49 --> 404 Page Not Found: KCMS/detail
ERROR - 2021-06-13 13:02:50 --> 404 Page Not Found: A/web
ERROR - 2021-06-13 13:02:50 --> 404 Page Not Found: Report/Report-ResultAction.do
ERROR - 2021-06-13 13:02:54 --> 404 Page Not Found: Vod/play
ERROR - 2021-06-13 13:02:54 --> 404 Page Not Found: admin/Orders/qdlist
ERROR - 2021-06-13 13:02:54 --> 404 Page Not Found: Mvc/organChart
ERROR - 2021-06-13 13:02:54 --> 404 Page Not Found: Ch/product.asp
ERROR - 2021-06-13 13:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:02:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:03:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:03:05 --> 404 Page Not Found: SscJzcx/index.html
ERROR - 2021-06-13 13:03:06 --> 404 Page Not Found: Info/ShowBidInfo8174.html
ERROR - 2021-06-13 13:03:07 --> 404 Page Not Found: Lipin/pinduoduo
ERROR - 2021-06-13 13:03:07 --> 404 Page Not Found: NewsDetailaspx/index
ERROR - 2021-06-13 13:03:07 --> 404 Page Not Found: HTML/3G
ERROR - 2021-06-13 13:03:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:03:12 --> 404 Page Not Found: 351/365
ERROR - 2021-06-13 13:03:15 --> 404 Page Not Found: News/34262.html
ERROR - 2021-06-13 13:03:19 --> 404 Page Not Found: Hraspx/index
ERROR - 2021-06-13 13:03:22 --> 404 Page Not Found: Zhongweidong/author
ERROR - 2021-06-13 13:03:24 --> 404 Page Not Found: BuyActiondo/index
ERROR - 2021-06-13 13:03:24 --> 404 Page Not Found: Cpxx/info_3412.aspx
ERROR - 2021-06-13 13:03:24 --> 404 Page Not Found: Live/livesysmanage.htm
ERROR - 2021-06-13 13:03:24 --> 404 Page Not Found: Kng/course
ERROR - 2021-06-13 13:03:24 --> 404 Page Not Found: Opac/showDetails.do
ERROR - 2021-06-13 13:03:24 --> 404 Page Not Found: Baokaozhinan/48134.html
ERROR - 2021-06-13 13:03:27 --> 404 Page Not Found: About/honor
ERROR - 2021-06-13 13:03:27 --> 404 Page Not Found: User/userDeatils
ERROR - 2021-06-13 13:03:30 --> 404 Page Not Found: Vod/detail
ERROR - 2021-06-13 13:03:33 --> 404 Page Not Found: Order/QTOrderDetail.aspx
ERROR - 2021-06-13 13:03:36 --> 404 Page Not Found: Vodata/412
ERROR - 2021-06-13 13:03:36 --> 404 Page Not Found: Live/index
ERROR - 2021-06-13 13:03:36 --> 404 Page Not Found: Goods-show-500html/index
ERROR - 2021-06-13 13:03:38 --> 404 Page Not Found: News1/news_show-631.html
ERROR - 2021-06-13 13:03:38 --> 404 Page Not Found: Home/BG_Inspect
ERROR - 2021-06-13 13:03:38 --> 404 Page Not Found: YJSWB/webenroll
ERROR - 2021-06-13 13:03:38 --> 404 Page Not Found: News-144354html/index
ERROR - 2021-06-13 13:03:38 --> 404 Page Not Found: Yiyuan/37776
ERROR - 2021-06-13 13:03:38 --> 404 Page Not Found: Indexaction/index
ERROR - 2021-06-13 13:03:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:03:42 --> 404 Page Not Found: Videos_list/cid25midisp
ERROR - 2021-06-13 13:03:52 --> 404 Page Not Found: S/102116050_16026448_2d082de44d
ERROR - 2021-06-13 13:03:55 --> 404 Page Not Found: Product/search
ERROR - 2021-06-13 13:03:57 --> 404 Page Not Found: Vod/play
ERROR - 2021-06-13 13:03:58 --> 404 Page Not Found: User/3178910
ERROR - 2021-06-13 13:03:58 --> 404 Page Not Found: Menu/7133
ERROR - 2021-06-13 13:04:12 --> 404 Page Not Found: Dsjj/new
ERROR - 2021-06-13 13:04:12 --> 404 Page Not Found: Km/review
ERROR - 2021-06-13 13:04:17 --> 404 Page Not Found: Member/Login
ERROR - 2021-06-13 13:04:24 --> 404 Page Not Found: Web/article
ERROR - 2021-06-13 13:04:27 --> 404 Page Not Found: Kng/course
ERROR - 2021-06-13 13:04:28 --> 404 Page Not Found: Kng/course
ERROR - 2021-06-13 13:04:28 --> 404 Page Not Found: Usermsg/index
ERROR - 2021-06-13 13:04:28 --> 404 Page Not Found: Ios2021-06-10/grn-065.html
ERROR - 2021-06-13 13:04:50 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-13 13:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:08:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 13:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:09:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 13:10:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:10:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:11:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 13:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:13:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 13:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:15:29 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-06-13 13:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:20:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:23:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:23:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:23:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:24:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:26:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 13:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:35:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 13:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:36:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:38:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 13:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:38:32 --> 404 Page Not Found: Aspx/zhw
ERROR - 2021-06-13 13:38:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 13:39:23 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-13 13:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:43:20 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-13 13:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:45:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 13:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:46:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 13:46:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 13:46:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 13:46:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 13:46:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 13:51:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 13:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:54:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 13:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:54:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 13:56:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 13:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 13:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:04:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 14:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:08:15 --> 404 Page Not Found: Member/Login
ERROR - 2021-06-13 14:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:10:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 14:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:14:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 14:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:15:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 14:16:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 14:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:21:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 14:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:22:37 --> 404 Page Not Found: C/index
ERROR - 2021-06-13 14:22:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 14:24:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:31:28 --> 404 Page Not Found: Env/index
ERROR - 2021-06-13 14:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:36:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 14:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 14:37:20 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 14:37:21 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-13 14:37:21 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 14:37:21 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-13 14:37:21 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 14:37:21 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 14:37:21 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-13 14:37:21 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 14:37:21 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 14:37:21 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-13 14:37:21 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 14:37:22 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-13 14:37:22 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-13 14:37:22 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-13 14:37:22 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-13 14:37:22 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 14:37:22 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 14:37:22 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 14:37:22 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-13 14:37:22 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-13 14:37:22 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-13 14:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:43:31 --> 404 Page Not Found: City/index
ERROR - 2021-06-13 14:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:43:34 --> 404 Page Not Found: City/1
ERROR - 2021-06-13 14:43:37 --> 404 Page Not Found: City/10
ERROR - 2021-06-13 14:43:40 --> 404 Page Not Found: City/15
ERROR - 2021-06-13 14:43:43 --> 404 Page Not Found: City/16
ERROR - 2021-06-13 14:43:47 --> 404 Page Not Found: City/2
ERROR - 2021-06-13 14:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:48:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 14:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:51:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:51:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 14:51:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:52:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:53:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:53:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:53:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:54:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:55:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:55:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:56:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 14:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:57:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 14:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 14:59:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:00:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:03:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:03:39 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-13 15:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:07:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 15:08:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 15:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:22:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 15:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:23:46 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-13 15:24:05 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-13 15:24:53 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-13 15:27:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:30:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:38:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:40:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:40:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:40:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:40:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:41:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:41:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:41:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:41:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:42:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:42:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:43:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:43:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:43:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:43:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:44:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:44:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:44:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:46:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:47:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:47:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:47:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 15:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:51:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:51:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:55:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:55:47 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-13 15:55:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:56:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:56:51 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-13 15:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 15:58:34 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-13 15:58:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:58:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:58:58 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-13 15:59:01 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-13 15:59:20 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-13 15:59:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 15:59:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:00:16 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-13 16:00:19 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-13 16:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:00:37 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-13 16:00:55 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-13 16:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:01:12 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-13 16:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:01:15 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-06-13 16:01:16 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-06-13 16:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:01:37 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-13 16:01:55 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-13 16:02:17 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-13 16:02:38 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-13 16:03:38 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-13 16:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:04:26 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-13 16:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:05:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 16:05:37 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-13 16:05:53 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-13 16:06:08 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-13 16:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:12:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:12:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:12:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:13:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:14:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:18:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:19:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:22:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:24:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:24:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:25:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 16:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:31:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:31:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:32:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:36:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:37:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:37:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:37:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:37:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:44:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:44:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:44:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:44:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:47:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:47:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:47:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:48:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:48:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:48:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:48:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:48:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:48:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:49:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:49:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:49:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:50:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:50:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:50:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:50:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:50:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:50:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:50:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:50:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:50:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 16:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:52:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:52:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:52:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:53:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:53:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:54:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:55:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 16:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:57:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:57:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 16:59:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:59:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 16:59:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:01:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 17:01:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 17:04:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:05:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:05:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:05:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:05:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:07:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:07:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:08:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 17:08:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 17:08:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 17:08:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 17:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:12:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 17:12:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 17:14:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 17:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:19:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:19:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:19:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:22:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:22:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:22:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:22:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:24:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:25:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:27:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:27:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:27:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:27:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 17:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:33:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 17:33:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 17:33:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 17:34:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 17:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:38:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 17:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:38:49 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-06-13 17:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:38:52 --> 404 Page Not Found: Feed/index
ERROR - 2021-06-13 17:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:39:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 17:41:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 17:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 17:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:43:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 17:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:44:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 17:44:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 17:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:47:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 17:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:56:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 17:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:58:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 17:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 17:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:02:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 18:02:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 18:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:06:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 18:07:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:08:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:09:47 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-13 18:09:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 18:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:09:54 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-13 18:09:55 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-13 18:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:10:02 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-13 18:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:11:01 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-13 18:11:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 18:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:12:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:12:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:14:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:21:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 18:21:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:23:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 18:25:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 18:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:27:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:33:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 18:33:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 18:33:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 18:33:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 18:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:34:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 18:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:36:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 18:36:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 18:36:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 18:36:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 18:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:40:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:41:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:41:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:41:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:41:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:42:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:42:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:42:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 18:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:42:43 --> 404 Page Not Found: English/index
ERROR - 2021-06-13 18:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:44:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 18:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:46:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:46:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:47:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:47:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:47:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:47:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:47:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:48:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:48:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:48:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 18:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:49:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:50:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:50:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:51:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:52:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:53:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:54:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:54:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:55:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:56:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 18:59:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 18:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:02:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 19:03:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 19:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:09:44 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 19:09:44 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 19:09:44 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-13 19:09:44 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 19:09:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 19:09:44 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-13 19:09:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 19:09:44 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-13 19:09:45 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 19:09:46 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-13 19:09:46 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-13 19:09:46 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-13 19:09:46 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-13 19:09:46 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 19:09:46 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 19:09:46 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 19:09:46 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-13 19:09:46 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-13 19:09:47 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-13 19:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:14:13 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-13 19:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:17:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 19:18:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 19:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:30:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 19:31:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 19:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:33:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 19:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:50:35 --> 404 Page Not Found: Webdav/index
ERROR - 2021-06-13 19:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:52:34 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-13 19:52:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 19:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:53:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 19:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 19:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:08:33 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-13 20:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:12:32 --> 404 Page Not Found: Shell/index
ERROR - 2021-06-13 20:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:18:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 20:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:20:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:23:54 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-13 20:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:27:49 --> 404 Page Not Found: A/gongchenganli
ERROR - 2021-06-13 20:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:29:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 20:29:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 20:30:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 20:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:33:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 20:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:34:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 20:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:35:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 20:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:44:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 20:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:51:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 20:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:55:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 20:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:58:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 20:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 20:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:01:22 --> 404 Page Not Found: City/16
ERROR - 2021-06-13 21:02:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 21:02:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 21:02:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 21:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 21:03:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 21:03:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 21:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:07:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 21:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:08:23 --> 404 Page Not Found: 1/all
ERROR - 2021-06-13 21:09:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 21:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:13:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 21:13:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 21:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:15:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 21:18:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 21:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:28:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 21:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:37:25 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-13 21:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:45:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:46:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 21:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:48:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 21:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:49:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-13 21:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:52:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 21:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:22 --> 404 Page Not Found: 1001%E5%8C%97%E4%BA%AC%E9%9D%93%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%8C%91%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E9%80%89%E5%8F%B7%E7%BD%91%EF%BC%8C%E5%8C%97%E4%BA%AC%E6%89%BE%E5%8F%B7%E7%BD%91%EF%BC%8C%E6%89%8B%E6%9C%BA%E5%8D%A1%EF%BC%8C%E6%89%8B%E6%9C%BA%E9%9D%93%E5%8F%B7%EF%BC%8C%E9%80%89%E5%8F%B7%E7%A0%81/index
ERROR - 2021-06-13 21:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 21:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:10:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:11:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:18:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 22:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:23:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 22:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:23:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 22:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:29:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:31:27 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 22:31:28 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-13 22:31:29 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-13 22:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:42:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:46:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:46:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:47:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:48:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:49:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 22:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:49:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:50:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:50:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:52:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 22:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:53:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:54:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:55:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:55:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 22:55:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 22:55:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 22:55:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 22:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:57:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:58:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:58:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 22:59:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 22:59:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 22:59:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 22:59:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 23:00:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 23:00:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 23:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:00:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 23:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:01:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 23:01:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 23:01:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 23:01:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 23:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:02:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 23:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:04:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 23:05:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 23:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:10:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 23:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:14:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 23:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:15:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 23:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:22:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 23:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:22:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 23:22:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 23:22:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 23:22:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-13 23:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:23:51 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-06-13 23:26:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 23:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:28:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 23:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:38:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 23:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:41:35 --> 404 Page Not Found: City/1
ERROR - 2021-06-13 23:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:43:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 23:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:51:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-13 23:51:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-13 23:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:53:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 23:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:54:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-13 23:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-13 23:59:24 --> 404 Page Not Found: Robotstxt/index
