<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-27 00:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 00:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 00:23:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 00:26:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 00:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 00:42:45 --> 404 Page Not Found: Text4041640536965/index
ERROR - 2021-12-27 00:42:45 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-12-27 00:42:45 --> 404 Page Not Found: Sdk/index
ERROR - 2021-12-27 00:42:46 --> 404 Page Not Found: Evox/about
ERROR - 2021-12-27 00:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 00:45:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 00:51:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 00:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 01:11:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 01:18:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 01:31:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 01:33:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 01:33:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 01:34:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 01:34:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 01:36:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 01:38:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:42:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 01:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 01:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 01:56:40 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-27 01:56:40 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-27 01:56:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 01:56:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:56:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:56:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:56:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 01:56:41 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-27 01:56:41 --> 404 Page Not Found: Member/space
ERROR - 2021-12-27 01:56:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:56:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:56:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 01:56:43 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 01:56:43 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 01:56:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:56:44 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-27 01:56:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:56:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:56:44 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 01:56:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 01:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 02:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 02:00:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 02:01:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:02:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 02:06:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:16:52 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-27 02:16:52 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-27 02:16:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 02:16:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:16:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:16:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:16:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 02:16:55 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-27 02:16:55 --> 404 Page Not Found: Member/space
ERROR - 2021-12-27 02:16:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:16:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:16:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 02:16:55 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 02:16:58 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 02:17:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:17:02 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-27 02:17:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:17:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:17:02 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 02:17:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:25:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 02:38:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 02:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 02:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 03:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 03:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 03:04:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 03:17:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 03:18:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 03:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 03:20:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 03:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 03:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 03:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 03:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 03:43:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 03:45:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 03:45:49 --> 404 Page Not Found: City/15
ERROR - 2021-12-27 03:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 03:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 03:53:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 03:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 04:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 04:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Member/space
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 04:13:03 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 04:13:04 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 04:13:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 04:13:04 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-27 04:13:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 04:13:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 04:13:04 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 04:13:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 04:20:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 04:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 04:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 04:52:28 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-12-27 04:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 04:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 05:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 06:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 06:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 06:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 06:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 06:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 06:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 06:28:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 06:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 06:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 06:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 06:36:10 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-12-27 06:49:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 06:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 06:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 07:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 07:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 07:17:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 07:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 07:25:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 07:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 07:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 07:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 07:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 07:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 07:57:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 08:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 08:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 08:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 08:38:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 08:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 08:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 08:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 09:00:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 09:02:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 09:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 09:04:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 09:04:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 09:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 09:07:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:07:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 09:11:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 09:12:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:16:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:16:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 09:21:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 09:23:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 09:25:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 09:25:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:25:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:29:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:29:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:29:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:32:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 09:32:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 09:41:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 09:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:47:41 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-12-27 09:47:50 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-12-27 09:49:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 09:51:41 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-12-27 09:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 10:05:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:05:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:05:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 10:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 10:17:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:17:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:17:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:20:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 10:20:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 10:21:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:21:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:21:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 10:25:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:27:19 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-12-27 10:27:20 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-12-27 10:27:21 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-12-27 10:27:50 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-12-27 10:27:51 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-12-27 10:31:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:31:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:31:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:31:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:35:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:35:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:35:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:35:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:39:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:39:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 10:42:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:43:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:43:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:48:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 10:52:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:52:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 10:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 10:57:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 10:57:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:02:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 11:05:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 11:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 11:06:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:06:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 11:08:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 11:15:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:15:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:15:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:16:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:17:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:17:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:17:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:19:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:20:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:20:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:22:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:23:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 11:26:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:26:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:27:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:32:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:32:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 11:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 11:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 11:41:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:43:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:45:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:47:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:48:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:50:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:50:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:50:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:51:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:51:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:51:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:51:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:52:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 11:54:41 --> 404 Page Not Found: Core/favicon.ico
ERROR - 2021-12-27 11:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 11:59:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 12:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 12:06:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:07:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 12:08:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 12:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 12:18:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 12:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 12:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 12:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:24:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 12:35:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 12:46:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 12:46:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 12:48:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:49:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:49:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:50:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:51:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:51:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:53:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:53:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:54:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:55:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:55:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:55:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:57:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:57:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:58:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:58:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:59:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:59:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 12:59:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:01:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:01:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:01:41 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-27 13:01:41 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-27 13:01:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 13:01:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:01:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:01:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:01:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 13:01:44 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-27 13:01:46 --> 404 Page Not Found: Member/space
ERROR - 2021-12-27 13:01:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:01:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:01:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 13:01:46 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 13:01:47 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 13:01:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:01:47 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-27 13:01:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:01:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:01:49 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 13:01:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:02:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:02:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:03:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:05:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 13:05:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 13:07:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:08:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:10:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:10:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:11:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 13:11:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:12:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:14:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 13:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:16:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:21:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 13:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:27:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:30:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 13:43:54 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-27 13:43:55 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-27 13:43:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 13:43:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:43:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:43:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:43:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 13:43:55 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-27 13:43:56 --> 404 Page Not Found: Member/space
ERROR - 2021-12-27 13:43:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:43:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:43:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 13:43:56 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 13:43:56 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 13:43:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:43:57 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-27 13:43:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:43:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:43:57 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 13:43:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 13:48:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 13:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:05:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 14:05:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 14:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:06:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 14:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:17:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:21:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:21:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:25:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:32:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 14:33:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:34:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:34:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:34:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:34:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:35:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:35:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:35:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:35:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:35:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:36:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:36:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:36:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:36:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:37:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:38:03 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-27 14:38:03 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-27 14:38:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 14:38:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 14:38:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 14:38:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 14:38:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 14:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:38:04 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-27 14:38:04 --> 404 Page Not Found: Member/space
ERROR - 2021-12-27 14:38:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 14:38:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 14:38:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 14:38:04 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 14:38:05 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 14:38:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 14:38:07 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-27 14:38:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 14:38:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 14:38:07 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-27 14:38:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 14:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:39:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:40:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:53:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 14:54:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:55:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:57:01 --> 404 Page Not Found: City/17
ERROR - 2021-12-27 14:57:08 --> 404 Page Not Found: City/17
ERROR - 2021-12-27 14:57:08 --> 404 Page Not Found: City/17
ERROR - 2021-12-27 14:57:08 --> 404 Page Not Found: City/17
ERROR - 2021-12-27 14:57:08 --> 404 Page Not Found: City/17
ERROR - 2021-12-27 14:57:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:57:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:57:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:57:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:57:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:57:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:57:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:57:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:57:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 14:58:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 15:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 15:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:04:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 15:04:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 15:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:15:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 15:15:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 15:15:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 15:15:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 15:17:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 15:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:24:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 15:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:33:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 15:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:45:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 15:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:51:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 15:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 15:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:53:19 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-12-27 15:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:57:26 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-27 15:57:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 15:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 15:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 16:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 16:05:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 16:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:21:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:21:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:21:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:21:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:23:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:23:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:27:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:30:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 16:31:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 16:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 16:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 16:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 16:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 16:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 16:52:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 16:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 16:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 16:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:00:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:20:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 17:20:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 17:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:23:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 17:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:35:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 17:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:43:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 17:44:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 17:51:03 --> 404 Page Not Found: Login/index
ERROR - 2021-12-27 17:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 17:56:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 18:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 18:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 18:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 18:06:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:06:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:09:49 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-12-27 18:14:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 18:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 18:14:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 18:14:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 18:16:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 18:21:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 18:25:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:26:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:27:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:27:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:32:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:34:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:38:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 18:47:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 18:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 18:51:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:52:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:52:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:53:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 18:58:01 --> 404 Page Not Found: %E5%B0%BE%E6%95%B0%E6%98%AF7687/index
ERROR - 2021-12-27 18:58:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 19:00:21 --> 404 Page Not Found: %E5%B0%BE%E6%95%B0%E6%98%AF7687/index
ERROR - 2021-12-27 19:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 19:01:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:12:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:13:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:13:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:14:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:14:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:14:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:15:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 19:16:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:17:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:18:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:19:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:21:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 19:25:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 19:25:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 19:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 19:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 19:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 19:37:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 19:52:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 19:57:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:57:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 19:58:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 20:11:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:16:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 20:20:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:24:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 20:29:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 20:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 20:43:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 20:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 20:48:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 20:49:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:50:11 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-27 20:50:26 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-27 20:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 20:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 20:52:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 20:55:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:57:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 20:59:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:00:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:00:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:03:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:05:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:06:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:07:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:07:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:07:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:07:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:08:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:11:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:11:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:11:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:17:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:18:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:21:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:27:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 21:30:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:33:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:34:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 21:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:38:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:39:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:40:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:41:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:45:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:45:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:45:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:48:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:49:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 21:53:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:54:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:55:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 21:55:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 21:56:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 22:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 22:13:56 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-12-27 22:14:40 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 22:19:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 22:28:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-27 22:41:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 22:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 22:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 22:52:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-27 22:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 22:56:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 22:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 23:05:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-27 23:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 23:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 23:30:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-27 23:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 23:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 23:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 23:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 23:54:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 23:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-27 23:56:47 --> 404 Page Not Found: Data/admin
