<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-24 00:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 00:26:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 00:31:25 --> 404 Page Not Found: English/index
ERROR - 2022-01-24 00:57:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 01:11:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 01:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 01:28:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 01:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 01:40:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 01:46:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 01:46:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 01:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 01:50:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 01:50:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 01:50:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 01:50:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 01:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 02:01:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 02:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 02:16:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 02:16:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 02:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 02:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 02:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 02:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 02:46:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 02:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 02:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 02:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 03:00:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 03:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 03:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 03:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 03:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 03:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 03:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 03:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 03:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 03:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 03:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 04:09:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 04:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 04:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 04:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 04:37:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 04:38:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 04:39:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 04:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 04:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 05:04:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 05:04:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 05:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 05:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 05:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 05:51:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 05:51:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 05:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 06:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 06:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/config.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Config/AspCms_Config.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Include/Functionl.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Inc/config.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Conconasp/index
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Config/AspCms_Config.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Include/base64.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Include/Functionl.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Conconasp/index
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Data/data.asp
ERROR - 2022-01-24 06:18:03 --> 404 Page Not Found: Include/base64.asp
ERROR - 2022-01-24 06:18:04 --> 404 Page Not Found: Data/data.asp
ERROR - 2022-01-24 06:18:04 --> 404 Page Not Found: Inc/config.asp
ERROR - 2022-01-24 06:18:04 --> 404 Page Not Found: Inc/config.asp
ERROR - 2022-01-24 06:18:04 --> 404 Page Not Found: Sitemap/templates
ERROR - 2022-01-24 06:18:04 --> 404 Page Not Found: Sitemap/templates
ERROR - 2022-01-24 06:18:04 --> 404 Page Not Found: Config/AspCms_Config.asp
ERROR - 2022-01-24 06:18:04 --> 404 Page Not Found: Templates/red.asp
ERROR - 2022-01-24 06:18:04 --> 404 Page Not Found: Config/AspCms_Config.asp
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Templates/red.asp
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Data/s.asp
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Data/s.asp
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Base/admin
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Kdatebase/index_.asp
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Base/admin
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Somnus/Somnus.asp
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Images/cache.asp
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Kdatebase/index_.asp
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Somnus/Somnus.asp
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Images/cache.asp
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Admin_gfive/js
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Admin_a/images
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Admin_gfive/js
ERROR - 2022-01-24 06:18:05 --> 404 Page Not Found: Zhanpushiasp/index
ERROR - 2022-01-24 06:18:06 --> 404 Page Not Found: Admin_a/images
ERROR - 2022-01-24 06:18:06 --> 404 Page Not Found: Configasp/index
ERROR - 2022-01-24 06:18:06 --> 404 Page Not Found: Zhanpushiasp/index
ERROR - 2022-01-24 06:18:06 --> 404 Page Not Found: Configasp/index
ERROR - 2022-01-24 06:18:07 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:07 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:07 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:07 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:08 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-01-24 06:18:08 --> 404 Page Not Found: Inc/config.asp
ERROR - 2022-01-24 06:18:08 --> 404 Page Not Found: Config/AspCms_Config.asp
ERROR - 2022-01-24 06:18:08 --> 404 Page Not Found: Include/Functionl.asp
ERROR - 2022-01-24 06:18:08 --> 404 Page Not Found: Conconasp/index
ERROR - 2022-01-24 06:18:08 --> 404 Page Not Found: Include/base64.asp
ERROR - 2022-01-24 06:18:08 --> 404 Page Not Found: Data/data.asp
ERROR - 2022-01-24 06:18:08 --> 404 Page Not Found: Inc/config.asp
ERROR - 2022-01-24 06:18:09 --> 404 Page Not Found: Sitemap/templates
ERROR - 2022-01-24 06:18:09 --> 404 Page Not Found: Config/AspCms_Config.asp
ERROR - 2022-01-24 06:18:09 --> 404 Page Not Found: Templates/red.asp
ERROR - 2022-01-24 06:18:09 --> 404 Page Not Found: Data/s.asp
ERROR - 2022-01-24 06:18:10 --> 404 Page Not Found: Base/admin
ERROR - 2022-01-24 06:18:10 --> 404 Page Not Found: Kdatebase/index_.asp
ERROR - 2022-01-24 06:18:10 --> 404 Page Not Found: Somnus/Somnus.asp
ERROR - 2022-01-24 06:18:10 --> 404 Page Not Found: Images/cache.asp
ERROR - 2022-01-24 06:18:10 --> 404 Page Not Found: Admin_gfive/js
ERROR - 2022-01-24 06:18:10 --> 404 Page Not Found: Admin_a/images
ERROR - 2022-01-24 06:18:10 --> 404 Page Not Found: Zhanpushiasp/index
ERROR - 2022-01-24 06:18:10 --> 404 Page Not Found: Configasp/index
ERROR - 2022-01-24 06:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 06:34:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 06:34:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 06:34:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 06:40:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 06:42:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 06:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 06:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 06:52:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 06:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 07:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 07:19:25 --> 404 Page Not Found: Article/view
ERROR - 2022-01-24 07:29:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 07:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 07:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 08:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 08:14:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 08:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 08:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 08:30:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 08:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 08:56:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 08:56:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 09:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:02:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 09:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:37:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 09:37:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 09:43:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 09:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:49:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 09:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 09:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 09:56:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:02:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 10:02:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 10:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 10:11:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:11:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:11:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:12:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:13:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:16:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:17:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 10:17:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:18:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:20:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:20:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:20:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:22:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 10:23:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:24:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:24:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:24:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:25:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:25:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:25:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:25:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:26:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:26:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:27:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:32:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:32:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:34:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 10:35:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 10:42:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 10:44:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 10:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 10:46:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:47:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 10:47:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 10:49:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:50:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:51:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:51:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:52:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 10:52:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:55:07 --> 404 Page Not Found: Text4041642992907/index
ERROR - 2022-01-24 10:55:08 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-24 10:55:08 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-24 10:55:08 --> 404 Page Not Found: Sdk/index
ERROR - 2022-01-24 10:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 10:55:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:57:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 10:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 10:59:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:00:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:02:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:03:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:04:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:07:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 11:07:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 11:12:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:13:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 11:14:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:17:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 11:17:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 11:19:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 11:20:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:20:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:25:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:28:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 11:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:30:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:30:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:31:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:31:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:36:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:39:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:40:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:43:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 11:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 11:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 11:50:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 11:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 11:54:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 11:56:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 12:07:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 12:07:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:08:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:09:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:10:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 12:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 12:16:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 12:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 12:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 12:43:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:43:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 12:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 12:50:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:54:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 12:55:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:57:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 12:58:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 12:59:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:03:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 13:03:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 13:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 13:09:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:10:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:10:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:10:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:11:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:11:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:11:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:11:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:12:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:13:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:13:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:14:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:15:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:15:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:17:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:17:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:17:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:22:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:23:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:25:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:26:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:28:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 13:35:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:36:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 13:38:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:40:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:40:45 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-24 13:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 13:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 13:44:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 13:46:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 13:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 13:59:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 14:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 14:04:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:13:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:20:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:21:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 14:22:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:25:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 14:34:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:44:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 14:44:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:52:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:53:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:54:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 14:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 14:59:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:00:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:08:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:10:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:17:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:17:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:17:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:18:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 15:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 15:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 15:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 15:32:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:33:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:35:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 15:35:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 15:39:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:40:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:40:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:44:19 --> 404 Page Not Found: Text4041643010259/index
ERROR - 2022-01-24 15:44:19 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-24 15:44:19 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-24 15:44:20 --> 404 Page Not Found: Sdk/index
ERROR - 2022-01-24 15:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 15:46:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 15:49:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 15:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 15:57:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:08:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 16:14:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:16:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 16:17:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:17:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:19:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:19:35 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 16:23:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 16:23:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:26:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:26:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:28:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 16:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 16:30:33 --> Severity: error --> 11111 test 1
ERROR - 2022-01-24 16:36:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:37:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:37:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:38:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 16:38:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:39:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:39:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:40:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:40:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:40:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 16:47:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:48:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:48:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:49:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:50:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:51:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:51:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:52:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:52:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:52:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:53:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 16:53:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:54:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:54:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:54:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:54:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:56:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:56:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:56:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:57:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:57:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 16:58:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:59:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 16:59:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 16:59:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:01:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:01:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:01:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:02:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:03:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 17:04:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:04:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 17:04:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 17:04:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 17:05:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 17:06:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:06:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:07:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:07:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:08:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:11:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:12:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:12:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:12:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:13:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:15:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:15:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:16:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:16:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:16:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:17:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:17:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:17:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:19:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:19:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 17:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 17:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 17:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 17:37:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 17:38:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 17:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 17:48:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 18:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:05:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:05:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:06:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:06:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:06:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:08:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:08:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:13:17 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-01-24 18:14:18 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2022-01-24 18:14:19 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2022-01-24 18:14:28 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2022-01-24 18:14:49 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-01-24 18:14:49 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-01-24 18:14:51 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2022-01-24 18:14:54 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2022-01-24 18:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 18:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 18:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 18:29:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:30:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:31:02 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2022-01-24 18:37:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:38:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:38:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:39:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:41:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 18:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 18:49:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 18:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 18:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 18:54:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:54:53 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2022-01-24 18:55:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:55:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 18:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 19:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 19:11:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 19:18:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 19:18:42 --> 404 Page Not Found: City/1
ERROR - 2022-01-24 19:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 19:22:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 19:22:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 19:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 19:29:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 19:29:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 19:30:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 19:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 19:33:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 19:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 19:43:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 19:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 19:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 19:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 19:57:31 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-24 20:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 20:04:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:04:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:06:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:09:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 20:23:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 20:30:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 20:30:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:39:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:40:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 20:41:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:41:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:42:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:44:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 20:45:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:46:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:56:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:56:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 20:56:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 20:57:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:01:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:02:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:02:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:03:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:04:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:06:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 21:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:13:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 21:16:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:17:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 21:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:23:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:27:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:28:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:53:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:54:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 21:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 21:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 22:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 22:15:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 22:16:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 22:21:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 22:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 22:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 22:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 22:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 22:28:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:33:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 22:37:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 22:44:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:52:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:52:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 22:52:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 22:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 22:54:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:54:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:54:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:55:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:55:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 22:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 23:04:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 23:04:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 23:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 23:09:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 23:09:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 23:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 23:18:38 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 23:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 23:32:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 23:32:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 23:33:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-24 23:33:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Member/space
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-24 23:34:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-24 23:37:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 23:41:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-24 23:52:11 --> 404 Page Not Found: Robotstxt/index
