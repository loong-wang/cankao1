ERROR - 2021-09-10 11:05:15 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:35 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:52 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:52 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:52 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:53 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:53 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:53 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:53 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:53 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:53 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:53 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:53 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:53 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:53 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:53 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:53 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:53 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:53 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:53 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:54 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:54 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:54 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:54 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:54 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:54 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:54 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:54 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:54 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:57 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:57 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:57 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:57 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:57 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:57 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:57 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:57 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:57 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:58 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:58 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:58 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:58 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:58 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:58 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:58 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:58 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:58 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:59 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:59 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:59 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:59 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:59 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:59 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:59 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:59 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:59 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:59 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:06:59 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:06:59 --> Unable to connect to the database
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:06:59 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:00 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:00 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:00 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:00 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:00 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:00 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:00 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:00 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:00 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:00 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:00 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:00 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:00 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:01 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:01 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:01 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:01 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:01 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:01 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:01 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:01 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:01 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:01 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:02 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:02 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:02 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:02 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:02 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:02 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:02 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:02 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:02 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:02 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:02 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:02 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:02 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:02 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_insert_id() expects parameter 1 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 370
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:02 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:02 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:02 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:02 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:02 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:04 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:04 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:04 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:04 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:04 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:04 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:04 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:04 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:04 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:04 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:05 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:05 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:05 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:05 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:05 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:05 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:05 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:05 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:05 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:07:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:07 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:07 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:07 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:07 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:07 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:07 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:07 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:08 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:08 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:08 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:08 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:08 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:08 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:08 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:08 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:08 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:10 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:10 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:10 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:10 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:10 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:10 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:10 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:10 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:10 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:10 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:11 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:11 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:11 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:11 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:11 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:11 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:12 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:12 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:12 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:12 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:12 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:12 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:12 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:12 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:12 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:13 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:13 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:13 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:13 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:13 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:13 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:13 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:13 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:13 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:14 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:14 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:14 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:14 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:14 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:14 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:14 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_insert_id() expects parameter 1 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 370
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:14 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:14 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:14 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:14 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:15 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:15 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:15 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:15 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:15 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:15 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:15 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:15 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:15 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:16 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:16 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:16 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:16 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:16 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:16 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:16 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:17 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:17 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:17 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:17 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:17 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:17 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:17 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:18 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:18 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:18 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:18 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:18 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:18 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:18 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:19 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:19 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:19 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:19 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:19 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:19 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:19 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:19 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:19 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:20 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:20 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:20 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:20 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:20 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:20 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:20 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:20 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:20 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:22 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:22 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:22 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:22 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:22 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:22 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:22 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:22 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:22 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:23 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:23 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:23 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:23 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:23 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:23 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:23 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:23 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:23 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_insert_id() expects parameter 1 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 370
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:23 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_real_escape_string() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 346
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:23 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:23 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:23 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:24 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:24 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:24 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:24 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:24 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:24 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:24 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:24 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:24 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:25 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:25 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:25 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:26 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:26 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:26 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:26 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:26 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:26 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:26 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:26 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:26 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:26 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:27 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:27 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:27 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:27 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:27 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:27 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:27 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:27 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:27 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:27 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:28 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:28 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:28 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:28 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:28 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:28 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:28 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:28 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:28 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:28 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:29 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:29 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:29 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:29 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:29 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:29 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:29 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:29 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:29 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:29 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:29 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:29 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:30 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:30 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:30 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:30 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:30 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:30 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:31 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:31 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:31 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:31 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:31 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:31 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:31 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:31 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:31 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:32 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:32 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:32 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:32 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:32 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:32 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:32 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:32 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:32 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:32 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:33 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:33 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:33 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:33 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:33 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:33 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:36 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:36 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:36 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:36 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:36 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:36 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:36 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:36 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:36 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:37 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:37 --> Severity: Warning --> mysql_connect(): Too many connections /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 136
ERROR - 2021-09-10 11:07:37 --> Severity: Warning --> mysql_select_db() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 191
ERROR - 2021-09-10 11:07:37 --> Unable to select database: xuanhao_net
ERROR - 2021-09-10 11:07:37 --> Unable to connect to the database
ERROR - 2021-09-10 11:07:37 --> Severity: Warning --> mysql_query() expects parameter 2 to be resource, boolean given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_driver.php 245
ERROR - 2021-09-10 11:07:37 --> Severity: Warning --> mysql_num_rows() expects parameter 1 to be resource, null given /www/wwwroot/www.xuanhao.net/system/database/drivers/mysql/mysql_result.php 63
ERROR - 2021-09-10 11:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:08:34 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-09-10 11:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:09:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 11:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:14:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 11:14:35 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-09-10 11:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:16:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 11:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:17:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 11:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:18:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 11:18:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 11:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:19:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 11:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:22:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 11:23:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:38:49 --> 404 Page Not Found: English/index
ERROR - 2021-09-10 11:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:39:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:52:42 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-10 11:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:53:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:54:04 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-10 11:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:57:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 11:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:13:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 12:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:16:29 --> 404 Page Not Found: Env/index
ERROR - 2021-09-10 12:17:04 --> 404 Page Not Found: Env/index
ERROR - 2021-09-10 12:17:04 --> 404 Page Not Found: admin/Env/index
ERROR - 2021-09-10 12:17:05 --> 404 Page Not Found: Admin-app/.env
ERROR - 2021-09-10 12:17:05 --> 404 Page Not Found: Api/.env
ERROR - 2021-09-10 12:17:05 --> 404 Page Not Found: Back/.env
ERROR - 2021-09-10 12:17:06 --> 404 Page Not Found: Backend/.env
ERROR - 2021-09-10 12:17:06 --> 404 Page Not Found: Cp/.env
ERROR - 2021-09-10 12:17:07 --> 404 Page Not Found: Development/.env
ERROR - 2021-09-10 12:17:07 --> 404 Page Not Found: Docker/.env
ERROR - 2021-09-10 12:17:07 --> 404 Page Not Found: Local/.env
ERROR - 2021-09-10 12:17:08 --> 404 Page Not Found: Private/.env
ERROR - 2021-09-10 12:17:08 --> 404 Page Not Found: Rest/.env
ERROR - 2021-09-10 12:17:09 --> 404 Page Not Found: Shared/.env
ERROR - 2021-09-10 12:17:09 --> 404 Page Not Found: Laravel/.env
ERROR - 2021-09-10 12:17:09 --> 404 Page Not Found: System/.env
ERROR - 2021-09-10 12:17:10 --> 404 Page Not Found: Sources/.env
ERROR - 2021-09-10 12:17:10 --> 404 Page Not Found: Public/.env
ERROR - 2021-09-10 12:17:11 --> 404 Page Not Found: V1/.env
ERROR - 2021-09-10 12:17:11 --> 404 Page Not Found: App/.env
ERROR - 2021-09-10 12:17:11 --> 404 Page Not Found: Config/.env
ERROR - 2021-09-10 12:17:12 --> 404 Page Not Found: Core/.env
ERROR - 2021-09-10 12:17:12 --> 404 Page Not Found: Apps/.env
ERROR - 2021-09-10 12:17:12 --> 404 Page Not Found: Lib/.env
ERROR - 2021-09-10 12:17:13 --> 404 Page Not Found: Cron/.env
ERROR - 2021-09-10 12:17:13 --> 404 Page Not Found: Database/.env
ERROR - 2021-09-10 12:17:14 --> 404 Page Not Found: Uploads/.env
ERROR - 2021-09-10 12:17:14 --> 404 Page Not Found: Site/.env
ERROR - 2021-09-10 12:17:14 --> 404 Page Not Found: Web/.env
ERROR - 2021-09-10 12:17:15 --> 404 Page Not Found: Administrator/.env
ERROR - 2021-09-10 12:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:26:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 12:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:36:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:38:40 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-10 12:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:46:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 12:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:49:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:59:11 --> 404 Page Not Found: Env/index
ERROR - 2021-09-10 12:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 12:59:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 12:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:00:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 13:01:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 13:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:01:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 13:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:12:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:17:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 13:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 13:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:27:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-10 13:28:13 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-10 13:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:36:00 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-10 13:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:44:10 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-10 13:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:45:55 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-10 13:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:49:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 13:49:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 13:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 13:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:00:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 14:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:01:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:13:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:15:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 14:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:20:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:25:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-10 14:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:26:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:30:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 14:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:33:39 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-10 14:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:39:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:40:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-10 14:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:41:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:41:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:42:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:43:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:44:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:45:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:45:28 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-10 14:45:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:46:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:47:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:48:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:51:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 14:51:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 14:51:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 14:51:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 14:52:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:53:35 --> 404 Page Not Found: Text4041631256815/index
ERROR - 2021-09-10 14:53:35 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-09-10 14:53:35 --> 404 Page Not Found: Evox/about
ERROR - 2021-09-10 14:53:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:55:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 14:57:53 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-10 14:57:53 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-10 14:57:53 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-10 14:57:53 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-10 14:57:53 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-10 14:57:53 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-10 14:57:53 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-10 14:57:53 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-10 14:57:53 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-10 14:57:54 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-10 14:57:55 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-10 14:57:55 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-10 14:57:55 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-10 14:57:55 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-10 14:57:55 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-10 14:57:55 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-10 14:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 14:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:00:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:00:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:07:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:08:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:08:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:14:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:16:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:18:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:19:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:19:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:19:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:19:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:19:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:26:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:33:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:34:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:35:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:36:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:37:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:37:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:38:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:38:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:38:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:38:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:39:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:43:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:43:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:43:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:43:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:43:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:44:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:44:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:44:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:45:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:45:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:49:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:50:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:50:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:50:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:50:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:55:40 --> 404 Page Not Found: Expensesasp/index
ERROR - 2021-09-10 15:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:57:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 15:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:58:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:58:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 15:59:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 15:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:04:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 16:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:16:46 --> 404 Page Not Found: English/index
ERROR - 2021-09-10 16:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:20:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 16:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:23:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 16:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:26:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:27:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:30:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:30:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:31:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:32:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:32:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:32:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:33:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:33:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:34:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:35:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:35:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:35:47 --> 404 Page Not Found: Env/index
ERROR - 2021-09-10 16:35:49 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-09-10 16:35:50 --> 404 Page Not Found: admin/Env/index
ERROR - 2021-09-10 16:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:36:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:36:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:37:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:37:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:37:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:37:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:37:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:38:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:38:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:39:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:40:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:40:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:41:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:41:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:42:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:43:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-10 16:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:44:46 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-10 16:44:46 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-10 16:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:49:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:51:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 16:51:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 16:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:57:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:57:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:57:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:58:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:58:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:59:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 16:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 16:59:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 17:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:02:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:02:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:03:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:03:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:03:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:03:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:04:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:05:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:05:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 17:05:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 17:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:06:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:07:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 17:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:29:25 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-09-10 17:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:30:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:33:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 17:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:39:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:39:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:39:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:39:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:39:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:39:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:40:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:40:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 17:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:56:23 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-10 17:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 17:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:18:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 18:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:20:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:26:42 --> Severity: Warning --> Missing argument 1 for Zifei::show() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 277
ERROR - 2021-09-10 18:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:28:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-10 18:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:38:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:40:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 18:40:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-10 18:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:42:43 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-10 18:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:54:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-10 18:57:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 18:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:03:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-10 19:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:11:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 19:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:13:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 19:13:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 19:13:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 19:13:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 19:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:20:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:33:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 19:33:40 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-09-10 19:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:37:39 --> 404 Page Not Found: Wwwlianghaocncomrar/index
ERROR - 2021-09-10 19:37:39 --> 404 Page Not Found: Wwwlianghaocncomzip/index
ERROR - 2021-09-10 19:37:39 --> 404 Page Not Found: Wwwlianghaocncomtargz/index
ERROR - 2021-09-10 19:37:39 --> 404 Page Not Found: Wwwlianghaocncom7z/index
ERROR - 2021-09-10 19:37:39 --> 404 Page Not Found: Www_lianghaocn_comrar/index
ERROR - 2021-09-10 19:37:39 --> 404 Page Not Found: Www_lianghaocn_comzip/index
ERROR - 2021-09-10 19:37:39 --> 404 Page Not Found: Www_lianghaocn_comtargz/index
ERROR - 2021-09-10 19:37:40 --> 404 Page Not Found: Www_lianghaocn_com7z/index
ERROR - 2021-09-10 19:37:40 --> 404 Page Not Found: Wwwlianghaocncomrar/index
ERROR - 2021-09-10 19:37:40 --> 404 Page Not Found: Wwwlianghaocncomzip/index
ERROR - 2021-09-10 19:37:40 --> 404 Page Not Found: Wwwlianghaocncomtargz/index
ERROR - 2021-09-10 19:37:40 --> 404 Page Not Found: Wwwlianghaocncom7z/index
ERROR - 2021-09-10 19:37:41 --> 404 Page Not Found: Wwwlianghaocncom1rar/index
ERROR - 2021-09-10 19:37:41 --> 404 Page Not Found: Article/view
ERROR - 2021-09-10 19:37:42 --> 404 Page Not Found: Wwwlianghaocncom1zip/index
ERROR - 2021-09-10 19:37:42 --> 404 Page Not Found: Wwwlianghaocncom1targz/index
ERROR - 2021-09-10 19:37:42 --> 404 Page Not Found: Wwwlianghaocncom17z/index
ERROR - 2021-09-10 19:37:42 --> 404 Page Not Found: Lianghaocncomrar/index
ERROR - 2021-09-10 19:37:43 --> 404 Page Not Found: Lianghaocncomzip/index
ERROR - 2021-09-10 19:37:43 --> 404 Page Not Found: Lianghaocncomtargz/index
ERROR - 2021-09-10 19:37:43 --> 404 Page Not Found: Lianghaocncom7z/index
ERROR - 2021-09-10 19:37:43 --> 404 Page Not Found: Lianghaocnrar/index
ERROR - 2021-09-10 19:37:44 --> 404 Page Not Found: Lianghaocnzip/index
ERROR - 2021-09-10 19:37:44 --> 404 Page Not Found: Lianghaocntargz/index
ERROR - 2021-09-10 19:37:45 --> 404 Page Not Found: Lianghaocn7z/index
ERROR - 2021-09-10 19:37:45 --> 404 Page Not Found: Lianghaocn1rar/index
ERROR - 2021-09-10 19:37:45 --> 404 Page Not Found: Lianghaocn1zip/index
ERROR - 2021-09-10 19:37:45 --> 404 Page Not Found: Lianghaocn1targz/index
ERROR - 2021-09-10 19:37:45 --> 404 Page Not Found: Lianghaocn17z/index
ERROR - 2021-09-10 19:37:45 --> 404 Page Not Found: Lianghaocnwwwzip/index
ERROR - 2021-09-10 19:37:46 --> 404 Page Not Found: Lianghaocnwwwrar/index
ERROR - 2021-09-10 19:37:46 --> 404 Page Not Found: Lianghaocnwwwtargz/index
ERROR - 2021-09-10 19:37:46 --> 404 Page Not Found: Lianghaocnwww7z/index
ERROR - 2021-09-10 19:37:46 --> 404 Page Not Found: Lianghaocnwebrar/index
ERROR - 2021-09-10 19:37:47 --> 404 Page Not Found: Lianghaocnwebzip/index
ERROR - 2021-09-10 19:37:47 --> 404 Page Not Found: Lianghaocnwebtargz/index
ERROR - 2021-09-10 19:37:48 --> 404 Page Not Found: Lianghaocnweb7z/index
ERROR - 2021-09-10 19:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:37:51 --> 404 Page Not Found: Lianghaocnwwwrootzip/index
ERROR - 2021-09-10 19:37:51 --> 404 Page Not Found: Lianghaocnwwwrootrar/index
ERROR - 2021-09-10 19:37:51 --> 404 Page Not Found: Lianghaocnwwwroottargz/index
ERROR - 2021-09-10 19:37:51 --> 404 Page Not Found: Lianghaocnwwwroot7z/index
ERROR - 2021-09-10 19:37:52 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-10 19:37:52 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-10 19:37:52 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-10 19:37:52 --> 404 Page Not Found: Www7z/index
ERROR - 2021-09-10 19:37:52 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-10 19:37:55 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-10 19:37:55 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-10 19:37:55 --> 404 Page Not Found: Webtar7z/index
ERROR - 2021-09-10 19:37:55 --> 404 Page Not Found: Www1zip/index
ERROR - 2021-09-10 19:37:56 --> 404 Page Not Found: Www1rar/index
ERROR - 2021-09-10 19:37:56 --> 404 Page Not Found: Www1targz/index
ERROR - 2021-09-10 19:37:56 --> 404 Page Not Found: Www17z/index
ERROR - 2021-09-10 19:37:56 --> 404 Page Not Found: Web1rar/index
ERROR - 2021-09-10 19:37:57 --> 404 Page Not Found: Web1zip/index
ERROR - 2021-09-10 19:37:57 --> 404 Page Not Found: Web1targz/index
ERROR - 2021-09-10 19:37:57 --> 404 Page Not Found: Web17z/index
ERROR - 2021-09-10 19:37:57 --> 404 Page Not Found: Wwwroot1rar/index
ERROR - 2021-09-10 19:37:57 --> 404 Page Not Found: Wwwroot1zip/index
ERROR - 2021-09-10 19:37:57 --> 404 Page Not Found: Wwwroot1targz/index
ERROR - 2021-09-10 19:37:57 --> 404 Page Not Found: Wwwroot17z/index
ERROR - 2021-09-10 19:37:58 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-10 19:37:58 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-10 19:37:58 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-10 19:37:58 --> 404 Page Not Found: Wwwroot7z/index
ERROR - 2021-09-10 19:37:59 --> 404 Page Not Found: Websiterar/index
ERROR - 2021-09-10 19:37:59 --> 404 Page Not Found: Websitezip/index
ERROR - 2021-09-10 19:37:59 --> 404 Page Not Found: Websitetargz/index
ERROR - 2021-09-10 19:38:00 --> 404 Page Not Found: Website17z/index
ERROR - 2021-09-10 19:38:00 --> 404 Page Not Found: Website1rar/index
ERROR - 2021-09-10 19:38:00 --> 404 Page Not Found: Website1zip/index
ERROR - 2021-09-10 19:38:00 --> 404 Page Not Found: Website1targz/index
ERROR - 2021-09-10 19:38:01 --> 404 Page Not Found: Website17z/index
ERROR - 2021-09-10 19:38:02 --> 404 Page Not Found: Yuanmazip/index
ERROR - 2021-09-10 19:38:03 --> 404 Page Not Found: Yuanmarar/index
ERROR - 2021-09-10 19:38:03 --> 404 Page Not Found: Yuanmatargz/index
ERROR - 2021-09-10 19:38:03 --> 404 Page Not Found: Yuanma7z/index
ERROR - 2021-09-10 19:38:03 --> 404 Page Not Found: Beifenrar/index
ERROR - 2021-09-10 19:38:03 --> 404 Page Not Found: Beifenzip/index
ERROR - 2021-09-10 19:38:03 --> 404 Page Not Found: Beifentargz/index
ERROR - 2021-09-10 19:38:04 --> 404 Page Not Found: Beifen7z/index
ERROR - 2021-09-10 19:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:42:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 19:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:49:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 19:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:52:14 --> 404 Page Not Found: Login/index
ERROR - 2021-09-10 19:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 19:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:35:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:38:36 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-10 20:38:36 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-10 20:38:36 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-10 20:38:36 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-10 20:38:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-10 20:38:36 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-10 20:38:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-10 20:38:36 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-10 20:38:36 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-10 20:38:37 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-10 20:38:37 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-10 20:38:37 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-10 20:38:37 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-10 20:38:37 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-10 20:38:37 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-10 20:38:37 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-10 20:38:38 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-10 20:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:42:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 20:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:43:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:47:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:51:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 20:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:53:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:53:55 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-10 20:53:56 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-10 20:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:54:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 20:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:14:34 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-10 21:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:18:24 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-10 21:18:49 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-09-10 21:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:27:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 21:28:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 21:28:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 21:28:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 21:29:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 21:29:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:31:18 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-09-10 21:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:33:22 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-09-10 21:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:37:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:50:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:52:55 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-10 21:53:07 --> 404 Page Not Found: Sites/default
ERROR - 2021-09-10 21:53:12 --> 404 Page Not Found: admin/Controller/extension
ERROR - 2021-09-10 21:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 21:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:08:18 --> 404 Page Not Found: SiteServer/Ajax
ERROR - 2021-09-10 22:08:18 --> 404 Page Not Found: SiteFiles/SiteTemplates
ERROR - 2021-09-10 22:08:18 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-09-10 22:08:19 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-09-10 22:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:17:15 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-10 22:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:20:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-10 22:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:31:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 22:31:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 22:32:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 22:32:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 22:32:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 22:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:33:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 22:33:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 22:36:15 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-10 22:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-10 22:39:05 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-10 22:39:06 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-10 22:39:07 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-10 22:39:07 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-10 22:39:44 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-10 22:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 22:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:44:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 22:44:49 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-10 22:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:44:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 22:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:45:28 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-10 22:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 22:46:00 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-10 22:46:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-10 22:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 22:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:00:13 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-10 23:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:02:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:19:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:27:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-10 23:27:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:43:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:46:53 --> 404 Page Not Found: Text4041631288813/index
ERROR - 2021-09-10 23:46:53 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-09-10 23:46:53 --> 404 Page Not Found: Evox/about
ERROR - 2021-09-10 23:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-10 23:59:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 23:59:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-10 23:59:35 --> 404 Page Not Found: Robotstxt/index
