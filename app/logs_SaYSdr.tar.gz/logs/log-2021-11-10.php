<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-10 00:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 00:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 00:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 00:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 00:34:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 01:01:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 01:24:09 --> 404 Page Not Found: Text4041636478649/index
ERROR - 2021-11-10 01:24:09 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-11-10 01:24:09 --> 404 Page Not Found: Evox/about
ERROR - 2021-11-10 01:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 01:24:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 01:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 01:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 01:46:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 01:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 02:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 02:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 02:23:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 02:25:11 --> 404 Page Not Found: Config/AspCms_Config.asp
ERROR - 2021-11-10 02:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 02:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 02:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 02:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 03:12:12 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-11-10 03:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 03:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 03:56:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 04:10:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 04:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 04:39:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 04:41:02 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-11-10 04:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 05:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 05:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 05:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 05:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 05:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 05:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 06:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 06:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 06:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 06:33:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 06:33:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 06:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 07:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 07:47:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 07:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 08:00:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 08:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 08:14:42 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-10 08:14:52 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-10 08:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 08:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 08:55:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 08:56:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 09:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 09:15:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 09:18:24 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-10 09:20:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 09:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 09:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 09:56:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 10:15:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:15:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:19:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:19:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:19:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:19:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:20:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:20:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:20:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:20:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:21:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 10:21:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:21:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:21:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 10:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 10:27:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 10:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 10:42:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 10:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 10:57:45 --> 404 Page Not Found: Evox/about
ERROR - 2021-11-10 10:57:46 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-11-10 11:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 11:01:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-10 11:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 11:36:10 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-10 11:43:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 11:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 12:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 12:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 12:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 13:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 13:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 13:28:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 13:29:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 13:29:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 13:32:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 13:33:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 13:34:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 13:34:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 13:39:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 13:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 13:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 13:56:41 --> 404 Page Not Found: City/1
ERROR - 2021-11-10 13:57:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 14:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 14:12:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 14:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 14:20:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 14:20:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 14:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 14:33:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 14:42:44 --> 404 Page Not Found: Undefined/index
ERROR - 2021-11-10 14:44:31 --> 404 Page Not Found: Undefined/index
ERROR - 2021-11-10 14:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 14:45:21 --> 404 Page Not Found: Undefined/index
ERROR - 2021-11-10 15:15:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:16:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:17:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:18:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:18:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:18:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:18:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:18:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:18:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:18:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 15:24:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 15:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 15:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 15:28:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:28:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 15:30:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 15:33:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 15:33:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:34:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:37:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 15:39:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:39:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:40:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:41:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:41:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:41:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:43:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:44:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:46:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:46:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:47:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:47:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:48:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:48:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:48:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:49:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:49:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:50:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:54:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:54:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:54:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:54:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:54:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:55:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:55:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 15:58:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 15:59:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 16:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 16:02:14 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-11-10 16:02:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:02:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:03:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:03:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:03:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:05:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:05:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:05:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:06:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:08:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:08:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:08:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:08:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:09:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 16:09:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:16:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 16:25:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 16:28:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 16:30:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 16:38:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 16:44:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 16:46:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 16:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 17:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 17:08:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 17:15:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 17:16:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:16:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:16:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:16:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:16:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:16:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:16:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:16:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:16:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:16:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:17:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:17:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:17:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:17:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:17:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:17:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:17:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:17:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:17:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 17:18:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:18:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:19:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-10 17:20:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:21:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:22:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 17:22:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 17:22:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 17:22:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 17:22:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:22:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 17:23:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:36:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:37:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:38:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:38:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:40:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:41:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:41:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:42:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:43:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:43:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 17:45:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 17:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 17:50:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 18:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 18:05:03 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-11-10 18:05:34 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-11-10 18:06:04 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-11-10 18:06:35 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-11-10 18:07:05 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-11-10 18:07:36 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-11-10 18:08:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-11-10 18:08:37 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-11-10 18:09:08 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-11-10 18:09:38 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-11-10 18:10:09 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-11-10 18:10:39 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-11-10 18:11:10 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-11-10 18:11:41 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-11-10 18:11:45 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-11-10 18:11:46 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-11-10 18:11:46 --> 404 Page Not Found: Netrar/index
ERROR - 2021-11-10 18:11:46 --> 404 Page Not Found: Netzip/index
ERROR - 2021-11-10 18:11:46 --> 404 Page Not Found: Websiterar/index
ERROR - 2021-11-10 18:11:46 --> 404 Page Not Found: Websitezip/index
ERROR - 2021-11-10 18:11:46 --> 404 Page Not Found: Webrootrar/index
ERROR - 2021-11-10 18:11:47 --> 404 Page Not Found: Webrootzip/index
ERROR - 2021-11-10 18:11:47 --> 404 Page Not Found: Wwwroottar/index
ERROR - 2021-11-10 18:11:47 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-11-10 18:11:47 --> 404 Page Not Found: Datatargz/index
ERROR - 2021-11-10 18:11:47 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-11-10 18:11:47 --> 404 Page Not Found: Ftptargz/index
ERROR - 2021-11-10 18:11:48 --> 404 Page Not Found: Databasezip/index
ERROR - 2021-11-10 18:11:48 --> 404 Page Not Found: Databaserar/index
ERROR - 2021-11-10 18:11:48 --> 404 Page Not Found: Databakrar/index
ERROR - 2021-11-10 18:11:48 --> 404 Page Not Found: Databakzip/index
ERROR - 2021-11-10 18:11:48 --> 404 Page Not Found: Dbrar/index
ERROR - 2021-11-10 18:11:48 --> 404 Page Not Found: Dbzip/index
ERROR - 2021-11-10 18:11:49 --> 404 Page Not Found: Sqlrar/index
ERROR - 2021-11-10 18:11:49 --> 404 Page Not Found: Sqlzip/index
ERROR - 2021-11-10 18:11:49 --> 404 Page Not Found: Sjkrar/index
ERROR - 2021-11-10 18:11:49 --> 404 Page Not Found: Sjkzip/index
ERROR - 2021-11-10 18:11:49 --> 404 Page Not Found: Sjrar/index
ERROR - 2021-11-10 18:11:49 --> 404 Page Not Found: Sjzip/index
ERROR - 2021-11-10 18:11:49 --> 404 Page Not Found: Siterar/index
ERROR - 2021-11-10 18:11:50 --> 404 Page Not Found: Sitezip/index
ERROR - 2021-11-10 18:11:50 --> 404 Page Not Found: Homerar/index
ERROR - 2021-11-10 18:11:50 --> 404 Page Not Found: Homezip/index
ERROR - 2021-11-10 18:11:50 --> 404 Page Not Found: Wangzhanzip/index
ERROR - 2021-11-10 18:11:50 --> 404 Page Not Found: Wangzhanrar/index
ERROR - 2021-11-10 18:11:50 --> 404 Page Not Found: Wzrar/index
ERROR - 2021-11-10 18:11:51 --> 404 Page Not Found: Wzzip/index
ERROR - 2021-11-10 18:11:51 --> 404 Page Not Found: Domainrar/index
ERROR - 2021-11-10 18:11:51 --> 404 Page Not Found: Domainzip/index
ERROR - 2021-11-10 18:11:51 --> 404 Page Not Found: Beifenrar/index
ERROR - 2021-11-10 18:11:51 --> 404 Page Not Found: Beifenzip/index
ERROR - 2021-11-10 18:11:51 --> 404 Page Not Found: Backuprar/index
ERROR - 2021-11-10 18:11:52 --> 404 Page Not Found: Backupzip/index
ERROR - 2021-11-10 18:11:52 --> 404 Page Not Found: Web1rar/index
ERROR - 2021-11-10 18:11:52 --> 404 Page Not Found: Web1zip/index
ERROR - 2021-11-10 18:11:52 --> 404 Page Not Found: Www1rar/index
ERROR - 2021-11-10 18:11:52 --> 404 Page Not Found: Www1zip/index
ERROR - 2021-11-10 18:11:52 --> 404 Page Not Found: Wwwroot1rar/index
ERROR - 2021-11-10 18:11:53 --> 404 Page Not Found: Wwwroot1zip/index
ERROR - 2021-11-10 18:11:53 --> 404 Page Not Found: Backrar/index
ERROR - 2021-11-10 18:11:53 --> 404 Page Not Found: Backzip/index
ERROR - 2021-11-10 18:11:53 --> 404 Page Not Found: Webzip/index
ERROR - 2021-11-10 18:11:53 --> 404 Page Not Found: Webrar/index
ERROR - 2021-11-10 18:11:53 --> 404 Page Not Found: Bbsrar/index
ERROR - 2021-11-10 18:11:53 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-11-10 18:11:54 --> 404 Page Not Found: Bakrar/index
ERROR - 2021-11-10 18:11:54 --> 404 Page Not Found: Bakzip/index
ERROR - 2021-11-10 18:11:54 --> 404 Page Not Found: Oarar/index
ERROR - 2021-11-10 18:11:54 --> 404 Page Not Found: 2018rar/index
ERROR - 2021-11-10 18:11:54 --> 404 Page Not Found: 2019rar/index
ERROR - 2021-11-10 18:11:54 --> 404 Page Not Found: 2020rar/index
ERROR - 2021-11-10 18:11:55 --> 404 Page Not Found: 2021rar/index
ERROR - 2021-11-10 18:11:55 --> 404 Page Not Found: 2018zip/index
ERROR - 2021-11-10 18:11:55 --> 404 Page Not Found: 2019zip/index
ERROR - 2021-11-10 18:11:55 --> 404 Page Not Found: 2020zip/index
ERROR - 2021-11-10 18:11:55 --> 404 Page Not Found: 2021zip/index
ERROR - 2021-11-10 18:11:55 --> 404 Page Not Found: Arar/index
ERROR - 2021-11-10 18:11:56 --> 404 Page Not Found: Azip/index
ERROR - 2021-11-10 18:11:56 --> 404 Page Not Found: A7z/index
ERROR - 2021-11-10 18:11:56 --> 404 Page Not Found: Abcrar/index
ERROR - 2021-11-10 18:11:56 --> 404 Page Not Found: Abczip/index
ERROR - 2021-11-10 18:11:56 --> 404 Page Not Found: Abc7z/index
ERROR - 2021-11-10 18:11:56 --> 404 Page Not Found: 1gz/index
ERROR - 2021-11-10 18:11:57 --> 404 Page Not Found: 1targz/index
ERROR - 2021-11-10 18:11:57 --> 404 Page Not Found: Bbsrar/index
ERROR - 2021-11-10 18:11:57 --> 404 Page Not Found: Bbszip/index
ERROR - 2021-11-10 18:11:57 --> 404 Page Not Found: Beianrar/index
ERROR - 2021-11-10 18:11:57 --> 404 Page Not Found: Flashfxprar/index
ERROR - 2021-11-10 18:11:57 --> 404 Page Not Found: Flashfxpzip/index
ERROR - 2021-11-10 18:11:57 --> 404 Page Not Found: Testrar/index
ERROR - 2021-11-10 18:11:58 --> 404 Page Not Found: Viprar/index
ERROR - 2021-11-10 18:11:58 --> 404 Page Not Found: Vipzip/index
ERROR - 2021-11-10 18:11:58 --> 404 Page Not Found: Mdbrar/index
ERROR - 2021-11-10 18:11:58 --> 404 Page Not Found: Mdbzip/index
ERROR - 2021-11-10 18:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 18:21:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 18:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 18:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 19:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 19:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 19:10:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 19:10:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 19:14:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 19:14:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 19:16:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 19:16:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 19:19:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 19:19:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 19:20:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 19:22:44 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-10 19:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 19:30:45 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-11-10 19:34:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 19:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 20:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 20:04:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 20:09:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 20:09:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 20:12:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 20:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 20:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 20:54:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 21:19:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 21:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 21:22:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 21:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 21:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 21:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 21:55:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 21:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 22:01:27 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-11-10 22:08:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:08:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:09:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:09:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:09:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:09:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:09:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:09:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:09:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 22:09:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:09:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:10:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:11:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 22:34:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 22:37:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:38:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:41:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:45:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:55:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 22:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 22:59:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 23:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 23:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 23:22:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-10 23:24:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:25:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:26:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:28:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:29:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:29:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:30:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:30:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:30:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:30:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-10 23:30:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:30:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-10 23:49:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:50:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:50:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:51:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:52:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:53:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:53:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:53:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:54:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:54:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-10 23:54:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
