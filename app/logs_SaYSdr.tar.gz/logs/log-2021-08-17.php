<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-17 00:01:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:02:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:02:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:03:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:05:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:06:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 00:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:07:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:07:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:09:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:11:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 00:12:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:12:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:12:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:14:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:14:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:16:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:19:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:22:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:23:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:25:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:26:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:26:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:27:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 00:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:29:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:29:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:30:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 00:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:32:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 00:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:33:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:33:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:34:31 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-17 00:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:36:04 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-08-17 00:36:44 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 00:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:37:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 00:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:37:53 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 00:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:40:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:41:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:41:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:41:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:42:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:45:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:48:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 00:58:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 00:59:07 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-17 01:00:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:07:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:08:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:10:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 01:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:19:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:19:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 01:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:20:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:20:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:20:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 01:21:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:21:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:22:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:22:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:23:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:23:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:24:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:24:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:24:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 01:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:26:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 01:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:26:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:27:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:27:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:27:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 01:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:27:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:28:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:28:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:29:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:29:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:30:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:30:16 --> 404 Page Not Found: Vod-play-id-2606-sid-0-pid-81html/index
ERROR - 2021-08-17 01:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:31:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:31:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:31:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:31:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:32:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:32:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:33:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:35:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:35:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:36:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:36:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:36:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:36:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:37:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:37:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:38:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:38:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:38:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:39:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:39:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:39:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:40:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 01:40:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:42:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:43:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:43:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:44:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:44:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:44:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:45:00 --> 404 Page Not Found: Company/view
ERROR - 2021-08-17 01:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:45:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 01:45:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:46:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:46:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 01:46:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 01:46:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:46:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:49:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:51:04 --> 404 Page Not Found: City/1
ERROR - 2021-08-17 01:51:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 01:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:52:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:53:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:53:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 01:53:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:53:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:54:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:54:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:55:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 01:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:55:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:55:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:58:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 01:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 01:59:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:00:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:00:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:00:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:01:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:02:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:03:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:06:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:07:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:09:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:10:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:12:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:13:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:14:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:15:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:16:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:16:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:16:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:16:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:16:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:17:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:17:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:17:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:18:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:19:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:19:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:19:23 --> 404 Page Not Found: City/1
ERROR - 2021-08-17 02:20:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:20:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 02:22:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:24:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:24:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:27:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:27:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:28:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:33:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:33:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:33:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:34:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:35:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 02:36:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:36:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:39:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 02:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:40:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:40:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:41:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:41:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:41:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:41:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:42:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:42:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:42:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:42:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:43:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:43:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:44:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:47:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 02:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:48:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:48:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:50:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:50:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:50:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:51:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:51:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:51:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:51:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:52:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 02:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:53:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:53:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:56:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:58:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 02:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 02:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:00:31 --> 404 Page Not Found: admin/Login/index.html
ERROR - 2021-08-17 03:00:44 --> 404 Page Not Found: admin/Login/index.html
ERROR - 2021-08-17 03:03:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:04:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:04:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:06:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:10:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:13:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:13:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:13:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:13:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:14:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:15:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:16:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:19:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:20:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:22:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:23:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:24:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:27:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:31:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:32:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:32:51 --> 404 Page Not Found: Public/feedback.asp
ERROR - 2021-08-17 03:32:51 --> 404 Page Not Found: ColIcon/feedback.asp
ERROR - 2021-08-17 03:32:51 --> 404 Page Not Found: Uploads/feedback.asp
ERROR - 2021-08-17 03:32:51 --> 404 Page Not Found: App/feedback.asp
ERROR - 2021-08-17 03:32:51 --> 404 Page Not Found: City/feedback.asp
ERROR - 2021-08-17 03:32:52 --> 404 Page Not Found: Dingzhi/feedback.asp
ERROR - 2021-08-17 03:32:52 --> 404 Page Not Found: Aspx/feedback.asp
ERROR - 2021-08-17 03:32:52 --> 404 Page Not Found: Xinxi/feedback.asp
ERROR - 2021-08-17 03:32:52 --> 404 Page Not Found: Servers/feedback.asp
ERROR - 2021-08-17 03:32:52 --> 404 Page Not Found: News/feedback.asp
ERROR - 2021-08-17 03:32:53 --> 404 Page Not Found: Kefu/feedback.asp
ERROR - 2021-08-17 03:32:53 --> 404 Page Not Found: Zifei/feedback.asp
ERROR - 2021-08-17 03:32:53 --> 404 Page Not Found: Haoma/feedback.asp
ERROR - 2021-08-17 03:32:53 --> 404 Page Not Found: Tourl/feedback.asp
ERROR - 2021-08-17 03:32:53 --> 404 Page Not Found: Member/feedback.asp
ERROR - 2021-08-17 03:32:54 --> 404 Page Not Found: Page/feedback.asp
ERROR - 2021-08-17 03:32:54 --> 404 Page Not Found: Cart/feedback.asp
ERROR - 2021-08-17 03:32:54 --> 404 Page Not Found: User/feedback.asp
ERROR - 2021-08-17 03:32:54 --> 404 Page Not Found: Feedbackasp/index
ERROR - 2021-08-17 03:33:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:34:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:34:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:34:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:36:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:39:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:40:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:40:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:41:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:42:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:43:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 03:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:43:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:43:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:45:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:45:41 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-08-17 03:45:41 --> 404 Page Not Found: admin//index
ERROR - 2021-08-17 03:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:45:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 03:45:42 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-08-17 03:45:42 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-08-17 03:45:43 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-08-17 03:45:45 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-08-17 03:45:45 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-17 03:45:45 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-08-17 03:45:46 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-08-17 03:45:46 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-08-17 03:45:46 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-17 03:45:46 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-17 03:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:47:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:47:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:49:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:49:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:52:21 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-17 03:52:21 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-17 03:52:21 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-17 03:52:21 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-17 03:52:21 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-17 03:52:22 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-17 03:52:23 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-17 03:52:24 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-17 03:52:24 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-17 03:52:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:53:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:54:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:56:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:56:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:56:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:57:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:57:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 03:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:58:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 03:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 03:58:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:00:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-08-17 04:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:04:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 04:06:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:07:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:07:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:09:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:10:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:10:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:17:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 04:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:18:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:18:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:18:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:20:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:21:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:22:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:24:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:24:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:24:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 04:24:24 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-08-17 04:24:24 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-08-17 04:24:24 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-17 04:24:24 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-17 04:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:25:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:25:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:26:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:26:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:27:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:28:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:31:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:31:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:32:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:33:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:34:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:34:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:34:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:35:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:37:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:37:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:40:17 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-17 04:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:40:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 04:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:49:55 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-08-17 04:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:53:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:56:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:57:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:57:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 04:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 04:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:00:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:01:33 --> 404 Page Not Found: City/16
ERROR - 2021-08-17 05:02:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:02:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:02:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:03:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:03:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:03:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:05:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:05:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:06:51 --> 404 Page Not Found: City/1
ERROR - 2021-08-17 05:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:08:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 05:08:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:09:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:09:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:10:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:12:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:12:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 05:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:14:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:15:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:16:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:20:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:20:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:21:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:24:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:25:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:29:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:30:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:31:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:31:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:33:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:37:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:38:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:40:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:41:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:42:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:42:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:43:03 --> 404 Page Not Found: City/1
ERROR - 2021-08-17 05:43:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:43:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:43:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:43:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:43:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:43:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:43:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:44:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:44:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:44:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:44:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:44:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:44:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:44:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:44:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:44:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:44:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:44:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 05:45:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:45:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:45:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:45:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:46:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:46:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:47:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:47:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:48:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:51:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:52:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:52:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:53:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:53:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:54:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:54:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:55:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 05:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:56:18 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-17 05:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:57:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 05:59:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:00:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:01:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:02:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:03:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 06:04:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:05:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:06:03 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-08-17 06:06:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:06:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:07:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:13:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:19:16 --> 404 Page Not Found: Article/index
ERROR - 2021-08-17 06:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:20:32 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-17 06:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:22:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:23:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:23:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:24:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:25:33 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-17 06:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:28:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 06:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:30:13 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-08-17 06:30:19 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-17 06:32:15 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-17 06:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:34:12 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-17 06:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:38:02 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-17 06:38:13 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-17 06:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:48:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 06:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:05:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:06:09 --> 404 Page Not Found: Index/login
ERROR - 2021-08-17 07:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:06:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:07:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 07:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:10:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:13:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:13:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:18:21 --> 404 Page Not Found: Public/feedback.asp
ERROR - 2021-08-17 07:18:21 --> 404 Page Not Found: ColIcon/feedback.asp
ERROR - 2021-08-17 07:18:21 --> 404 Page Not Found: Uploads/feedback.asp
ERROR - 2021-08-17 07:18:21 --> 404 Page Not Found: App/feedback.asp
ERROR - 2021-08-17 07:18:22 --> 404 Page Not Found: City/feedback.asp
ERROR - 2021-08-17 07:18:22 --> 404 Page Not Found: Dingzhi/feedback.asp
ERROR - 2021-08-17 07:18:22 --> 404 Page Not Found: Aspx/feedback.asp
ERROR - 2021-08-17 07:18:22 --> 404 Page Not Found: Xinxi/feedback.asp
ERROR - 2021-08-17 07:18:22 --> 404 Page Not Found: Servers/feedback.asp
ERROR - 2021-08-17 07:18:23 --> 404 Page Not Found: News/feedback.asp
ERROR - 2021-08-17 07:18:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:18:23 --> 404 Page Not Found: Kefu/feedback.asp
ERROR - 2021-08-17 07:18:23 --> 404 Page Not Found: Zifei/feedback.asp
ERROR - 2021-08-17 07:18:23 --> 404 Page Not Found: Haoma/feedback.asp
ERROR - 2021-08-17 07:18:23 --> 404 Page Not Found: Tourl/feedback.asp
ERROR - 2021-08-17 07:18:24 --> 404 Page Not Found: Member/feedback.asp
ERROR - 2021-08-17 07:18:24 --> 404 Page Not Found: Page/feedback.asp
ERROR - 2021-08-17 07:18:24 --> 404 Page Not Found: Cart/feedback.asp
ERROR - 2021-08-17 07:18:24 --> 404 Page Not Found: User/feedback.asp
ERROR - 2021-08-17 07:18:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:18:24 --> 404 Page Not Found: Feedbackasp/index
ERROR - 2021-08-17 07:19:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:22:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:23:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:24:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 07:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:28:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:32:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:33:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:42:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 07:42:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 07:43:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 07:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:44:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 07:45:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:45:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:46:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:48:32 --> 404 Page Not Found: Article/view
ERROR - 2021-08-17 07:48:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:49:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:50:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:50:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:50:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:50:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:50:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:51:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 07:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:52:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:52:51 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-08-17 07:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:55:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 07:57:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:57:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:58:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:58:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 07:59:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:01:29 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-17 08:01:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:04:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:04:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:05:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:05:39 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-17 08:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:07:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 08:08:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 08:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:08:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 08:08:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 08:08:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 08:09:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 08:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:15:01 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-08-17 08:15:01 --> 404 Page Not Found: admin//index
ERROR - 2021-08-17 08:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:15:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 08:15:03 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-08-17 08:15:03 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-08-17 08:15:03 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-08-17 08:15:04 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-08-17 08:15:04 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-08-17 08:15:04 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-08-17 08:15:05 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-08-17 08:15:05 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-08-17 08:15:05 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-17 08:15:05 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-17 08:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:17:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:19:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:25:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 08:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:27:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:30:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:31:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:33:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:34:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:38:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:39:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:42:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:42:59 --> 404 Page Not Found: A/gongchenganli
ERROR - 2021-08-17 08:43:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:44:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:44:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:44:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:45:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:45:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:45:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:46:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:48:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:48:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:49:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:51:37 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-17 08:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:52:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:54:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:56:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:57:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:57:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 08:58:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:58:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:59:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:59:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 08:59:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:00:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 09:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:00:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:00:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:02:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:02:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:03:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:04:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 09:04:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 09:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:05:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:06:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:08:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 09:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:09:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 09:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 09:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 09:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:11:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:11:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:12:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:15:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:15:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:16:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:17:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:20:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:20:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:20:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:20:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:21:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:21:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:21:45 --> 404 Page Not Found: Article/view
ERROR - 2021-08-17 09:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:23:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:24:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:25:32 --> 404 Page Not Found: 1/10000
ERROR - 2021-08-17 09:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:27:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:30:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:31:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:32:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 09:32:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 09:32:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:32:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:34:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:34:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:34:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:36:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:39:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 09:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:39:53 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-17 09:40:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:40:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:42:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:42:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 09:43:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:47:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:47:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 09:47:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:48:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:50:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:51:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:52:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 09:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:53:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 09:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:54:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 09:55:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:56:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:57:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:57:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 09:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 09:59:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 10:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:00:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:01:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:01:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:01:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:01:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:02:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:02:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 10:03:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:04:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:05:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:06:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 10:06:27 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:06:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 10:06:32 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:06:40 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:07:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:09:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:10:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 10:11:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:14:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 10:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:17:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:18:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:19:14 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-17 10:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 10:20:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 10:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:20:42 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-17 10:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:20:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 10:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:21:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 10:21:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 10:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:25:02 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:25:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:25:36 --> 404 Page Not Found: Backup/wp-admin
ERROR - 2021-08-17 10:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:27:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 10:28:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:28:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 10:28:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 10:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:28:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 10:28:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:28:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:28:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 10:28:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 10:29:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 10:29:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 10:29:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 10:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:30:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:34:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:36:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:36:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 10:37:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:38:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:38:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 10:39:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:40:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:43:58 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:44:13 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:46:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:49:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:50:12 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:50:12 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:50:29 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:50:32 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:55:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:56:45 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:56:50 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:57:11 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 10:57:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:57:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 10:58:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 10:59:09 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-17 10:59:09 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-17 10:59:10 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-17 10:59:11 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-17 10:59:11 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-17 10:59:11 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-17 10:59:11 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-17 10:59:11 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-17 10:59:11 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-17 10:59:11 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-17 10:59:11 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-17 10:59:11 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-17 10:59:11 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-17 10:59:12 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-17 10:59:12 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-17 10:59:12 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-17 10:59:12 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-17 10:59:12 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-17 10:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:01:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:01:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 11:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:03:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 11:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:04:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:04:17 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-08-17 11:04:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:06:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 11:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:07:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 11:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:09:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 11:09:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:09:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 11:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:13:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 11:13:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 11:13:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 11:13:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:16:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:17:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:19:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:21:25 --> 404 Page Not Found: Shell/index
ERROR - 2021-08-17 11:21:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:22:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:22:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:23:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:23:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:24:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:24:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:24:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:27:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 11:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 11:27:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 11:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:27:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 11:28:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 11:31:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:35:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:36:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:40:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:40:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:41:52 --> 404 Page Not Found: A/chanpinzhongxin
ERROR - 2021-08-17 11:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:45:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:46:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:47:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:48:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:49:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:51:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:53:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 11:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 11:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:01:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 12:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:05:36 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-08-17 12:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:08:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 12:10:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 12:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:11:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 12:11:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 12:11:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 12:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:12:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 12:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:12:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 12:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:20:21 --> 404 Page Not Found: Nice%20ports%2C/Tri%6Eity.txt%2ebak
ERROR - 2021-08-17 12:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:23:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 12:23:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 12:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 12:24:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 12:24:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 12:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:25:03 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-17 12:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:25:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 12:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 12:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:29:47 --> 404 Page Not Found: Env/index
ERROR - 2021-08-17 12:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:33:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:34:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 12:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:42:54 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-08-17 12:43:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 12:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:45:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 12:46:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 12:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:57:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 12:57:48 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-17 12:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 12:59:54 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-08-17 13:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:02:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:06:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:08:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 13:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:23:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:23:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:23:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 13:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:28:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:35:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:38:08 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-08-17 13:38:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:38:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:39:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:39:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:39:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 13:40:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:40:06 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-08-17 13:41:12 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-17 13:42:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:42:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 13:42:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 13:43:02 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-17 13:43:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 13:43:02 --> 404 Page Not Found: Tourl/index
ERROR - 2021-08-17 13:43:03 --> 404 Page Not Found: Tourl/index
ERROR - 2021-08-17 13:43:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 13:43:03 --> 404 Page Not Found: Tour/index
ERROR - 2021-08-17 13:43:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 13:43:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 13:43:54 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-08-17 13:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:44:15 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-08-17 13:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:45:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:47:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:49:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:51:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:52:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 13:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:53:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:53:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 13:53:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 13:54:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 13:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:56:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 13:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 13:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:02:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:10:51 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-17 14:10:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 14:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:12:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 14:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:12:21 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-17 14:17:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 14:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:21:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 14:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:23:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:33:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:36:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:40:29 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-08-17 14:40:29 --> 404 Page Not Found: admin//index
ERROR - 2021-08-17 14:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:40:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 14:40:29 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-08-17 14:40:29 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-08-17 14:40:29 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-08-17 14:40:30 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-08-17 14:40:30 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-08-17 14:40:30 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-17 14:40:30 --> 404 Page Not Found: Wcm/index
ERROR - 2021-08-17 14:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:45:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 14:45:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:45:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 14:46:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:46:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 14:47:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:48:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:49:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:49:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:50:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:51:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 14:51:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:52:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 14:54:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 14:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:56:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 14:56:52 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-17 14:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:56:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 14:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 14:59:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 14:59:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 14:59:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:00:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:00:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:00:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:03:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:04:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:05:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:05:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:06:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 15:07:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:10:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:13:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:13:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 15:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:15:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:15:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:16:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:17:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:17:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:17:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:17:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:18:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:18:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:18:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:18:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:24:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:24:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:26:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:27:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 15:27:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 15:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:28:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:29:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:30:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 15:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:31:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 15:31:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 15:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:32:39 --> 404 Page Not Found: Env/index
ERROR - 2021-08-17 15:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:40:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 15:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:47:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 15:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 15:55:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:55:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:56:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:56:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 15:57:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:02:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:03:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:07:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:08:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:10:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:10:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:11:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:12:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:13:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:14:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:14:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:14:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:15:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:15:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:19:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:23:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:25:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:30:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:36:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 16:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:40:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 16:41:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 16:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:43:37 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-17 16:44:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:47:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:49:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 16:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:52:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:52:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:55:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:56:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:57:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:57:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:58:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:58:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:58:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 16:58:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:59:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 16:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 16:59:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:01:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:01:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:04:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:04:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:05:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:05:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:08:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:09:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:10:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:10:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:11:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:11:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:12:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 17:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:14:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:15:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:16:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:17:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:18:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:19:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:20:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:20:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:21:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:23:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:23:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:24:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:24:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:24:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:24:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:25:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:26:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:26:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:27:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:28:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:28:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:31:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:31:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:31:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:31:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:31:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:32:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:34:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:35:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:36:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:37:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:37:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:37:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:39:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:40:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:42:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:42:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:43:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:43:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:44:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:44:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:46:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:47:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:48:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:48:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:49:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:50:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:50:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:51:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:51:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:52:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:53:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 17:53:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:53:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:53:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:55:12 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-08-17 17:55:14 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-08-17 17:55:15 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-08-17 17:55:16 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-08-17 17:55:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:55:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:55:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:55:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:56:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:56:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:56:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:58:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:58:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 17:59:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:59:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 17:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:00:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:00:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:02:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:02:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:02:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:02:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:03:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:03:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:04:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:05:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:06:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:10:54 --> Severity: Warning --> Missing argument 1 for Taocan::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 101
ERROR - 2021-08-17 18:11:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:11:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 18:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:21:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 18:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:27:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:30:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:31:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:32:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:35:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 18:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:37:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:39:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:40:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:40:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:40:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:40:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:40:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:40:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:40:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:40:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:40:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:40:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:41:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:42:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:42:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:42:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:42:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:42:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:43:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:43:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:43:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:43:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:43:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:43:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:44:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:46:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:46:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:47:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:48:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:49:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:50:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:51:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:51:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:52:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 18:52:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 18:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:55:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:55:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 18:55:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 18:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 18:56:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:00:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:05:04 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-17 19:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:05:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 19:05:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 19:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:14:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 19:14:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:16:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:16:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 19:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:18:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:20:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:21:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 19:22:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 19:23:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 19:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:24:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:24:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:25:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 19:25:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:25:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:25:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:25:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:27:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:31:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:32:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 19:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:33:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:33:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:34:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 19:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:37:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:37:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:38:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:39:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 19:39:32 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-17 19:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:41:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:41:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:45:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:45:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 19:46:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:47:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:48:04 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-08-17 19:48:04 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-08-17 19:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:49:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:49:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:49:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:53:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:54:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:55:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 19:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 19:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:01:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:03:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:03:09 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-17 20:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:03:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:03:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:04:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:04:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:04:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:04:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:04:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:04:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:05:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:05:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:05:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:06:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:09:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:10:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:10:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:12:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:17:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 20:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:18:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:22:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:26:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 20:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:34:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:35:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 20:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:36:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:36:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 20:37:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:45:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:46:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 20:48:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:48:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:49:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:50:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:50:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:52:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:53:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:53:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:53:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:53:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:53:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:54:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:54:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:55:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:55:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:55:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:55:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:55:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:55:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:55:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:55:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:55:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:56:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-17 20:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:57:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:58:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:58:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 20:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:58:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 20:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 20:59:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:00:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:00:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:00:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:00:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:01:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:01:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:02:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:02:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:02:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:03:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:03:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:04:46 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-08-17 21:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:07:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:07:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:08:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:08:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:09:09 --> Severity: Warning --> Missing argument 1 for Xinxi::show() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 97
ERROR - 2021-08-17 21:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:10:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:10:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:12:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:16:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:17:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:18:29 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-08-17 21:18:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:18:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:18:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:18:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:20:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:25:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:25:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:28:10 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-17 21:28:10 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-17 21:28:10 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-17 21:28:10 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-17 21:28:10 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-17 21:28:10 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-17 21:28:10 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-17 21:28:11 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-17 21:28:12 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-17 21:28:12 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-17 21:28:12 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-17 21:28:12 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-17 21:28:12 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-17 21:28:12 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-17 21:28:12 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-17 21:28:12 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-17 21:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:30:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:30:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:30:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 21:30:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:30:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:30:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:31:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:31:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:31:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:31:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 21:31:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:32:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:40:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 21:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:52:04 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-08-17 21:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 21:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:02:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:03:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 22:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:07:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:08:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:09:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 22:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:12:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:17:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:19:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:19:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 22:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:21:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:28:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:28:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:28:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:29:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:29:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:29:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 22:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:30:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:31:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:31:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:33:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:34:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 22:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:34:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:34:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:35:22 --> 404 Page Not Found: City/1
ERROR - 2021-08-17 22:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:36:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:36:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:36:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:37:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:37:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:37:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:37:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:37:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:37:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:38:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:39:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:39:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:42:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:47:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 22:47:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:47:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-08-17 22:47:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:49:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:50:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:53:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:53:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 22:56:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:58:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 22:58:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 22:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:05:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:06:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 23:06:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 23:06:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 23:06:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-17 23:06:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:08:43 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-08-17 23:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:09:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:10:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:12:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:14:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 23:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:15:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 23:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:20:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:22:53 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-17 23:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:23:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:28:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:31:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:32:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:34:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:42:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:47:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:47:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:48:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-17 23:48:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:50:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-17 23:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:57:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:58:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-17 23:58:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-17 23:59:27 --> 404 Page Not Found: Robotstxt/index
