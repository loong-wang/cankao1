<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-14 00:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:01:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 00:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:09:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 00:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:14:56 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-14 00:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:15:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 00:15:58 --> 404 Page Not Found: Env/index
ERROR - 2021-07-14 00:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:16:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 00:17:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 00:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:23:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 00:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:25:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:42:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 00:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:46:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 00:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:47:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 00:47:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 00:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:52:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 00:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:54:17 --> 404 Page Not Found: English/index
ERROR - 2021-07-14 00:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 00:58:37 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 00:58:37 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 00:58:37 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-14 00:58:37 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 00:58:37 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 00:58:37 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-14 00:58:37 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 00:58:37 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-14 00:58:37 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 00:58:37 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 00:58:38 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-14 00:58:38 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 00:58:38 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 00:58:38 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-14 00:58:38 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-14 00:58:39 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-14 00:58:40 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-14 01:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:02:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 01:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:05:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 01:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:07:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 01:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:17:07 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-14 01:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:20:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:23:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 01:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:31:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 01:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:33:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 01:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:47:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:49:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 01:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:50:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 01:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:57:22 --> 404 Page Not Found: City/1
ERROR - 2021-07-14 01:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:58:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:59:19 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-14 01:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 01:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:04:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:04:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:06:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 02:06:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 02:06:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 02:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:11:12 --> 404 Page Not Found: Portal/redlion
ERROR - 2021-07-14 02:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:13:07 --> 404 Page Not Found: City/15
ERROR - 2021-07-14 02:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:22:14 --> 404 Page Not Found: City/index
ERROR - 2021-07-14 02:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:23:45 --> 404 Page Not Found: City/16
ERROR - 2021-07-14 02:23:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:24:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:25:19 --> 404 Page Not Found: City/2
ERROR - 2021-07-14 02:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:26:58 --> 404 Page Not Found: City/10
ERROR - 2021-07-14 02:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:27:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 02:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:33:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:40:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:46:59 --> 404 Page Not Found: Actuator/health
ERROR - 2021-07-14 02:47:08 --> Severity: Warning --> Missing argument 1 for Taocan::show() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 261
ERROR - 2021-07-14 02:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:49:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 02:50:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 02:50:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 02:50:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 02:50:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 02:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:51:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 02:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 02:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:00:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:08:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 03:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:13:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:14:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:19:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 03:19:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 03:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:20:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:21:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 03:21:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 03:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:25:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:27:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 03:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:29:22 --> 404 Page Not Found: Hudson/index
ERROR - 2021-07-14 03:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:42:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 03:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:43:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 03:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:47:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 03:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 03:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-07-14 04:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:03:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 04:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:06:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 04:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:12:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 04:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:16:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:23:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 04:23:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:27:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 04:27:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 04:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:28:58 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-14 04:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:30:09 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-14 04:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:30:43 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-14 04:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:31:19 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-14 04:31:58 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-14 04:32:34 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-14 04:36:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 04:36:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 04:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:37:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 04:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:39:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:40:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 04:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:42:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 04:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:49:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 04:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:54:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 04:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 04:59:54 --> 404 Page Not Found: English/index
ERROR - 2021-07-14 04:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:00:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 05:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:02:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:04:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 05:05:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:05:52 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-14 05:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:08:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 05:08:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 05:08:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 05:08:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 05:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:13:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:14:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 05:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:15:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 05:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:16:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:19:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 05:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:20:27 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-14 05:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:31:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:31:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 05:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:37:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:39:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 05:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:40:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 05:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:46:26 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-14 05:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:50:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:57:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 05:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 05:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:02:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:02:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 06:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:02:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 06:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:07:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 06:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:11:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 06:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:13:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 06:15:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 06:15:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 06:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 06:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:16:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:17:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:20:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:21:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:21:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 06:21:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 06:23:17 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 06:23:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 06:23:17 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-14 06:23:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 06:23:17 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 06:23:17 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-14 06:23:17 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 06:23:18 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-14 06:23:19 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-14 06:23:19 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-14 06:23:19 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-14 06:23:19 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 06:23:19 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 06:23:19 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 06:23:19 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-14 06:23:19 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-14 06:23:19 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-14 06:26:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:30:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:32:08 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-14 06:33:23 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-14 06:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:33:50 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-14 06:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:42:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 06:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:43:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 06:43:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 06:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:45:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 06:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:47:37 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-07-14 06:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:51:45 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-14 06:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:56:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 06:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 06:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:06:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:07:08 --> 404 Page Not Found: City/1
ERROR - 2021-07-14 07:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:09:39 --> 404 Page Not Found: Webshop/99520.html
ERROR - 2021-07-14 07:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:09:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:09:44 --> 404 Page Not Found: Xxlnj/29780.html
ERROR - 2021-07-14 07:10:10 --> 404 Page Not Found: Dict/index
ERROR - 2021-07-14 07:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:10:32 --> 404 Page Not Found: Error_404html/index
ERROR - 2021-07-14 07:10:38 --> 404 Page Not Found: Gongwen/shenqingshu
ERROR - 2021-07-14 07:10:41 --> 404 Page Not Found: Zddd/201903
ERROR - 2021-07-14 07:10:41 --> 404 Page Not Found: Html/1540.html
ERROR - 2021-07-14 07:10:43 --> 404 Page Not Found: Question/20190924
ERROR - 2021-07-14 07:10:43 --> 404 Page Not Found: W/consistently
ERROR - 2021-07-14 07:10:57 --> 404 Page Not Found: Detail/9
ERROR - 2021-07-14 07:11:34 --> 404 Page Not Found: Slide/225
ERROR - 2021-07-14 07:11:35 --> 404 Page Not Found: Zhishi/687.html
ERROR - 2021-07-14 07:12:23 --> 404 Page Not Found: Gaokao/236946.html
ERROR - 2021-07-14 07:12:24 --> 404 Page Not Found: Susong/5cfab507aa45478a8bd3ea3e16ad2305
ERROR - 2021-07-14 07:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:12:32 --> 404 Page Not Found: Error_404html/index
ERROR - 2021-07-14 07:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:24:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 07:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:25:33 --> 404 Page Not Found: Nmaplowercheck1626218733/index
ERROR - 2021-07-14 07:25:33 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-07-14 07:25:33 --> 404 Page Not Found: Evox/about
ERROR - 2021-07-14 07:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:28:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 07:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 07:35:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 07:35:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 07:36:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 07:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:44:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 07:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:45:51 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-14 07:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:54:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:54:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 07:54:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:54:38 --> 404 Page Not Found: City/1
ERROR - 2021-07-14 07:54:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 07:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:57:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 07:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:01:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 08:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:02:08 --> Severity: Warning --> Missing argument 1 for Kefu::show() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 359
ERROR - 2021-07-14 08:02:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 08:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:08:39 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-14 08:09:00 --> 404 Page Not Found: City/10
ERROR - 2021-07-14 08:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:10:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 08:11:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 08:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:11:49 --> 404 Page Not Found: City/16
ERROR - 2021-07-14 08:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-14 08:12:33 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 08:12:34 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 08:12:35 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 08:12:35 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-14 08:12:35 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-14 08:12:35 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-14 08:12:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 08:12:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 08:13:12 --> 404 Page Not Found: City/16
ERROR - 2021-07-14 08:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:17:11 --> 404 Page Not Found: City/2
ERROR - 2021-07-14 08:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:22:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 08:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:25:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 08:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:34:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 08:35:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 08:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 08:36:34 --> 404 Page Not Found: City/1
ERROR - 2021-07-14 08:37:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 08:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:39:37 --> 404 Page Not Found: City/17
ERROR - 2021-07-14 08:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:42:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 08:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:44:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 08:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:45:53 --> 404 Page Not Found: City/16
ERROR - 2021-07-14 08:46:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 08:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:50:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 08:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:51:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 08:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:52:25 --> 404 Page Not Found: City/10
ERROR - 2021-07-14 08:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:54:33 --> 404 Page Not Found: City/index
ERROR - 2021-07-14 08:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:55:23 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-14 08:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:55:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:56:43 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-14 08:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 08:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:00:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:00:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:01:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 09:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:02:53 --> 404 Page Not Found: Config/getuser
ERROR - 2021-07-14 09:03:54 --> 404 Page Not Found: City/15
ERROR - 2021-07-14 09:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:05:37 --> 404 Page Not Found: City/16
ERROR - 2021-07-14 09:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:06:54 --> 404 Page Not Found: City/index
ERROR - 2021-07-14 09:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:08:09 --> 404 Page Not Found: City/10
ERROR - 2021-07-14 09:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:09:27 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-07-14 09:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:10:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 09:10:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 09:10:49 --> 404 Page Not Found: City/1
ERROR - 2021-07-14 09:11:23 --> 404 Page Not Found: City/2
ERROR - 2021-07-14 09:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:21:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 09:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:24:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 09:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:25:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 09:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:32:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 09:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:35:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 09:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:38:17 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-14 09:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:42:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 09:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:45:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:47:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 09:47:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 09:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:48:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 09:49:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 09:50:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 09:52:08 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-14 09:52:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 09:52:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 09:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:53:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 09:53:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 09:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:55:40 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-14 09:55:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:56:53 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-14 09:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:58:14 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-14 09:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:59:17 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-14 09:59:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 09:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 09:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:00:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 10:00:43 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-14 10:00:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 10:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:14:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 10:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:16:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:19:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 10:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:21:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:22:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 10:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:31:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 10:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:34:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 10:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:38:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 10:38:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 10:38:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 10:38:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 10:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:38:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 10:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:38:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 10:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:40:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:42:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 10:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:44:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 10:44:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:45:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 10:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:50:21 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-14 10:52:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 10:52:54 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-14 10:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:56:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 10:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:56:47 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 10:56:47 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-14 10:56:48 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-14 10:56:49 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-14 10:56:50 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-14 10:56:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 10:57:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 10:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:57:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 10:57:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 10:57:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 10:57:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 10:57:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 10:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 10:59:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 10:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:00:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:00:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:00:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:00:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:00:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:00:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:00:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:00:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:01:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:02:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:02:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:02:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:02:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:02:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:02:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:02:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:02:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:04:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:04:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:04:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:04:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:04:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 11:04:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:05:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:05:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:05:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:05:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:06:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:06:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:06:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:06:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:06:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:06:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 11:06:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 11:07:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:07:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:07:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:07:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:07:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:07:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 11:08:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 11:08:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:08:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 11:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:09:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:09:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:09:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:09:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:09:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:09:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:09:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:09:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:10:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:10:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:10:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:10:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:10:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:10:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:10:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:10:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:11:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 11:11:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:11:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:11:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:11:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:12:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 11:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:12:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:12:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:12:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:12:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:13:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:14:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:14:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:14:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:14:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:14:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:14:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:14:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:14:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:15:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:15:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:15:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:15:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:15:35 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-14 11:15:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:15:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:15:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:15:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:16:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:16:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:16:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:16:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:16:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:17:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:17:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:17:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:17:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:21:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:21:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:21:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:21:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 11:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:23:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 11:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:24:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 11:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:27:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 11:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:31:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 11:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:33:44 --> 404 Page Not Found: City/2
ERROR - 2021-07-14 11:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:37:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:44:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 11:44:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 11:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:47:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 11:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:49:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 11:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:50:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 11:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 11:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:02:06 --> 404 Page Not Found: Article/view
ERROR - 2021-07-14 12:02:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 12:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:07:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:08:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:12:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:13:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 12:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:15:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:15:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:22:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 12:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:23:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 12:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:29:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 12:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:36:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:36:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:36:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:36:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:37:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:40:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:41:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:41:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:42:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:42:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:43:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 12:44:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:46:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:46:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:52:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 12:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:53:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:55:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:55:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 12:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 12:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:00:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:07:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 13:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:09:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:09:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:11:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 13:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:14:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 13:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:20:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:20:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:24:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:24:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:25:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:25:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:26:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:26:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:26:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 13:26:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:27:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:27:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:28:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:28:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:35:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 13:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:37:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:38:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:38:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:38:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:39:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:39:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:39:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:42:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:43:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 13:43:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:43:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:45:50 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-07-14 13:45:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:46:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:46:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:46:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:46:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:46:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:47:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:47:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:49:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:50:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:50:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 13:50:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:51:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:51:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:52:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 13:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:52:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 13:54:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 13:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:55:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 13:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:56:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:58:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:58:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 13:59:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:59:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:59:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 13:59:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:03:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:04:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 14:04:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:07:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:13:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 14:13:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:13:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:13:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:14:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:14:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:14:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:14:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:14:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:14:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:14:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:14:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:16:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:18:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 14:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:20:11 --> 404 Page Not Found: City/1
ERROR - 2021-07-14 14:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:20:19 --> 404 Page Not Found: City/10
ERROR - 2021-07-14 14:20:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 14:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:23:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:24:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 14:25:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:25:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 14:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:26:51 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-07-14 14:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:31:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:33:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:33:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 14:34:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:35:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:35:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 14:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:36:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 14:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:38:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 14:39:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 14:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:40:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:45:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:46:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:47:44 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 14:47:44 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 14:47:44 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-14 14:47:44 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 14:47:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 14:47:44 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-14 14:47:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-14 14:47:45 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-14 14:47:46 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-14 14:47:46 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 14:47:46 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 14:47:46 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 14:47:46 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-14 14:47:46 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-14 14:47:47 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-14 14:47:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 14:49:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:52:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 14:52:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 14:52:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:53:20 --> 404 Page Not Found: City/index
ERROR - 2021-07-14 14:54:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:54:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 14:54:34 --> 404 Page Not Found: City/16
ERROR - 2021-07-14 14:55:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 14:55:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:55:38 --> 404 Page Not Found: City/10
ERROR - 2021-07-14 14:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:56:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 14:56:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:56:39 --> 404 Page Not Found: City/2
ERROR - 2021-07-14 14:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 14:57:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:57:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 14:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:00:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:02:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:04:06 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-14 15:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:04:50 --> 404 Page Not Found: City/15
ERROR - 2021-07-14 15:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:06:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:07:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:08:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:08:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:09:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:10:15 --> 404 Page Not Found: City/1
ERROR - 2021-07-14 15:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:11:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:11:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:11:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:11:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:12:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:12:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:13:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:13:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:13:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:13:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:13:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:14:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:14:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:14:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:14:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:14:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:14:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:15:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:15:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:15:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 15:15:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:15:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:15:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:15:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:16:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:17:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:17:28 --> 404 Page Not Found: City/10
ERROR - 2021-07-14 15:17:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:17:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:18:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:18:50 --> 404 Page Not Found: City/2
ERROR - 2021-07-14 15:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:19:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:20:20 --> 404 Page Not Found: City/15
ERROR - 2021-07-14 15:21:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:22:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 15:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:23:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:23:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:24:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:24:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:25:12 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 15:25:12 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 15:25:12 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 15:25:13 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-14 15:25:14 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 15:25:14 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-14 15:25:14 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-14 15:25:14 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-14 15:25:14 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-14 15:25:14 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 15:25:14 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 15:25:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 15:25:14 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-14 15:25:14 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-14 15:25:14 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-14 15:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:26:05 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-14 15:26:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:26:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 15:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:28:13 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-14 15:28:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:29:23 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-07-14 15:29:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 15:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:29:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 15:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:30:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:31:18 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-14 15:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:32:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:32:15 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-14 15:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:33:18 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-14 15:34:21 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-14 15:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:35:23 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-14 15:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:36:26 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-14 15:36:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 15:36:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:37:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:39:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:39:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:40:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:41:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:42:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:46:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:46:23 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-14 15:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:47:29 --> 404 Page Not Found: 1/10000
ERROR - 2021-07-14 15:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:51:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:52:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 15:52:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 15:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 15:59:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:00:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:00:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:01:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:01:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:01:20 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-14 16:01:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:01:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:02:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:02:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:02:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:02:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:02:49 --> 404 Page Not Found: English/index
ERROR - 2021-07-14 16:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:03:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:03:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:04:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:05:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:05:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:07:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:07:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:07:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:08:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:10:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:12:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:13:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:16:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:19:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:19:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:21:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:21:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:22:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:22:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:23:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:24:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:25:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 16:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:26:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:26:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:29:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:29:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:30:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:32:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:32:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:33:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 16:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:35:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:36:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:36:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:36:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:36:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:36:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:36:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:36:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:36:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:36:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:36:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:36:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:36:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:41:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:42:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:43:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:49:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:49:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:49:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:49:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:49:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:50:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:54:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 16:54:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:55:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:55:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:55:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:56:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:56:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:56:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:56:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:57:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:57:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:57:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:57:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 16:58:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 16:58:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:58:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 16:58:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:58:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 16:59:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 17:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:03:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 17:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:07:11 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-14 17:07:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 17:07:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 17:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:11:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 17:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:12:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 17:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:18:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 17:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 17:22:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 17:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:22:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 17:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:23:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 17:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:26:40 --> 404 Page Not Found: City/16
ERROR - 2021-07-14 17:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:27:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:32:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 17:33:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:35:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 17:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:37:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 17:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:39:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 17:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:43:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 17:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:48:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 17:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:53:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-60, 60' at line 7 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_city` = '1'
AND  `hao_title` LIKE '%8888%' ESCAPE '!'
AND `hao_lock` <=0
ORDER BY `hao_time` DESC
 LIMIT -60, 60
ERROR - 2021-07-14 17:53:29 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 117
ERROR - 2021-07-14 17:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 17:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:00:41 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 18:00:41 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 18:00:42 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-14 18:00:43 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-14 18:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:02:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 18:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:04:32 --> 404 Page Not Found: City/10
ERROR - 2021-07-14 18:04:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:09:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 18:09:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 18:09:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 18:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 18:10:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 18:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:10:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 18:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:15:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 18:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:18:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:21:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 18:23:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 18:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:26:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 18:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:29:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 18:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:38:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 18:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:39:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 18:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:40:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:43:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 18:44:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 18:45:19 --> 404 Page Not Found: English/index
ERROR - 2021-07-14 18:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:50:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 18:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:50:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 18:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:51:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 18:52:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 18:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:53:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:58:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 18:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 18:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:00:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 19:00:36 --> 404 Page Not Found: City/1
ERROR - 2021-07-14 19:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:05:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 19:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:10:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 19:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:11:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 19:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:14:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 19:14:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 19:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:18:57 --> 404 Page Not Found: City/10
ERROR - 2021-07-14 19:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:19:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 19:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:21:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 19:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 19:22:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 19:22:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 19:22:37 --> 404 Page Not Found: City/1
ERROR - 2021-07-14 19:23:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 19:23:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 19:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:23:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 19:23:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:32:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 19:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:33:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 19:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:35:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 19:35:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 19:35:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 19:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:39:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 19:39:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 19:39:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 19:39:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 19:40:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 19:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:42:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:48:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 19:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:55:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 19:56:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 19:56:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 19:56:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 19:58:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 19:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 19:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:02:00 --> 404 Page Not Found: Env/index
ERROR - 2021-07-14 20:02:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 20:03:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:05:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 20:05:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 20:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:09:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 20:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:10:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 20:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:12:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 20:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:16:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 20:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:18:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 20:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:19:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 20:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:27:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 20:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:34:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 20:34:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 20:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:36:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 20:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:39:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:46:00 --> 404 Page Not Found: H5/index
ERROR - 2021-07-14 20:46:00 --> 404 Page Not Found: H5/index
ERROR - 2021-07-14 20:46:01 --> 404 Page Not Found: M/ticker
ERROR - 2021-07-14 20:46:01 --> 404 Page Not Found: M/allticker
ERROR - 2021-07-14 20:46:01 --> 404 Page Not Found: N/news
ERROR - 2021-07-14 20:46:03 --> 404 Page Not Found: Base/exchange_article
ERROR - 2021-07-14 20:46:03 --> 404 Page Not Found: Legal/currency
ERROR - 2021-07-14 20:46:03 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-07-14 20:46:03 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-07-14 20:46:05 --> 404 Page Not Found: User/allroleinfo
ERROR - 2021-07-14 20:46:05 --> 404 Page Not Found: Wap/trading
ERROR - 2021-07-14 20:46:05 --> 404 Page Not Found: Market/market-ws
ERROR - 2021-07-14 20:46:05 --> 404 Page Not Found: Wap/trading
ERROR - 2021-07-14 20:46:06 --> 404 Page Not Found: Otc/index
ERROR - 2021-07-14 20:46:06 --> 404 Page Not Found: Web/api
ERROR - 2021-07-14 20:46:06 --> 404 Page Not Found: Index/login
ERROR - 2021-07-14 20:46:08 --> 404 Page Not Found: Room/getRoomBangFans
ERROR - 2021-07-14 20:46:08 --> 404 Page Not Found: S_api/basic
ERROR - 2021-07-14 20:46:08 --> 404 Page Not Found: Api/user
ERROR - 2021-07-14 20:46:09 --> 404 Page Not Found: Pc/Lang
ERROR - 2021-07-14 20:46:09 --> 404 Page Not Found: Home/Bind
ERROR - 2021-07-14 20:46:10 --> 404 Page Not Found: User/userlist
ERROR - 2021-07-14 20:46:10 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-07-14 20:46:10 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-07-14 20:46:11 --> 404 Page Not Found: Api/content_bottom
ERROR - 2021-07-14 20:46:11 --> 404 Page Not Found: Room/1002
ERROR - 2021-07-14 20:46:11 --> 404 Page Not Found: V1/management
ERROR - 2021-07-14 20:46:12 --> 404 Page Not Found: Ajax/allcoin_a
ERROR - 2021-07-14 20:46:13 --> 404 Page Not Found: Static/local
ERROR - 2021-07-14 20:46:13 --> 404 Page Not Found: GetLocale/index
ERROR - 2021-07-14 20:46:13 --> 404 Page Not Found: S_api/basic
ERROR - 2021-07-14 20:46:15 --> 404 Page Not Found: FePublicInfo/index
ERROR - 2021-07-14 20:46:15 --> 404 Page Not Found: Home/GetAllGameCategory
ERROR - 2021-07-14 20:46:16 --> 404 Page Not Found: Recruit/download_url
ERROR - 2021-07-14 20:46:16 --> 404 Page Not Found: Home/GetQrCodeInfo
ERROR - 2021-07-14 20:46:16 --> 404 Page Not Found: Infe/rest
ERROR - 2021-07-14 20:46:16 --> 404 Page Not Found: Xianyu/index
ERROR - 2021-07-14 20:46:16 --> 404 Page Not Found: Infe/rest
ERROR - 2021-07-14 20:46:17 --> 404 Page Not Found: Mh/phone.do
ERROR - 2021-07-14 20:46:17 --> 404 Page Not Found: Xy/index
ERROR - 2021-07-14 20:46:17 --> 404 Page Not Found: Bannerdo/index
ERROR - 2021-07-14 20:46:18 --> 404 Page Not Found: Iframe/rankgiftgotapi
ERROR - 2021-07-14 20:46:21 --> 404 Page Not Found: Api/v1
ERROR - 2021-07-14 20:46:21 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-07-14 20:46:22 --> 404 Page Not Found: Mobile/v3
ERROR - 2021-07-14 20:46:22 --> 404 Page Not Found: CscpLoginWeb/app
ERROR - 2021-07-14 20:46:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 20:46:23 --> 404 Page Not Found: admin//index
ERROR - 2021-07-14 20:46:23 --> 404 Page Not Found: Home/Get
ERROR - 2021-07-14 20:46:23 --> 404 Page Not Found: Api/ApiHub
ERROR - 2021-07-14 20:46:23 --> 404 Page Not Found: Api/index
ERROR - 2021-07-14 20:46:23 --> 404 Page Not Found: Verificationasp/index
ERROR - 2021-07-14 20:46:24 --> 404 Page Not Found: Site/get-hq
ERROR - 2021-07-14 20:46:24 --> 404 Page Not Found: Home/login
ERROR - 2021-07-14 20:46:24 --> 404 Page Not Found: Api/uploads
ERROR - 2021-07-14 20:46:26 --> 404 Page Not Found: Front/User
ERROR - 2021-07-14 20:46:26 --> 404 Page Not Found: Front/FctPage
ERROR - 2021-07-14 20:46:27 --> 404 Page Not Found: Ajax/index
ERROR - 2021-07-14 20:46:28 --> 404 Page Not Found: Api/Index
ERROR - 2021-07-14 20:46:28 --> 404 Page Not Found: Home/GetInitSource
ERROR - 2021-07-14 20:46:28 --> 404 Page Not Found: Step1asp/index
ERROR - 2021-07-14 20:46:29 --> 404 Page Not Found: Static/data
ERROR - 2021-07-14 20:46:30 --> 404 Page Not Found: Ws/index
ERROR - 2021-07-14 20:46:31 --> 404 Page Not Found: Sign/index
ERROR - 2021-07-14 20:46:32 --> 404 Page Not Found: Ajax/index
ERROR - 2021-07-14 20:46:32 --> 404 Page Not Found: Api/wallet
ERROR - 2021-07-14 20:46:32 --> 404 Page Not Found: H5/index
ERROR - 2021-07-14 20:46:33 --> 404 Page Not Found: Base/goexjs
ERROR - 2021-07-14 20:46:33 --> 404 Page Not Found: Anquan/qgga.asp
ERROR - 2021-07-14 20:46:34 --> 404 Page Not Found: Homes/index
ERROR - 2021-07-14 20:46:35 --> 404 Page Not Found: Promotions/list.mvc
ERROR - 2021-07-14 20:46:35 --> 404 Page Not Found: Index/index
ERROR - 2021-07-14 20:46:35 --> 404 Page Not Found: Api/message
ERROR - 2021-07-14 20:46:36 --> 404 Page Not Found: Api/product
ERROR - 2021-07-14 20:46:36 --> 404 Page Not Found: Api/currency
ERROR - 2021-07-14 20:46:36 --> 404 Page Not Found: Content/favicon.ico
ERROR - 2021-07-14 20:46:37 --> 404 Page Not Found: Wap/Api
ERROR - 2021-07-14 20:46:37 --> 404 Page Not Found: Wap/Api
ERROR - 2021-07-14 20:46:37 --> 404 Page Not Found: Api/mobile
ERROR - 2021-07-14 20:46:37 --> 404 Page Not Found: Api/index
ERROR - 2021-07-14 20:46:38 --> 404 Page Not Found: Stock/search.html
ERROR - 2021-07-14 20:46:38 --> 404 Page Not Found: Index/api
ERROR - 2021-07-14 20:46:40 --> 404 Page Not Found: Loan/index
ERROR - 2021-07-14 20:46:40 --> 404 Page Not Found: Api/exclude
ERROR - 2021-07-14 20:46:40 --> 404 Page Not Found: Api/user
ERROR - 2021-07-14 20:46:40 --> 404 Page Not Found: Kkrps/im_group
ERROR - 2021-07-14 20:46:40 --> 404 Page Not Found: Im/in
ERROR - 2021-07-14 20:46:41 --> 404 Page Not Found: Mytio/config
ERROR - 2021-07-14 20:46:41 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-07-14 20:46:41 --> 404 Page Not Found: Site/info
ERROR - 2021-07-14 20:46:41 --> 404 Page Not Found: Api/common
ERROR - 2021-07-14 20:46:41 --> 404 Page Not Found: Api/config-init
ERROR - 2021-07-14 20:46:42 --> 404 Page Not Found: Portal/index
ERROR - 2021-07-14 20:46:42 --> 404 Page Not Found: Api/site
ERROR - 2021-07-14 20:46:42 --> 404 Page Not Found: Api/stock
ERROR - 2021-07-14 20:46:42 --> 404 Page Not Found: Api/apps
ERROR - 2021-07-14 20:46:42 --> 404 Page Not Found: Api/user
ERROR - 2021-07-14 20:46:42 --> 404 Page Not Found: Appxz/index.html
ERROR - 2021-07-14 20:46:43 --> 404 Page Not Found: Api/contactWay
ERROR - 2021-07-14 20:46:43 --> 404 Page Not Found: Market/getStockBaseInfo
ERROR - 2021-07-14 20:46:44 --> 404 Page Not Found: Api/v1
ERROR - 2021-07-14 20:46:44 --> 404 Page Not Found: M/index
ERROR - 2021-07-14 20:46:45 --> 404 Page Not Found: FriendGroup/list
ERROR - 2021-07-14 20:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:48:43 --> 404 Page Not Found: City/15
ERROR - 2021-07-14 20:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:58:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 20:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 20:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:03:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 21:04:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 21:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:08:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 21:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:08:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 21:08:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 21:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:10:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:14:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 21:15:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 21:15:32 --> 404 Page Not Found: English/index
ERROR - 2021-07-14 21:15:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 21:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:18:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 21:20:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 21:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 21:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:27:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 21:27:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 21:27:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 21:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:28:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 21:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:35:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 21:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:39:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 21:44:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 21:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:53:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 21:53:45 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-14 21:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:56:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 21:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 21:58:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 21:59:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 21:59:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 22:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:01:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:09:11 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-07-14 22:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:10:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 22:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:14:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:15:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 22:15:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:15:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:15:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:15:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:15:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:17:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:18:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:20:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:20:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:20:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:20:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:22:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 22:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:26:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:26:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:26:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:26:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:28:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 22:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:31:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 22:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:32:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 22:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:33:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:33:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:33:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:33:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:33:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:33:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:33:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:33:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:34:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 22:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:34:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:35:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 22:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:36:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 22:36:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 22:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:38:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 22:38:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 22:38:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 22:38:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 22:38:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 22:38:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 22:39:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 22:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:43:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 22:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:44:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 22:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:50:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 22:51:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 22:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:54:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 22:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:55:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 22:56:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 22:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 22:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:00:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 23:01:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 23:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:05:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 23:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:05:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 23:07:31 --> 404 Page Not Found: City/10
ERROR - 2021-07-14 23:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:10:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 23:11:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 23:11:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 23:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:14:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 23:15:14 --> 404 Page Not Found: Undefined/index
ERROR - 2021-07-14 23:15:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 23:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:17:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 23:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:18:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:21:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-14 23:21:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 23:22:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 23:22:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 23:22:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:27:35 --> 404 Page Not Found: City/1
ERROR - 2021-07-14 23:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:29:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 23:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:33:52 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-14 23:34:22 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 23:34:22 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-14 23:34:22 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-14 23:34:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 23:34:22 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-14 23:34:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-14 23:34:22 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-14 23:34:22 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-14 23:34:23 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-14 23:34:24 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-14 23:34:24 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-14 23:34:24 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-14 23:34:24 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-14 23:34:24 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-14 23:34:24 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-14 23:34:24 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-14 23:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:38:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:38:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 23:38:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:38:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 23:39:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 23:39:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 23:39:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:39:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 23:39:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:39:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:39:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:39:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 23:39:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:39:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:40:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-14 23:40:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:40:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:41:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:41:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-14 23:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:45:19 --> 404 Page Not Found: City/1
ERROR - 2021-07-14 23:45:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 23:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:46:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 23:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:47:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 23:47:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 23:48:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 23:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:52:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 23:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:52:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-14 23:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-14 23:57:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-14 23:58:10 --> 404 Page Not Found: Robotstxt/index
