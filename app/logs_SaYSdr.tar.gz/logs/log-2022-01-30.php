<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-30 00:10:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 00:29:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 00:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 00:42:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 00:44:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 00:51:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 00:53:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 00:53:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 00:53:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 00:54:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 00:54:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 00:56:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 01:02:17 --> 404 Page Not Found: Index/index
ERROR - 2022-01-30 01:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 01:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 01:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 01:18:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 01:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 01:31:39 --> 404 Page Not Found: City/index
ERROR - 2022-01-30 01:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 01:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 01:44:02 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2022-01-30 01:47:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 01:47:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 01:50:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 01:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:00:48 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-01-30 02:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:13:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 02:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:35:41 --> 404 Page Not Found: Text4041643481341/index
ERROR - 2022-01-30 02:35:41 --> 404 Page Not Found: Sdk/index
ERROR - 2022-01-30 02:35:41 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-30 02:35:42 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-30 02:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 02:50:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 03:05:34 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-30 03:07:58 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-30 03:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 03:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 03:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 03:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 03:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 03:48:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 03:48:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 03:49:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 03:49:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 04:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 04:10:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 04:10:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 04:10:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 04:11:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 04:11:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 04:11:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 04:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 04:12:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 04:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 04:13:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 04:13:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 04:13:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 04:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 04:16:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 04:16:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 04:17:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 04:17:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 04:21:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 04:22:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 04:31:50 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2022-01-30 04:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 04:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 04:46:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 04:47:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 05:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 05:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 05:41:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 05:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 05:47:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 05:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 05:54:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 06:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 06:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 06:03:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 06:03:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 06:03:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 06:05:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 06:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 06:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 06:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 06:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 06:42:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 06:42:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 06:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 06:52:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 06:52:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 06:53:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 07:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 07:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 07:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 07:12:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 07:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 07:27:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 07:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 07:31:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 07:33:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 07:34:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 07:34:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 07:34:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 07:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 07:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 07:38:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 07:38:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 07:39:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 07:39:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 07:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 07:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 07:48:02 --> 404 Page Not Found: Boaform/admin
ERROR - 2022-01-30 08:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 08:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 08:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 08:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 08:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 08:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 08:18:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 08:21:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 08:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 08:23:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 08:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 08:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 08:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 08:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 08:33:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 08:35:01 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-30 08:37:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 08:38:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 08:38:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 08:38:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 08:44:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 08:44:09 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-30 08:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 08:50:58 --> 404 Page Not Found: Login/index
ERROR - 2022-01-30 08:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 09:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 09:04:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 09:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 09:10:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 09:14:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:15:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:15:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:16:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:16:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 09:17:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:17:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:17:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:18:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:18:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:18:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:20:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:22:25 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-30 09:27:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 09:27:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 09:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 09:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 09:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 09:50:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:53:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:54:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:54:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 09:58:39 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-30 09:58:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 10:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 10:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 10:04:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 10:09:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 10:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 10:10:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 10:10:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 10:12:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 10:12:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 10:13:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 10:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 10:16:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 10:16:53 --> Severity: error --> 11111 test 1
ERROR - 2022-01-30 10:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 10:28:28 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-01-30 10:28:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 10:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 10:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 10:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 10:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 10:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 11:08:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 11:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 11:09:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 11:16:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 11:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 11:18:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:21:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:23:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:23:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:23:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:23:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:24:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:25:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 11:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 11:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 11:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 11:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 11:52:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-30 11:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 11:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 12:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 12:20:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 12:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 12:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 12:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 12:43:11 --> 404 Page Not Found: City/10
ERROR - 2022-01-30 12:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 13:02:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 13:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 13:25:28 --> 404 Page Not Found: Inc/AspCms_AdvJs.asp
ERROR - 2022-01-30 13:25:28 --> 404 Page Not Found: Inc/AspCms_AdvJs.asp
ERROR - 2022-01-30 13:33:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 13:36:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 13:48:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 13:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 13:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 14:00:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 14:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 14:05:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 14:06:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 14:07:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 14:07:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 14:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 14:08:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 14:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 14:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 14:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 14:42:30 --> 404 Page Not Found: Index/index
ERROR - 2022-01-30 14:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 14:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 15:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 15:05:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 15:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 15:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 15:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 15:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 15:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 16:03:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 16:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 16:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 16:20:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 16:24:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 16:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 16:25:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 16:27:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 16:28:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 16:45:19 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-30 16:55:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 17:01:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 17:05:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 17:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 17:10:52 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-30 17:18:35 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-30 17:20:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 17:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 17:30:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-30 17:33:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-01-30 17:34:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 17:35:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 17:39:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 17:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 17:40:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 17:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 17:46:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 17:48:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 17:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 17:54:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 17:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 18:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 18:08:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 18:27:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-30 18:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 18:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 18:37:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 18:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 18:39:17 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2022-01-30 18:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 18:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 18:53:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:53:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:53:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:54:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:55:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:56:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:57:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:57:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:57:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:57:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 18:59:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 19:00:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 19:01:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 19:03:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 19:04:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 19:06:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 19:06:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 19:07:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-01-30 19:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 19:12:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 19:13:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 19:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 19:25:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 19:32:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 19:37:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 19:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 19:44:45 --> 404 Page Not Found: Sitemap42517html/index
ERROR - 2022-01-30 19:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 19:59:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 20:00:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 20:00:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 20:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:11:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 20:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:12:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 20:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:20:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 20:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:41:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 20:41:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 20:49:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:51:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 20:54:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 20:55:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:02:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 21:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:22:32 --> 404 Page Not Found: App/views
ERROR - 2022-01-30 21:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:33:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 21:33:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 21:34:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 21:36:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 21:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 21:43:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 21:44:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 21:44:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 21:44:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 21:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 21:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 22:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 22:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 22:08:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 22:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 22:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 22:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 22:22:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 22:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 22:25:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 22:36:31 --> 404 Page Not Found: Eipyonmgbkudwjc/index
ERROR - 2022-01-30 22:36:32 --> 404 Page Not Found: Api/chat
ERROR - 2022-01-30 22:36:32 --> 404 Page Not Found: Web/wap
ERROR - 2022-01-30 22:36:32 --> 404 Page Not Found: Api/pc
ERROR - 2022-01-30 22:36:32 --> 404 Page Not Found: Btc/system-user
ERROR - 2022-01-30 22:36:32 --> 404 Page Not Found: Info/hide
ERROR - 2022-01-30 22:36:32 --> 404 Page Not Found: Option/coin
ERROR - 2022-01-30 22:36:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Static/wap
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Backend/index
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/index
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Dock/system
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Auth/web
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/zhenren
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/index
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/currency
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/config
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: :8088/index
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/config
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: admin/Event/uploadfile
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Pub/getQhDynamic
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Manifestjson/index
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Pc/tools
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Home/tools
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Application/Home
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Step3asp/index
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/Game
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: AppApi/NotLoggedInApi
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/home
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Xmlb/index
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: V2/start
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/user
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/v1
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/site
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/apps
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Notice/unreadMsgCount
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/v2
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/user
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Sys/setting
ERROR - 2022-01-30 22:36:33 --> 404 Page Not Found: Api/site
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Login/index.asp
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: History_codeshtml/index
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Api/login
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: OpenApi/getHelpInfo
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Api/shares
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Api/sms
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Default_drawnoticeshtml/index
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Js/preload
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Api/product
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Service/index
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Home/login
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Wallet/index
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: User/login.html
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: H5/login
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Shujuku/index.asp
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: En/autonews.html
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Ws/index
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Api/index
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Api/getapi
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: :8013/index
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Mobile/index.html
ERROR - 2022-01-30 22:36:34 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Index/index
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Index/index
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Api/message
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Case/index
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Fei1asp/index
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Business/t-ec-info
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: admin/Auth/login
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Api/uploads
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Ajax/index_b_trends
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Index/login
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Platform/passport
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Index/chat
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Html/wechat
ERROR - 2022-01-30 22:36:35 --> 404 Page Not Found: Melody/api
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Api/index
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: V1/management
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Gethmaspx/index
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Native/getStationInfo.do
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Api/nimcc
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Api/exclude
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: View/game
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Template/Home
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Web/api
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Views/bank
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Index/index
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Index/index
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: M/trial.asp
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Jsonpublic/selectAddtion.asp
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Bin-release/update_descriptor_1.xml
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Index/index
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Resource/ui_config
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Image/delImage
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Login/index
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Loan/SubmitLogin
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Mobile/loan
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Mobile/index
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Mobile/api
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Superadmin/lock.lock
ERROR - 2022-01-30 22:36:36 --> 404 Page Not Found: Static/appAdd.jsp
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Api/Index
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Index/index
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Index/pcpage
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: User/Reg
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Trade/quote
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Index/lotteryHall.do
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Wx/ZFpass.asp
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Msky/v1.0
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Public/1.txt
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: _login/in
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Aw010072asp/index
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: 11txt/index
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Db/admin_yly.sql
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: _vti_pvt/structure.cnf
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Gov/manager
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Manager/top.asp
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Guanyuhtml/index
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Detaila/purchaseorder.asp
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Submitasp/index
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Loginasp/index
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Verificationasp/index
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Serverhtml/index
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: Dd/order.asp
ERROR - 2022-01-30 22:36:37 --> 404 Page Not Found: %23m%23a%23n%23a%23g%23e%23r_/index.asp
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Ht/top.asp
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Networdasp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Wap/tixing.asp
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: 1asp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Manager/index.asp
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Control/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: T3/Account
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Txt_index_dna_cntxt/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: 123/stat_login.asp
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Submit-tbasp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Onlinerunasp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Ye1asp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Vwaitasp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Erroasp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Jiankonghtm/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Instructions/toWait.do
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: S1asp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Error3asp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Postasp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Save2asp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Submitasp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Captchaasp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Zhucheasp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Plus/guestbook
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Code/cxk_xym.asp
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Admin/Index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: User/step1.asp
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: Cxkcasp/index
ERROR - 2022-01-30 22:36:38 --> 404 Page Not Found: %E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8Etxt/index
ERROR - 2022-01-30 22:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 22:47:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 22:47:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 22:51:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 22:52:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 22:55:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 22:56:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 22:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 23:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 23:08:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 23:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 23:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 23:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 23:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 23:28:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 23:37:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-30 23:38:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 23:42:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 23:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 23:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-30 23:55:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-30 23:56:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 23:56:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 23:57:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-30 23:57:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
