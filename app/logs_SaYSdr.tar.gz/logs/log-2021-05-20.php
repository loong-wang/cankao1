<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-20 00:00:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:01:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:02:47 --> 404 Page Not Found: English/index
ERROR - 2021-05-20 00:03:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:05:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 00:06:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 00:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:08:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:09:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:09:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:15:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 00:15:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:16:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 00:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:16:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:19:00 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-05-20 00:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:19:10 --> 404 Page Not Found: User/index
ERROR - 2021-05-20 00:19:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:19:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:24:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:24:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:25:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:25:50 --> Severity: Warning --> Missing argument 1 for Xinxi::show() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 97
ERROR - 2021-05-20 00:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:33:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:33:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 00:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:34:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:34:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 00:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:34:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 00:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 00:35:53 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-20 00:35:54 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-20 00:35:55 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-20 00:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:41:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:42:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:46:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 00:47:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 00:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:47:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:50:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:53:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:56:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:56:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 00:57:06 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-05-20 00:57:13 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-05-20 00:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 00:59:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 01:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:10:22 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-05-20 01:11:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:11:56 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-05-20 01:12:00 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-05-20 01:12:00 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-05-20 01:12:00 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-05-20 01:12:00 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-05-20 01:12:01 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-05-20 01:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:17:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 01:17:22 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-05-20 01:17:23 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-05-20 01:17:23 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-05-20 01:17:23 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-05-20 01:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:17:24 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-05-20 01:17:24 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-05-20 01:17:24 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-05-20 01:17:27 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-05-20 01:17:27 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-05-20 01:17:27 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-05-20 01:17:27 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-05-20 01:17:28 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-05-20 01:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:19:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 01:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:21:18 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-05-20 01:21:19 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-05-20 01:21:19 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-05-20 01:21:19 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-05-20 01:21:19 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-05-20 01:21:20 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-05-20 01:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:26:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 01:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:28:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 01:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:33:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 01:33:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 01:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:42:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 01:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:46:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 01:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:48:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 01:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:50:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 01:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:53:19 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-05-20 01:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:55:29 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-05-20 01:55:32 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-05-20 01:55:34 --> Severity: Warning --> Missing argument 1 for Xinxi::show() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 97
ERROR - 2021-05-20 01:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:56:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 01:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 01:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:04:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:07:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:11:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:11:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:12:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:13:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:18:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:19:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:19:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 02:19:57 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-20 02:19:58 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 02:19:59 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 02:19:59 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 02:19:59 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-20 02:19:59 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-20 02:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:22:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:22:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:24:17 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-05-20 02:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:29:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:30:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:35:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:38:45 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 02:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:39:37 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-05-20 02:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:42:46 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-05-20 02:43:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:43:46 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-05-20 02:44:44 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-05-20 02:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:47:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:49:55 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-05-20 02:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:51:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:53:35 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-05-20 02:53:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 02:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:55:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 02:57:29 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-05-20 02:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:00:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:07:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 03:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:11:17 --> 404 Page Not Found: Wp-admin/index
ERROR - 2021-05-20 03:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:12:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 03:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:13:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 03:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:14:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:15:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:19:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:23:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:28:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:28:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:30:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 03:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:32:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 03:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:34:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 03:35:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:37:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:38:38 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 03:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:44:09 --> 404 Page Not Found: Apply/_notes
ERROR - 2021-05-20 03:44:16 --> 404 Page Not Found: Apply/_notes
ERROR - 2021-05-20 03:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:49:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:52:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:53:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:55:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:55:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:59:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 03:59:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 03:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:01:02 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-05-20 04:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:08:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 04:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:11:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:12:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 04:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:13:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 04:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:20:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 04:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:21:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 04:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:22:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 04:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:27:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:27:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 04:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:33:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 04:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:40:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 04:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:42:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 04:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:44:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:44:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:44:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:45:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:45:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:46:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:46:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:46:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:47:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:47:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 04:47:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:47:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:47:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:48:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:48:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:49:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:49:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:49:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:50:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:50:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:50:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:51:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:51:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:52:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:52:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:52:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:53:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:53:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 04:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 04:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:00:12 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2021-05-20 05:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:06:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 05:06:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 05:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:09:36 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2021-05-20 05:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:15:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:16:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:19:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:20:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:20:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:21:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:25:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:26:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:27:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:28:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 05:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:30:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:36:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:37:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:48:23 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-05-20 05:49:52 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-05-20 05:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:51:23 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-05-20 05:51:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 05:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:52:58 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-05-20 05:54:33 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-05-20 05:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:56:01 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-05-20 05:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:56:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 05:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:11:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:13:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:14:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:15:27 --> 404 Page Not Found: Seterphpsuspected/index
ERROR - 2021-05-20 06:17:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 06:19:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:20:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:22:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:24:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:25:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:25:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:26:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:30:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:30:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:31:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:34:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:36:57 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 06:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:38:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 06:38:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 06:38:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 06:38:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 06:39:00 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 06:39:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 06:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:40:03 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-05-20 06:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:40:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:47:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:48:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 06:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 06:58:27 --> 404 Page Not Found: Indexrss/index
ERROR - 2021-05-20 06:58:27 --> 404 Page Not Found: Feeds/index
ERROR - 2021-05-20 06:58:27 --> 404 Page Not Found: Indexxml/index
ERROR - 2021-05-20 06:58:27 --> 404 Page Not Found: Feed/index
ERROR - 2021-05-20 06:58:27 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-05-20 06:58:27 --> 404 Page Not Found: Indexrdf/index
ERROR - 2021-05-20 06:59:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 07:00:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 07:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:02:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 07:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:05:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:07:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 07:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:12:57 --> 404 Page Not Found: Feeds/index
ERROR - 2021-05-20 07:12:57 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-05-20 07:12:57 --> 404 Page Not Found: Indexrss/index
ERROR - 2021-05-20 07:12:57 --> 404 Page Not Found: Feed/index
ERROR - 2021-05-20 07:12:57 --> 404 Page Not Found: Indexrdf/index
ERROR - 2021-05-20 07:12:57 --> 404 Page Not Found: Indexxml/index
ERROR - 2021-05-20 07:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:30:03 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-05-20 07:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:35:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 07:35:16 --> 404 Page Not Found: English/index
ERROR - 2021-05-20 07:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:39:38 --> 404 Page Not Found: 0bef/index
ERROR - 2021-05-20 07:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:40:59 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 07:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:42:53 --> 404 Page Not Found: 1/10000
ERROR - 2021-05-20 07:43:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 07:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:49:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:49:07 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 07:49:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 07:49:07 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-20 07:49:07 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 07:49:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 07:49:07 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-20 07:49:07 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 07:49:07 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-20 07:49:07 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 07:49:07 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 07:49:07 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-20 07:49:08 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-20 07:49:09 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 07:49:09 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 07:49:09 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 07:49:09 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-20 07:49:09 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-20 07:49:09 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-20 07:49:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 07:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:50:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 07:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:52:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 07:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:56:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 07:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:59:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 07:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:05:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 08:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:08:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 08:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:08:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 08:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 08:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:18:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:25:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 08:26:00 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-05-20 08:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:28:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 08:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:35:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 08:35:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 08:37:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 08:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:42:31 --> 404 Page Not Found: Feeds/index
ERROR - 2021-05-20 08:42:31 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-05-20 08:42:31 --> 404 Page Not Found: Feed/index
ERROR - 2021-05-20 08:42:31 --> 404 Page Not Found: Indexrss/index
ERROR - 2021-05-20 08:42:31 --> 404 Page Not Found: Indexrdf/index
ERROR - 2021-05-20 08:42:32 --> 404 Page Not Found: Indexxml/index
ERROR - 2021-05-20 08:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:45:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 08:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:49:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 08:51:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 08:51:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 08:51:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 08:52:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 08:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:52:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 08:54:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 08:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:55:45 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-05-20 08:56:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 08:57:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 08:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 08:59:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 08:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:00:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 09:00:08 --> 404 Page Not Found: Newsinfo/-2755.html
ERROR - 2021-05-20 09:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:01:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 09:01:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:03:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:11:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:11:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:13:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:14:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:14:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 09:19:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 09:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:20:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:20:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:23:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:27:37 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-05-20 09:27:37 --> 404 Page Not Found: Indexrdf/index
ERROR - 2021-05-20 09:27:37 --> 404 Page Not Found: Feed/index
ERROR - 2021-05-20 09:27:37 --> 404 Page Not Found: Indexrss/index
ERROR - 2021-05-20 09:27:37 --> 404 Page Not Found: Feeds/index
ERROR - 2021-05-20 09:27:37 --> 404 Page Not Found: Indexxml/index
ERROR - 2021-05-20 09:29:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:30:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:34:12 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 09:34:12 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 09:34:12 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-20 09:34:12 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 09:34:12 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 09:34:12 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-20 09:34:12 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 09:34:12 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-20 09:34:12 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 09:34:12 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 09:34:13 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 09:34:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 09:34:14 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-20 09:34:14 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-20 09:34:14 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-20 09:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:35:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 09:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:41:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:44:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 09:46:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:46:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 09:47:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:47:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 09:47:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:47:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:47:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 09:47:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 09:48:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:48:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:48:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:48:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:48:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 09:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:53:39 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 09:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:54:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:54:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:54:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:54:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 09:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:57:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 09:57:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 09:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:00:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:03:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:05:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 10:06:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:08:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 10:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:12:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:20:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:21:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:25:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:29:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:33:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:34:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:36:25 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 10:36:32 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 10:36:59 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 10:37:01 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 10:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:41:19 --> 404 Page Not Found: Order/hforder
ERROR - 2021-05-20 10:41:19 --> 404 Page Not Found: Content/253.html
ERROR - 2021-05-20 10:41:32 --> 404 Page Not Found: Defaultaspx/index
ERROR - 2021-05-20 10:41:39 --> 404 Page Not Found: Jcerp/index
ERROR - 2021-05-20 10:41:41 --> 404 Page Not Found: Z/d8
ERROR - 2021-05-20 10:41:54 --> 404 Page Not Found: Ebtouch/Client
ERROR - 2021-05-20 10:42:03 --> 404 Page Not Found: Vod/type
ERROR - 2021-05-20 10:42:07 --> 404 Page Not Found: NTRdrBookRetraspx/index
ERROR - 2021-05-20 10:42:08 --> 404 Page Not Found: Uniformaspx/index
ERROR - 2021-05-20 10:42:12 --> 404 Page Not Found: Spa/workflow
ERROR - 2021-05-20 10:42:13 --> 404 Page Not Found: YllhjDoc/yllhjDoc
ERROR - 2021-05-20 10:42:16 --> 404 Page Not Found: Experiment/Home
ERROR - 2021-05-20 10:42:19 --> 404 Page Not Found: Defaultroot/public
ERROR - 2021-05-20 10:42:23 --> 404 Page Not Found: Nk/html
ERROR - 2021-05-20 10:42:25 --> 404 Page Not Found: OAHome/WorkDetail
ERROR - 2021-05-20 10:42:31 --> 404 Page Not Found: JSXSX/MainAction.do
ERROR - 2021-05-20 10:42:33 --> 404 Page Not Found: Ershoufang/1586951016_9.html
ERROR - 2021-05-20 10:42:35 --> 404 Page Not Found: Seeyon/fileDownload.do
ERROR - 2021-05-20 10:42:36 --> 404 Page Not Found: Km/review
ERROR - 2021-05-20 10:42:36 --> 404 Page Not Found: Defaultaspx/index
ERROR - 2021-05-20 10:42:39 --> 404 Page Not Found: Sz/gangbi.asp
ERROR - 2021-05-20 10:42:42 --> 404 Page Not Found: Shop/tally
ERROR - 2021-05-20 10:42:43 --> 404 Page Not Found: Oa/ViewFilesInfoDetail
ERROR - 2021-05-20 10:43:01 --> 404 Page Not Found: Ioeweb/woOrder
ERROR - 2021-05-20 10:43:03 --> 404 Page Not Found: Flow/fl_ui_main.aspx
ERROR - 2021-05-20 10:43:07 --> 404 Page Not Found: Tender/info
ERROR - 2021-05-20 10:43:11 --> 404 Page Not Found: Gsmi_erp/%E5%88%86%E6%88%B7%E6%8A%A5%E8%A1%A8%E6%9F%A5%E7%9C%8B
ERROR - 2021-05-20 10:43:12 --> 404 Page Not Found: Errorhtm/index
ERROR - 2021-05-20 10:43:16 --> 404 Page Not Found: Spa/workflow
ERROR - 2021-05-20 10:43:19 --> 404 Page Not Found: 2021/05
ERROR - 2021-05-20 10:43:21 --> 404 Page Not Found: Member/receipt
ERROR - 2021-05-20 10:43:22 --> 404 Page Not Found: Book/%E4%B8%AD%E5%A4%AE%E6%88%8F%E5%89%A7%E5%AD%A6%E9%99%A2%E6%95%99%E6%9D%90%E4%B8%9B%E4%B9%A6%E5%BD%B1%E8%A7%86%E5%88%B6%E7%89%87%E7%AE%A1%E7%90%86-15674-chm.html
ERROR - 2021-05-20 10:43:23 --> 404 Page Not Found: Errorhtm/index
ERROR - 2021-05-20 10:43:24 --> 404 Page Not Found: Sso/oauth_gz
ERROR - 2021-05-20 10:43:27 --> 404 Page Not Found: ReportBillDetail/index
ERROR - 2021-05-20 10:43:28 --> 404 Page Not Found: ShippingAgency/EDO
ERROR - 2021-05-20 10:43:29 --> 404 Page Not Found: Member/Login.aspx
ERROR - 2021-05-20 10:43:30 --> 404 Page Not Found: Gradthesis/login.jsp
ERROR - 2021-05-20 10:43:33 --> 404 Page Not Found: Zdmxwq4/index
ERROR - 2021-05-20 10:43:34 --> 404 Page Not Found: Category-636-b0html/index
ERROR - 2021-05-20 10:43:41 --> 404 Page Not Found: Vodtype/2.html
ERROR - 2021-05-20 10:43:46 --> 404 Page Not Found: Redmine/users
ERROR - 2021-05-20 10:43:48 --> 404 Page Not Found: BaseDataInfo/ByHCT
ERROR - 2021-05-20 10:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:44:14 --> 404 Page Not Found: Zffw/yiliaobxbs
ERROR - 2021-05-20 10:44:20 --> 404 Page Not Found: Scp/pages
ERROR - 2021-05-20 10:44:25 --> 404 Page Not Found: Thread-500276-1-1html/index
ERROR - 2021-05-20 10:44:30 --> 404 Page Not Found: Web_Dtx/contractPayment
ERROR - 2021-05-20 10:44:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:44:54 --> 404 Page Not Found: Hndex/5ategory
ERROR - 2021-05-20 10:44:55 --> 404 Page Not Found: 2085927/2021-01-17
ERROR - 2021-05-20 10:44:57 --> 404 Page Not Found: Simulation/simulationView.do
ERROR - 2021-05-20 10:44:58 --> 404 Page Not Found: Account/Login
ERROR - 2021-05-20 10:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:45:12 --> 404 Page Not Found: Pay/pay
ERROR - 2021-05-20 10:45:16 --> 404 Page Not Found: InfoAffirmRYhtml/index
ERROR - 2021-05-20 10:45:24 --> 404 Page Not Found: admin/Storage_bill/print
ERROR - 2021-05-20 10:45:26 --> 404 Page Not Found: Route/route
ERROR - 2021-05-20 10:45:27 --> 404 Page Not Found: MyWorkflow/WF_ProcessHandle_Form.aspx
ERROR - 2021-05-20 10:45:42 --> 404 Page Not Found: Tmw/24
ERROR - 2021-05-20 10:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:45:52 --> 404 Page Not Found: House/search
ERROR - 2021-05-20 10:45:58 --> 404 Page Not Found: Changfang/zIxusVxaNqy.htm
ERROR - 2021-05-20 10:45:59 --> 404 Page Not Found: Gallery-12-indexhtml/index
ERROR - 2021-05-20 10:46:05 --> 404 Page Not Found: Userasp/index
ERROR - 2021-05-20 10:46:08 --> 404 Page Not Found: View/index
ERROR - 2021-05-20 10:46:18 --> 404 Page Not Found: Gzsw/report.pdf
ERROR - 2021-05-20 10:46:27 --> 404 Page Not Found: Tj-live-anchor/index
ERROR - 2021-05-20 10:46:32 --> 404 Page Not Found: Loupan/yibinqu
ERROR - 2021-05-20 10:46:34 --> 404 Page Not Found: Xinwen/5378-%E4%B8%AD%E5%85%B1%E4%B8%AD%E5%A4%AE%E5%A7%94%E5%91%98%E3%80%81%E6%96%B0%E5%8D%8E%E7%A4%BE%E5%8E%9F%E7%A4%BE%E9%95%BF%E6%9D%8E%E4%BB%8E%E5%86%9B%E6%9D%A5%E6%B1%9F%E5%AE%81%E5%BC%80%E5%8F%91%E5%8C%BA%E8%B0%83%E7%A0%94
ERROR - 2021-05-20 10:46:52 --> 404 Page Not Found: StuDetailasp/index
ERROR - 2021-05-20 10:46:54 --> 404 Page Not Found: Kng/plan
ERROR - 2021-05-20 10:46:56 --> 404 Page Not Found: Models/12381
ERROR - 2021-05-20 10:46:58 --> 404 Page Not Found: Wui/main.jsp
ERROR - 2021-05-20 10:47:00 --> 404 Page Not Found: 111965html/index
ERROR - 2021-05-20 10:47:12 --> 404 Page Not Found: Reseller/RsNewCso.aspx
ERROR - 2021-05-20 10:47:14 --> 404 Page Not Found: Bbs/13601bbs10.html
ERROR - 2021-05-20 10:47:17 --> 404 Page Not Found: Spzs/html
ERROR - 2021-05-20 10:47:18 --> 404 Page Not Found: Seeyon/govdoc
ERROR - 2021-05-20 10:47:21 --> 404 Page Not Found: Pres/ser
ERROR - 2021-05-20 10:47:22 --> 404 Page Not Found: News_indexaspx/index
ERROR - 2021-05-20 10:47:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 10:47:37 --> 404 Page Not Found: Portal/article
ERROR - 2021-05-20 10:47:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:52:01 --> 404 Page Not Found: View/15.html
ERROR - 2021-05-20 10:52:02 --> 404 Page Not Found: Myroom/complete
ERROR - 2021-05-20 10:52:03 --> 404 Page Not Found: E/search
ERROR - 2021-05-20 10:52:03 --> 404 Page Not Found: 20000/14699469.html
ERROR - 2021-05-20 10:52:08 --> 404 Page Not Found: Companyinfoasp/index
ERROR - 2021-05-20 10:52:35 --> 404 Page Not Found: 17824html/index
ERROR - 2021-05-20 10:52:38 --> 404 Page Not Found: Login/login.htm
ERROR - 2021-05-20 10:52:38 --> 404 Page Not Found: Login/pay
ERROR - 2021-05-20 10:52:40 --> 404 Page Not Found: Website_keyun/news_show.aspx
ERROR - 2021-05-20 10:52:40 --> 404 Page Not Found: SBZXYL/394.html
ERROR - 2021-05-20 10:52:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:52:47 --> 404 Page Not Found: Guonei/41-527.html
ERROR - 2021-05-20 10:52:59 --> 404 Page Not Found: Products/list-53_2.html
ERROR - 2021-05-20 10:53:00 --> 404 Page Not Found: Article/215501.html
ERROR - 2021-05-20 10:53:03 --> 404 Page Not Found: Fang/fczx
ERROR - 2021-05-20 10:53:21 --> 404 Page Not Found: Service-detail/index
ERROR - 2021-05-20 10:53:22 --> 404 Page Not Found: Loginaspx/index
ERROR - 2021-05-20 10:53:30 --> 404 Page Not Found: Guide/index
ERROR - 2021-05-20 10:53:36 --> 404 Page Not Found: Search/index
ERROR - 2021-05-20 10:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:53:36 --> 404 Page Not Found: Videos/show_41502.html
ERROR - 2021-05-20 10:53:38 --> 404 Page Not Found: Learn/package
ERROR - 2021-05-20 10:53:51 --> 404 Page Not Found: Bep/bep
ERROR - 2021-05-20 10:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:54:10 --> 404 Page Not Found: Shownewsasp/index
ERROR - 2021-05-20 10:54:27 --> 404 Page Not Found: Index/article
ERROR - 2021-05-20 10:54:28 --> 404 Page Not Found: Spa/workflow
ERROR - 2021-05-20 10:54:33 --> 404 Page Not Found: BIG5/8722
ERROR - 2021-05-20 10:54:37 --> 404 Page Not Found: Down/index
ERROR - 2021-05-20 10:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:54:50 --> 404 Page Not Found: Ycqwz/appealDealAction.do
ERROR - 2021-05-20 10:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:54:58 --> 404 Page Not Found: ReadNewsaspx/index
ERROR - 2021-05-20 10:54:58 --> 404 Page Not Found: Testcase-browse-10--byModule-1598-id_desc-35-20-2html/index
ERROR - 2021-05-20 10:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:54:59 --> 404 Page Not Found: Displayasp/index
ERROR - 2021-05-20 10:55:01 --> 404 Page Not Found: Jishu/jichu
ERROR - 2021-05-20 10:55:31 --> 404 Page Not Found: News-detailaspx/index
ERROR - 2021-05-20 10:56:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 10:56:31 --> 404 Page Not Found: Content/index
ERROR - 2021-05-20 10:56:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 10:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:57:17 --> 404 Page Not Found: Course/explore
ERROR - 2021-05-20 10:58:42 --> 404 Page Not Found: English/index
ERROR - 2021-05-20 10:58:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 10:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 10:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:02:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 11:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 11:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:05:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 11:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:11:06 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 11:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:14:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 11:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:18:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:19:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 11:19:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 11:19:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 11:20:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 11:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:23:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 11:23:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 11:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:30:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 11:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:34:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 11:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:39:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:52:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 11:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-05-20 11:54:30 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-05-20 11:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:56:49 --> 404 Page Not Found: Indexrdf/index
ERROR - 2021-05-20 11:56:49 --> 404 Page Not Found: Feeds/index
ERROR - 2021-05-20 11:56:49 --> 404 Page Not Found: Indexxml/index
ERROR - 2021-05-20 11:56:49 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-05-20 11:56:49 --> 404 Page Not Found: Indexrss/index
ERROR - 2021-05-20 11:56:49 --> 404 Page Not Found: Feed/index
ERROR - 2021-05-20 11:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 11:58:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:02:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:08:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 12:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:22:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 12:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:23:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 12:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:26:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:26:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:30:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:40:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:41:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:43:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 12:43:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 12:43:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 12:43:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 12:43:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 12:43:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 12:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:43:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 12:44:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 12:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:47:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:48:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 12:48:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 12:48:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 12:48:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:48:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 12:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:49:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 12:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:50:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:50:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 12:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:54:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:57:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:57:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 12:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 12:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:00:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:02:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:02:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:03:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 13:03:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 13:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:07:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:08:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:09:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:09:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:10:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:11:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:11:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:11:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:12:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:15:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:15:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:16:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:17:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:23:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:28:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:31:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:32:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:33:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:33:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:34:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:34:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:36:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:37:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:40:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:44:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:44:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 13:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:44:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:47:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:47:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:52:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 13:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:58:18 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 13:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 13:59:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 13:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:00:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 14:00:17 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 14:00:18 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 14:00:19 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-20 14:00:19 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-20 14:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:02:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:03:32 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 14:03:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 14:03:32 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-20 14:03:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 14:03:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 14:03:32 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-20 14:03:33 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 14:03:33 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-20 14:03:34 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 14:03:35 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-20 14:03:35 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-20 14:03:35 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-20 14:03:35 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-20 14:03:36 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 14:03:36 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 14:03:36 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 14:03:36 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-20 14:03:36 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-20 14:03:36 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-20 14:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:06:23 --> 404 Page Not Found: Config/getuser
ERROR - 2021-05-20 14:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:07:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:07:38 --> 404 Page Not Found: 10/10000
ERROR - 2021-05-20 14:07:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:08:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:10:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:10:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:10:43 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 14:10:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:11:41 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 14:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:14:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:14:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:18:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 14:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:20:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:26:57 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-05-20 14:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:27:34 --> 404 Page Not Found: English/index
ERROR - 2021-05-20 14:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:30:07 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-05-20 14:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:30:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:31:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 14:32:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:32:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:34:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 14:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:35:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 14:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:37:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 14:37:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 14:37:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 14:37:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 14:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:37:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 14:37:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 14:37:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 14:37:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 14:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:39:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:39:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:43:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:44:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:44:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:44:58 --> 404 Page Not Found: Client_area/index
ERROR - 2021-05-20 14:45:01 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2021-05-20 14:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:45:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:45:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:46:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:46:37 --> 404 Page Not Found: Feeds/index
ERROR - 2021-05-20 14:46:37 --> 404 Page Not Found: Indexrss/index
ERROR - 2021-05-20 14:46:37 --> 404 Page Not Found: Feed/index
ERROR - 2021-05-20 14:46:37 --> 404 Page Not Found: Indexrdf/index
ERROR - 2021-05-20 14:46:37 --> 404 Page Not Found: Indexxml/index
ERROR - 2021-05-20 14:46:38 --> 404 Page Not Found: Rssxml/index
ERROR - 2021-05-20 14:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:50:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:51:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:51:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:52:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:52:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 14:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:56:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 14:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 14:59:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:01:11 --> 404 Page Not Found: City/16
ERROR - 2021-05-20 15:01:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 15:02:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:06:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:06:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:10:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 15:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:14:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:15:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:16:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:17:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 15:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:19:01 --> Severity: Warning --> Missing argument 1 for News::show() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 581
ERROR - 2021-05-20 15:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:21:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:23:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 15:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:26:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:27:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 15:27:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 15:29:12 --> 404 Page Not Found: Shell/index
ERROR - 2021-05-20 15:29:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:30:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:33:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 15:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:34:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 15:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:34:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 15:35:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 15:35:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:35:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:36:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:37:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 15:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:39:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 15:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:39:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:42:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:43:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:47:42 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-05-20 15:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:48:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:50:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:55:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:56:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 15:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:59:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 15:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:00:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:00:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:01:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:02:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:09:36 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-05-20 16:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:12:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:12:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:13:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:16:01 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 16:16:01 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 16:16:01 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-05-20 16:16:01 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-05-20 16:16:01 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 16:16:01 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-05-20 16:16:01 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-05-20 16:16:02 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-05-20 16:16:03 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-05-20 16:16:03 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-05-20 16:16:03 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-05-20 16:16:03 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-05-20 16:16:03 --> 404 Page Not Found: Webrar/index
ERROR - 2021-05-20 16:16:03 --> 404 Page Not Found: Webzip/index
ERROR - 2021-05-20 16:16:03 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-05-20 16:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:18:58 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-05-20 16:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:24:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:25:21 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-05-20 16:25:27 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-05-20 16:25:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:26:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 16:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:27:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:28:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:28:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 16:29:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:30:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 16:30:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:30:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:31:03 --> 404 Page Not Found: Www20210518rar/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Wwwxuanhaonet20210518rar/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Www_xuanhao_net20210518rar/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Wwwxuanhaonet20210518rar/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Xuanhaonet20210518rar/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Xuanhao_net20210518rar/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Xuanhaonet20210518rar/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Xuanhao20210518rar/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Www20210518targz/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Wwwxuanhaonet20210518targz/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Www_xuanhao_net20210518targz/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Wwwxuanhaonet20210518targz/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Xuanhaonet20210518targz/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Xuanhao_net20210518targz/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Xuanhaonet20210518targz/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Xuanhao20210518targz/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Www20210518zip/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Wwwxuanhaonet20210518zip/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Www_xuanhao_net20210518zip/index
ERROR - 2021-05-20 16:31:04 --> 404 Page Not Found: Wwwxuanhaonet20210518zip/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Xuanhaonet20210518zip/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Xuanhao_net20210518zip/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Xuanhaonet20210518zip/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Xuanhao20210518zip/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Www2021-05-18rar/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Wwwxuanhaonet2021-05-18rar/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Www_xuanhao_net2021-05-18rar/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Wwwxuanhaonet2021-05-18rar/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Xuanhaonet2021-05-18rar/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Xuanhao_net2021-05-18rar/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Xuanhaonet2021-05-18rar/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Xuanhao2021-05-18rar/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Www2021-05-18targz/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Wwwxuanhaonet2021-05-18targz/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Www_xuanhao_net2021-05-18targz/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Wwwxuanhaonet2021-05-18targz/index
ERROR - 2021-05-20 16:31:05 --> 404 Page Not Found: Xuanhaonet2021-05-18targz/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Xuanhao_net2021-05-18targz/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Xuanhaonet2021-05-18targz/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Xuanhao2021-05-18targz/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Www2021-05-18zip/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Wwwxuanhaonet2021-05-18zip/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Www_xuanhao_net2021-05-18zip/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Wwwxuanhaonet2021-05-18zip/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Xuanhaonet2021-05-18zip/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Xuanhao_net2021-05-18zip/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Xuanhaonet2021-05-18zip/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Xuanhao2021-05-18zip/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Www20210518rar/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Wwwxuanhaonet20210518rar/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Www_xuanhao_net20210518rar/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Wwwxuanhaonet20210518rar/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Xuanhaonet20210518rar/index
ERROR - 2021-05-20 16:31:06 --> 404 Page Not Found: Xuanhao_net20210518rar/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Xuanhaonet20210518rar/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Xuanhao20210518rar/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Www20210518targz/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Wwwxuanhaonet20210518targz/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Www_xuanhao_net20210518targz/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Wwwxuanhaonet20210518targz/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Xuanhaonet20210518targz/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Xuanhao_net20210518targz/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Xuanhaonet20210518targz/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Xuanhao20210518targz/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Www20210518zip/index
ERROR - 2021-05-20 16:31:07 --> 404 Page Not Found: Wwwxuanhaonet20210518zip/index
ERROR - 2021-05-20 16:31:08 --> 404 Page Not Found: Www_xuanhao_net20210518zip/index
ERROR - 2021-05-20 16:31:08 --> 404 Page Not Found: Wwwxuanhaonet20210518zip/index
ERROR - 2021-05-20 16:31:08 --> 404 Page Not Found: Xuanhaonet20210518zip/index
ERROR - 2021-05-20 16:31:08 --> 404 Page Not Found: Xuanhao_net20210518zip/index
ERROR - 2021-05-20 16:31:08 --> 404 Page Not Found: Xuanhaonet20210518zip/index
ERROR - 2021-05-20 16:31:08 --> 404 Page Not Found: Xuanhao20210518zip/index
ERROR - 2021-05-20 16:31:08 --> 404 Page Not Found: 20210518rar/index
ERROR - 2021-05-20 16:31:08 --> 404 Page Not Found: 20210518targz/index
ERROR - 2021-05-20 16:31:08 --> 404 Page Not Found: 20210518zip/index
ERROR - 2021-05-20 16:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:37:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:38:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:40:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:41:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:44:23 --> 404 Page Not Found: Sznews/20171017
ERROR - 2021-05-20 16:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:44:38 --> 404 Page Not Found: Gzwl/shiti_id_92fd2bbb4639c0e78edc1e1a546e4b27
ERROR - 2021-05-20 16:44:42 --> 404 Page Not Found: Win7/index
ERROR - 2021-05-20 16:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:46:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:46:09 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-05-20 16:46:37 --> 404 Page Not Found: City/10
ERROR - 2021-05-20 16:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:47:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:47:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 16:47:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:48:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:48:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:49:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:53:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:54:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:54:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 16:55:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:58:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 16:59:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 16:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:07:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 17:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:12:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 17:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:13:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 17:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:14:20 --> 404 Page Not Found: English/index
ERROR - 2021-05-20 17:14:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 17:14:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 17:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:15:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 17:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:17:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 17:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:18:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 17:18:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 17:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:21:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:33:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 17:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:39:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:41:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 17:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:43:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:45:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 17:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:49:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 17:49:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:53:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 17:53:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 17:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:54:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 17:54:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 17:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 17:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:00:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:00:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 18:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:05:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:09:57 --> 404 Page Not Found: Wp-admin/index
ERROR - 2021-05-20 18:10:10 --> 404 Page Not Found: Wp-admin/index
ERROR - 2021-05-20 18:10:10 --> 404 Page Not Found: Wp-admin/index
ERROR - 2021-05-20 18:11:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:12:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:13:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:15:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:22:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:29:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 18:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:30:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:31:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:32:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:35:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:42:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:43:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:45:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:47:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 18:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:49:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 18:49:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 18:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:52:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:56:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:57:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 18:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:58:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 18:58:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 18:58:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 18:58:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 18:58:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 18:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 18:59:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:01:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:07:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:10:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:10:17 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-05-20 19:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:12:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:13:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:15:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:16:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:16:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:17:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:20:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:20:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:21:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:23:11 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-05-20 19:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:23:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:24:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:24:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:24:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:25:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:25:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:26:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:26:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:27:39 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-05-20 19:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:28:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:29:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:29:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:29:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:30:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:30:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:31:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:31:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:33:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:33:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:33:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:33:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:33:53 --> 404 Page Not Found: City/10
ERROR - 2021-05-20 19:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:34:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:34:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:34:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:34:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:35:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:35:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:36:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:38:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:38:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:38:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:38:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:40:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:40:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:40:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:40:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 19:40:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:41:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:41:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:41:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:44:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:47:31 --> 404 Page Not Found: City/index
ERROR - 2021-05-20 19:47:36 --> 404 Page Not Found: City/1
ERROR - 2021-05-20 19:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:49:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:49:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 19:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:51:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:52:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 19:58:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 19:59:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:03:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 20:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:07:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:07:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 20:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:12:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:12:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:12:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:13:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:13:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:13:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:14:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:15:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 20:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:16:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 20:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:16:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:17:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 20:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:22:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 20:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:24:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:25:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:25:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 20:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:27:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 20:27:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 20:27:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 20:27:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 20:27:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 20:27:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 20:27:20 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 20:27:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:27:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:29:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:30:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:31:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:31:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:31:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:32:14 --> 404 Page Not Found: City/10
ERROR - 2021-05-20 20:32:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 20:32:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 20:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:35:48 --> 404 Page Not Found: City/1
ERROR - 2021-05-20 20:36:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 20:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:42:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 20:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:48:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 20:50:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 20:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:56:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 20:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 20:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:04:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 21:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:06:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:07:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:11:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:11:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:12:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 21:12:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:12:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:12:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:12:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:13:24 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 21:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:14:00 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 21:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:14:24 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 21:14:24 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 21:14:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:15:00 --> 404 Page Not Found: Search/likea
ERROR - 2021-05-20 21:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:22:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 21:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:24:02 --> 404 Page Not Found: Wp-admin/index
ERROR - 2021-05-20 21:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:32:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:32:58 --> 404 Page Not Found: Env/index
ERROR - 2021-05-20 21:33:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:36:12 --> 404 Page Not Found: Env/index
ERROR - 2021-05-20 21:36:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 21:37:52 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-05-20 21:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:38:23 --> Severity: Warning --> Missing argument 1 for News::show() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 581
ERROR - 2021-05-20 21:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:40:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 21:41:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:41:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:44:33 --> 404 Page Not Found: Env/index
ERROR - 2021-05-20 21:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:45:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 21:45:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 21:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:49:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 21:51:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 21:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:53:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 21:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:53:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 21:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:55:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 21:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:56:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 21:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:57:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 21:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 21:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:07:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:09:13 --> 404 Page Not Found: Menuhtml/index
ERROR - 2021-05-20 22:09:15 --> 404 Page Not Found: GponForm/diag_FORM
ERROR - 2021-05-20 22:09:21 --> 404 Page Not Found: Console/login
ERROR - 2021-05-20 22:09:25 --> 404 Page Not Found: Console/LoginForm.jsp
ERROR - 2021-05-20 22:09:27 --> 404 Page Not Found: Console/Login.jsp
ERROR - 2021-05-20 22:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:13:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:13:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:15:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:17:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:20:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:22:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:23:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:25:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-05-20 22:26:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:31:17 --> 404 Page Not Found: City/18
ERROR - 2021-05-20 22:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:43:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:44:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:45:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:47:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:49:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:52:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:55:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 22:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:56:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 22:57:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 22:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:59:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 22:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 22:59:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 22:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:00:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:00:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:01:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:02:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:03:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:03:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:04:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:04:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:05:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:05:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:06:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:06:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:09:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:09:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:09:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:10:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:10:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:10:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:11:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:11:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:11:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:21:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:22:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-05-20 23:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:30:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:30:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:32:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:35:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:38:39 --> 404 Page Not Found: English/index
ERROR - 2021-05-20 23:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:45:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:45:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:47:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:47:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:47:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:48:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:51:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:51:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-05-20 23:51:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:51:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-05-20 23:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:52:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:55:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-05-20 23:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-05-20 23:58:43 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-05-20 23:59:32 --> 404 Page Not Found: Robotstxt/index
