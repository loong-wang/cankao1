<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-22 00:00:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 00:00:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 00:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 00:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 00:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 00:26:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 00:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 00:30:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 00:32:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 00:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 00:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 01:18:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 01:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 01:23:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 01:32:17 --> 404 Page Not Found: Shell/index
ERROR - 2021-10-22 01:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 01:41:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 01:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 01:51:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 02:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 02:29:11 --> 404 Page Not Found: City/1
ERROR - 2021-10-22 02:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 02:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 03:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 03:09:18 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-10-22 03:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 03:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 03:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 03:58:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 04:01:02 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-10-22 04:02:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 04:04:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 04:05:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 04:05:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 04:05:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 04:05:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 04:05:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 04:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 04:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 04:48:17 --> 404 Page Not Found: SiteServer/Ajax
ERROR - 2021-10-22 04:48:17 --> 404 Page Not Found: SiteFiles/SiteTemplates
ERROR - 2021-10-22 04:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 05:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 05:22:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 05:22:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 05:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 05:40:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-22 05:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 05:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 05:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 05:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 06:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 06:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 06:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 06:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 06:22:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-22 06:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 06:48:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 06:48:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 06:49:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 06:51:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 06:52:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 06:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 06:54:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 06:58:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 07:04:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 07:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 07:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 07:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 07:08:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 07:08:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 07:09:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 07:09:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 07:10:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 07:11:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 07:12:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 07:14:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 07:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 07:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 08:03:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:04:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:05:05 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-22 08:05:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 08:12:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:12:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:12:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:12:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:12:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:16:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:17:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:18:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 08:19:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:21:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 08:25:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 08:28:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:29:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 08:31:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:32:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:33:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:34:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:35:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:35:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:37:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 08:40:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:43:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:43:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:43:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:43:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:45:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 08:48:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-22 08:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 09:06:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 09:06:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 09:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 09:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 09:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 09:20:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 09:21:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 09:21:34 --> 404 Page Not Found: Login/index
ERROR - 2021-10-22 09:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 09:27:50 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-22 09:30:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 09:30:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 09:31:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 09:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 09:56:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 10:02:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-22 10:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 10:13:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 10:13:51 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 10:13:51 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 10:14:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 10:14:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 10:20:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 10:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 10:25:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 10:25:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 10:27:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 10:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 10:35:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 10:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 10:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 10:56:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 10:57:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 10:57:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 11:07:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-22 11:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 11:16:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 11:18:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 11:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 11:27:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-22 11:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 11:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 11:47:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 11:53:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 11:53:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 11:53:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 11:53:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 11:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 11:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 11:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 11:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 11:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 11:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 11:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 12:04:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 12:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 12:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 12:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 12:23:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:23:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:24:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:24:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:25:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:25:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:26:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:26:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:27:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:27:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:30:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:31:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:32:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:33:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 12:34:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:35:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:35:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:37:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:37:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:37:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 12:38:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 12:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 12:46:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:47:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:49:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:49:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:50:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:50:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:51:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 12:56:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 13:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 13:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 13:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 13:12:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 13:15:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 13:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 13:33:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 13:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 13:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 13:57:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 13:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 14:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 14:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 14:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 14:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 14:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 14:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 14:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 14:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 15:11:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 15:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 15:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 15:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 15:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 15:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 15:31:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 15:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 15:36:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 15:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 15:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 15:48:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 15:50:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 15:50:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 15:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 16:02:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 16:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 16:11:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 16:24:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 16:29:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 16:29:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 16:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 16:33:13 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-22 16:33:14 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-22 16:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 16:41:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-22 16:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 16:43:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 16:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 16:46:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 16:46:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 16:49:52 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-22 16:51:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:51:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:51:50 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:51:50 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:51:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:51:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:52:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:52:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:52:05 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:52:05 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:52:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:52:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 16:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 16:54:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 16:57:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 16:57:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 16:57:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 16:57:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-22 17:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 17:02:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:05:46 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 17:05:46 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-22 17:08:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-22 17:18:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:19:12 --> 404 Page Not Found: City/1
ERROR - 2021-10-22 17:20:44 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-22 17:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 17:26:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:27:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:29:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:29:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:29:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:29:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:29:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:29:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:30:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:30:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:30:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:30:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:31:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:33:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 17:36:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:37:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:37:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:37:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:38:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:38:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:38:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:39:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:39:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:40:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:40:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 17:42:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 17:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 17:47:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 17:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 17:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 17:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 17:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 17:49:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 17:50:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:55:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:55:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 17:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 17:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 18:03:22 --> 404 Page Not Found: City/2
ERROR - 2021-10-22 18:03:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 18:04:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 18:04:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:08:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 18:09:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 18:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 18:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 18:14:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 18:17:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:17:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:18:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:19:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 18:20:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:21:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:22:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:23:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 18:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 18:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 18:27:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 18:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 18:40:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:40:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:42:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 18:42:51 --> 404 Page Not Found: QeeB/index
ERROR - 2021-10-22 18:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 18:44:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 18:44:50 --> 404 Page Not Found: Api/manyou
ERROR - 2021-10-22 18:44:50 --> 404 Page Not Found: Uc_server/view
ERROR - 2021-10-22 18:44:50 --> 404 Page Not Found: Bbs/api
ERROR - 2021-10-22 18:44:50 --> 404 Page Not Found: Bbs/uc_server
ERROR - 2021-10-22 18:44:51 --> 404 Page Not Found: Application/Home
ERROR - 2021-10-22 18:44:51 --> 404 Page Not Found: Application/Admin
ERROR - 2021-10-22 18:48:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 19:02:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 19:03:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 19:08:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 19:18:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 19:20:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 19:20:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 19:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 19:27:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 19:28:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 19:30:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 19:30:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 19:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 19:50:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 19:52:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 19:53:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 19:55:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 19:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 19:56:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 19:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 19:58:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 19:58:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 19:58:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 19:59:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:00:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 20:00:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 20:00:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:04:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 20:05:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 20:05:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:05:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:07:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:08:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:14:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:20:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 20:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 20:32:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:33:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:34:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:34:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 20:35:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 20:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 20:39:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:39:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-22 20:40:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:40:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:40:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:45:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 20:50:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 20:50:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 20:52:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:57:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 20:59:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 21:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:00:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 21:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:05:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 21:05:31 --> 404 Page Not Found: Api/manyou
ERROR - 2021-10-22 21:05:31 --> 404 Page Not Found: Uc_server/view
ERROR - 2021-10-22 21:05:31 --> 404 Page Not Found: Bbs/api
ERROR - 2021-10-22 21:05:32 --> 404 Page Not Found: Bbs/uc_server
ERROR - 2021-10-22 21:05:32 --> 404 Page Not Found: Application/Home
ERROR - 2021-10-22 21:05:32 --> 404 Page Not Found: Application/Admin
ERROR - 2021-10-22 21:05:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:07:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:08:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-22 21:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:13:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-22 21:13:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 21:16:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:25:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 21:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:36:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 21:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:48:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 21:49:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:50:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:50:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:50:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:50:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:50:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:50:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:50:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:50:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:50:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:50:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 21:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 21:51:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 22:07:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:07:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:07:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:07:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:08:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 22:08:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:08:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:08:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:08:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:21:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 22:30:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:30:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 22:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 22:42:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 22:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 22:55:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-22 23:00:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-22 23:12:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-22 23:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 23:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 23:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 23:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-22 23:46:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
