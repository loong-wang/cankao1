<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-03 00:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:01:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 00:02:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 00:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:05:20 --> 404 Page Not Found: H5/index
ERROR - 2021-06-03 00:05:20 --> 404 Page Not Found: Base/exchange_article
ERROR - 2021-06-03 00:05:20 --> 404 Page Not Found: M/ticker
ERROR - 2021-06-03 00:05:20 --> 404 Page Not Found: Wap/trading
ERROR - 2021-06-03 00:05:20 --> 404 Page Not Found: Legal/currency
ERROR - 2021-06-03 00:05:20 --> 404 Page Not Found: M/allticker
ERROR - 2021-06-03 00:05:21 --> 404 Page Not Found: Wap/trading
ERROR - 2021-06-03 00:05:21 --> 404 Page Not Found: admin/Index/index
ERROR - 2021-06-03 00:05:21 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-06-03 00:05:21 --> 404 Page Not Found: Market/market-ws
ERROR - 2021-06-03 00:05:21 --> 404 Page Not Found: H5/index
ERROR - 2021-06-03 00:05:21 --> 404 Page Not Found: N/news
ERROR - 2021-06-03 00:05:22 --> 404 Page Not Found: Otc/index
ERROR - 2021-06-03 00:05:22 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-06-03 00:05:22 --> 404 Page Not Found: User/allroleinfo
ERROR - 2021-06-03 00:05:22 --> 404 Page Not Found: Room/getRoomBangFans
ERROR - 2021-06-03 00:05:22 --> 404 Page Not Found: Api/content_bottom
ERROR - 2021-06-03 00:05:23 --> 404 Page Not Found: User/userlist
ERROR - 2021-06-03 00:05:23 --> 404 Page Not Found: Recruit/download_url
ERROR - 2021-06-03 00:05:23 --> 404 Page Not Found: Home/loadmymanager
ERROR - 2021-06-03 00:05:23 --> 404 Page Not Found: Room/1002
ERROR - 2021-06-03 00:05:24 --> 404 Page Not Found: Account/login
ERROR - 2021-06-03 00:05:27 --> 404 Page Not Found: Ajax/allcoin_a
ERROR - 2021-06-03 00:05:30 --> 404 Page Not Found: Api/user
ERROR - 2021-06-03 00:05:32 --> 404 Page Not Found: S_api/basic
ERROR - 2021-06-03 00:05:33 --> 404 Page Not Found: V1/management
ERROR - 2021-06-03 00:05:33 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-06-03 00:05:33 --> 404 Page Not Found: S_api/basic
ERROR - 2021-06-03 00:05:34 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-06-03 00:05:34 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-06-03 00:05:34 --> 404 Page Not Found: Xianyu/index
ERROR - 2021-06-03 00:05:34 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-06-03 00:05:34 --> 404 Page Not Found: Xy/index
ERROR - 2021-06-03 00:05:34 --> 404 Page Not Found: Pc/Lang
ERROR - 2021-06-03 00:05:35 --> 404 Page Not Found: Home/Bind
ERROR - 2021-06-03 00:05:35 --> 404 Page Not Found: Data/json
ERROR - 2021-06-03 00:05:35 --> 404 Page Not Found: Mobile/v3
ERROR - 2021-06-03 00:05:35 --> 404 Page Not Found: GetLocale/index
ERROR - 2021-06-03 00:05:35 --> 404 Page Not Found: Iframe/rankgiftgotapi
ERROR - 2021-06-03 00:05:35 --> 404 Page Not Found: Home/GetAllGameCategory
ERROR - 2021-06-03 00:05:35 --> 404 Page Not Found: FePublicInfo/index
ERROR - 2021-06-03 00:05:35 --> 404 Page Not Found: Web/api
ERROR - 2021-06-03 00:05:36 --> 404 Page Not Found: Infe/rest
ERROR - 2021-06-03 00:05:36 --> 404 Page Not Found: Infe/rest
ERROR - 2021-06-03 00:05:36 --> 404 Page Not Found: Home/GetQrCodeInfo
ERROR - 2021-06-03 00:05:37 --> 404 Page Not Found: Api/ApiHub
ERROR - 2021-06-03 00:05:38 --> 404 Page Not Found: Mh/phone.do
ERROR - 2021-06-03 00:05:39 --> 404 Page Not Found: Bannerdo/index
ERROR - 2021-06-03 00:05:40 --> 404 Page Not Found: Index/login
ERROR - 2021-06-03 00:05:41 --> 404 Page Not Found: Registerasp/index
ERROR - 2021-06-03 00:05:42 --> 404 Page Not Found: Step1asp/index
ERROR - 2021-06-03 00:05:44 --> 404 Page Not Found: Front/User
ERROR - 2021-06-03 00:05:44 --> 404 Page Not Found: CscpLoginWeb/app
ERROR - 2021-06-03 00:05:45 --> 404 Page Not Found: Ajax/index
ERROR - 2021-06-03 00:05:45 --> 404 Page Not Found: Front/FctPage
ERROR - 2021-06-03 00:05:45 --> 404 Page Not Found: Ajax/index
ERROR - 2021-06-03 00:05:46 --> 404 Page Not Found: admin//index
ERROR - 2021-06-03 00:05:46 --> 404 Page Not Found: Api/index
ERROR - 2021-06-03 00:05:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 00:05:47 --> 404 Page Not Found: Home/Get
ERROR - 2021-06-03 00:05:47 --> 404 Page Not Found: Mtjahtml/index
ERROR - 2021-06-03 00:05:48 --> 404 Page Not Found: Home/login
ERROR - 2021-06-03 00:05:48 --> 404 Page Not Found: Site/get-hq
ERROR - 2021-06-03 00:05:49 --> 404 Page Not Found: Api/uploads
ERROR - 2021-06-03 00:05:51 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-03 00:05:52 --> 404 Page Not Found: Home/GetInitSource
ERROR - 2021-06-03 00:05:52 --> 404 Page Not Found: Ws/index
ERROR - 2021-06-03 00:05:53 --> 404 Page Not Found: Api/v
ERROR - 2021-06-03 00:05:54 --> 404 Page Not Found: Static/data
ERROR - 2021-06-03 00:05:54 --> 404 Page Not Found: Homes/index
ERROR - 2021-06-03 00:05:57 --> 404 Page Not Found: Api/Index
ERROR - 2021-06-03 00:05:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 00:05:57 --> 404 Page Not Found: Sign/index
ERROR - 2021-06-03 00:05:59 --> 404 Page Not Found: Homes/index
ERROR - 2021-06-03 00:05:59 --> 404 Page Not Found: Api/wallet
ERROR - 2021-06-03 00:06:00 --> 404 Page Not Found: Promotions/list.mvc
ERROR - 2021-06-03 00:06:00 --> 404 Page Not Found: Api/site
ERROR - 2021-06-03 00:06:00 --> 404 Page Not Found: H5/index
ERROR - 2021-06-03 00:06:01 --> 404 Page Not Found: Api/stock
ERROR - 2021-06-03 00:06:01 --> 404 Page Not Found: Base/goexjs
ERROR - 2021-06-03 00:06:01 --> 404 Page Not Found: Static/local
ERROR - 2021-06-03 00:06:02 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-03 00:06:02 --> 404 Page Not Found: Anquan/qgga.asp
ERROR - 2021-06-03 00:06:03 --> 404 Page Not Found: Index/register.html
ERROR - 2021-06-03 00:06:03 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-03 00:06:03 --> 404 Page Not Found: Index/index
ERROR - 2021-06-03 00:06:03 --> 404 Page Not Found: Api/message
ERROR - 2021-06-03 00:06:04 --> 404 Page Not Found: Api/product
ERROR - 2021-06-03 00:06:07 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-06-03 00:06:07 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-06-03 00:06:08 --> 404 Page Not Found: Api/mobile
ERROR - 2021-06-03 00:06:08 --> 404 Page Not Found: Api/apps
ERROR - 2021-06-03 00:06:09 --> 404 Page Not Found: Api/index
ERROR - 2021-06-03 00:06:09 --> 404 Page Not Found: Api/contactWay
ERROR - 2021-06-03 00:06:09 --> 404 Page Not Found: Market/getStockBaseInfo
ERROR - 2021-06-03 00:06:10 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-03 00:06:11 --> 404 Page Not Found: Loan/index
ERROR - 2021-06-03 00:06:11 --> 404 Page Not Found: Kkrps/im_group
ERROR - 2021-06-03 00:06:11 --> 404 Page Not Found: FriendGroup/list
ERROR - 2021-06-03 00:06:12 --> 404 Page Not Found: Index/api
ERROR - 2021-06-03 00:06:13 --> 404 Page Not Found: Api/common
ERROR - 2021-06-03 00:06:14 --> 404 Page Not Found: Stock/search.html
ERROR - 2021-06-03 00:06:14 --> 404 Page Not Found: Api/config-init
ERROR - 2021-06-03 00:06:14 --> 404 Page Not Found: Api/user
ERROR - 2021-06-03 00:06:14 --> 404 Page Not Found: Portal/index
ERROR - 2021-06-03 00:06:14 --> 404 Page Not Found: Api/currency
ERROR - 2021-06-03 00:06:14 --> 404 Page Not Found: Appxz/index.html
ERROR - 2021-06-03 00:06:15 --> 404 Page Not Found: Home/main
ERROR - 2021-06-03 00:06:16 --> 404 Page Not Found: Api/exclude
ERROR - 2021-06-03 00:06:16 --> 404 Page Not Found: Api/user
ERROR - 2021-06-03 00:06:16 --> 404 Page Not Found: Im/in
ERROR - 2021-06-03 00:06:29 --> 404 Page Not Found: H5/index
ERROR - 2021-06-03 00:06:48 --> 404 Page Not Found: City/2
ERROR - 2021-06-03 00:07:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:07:57 --> 404 Page Not Found: English/index
ERROR - 2021-06-03 00:08:25 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-03 00:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:21:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 00:21:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 00:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:30:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:40:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 00:41:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 00:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:43:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 00:43:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 00:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:45:07 --> Severity: Warning --> Missing argument 1 for Xinxi::show() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 97
ERROR - 2021-06-03 00:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:51:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:52:36 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-03 00:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 00:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:02:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:05:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 01:05:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 01:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:10:12 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-06-03 01:10:12 --> 404 Page Not Found: admin//index
ERROR - 2021-06-03 01:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:10:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 01:10:14 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-06-03 01:10:14 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-06-03 01:10:14 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-06-03 01:10:15 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-06-03 01:10:15 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-06-03 01:10:15 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-06-03 01:10:15 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-06-03 01:10:15 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-06-03 01:10:15 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-06-03 01:10:15 --> 404 Page Not Found: Wcm/index
ERROR - 2021-06-03 01:10:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 01:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:11:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 01:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:12:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 01:15:10 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-03 01:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:20:43 --> 404 Page Not Found: City/1
ERROR - 2021-06-03 01:21:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 01:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:22:16 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-03 01:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:26:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 01:26:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 01:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:27:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 01:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:28:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 01:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:30:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 01:32:38 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-06-03 01:32:38 --> 404 Page Not Found: Home/tradeInfo
ERROR - 2021-06-03 01:32:39 --> 404 Page Not Found: Article/index
ERROR - 2021-06-03 01:32:40 --> 404 Page Not Found: Article/view
ERROR - 2021-06-03 01:32:40 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-06-03 01:32:41 --> 404 Page Not Found: Jdybsc/index
ERROR - 2021-06-03 01:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:32:42 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-06-03 01:32:43 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-06-03 01:32:44 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-06-03 01:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:40:10 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-03 01:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:43:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-03 01:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:45:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 01:47:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 01:47:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 01:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:52:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 01:53:29 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-03 01:53:31 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-03 01:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 01:57:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 01:58:35 --> 404 Page Not Found: City/1
ERROR - 2021-06-03 02:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:02:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:02:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:03:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:09:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:10:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:11:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 02:11:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:12:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:12:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:13:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:16:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:22:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 02:22:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:23:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 02:23:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 02:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:26:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:27:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:27:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 02:27:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:31:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:32:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 02:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:35:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 02:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:39:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:42:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:43:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 02:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:43:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:44:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:44:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 02:44:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:45:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 02:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:49:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 02:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:51:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 02:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:56:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 02:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:57:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-03 02:57:47 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-03 02:57:48 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-03 02:57:49 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-03 02:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 02:59:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 03:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:00:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 03:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:09:01 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-06-03 03:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:12:20 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-06-03 03:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:17:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 03:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-03 03:24:27 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-03 03:24:28 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 03:24:29 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 03:24:29 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 03:24:29 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-03 03:24:29 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-03 03:24:29 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-03 03:24:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:33:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:33:21 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-06-03 03:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:36:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 03:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:38:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 03:40:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 03:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:53:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 03:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:55:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 03:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:57:53 --> 404 Page Not Found: English/index
ERROR - 2021-06-03 03:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 03:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-06-03 04:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:06:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 04:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:14:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 04:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:23:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 04:24:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 04:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:28:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 04:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:30:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 04:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:38:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 04:41:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 04:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:46:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 04:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:48:12 --> 404 Page Not Found: OLD/wp-admin
ERROR - 2021-06-03 04:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:49:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 04:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:51:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 04:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 04:56:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 04:57:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 05:00:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:05:01 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-03 05:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:09:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:23:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 05:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:27:41 --> 404 Page Not Found: City/15
ERROR - 2021-06-03 05:29:40 --> 404 Page Not Found: Js/common.js%20%20
ERROR - 2021-06-03 05:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:33:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 05:33:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 05:33:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 05:33:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 05:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:44:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 05:47:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 05:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:48:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 05:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:51:41 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-03 05:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:54:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:57:44 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-03 05:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 05:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:01:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 06:02:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 06:02:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 06:03:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 06:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:04:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:07:24 --> 404 Page Not Found: City/1
ERROR - 2021-06-03 06:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:09:14 --> 404 Page Not Found: Config/getuser
ERROR - 2021-06-03 06:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:18:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 06:18:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 06:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:21:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 06:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:21:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 06:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:23:08 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-03 06:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:24:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 06:24:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 06:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:31:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 06:34:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 06:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:36:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 06:36:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 06:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:37:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 06:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:40:08 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-06-03 06:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:44:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 06:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:48:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-03 06:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:54:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 06:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:59:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 06:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 06:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:03:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:03:27 --> 404 Page Not Found: Www20210601rar/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Wwwxuanhaonet20210601rar/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Www_xuanhao_net20210601rar/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Wwwxuanhaonet20210601rar/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Xuanhaonet20210601rar/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Xuanhao_net20210601rar/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Xuanhaonet20210601rar/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Xuanhao20210601rar/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Www20210601targz/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Wwwxuanhaonet20210601targz/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Www_xuanhao_net20210601targz/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Wwwxuanhaonet20210601targz/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Xuanhaonet20210601targz/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Xuanhao_net20210601targz/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Xuanhaonet20210601targz/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Xuanhao20210601targz/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Www20210601zip/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Wwwxuanhaonet20210601zip/index
ERROR - 2021-06-03 07:03:28 --> 404 Page Not Found: Www_xuanhao_net20210601zip/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Wwwxuanhaonet20210601zip/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Xuanhaonet20210601zip/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Xuanhao_net20210601zip/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Xuanhaonet20210601zip/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Xuanhao20210601zip/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Www2021-06-01rar/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Wwwxuanhaonet2021-06-01rar/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Www_xuanhao_net2021-06-01rar/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Wwwxuanhaonet2021-06-01rar/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Xuanhaonet2021-06-01rar/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Xuanhao_net2021-06-01rar/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Xuanhaonet2021-06-01rar/index
ERROR - 2021-06-03 07:03:29 --> 404 Page Not Found: Xuanhao2021-06-01rar/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Www2021-06-01targz/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Wwwxuanhaonet2021-06-01targz/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Www_xuanhao_net2021-06-01targz/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Wwwxuanhaonet2021-06-01targz/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Xuanhaonet2021-06-01targz/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Xuanhao_net2021-06-01targz/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Xuanhaonet2021-06-01targz/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Xuanhao2021-06-01targz/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Www2021-06-01zip/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Wwwxuanhaonet2021-06-01zip/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Www_xuanhao_net2021-06-01zip/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Wwwxuanhaonet2021-06-01zip/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Xuanhaonet2021-06-01zip/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Xuanhao_net2021-06-01zip/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Xuanhaonet2021-06-01zip/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Xuanhao2021-06-01zip/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Www20210601rar/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Wwwxuanhaonet20210601rar/index
ERROR - 2021-06-03 07:03:30 --> 404 Page Not Found: Www_xuanhao_net20210601rar/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Wwwxuanhaonet20210601rar/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Xuanhaonet20210601rar/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Xuanhao_net20210601rar/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Xuanhaonet20210601rar/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Xuanhao20210601rar/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Www20210601targz/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Wwwxuanhaonet20210601targz/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Www_xuanhao_net20210601targz/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Wwwxuanhaonet20210601targz/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Xuanhaonet20210601targz/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Xuanhao_net20210601targz/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Xuanhaonet20210601targz/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Xuanhao20210601targz/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Www20210601zip/index
ERROR - 2021-06-03 07:03:31 --> 404 Page Not Found: Wwwxuanhaonet20210601zip/index
ERROR - 2021-06-03 07:03:32 --> 404 Page Not Found: Www_xuanhao_net20210601zip/index
ERROR - 2021-06-03 07:03:32 --> 404 Page Not Found: Wwwxuanhaonet20210601zip/index
ERROR - 2021-06-03 07:03:32 --> 404 Page Not Found: Xuanhaonet20210601zip/index
ERROR - 2021-06-03 07:03:32 --> 404 Page Not Found: Xuanhao_net20210601zip/index
ERROR - 2021-06-03 07:03:32 --> 404 Page Not Found: Xuanhaonet20210601zip/index
ERROR - 2021-06-03 07:03:32 --> 404 Page Not Found: Xuanhao20210601zip/index
ERROR - 2021-06-03 07:03:32 --> 404 Page Not Found: 20210601rar/index
ERROR - 2021-06-03 07:03:32 --> 404 Page Not Found: 20210601targz/index
ERROR - 2021-06-03 07:03:32 --> 404 Page Not Found: 20210601zip/index
ERROR - 2021-06-03 07:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:06:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:08:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:08:12 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-03 07:08:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-03 07:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:11:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 07:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:14:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:17:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-03 07:17:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 07:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:19:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:19:35 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 07:19:35 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 07:19:35 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-03 07:19:35 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 07:19:35 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 07:19:35 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-03 07:19:35 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 07:19:35 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-03 07:19:35 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 07:19:35 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 07:19:35 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-03 07:19:36 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 07:19:37 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 07:19:37 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 07:19:37 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-03 07:19:37 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-03 07:19:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:20:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:21:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:23:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 07:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:27:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:27:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 07:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 07:28:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 07:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:29:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 07:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:30:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 07:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:31:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 07:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:35:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 07:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:35:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 07:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:35:49 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 07:36:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 07:36:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 07:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:40:03 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-03 07:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:41:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:42:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:50:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 07:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:52:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:53:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:53:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 07:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 07:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:04:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 08:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:07:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 08:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:09:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 08:10:37 --> 404 Page Not Found: 1/all
ERROR - 2021-06-03 08:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:11:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:11:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:13:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 08:15:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:16:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 08:16:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 08:16:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:16:57 --> 404 Page Not Found: Bag2/index
ERROR - 2021-06-03 08:18:03 --> 404 Page Not Found: Solr/index
ERROR - 2021-06-03 08:18:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:19:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:20:20 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-06-03 08:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:22:54 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 08:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:23:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 08:23:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:23:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:24:49 --> 404 Page Not Found: City/1
ERROR - 2021-06-03 08:26:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:28:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 08:28:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 08:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:30:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:34:40 --> 404 Page Not Found: English/index
ERROR - 2021-06-03 08:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:36:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:39:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:41:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:42:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:46:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:49:16 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 08:49:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:54:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 08:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:56:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:56:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:56:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 08:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 08:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:00:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:01:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 09:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:03:33 --> 404 Page Not Found: Images/Nxrs4tAtO
ERROR - 2021-06-03 09:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:10:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 09:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:12:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:13:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 09:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:14:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:14:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 09:14:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:16:19 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-03 09:16:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 09:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:17:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 09:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:18:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:18:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:18:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:18:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:19:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:20:51 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-03 09:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:24:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 09:24:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 09:24:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 09:25:30 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-03 09:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:27:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 09:27:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 09:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:27:52 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-03 09:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:28:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:28:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:28:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 09:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:28:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:29:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:29:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:29:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:30:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:36:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 09:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:39:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 09:39:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 09:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:40:08 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 09:40:09 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-03 09:40:10 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 09:40:10 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-03 09:40:10 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 09:40:10 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 09:40:10 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-03 09:40:10 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 09:40:10 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 09:40:10 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-03 09:40:11 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 09:40:11 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-03 09:40:11 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-03 09:40:11 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-03 09:40:11 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-03 09:40:11 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 09:40:11 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 09:40:11 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 09:40:11 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-03 09:40:11 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-03 09:40:11 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-03 09:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:41:23 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-03 09:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:43:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:44:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 09:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:45:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 09:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:49:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 09:49:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:49:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:50:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:50:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:51:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:54:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 09:55:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 09:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 09:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:03:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 10:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:09:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 10:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:10:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionbeecfd4eadd41edfa43c320271498957f83d2f0b): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionca7a42fd4a02b5f7417ed283e8992ad4a3c381c4): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session87ed53a39c1dc3bb08193e4331c361e61f7db4b4): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiona4eb5b44f8a434d97c3b96d059cbdb51429c4f73): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiona5fe54e65bae66c14fb9d898816422dfd88875f7): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session40cbda60f65ed542d254453386dbc3b8efff475a): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session38a78c0ad69ff48d2f4a0cd010b0ee7ff22bb994): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionfba2d0ae43cb82fff31f3bac5799baf931054d5a): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessione01ad473e8f83817f07657eb517bc9e3799f27de): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionfb573308841398428718424323cc3ec5e3f99160): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session3ba205adfc7c0c508c1e246ffcf7969ed1d5b589): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session037a4022000689c1a5f931b79b85575bdc0e783b): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session3bdf4dcd869d907325f72db38120bf8c53dd201a): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session8c5929aaa2e57668f83838e0bb996003b3c965eb): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session26bf9a700f212d553b7772738d7735e4443fe78f): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionf13bb667b60f56342913169d04571dd934dd7cc3): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiond77d4781157a1b93877d34eefc5acc3a10ea44d8): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session5444d5c9afb2679689c5b35a592e606d1d2c4368): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session1f566cf7c0bb8a9b406722b8ae0aee624bb7efa1): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessione34a6edded1cc777c83f9fd6bd91056b3ab04373): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session766c001ee13622a440b5a4bf3dd2d492e65f169e): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session4b312b73d532d4059a2729e6f81aadd195e3c0a2): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session84e4ca8a03674543c66e9ed5049911ea8b8c9fe2): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session7a337d2987eef6cfc5395ccc56d4f071d0a8a16a): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session674e34e9a9a3e774b90532c5676890bab77b2211): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session4c41c17527bb7378862bef13354230483ef1d49e): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session04d7d3ed3ce8c07b106d7ec8856276b41cf478ca): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session4522cb3cd3effed337eb4e04e38370be8645856b): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session38c94b38eeebcb3f3eb51e4d39cc5a0e4eb1cf91): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session1fbe41d193dbca16c43ee40d8e1051615e9e0407): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session2efd3951342204542c8c65e60510ccb470567b3e): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionc1f9b2ff1b67a4192cc6383851255b22cb7ed427): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session5c3a0c93a7fcae37fd5307ab533dd73b9906c33d): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiond4ddedc7cf8dd300f79e911ba0921b62aa8afde2): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiona5223945a87c5f39372407fe0aa725d2c41af070): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session9fd3ea3bc3118d129bfca7b3f2244b253420599e): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session6ef785e7382e1b35f4b12c30bb3fbe1ef735ac86): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session22e3e8b2ac760d5e2ae637cbd883a0e3001ad3da): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionf435262b2a0a7fe456ca2fe1433e7493fdd8c278): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session42a2126576e0388fdf61629f6996c4ee1a268ff2): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session15e3266ec662c0372b920cf06b75c9a2f9e8054f): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionb0c05b3f2c6ad8c9cff772a499ef91be392f5f6a): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiond659ee85cc37b38d473dfa6c74cd7c554dbe3115): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session8b94a8fc325bf0e2a8b2e22122914643451838ae): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session677afa6296e5fc155abe2350ab7fb193ff8a68d7): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session3eafd094fcc0301d964469680cda4879120611b9): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session25b57c22413cdcbd389e2eab0de633430297bd8b): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session8cea44e0d4cc6341f620cdecc0cb08e9d8ac58da): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session7e0734c52c15fb66e9b411a4c4d6e337671a1f9d): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionb88674da31c65b26e63f19a2e03531b06e5b38ab): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session790bf2e6dfc00ff037dc3e94a6a5edd6a55b45db): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session7f021d58fd5ad016df5ef6dc23c5451ed78297ee): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiona42c0abdf84d52c79e96cd29ad6c85b757d7abbe): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session4a3cdeaf022e8b54389cdb9a9c5bb8c4caa0dea0): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionedb183fc3d562a03ab2daf598a48e1734061fd06): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session681bb7a7329170a1c76c1ab24efb3cbc8071b11a): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session559ce34f37e7c6ca5693698c6544de9e1648ea5c): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session81aee900baba7810d1f593b5b7f847e2f5ce5897): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session6c0b38da357c7310332bf69926c5c45086730d33): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session4e78569326b176bd6912c19a63431878b1873b81): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionee4db41c4b5a9d5a39e0592735d3df62de3f1173): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessioned544ba10991ae9a97e27eba9c2bf034e5c040b5): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session7c15eb4ca087905642dd1ef73b610f5556d076bf): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session8ff36604a964029f428c0e0748366ba6e8597c93): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session58a7386ba908b4f7c0558a6db77d490305271509): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session6bedc3ba36d337cde020c51120041f4c08fdcfa6): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session338756be032c336c3ebfd4fedd50781916a8546b): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session45d543db701d9dec3505b7a148ac4eed6d4cf3bb): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session8dbb5fbc110b42aae090e70f6049cd959c7371b2): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessione033f603ab4b2f07eee6c4715a1030b635f055c2): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessione335dd8d62add7517965fa999c405442a8810a36): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionf338f3f851555176252df5e74c270a156f05b460): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionbbf50249677e6304da23a5ba0c88e8ec7bdb440d): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session0725d0595db1ee7299cfbdf52e45c585c87c9f86): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session25cddf098f198b964c97bd44674f002abdaa3005): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session4b96862554a0f5431b111df25f45086e3dfdb363): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session2e57b39d06757eae94b22dbd06a880f5b4cd2594): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionefb5240d7240862eed4812785b31e91f375fa483): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session95aa941c3e142685b3415f579d8e257bc86d9f17): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiond6334e6ca12dc8f3d8f12c2e27bb70f0c4d0d44e): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session62076581965276521b56f9ecadf485eb12f3c893): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session12e4fdc594111149b019a8703ed48f59e2e55057): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session6b17b6be3538d4128c2119041652e8124d8ce952): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session0fad638ad655a32e9701683889792d9a02c7f6b4): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session480fd9b330574c5c91b6d5356cbfc9fc542f29f6): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionf8c4284cc9c93380f38b35f0bb29aa8fb7ede07c): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionc2344f53ba6e0b3a78274b820e30ba49fda1936e): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionf30763dd7b148638298ae98ea6d85c0d32f670a5): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session85eab4613e08669f6bdf8f2943e002ad4c1297fe): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionf5a4ce273f2a132723a97c487c6ce200653cf582): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session81c762429c4d32943e1eb715729b0ce2f512437a): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session4cf6d2975e0723418e3d0b10be44254b3e86d90c): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionca358bd97725e61bbae0e990a202705b672fdcb8): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session38947bbcd666d972456e3ec97ca5e55608a000ec): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session31c944569bede16b3b1427ba47f1bc8c66cc70a9): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session875d44075d4b8460014c19d2e72c2e15a4409608): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session9b5183b1f6f30605087ecaef9afe63d71aebee91): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionf586d905f6dfaf85c47ab613383e61d962d884e7): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionc4fe711ae013fc288da1a8dac9a6ecab2356b29e): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessione56b5b90a5f18acc1aea685890a5370ac7357a9a): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionb2c0f430c8afdcbce782d53ea77c07311d2d295a): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session73b8995804dcb186ce69c70a7d431b0dcfe3a410): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session4eb4fda606e788c41ecf73c7d599ce191e613df7): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session8d660d242aeb0b2e8bbd9140473aaae79a9ffdf3): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session8c0b25479b7b7449dabc4aaf78a2569e5cb6f0d4): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session773a912a2d5b0ef173bf743dba4558927a727335): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session5dcfc1dfc16e7097fef6610283fbc98b49f4998e): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session7ef3db0acad1f66733e5920385f6a20df6c33fa1): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionf097a52af81f10f01cb5e52c2ecdb8d332d1df56): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session4325bf3fb8d95fd4d4cfa2d473a6f960172b0ef2): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiondd290ac2e15d1a59cb0981faf9ff7e84017d0af8): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session7fdd88fbf21e8f23250c830bacc0e91eac5a0d41): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session6d4f5db0467a86e45dde637f6d3ede7e4a066445): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session856bc53638cd6c55c306465dcfb389274144e11f): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:11:39 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session6a475fb32a9eb19d87816a48dc01719111fa9024): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-06-03 10:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:14:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 10:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:17:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:18:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:19:16 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-03 10:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:21:35 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-03 10:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:40:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-03 10:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:51:48 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 10:51:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:51:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:53:42 --> 404 Page Not Found: English/index
ERROR - 2021-06-03 10:54:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 10:54:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 10:54:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:55:26 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 10:55:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 10:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:55:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:55:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:56:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:57:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:58:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:58:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:58:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:58:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:59:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:59:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 10:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:59:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 10:59:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:00:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:00:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:01:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:03:01 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 11:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:03:14 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 11:03:17 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 11:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:04:45 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-03 11:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:05:50 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 11:05:50 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 11:05:50 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-03 11:05:50 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 11:05:50 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 11:05:50 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-03 11:05:50 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 11:05:50 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-03 11:05:50 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 11:05:50 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-03 11:05:51 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 11:05:52 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 11:05:52 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 11:05:52 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-03 11:05:52 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-03 11:05:52 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-03 11:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:09:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:09:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:09:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:10:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 11:10:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:10:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:11:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:12:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:15:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 11:15:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 11:16:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:16:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 11:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:17:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 11:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:18:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:20:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:20:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:20:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:21:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:22:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:22:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:22:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:22:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:23:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:23:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:23:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:23:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:23:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:24:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:24:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:24:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:25:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:25:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 11:26:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:26:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:26:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:26:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:27:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:27:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:30:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:31:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:32:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 11:33:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:33:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:33:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 11:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:34:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:34:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:34:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:34:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:34:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:35:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:35:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:35:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:35:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:35:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:35:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:35:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:35:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:35:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:35:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:35:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:35:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:37:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:39:19 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-03 11:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:39:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:39:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:39:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:39:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:39:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:39:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:39:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:39:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:40:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 11:40:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:40:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:40:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:40:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:40:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:40:57 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-03 11:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:41:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:41:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:41:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:41:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:42:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:42:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:42:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:42:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:42:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:43:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:43:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:43:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:43:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:43:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:43:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:43:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:43:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:44:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:44:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:44:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:44:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:45:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 11:45:33 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-06-03 11:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:50:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 11:51:24 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-06-03 11:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:52:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 11:53:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:54:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:56:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 11:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:58:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:58:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:59:07 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-06-03 11:59:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:59:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:59:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:59:28 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-06-03 11:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:59:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 11:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 11:59:55 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-06-03 12:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:00:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 12:01:14 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 12:01:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 12:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:02:14 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 12:02:17 --> 404 Page Not Found: Config/getuser
ERROR - 2021-06-03 12:02:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:03:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:04:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:04:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 12:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:06:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 12:06:41 --> 404 Page Not Found: Haoma/index
ERROR - 2021-06-03 12:08:56 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 12:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:10:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 12:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:12:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 12:12:56 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-03 12:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:14:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 12:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:16:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 12:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:17:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 12:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:20:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 12:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:25:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 12:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:33:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:33:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:34:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:37:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 12:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:40:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:41:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 12:41:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 12:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:44:12 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-03 12:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:45:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 12:46:36 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-03 12:47:02 --> 404 Page Not Found: Env/index
ERROR - 2021-06-03 12:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:48:57 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-03 12:49:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 12:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:51:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:51:21 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-03 12:51:43 --> 404 Page Not Found: Env/index
ERROR - 2021-06-03 12:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:52:15 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 12:52:40 --> 404 Page Not Found: Env/index
ERROR - 2021-06-03 12:52:41 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-06-03 12:52:45 --> 404 Page Not Found: Invoker/readonly
ERROR - 2021-06-03 12:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:53:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:53:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 12:53:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 12:53:48 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 12:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:54:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:55:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:55:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:55:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 12:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:58:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 12:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 12:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:03:39 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-06-03 13:04:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 13:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:05:26 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 13:06:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 13:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:12:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 13:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:13:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 13:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:19:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:20:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 13:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:21:56 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 13:21:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 13:22:00 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 13:22:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 13:22:12 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 13:22:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 13:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:22:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 13:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:24:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 13:24:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 13:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:27:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 13:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:29:02 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt9): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-06-03 13:29:02 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt9): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-06-03 13:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:31:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 13:31:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 13:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:32:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 13:32:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 13:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:36:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 13:36:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 13:37:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 13:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:39:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 13:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:43:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 13:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:46:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 13:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:48:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:48:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-03 13:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:50:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 13:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:53:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 13:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:59:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 13:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:02:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 14:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:04:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:05:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:06:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:07:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:08:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:12:08 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-03 14:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:14:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-03 14:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:20:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:20:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:20:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:22:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:24:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:24:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:27:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 14:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:29:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:32:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 14:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:36:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 14:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:37:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 14:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:38:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 14:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:40:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:40:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 14:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:41:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 14:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:45:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 14:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:47:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 14:48:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:49:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 14:49:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 14:50:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 14:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:51:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 14:51:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 14:52:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 14:52:23 --> 404 Page Not Found: Env/index
ERROR - 2021-06-03 14:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:58:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 14:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 14:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:00:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-03 15:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:07:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:08:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:10:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:12:44 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 15:12:44 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 15:12:44 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-03 15:12:44 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 15:12:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 15:12:44 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-03 15:12:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 15:12:44 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-03 15:12:44 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 15:12:44 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-03 15:12:45 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 15:12:46 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-03 15:12:46 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-03 15:12:46 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-03 15:12:46 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-03 15:12:46 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 15:12:46 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 15:12:46 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 15:12:46 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-03 15:12:46 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-03 15:12:46 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-03 15:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:18:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 15:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:21:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 15:22:11 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-06-03 15:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:24:22 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-06-03 15:24:43 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-06-03 15:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:26:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 15:26:34 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-06-03 15:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:30:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:30:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:30:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:32:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:33:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:33:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:33:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:33:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:33:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:33:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:34:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:34:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:34:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:35:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 15:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:36:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:38:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 15:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 15:39:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 15:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:40:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:42:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 15:44:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:44:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:45:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:45:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:45:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:45:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:45:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:46:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:46:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:46:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:46:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:46:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:47:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:47:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:47:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:47:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:48:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:48:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:48:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:48:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 15:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:49:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 15:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:59:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 15:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 15:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:00:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 16:00:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 16:00:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 16:01:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 16:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:06:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 16:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:06:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 16:08:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 16:08:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 16:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:09:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 16:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:12:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 16:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:16:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 16:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:17:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 16:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:21:27 --> 404 Page Not Found: Shell/index
ERROR - 2021-06-03 16:21:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:21:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 16:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:22:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 16:23:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 16:24:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 16:24:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 16:25:09 --> 404 Page Not Found: City/17
ERROR - 2021-06-03 16:25:10 --> 404 Page Not Found: City/17
ERROR - 2021-06-03 16:25:10 --> 404 Page Not Found: City/17
ERROR - 2021-06-03 16:25:10 --> 404 Page Not Found: City/17
ERROR - 2021-06-03 16:25:10 --> 404 Page Not Found: City/17
ERROR - 2021-06-03 16:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:28:20 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-06-03 16:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:29:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 16:29:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 16:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:36:17 --> 404 Page Not Found: English/index
ERROR - 2021-06-03 16:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:36:50 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-06-03 16:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:39:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 16:39:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 16:39:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 16:39:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 16:40:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:45:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 16:46:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 16:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:47:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 16:47:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 16:48:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 16:48:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 16:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:49:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 16:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:52:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 16:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 16:59:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 17:00:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 17:00:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 17:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:01:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 17:02:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 17:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:08:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 17:08:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 17:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:16:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:17:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:17:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:18:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:19:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:20:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 17:20:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 17:22:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 17:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:23:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:25:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:25:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:26:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:27:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:29:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:30:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:31:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:35:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 17:36:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:36:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 17:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:39:09 --> 404 Page Not Found: City/2
ERROR - 2021-06-03 17:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:43:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:49:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:49:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:50:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 17:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:52:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 17:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:54:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:56:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 17:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:57:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 17:57:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 17:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:00:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 18:00:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 18:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:01:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:06:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 18:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:09:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:09:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:11:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:14:09 --> 404 Page Not Found: Client_area/index
ERROR - 2021-06-03 18:14:13 --> 404 Page Not Found: Stalker_portal/c
ERROR - 2021-06-03 18:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:18:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:20:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:24:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:25:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 18:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:33:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 18:33:59 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 18:33:59 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 18:33:59 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-03 18:33:59 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 18:33:59 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 18:33:59 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-03 18:33:59 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-03 18:34:00 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 18:34:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 18:34:01 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-03 18:34:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 18:34:01 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-03 18:34:01 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-03 18:34:01 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-03 18:34:01 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-03 18:34:01 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 18:34:01 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 18:34:01 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 18:34:02 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-03 18:34:02 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-03 18:34:02 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-03 18:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:36:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:48:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 18:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:50:04 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-03 18:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:52:15 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-03 18:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:54:15 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-03 18:56:19 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-03 18:56:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:57:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:58:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 18:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 18:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:12:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 19:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:14:39 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 19:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:14:39 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-03 19:14:39 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 19:14:39 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 19:14:39 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-03 19:14:39 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 19:14:40 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-03 19:14:41 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 19:14:41 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-03 19:14:41 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-03 19:14:41 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-03 19:14:42 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-03 19:14:42 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 19:14:42 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 19:14:42 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 19:14:42 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-03 19:14:42 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-03 19:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:17:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 19:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:21:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 19:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:33:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 19:34:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 19:34:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 19:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:36:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 19:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:37:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 19:37:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 19:37:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 19:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:41:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 19:43:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 19:43:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:44:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 19:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:45:50 --> 404 Page Not Found: admin/Connection/index
ERROR - 2021-06-03 19:45:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 19:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:48:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 19:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:49:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 19:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:50:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 19:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:52:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 19:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:53:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 19:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:54:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 19:58:22 --> 404 Page Not Found: English/index
ERROR - 2021-06-03 20:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:09:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 20:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:11:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 20:11:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 20:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:21:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 20:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:24:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 20:24:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 20:26:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:30:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 20:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:32:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 20:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:32:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 20:32:47 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 20:32:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 20:32:50 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 20:32:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 20:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:33:02 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 20:33:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 20:33:08 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 20:33:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 20:33:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 20:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:35:59 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 20:35:59 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 20:36:05 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 20:36:06 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-03 20:36:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 20:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:38:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 20:38:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 20:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:39:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 20:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:41:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 20:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:45:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:46:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 20:47:22 --> 404 Page Not Found: Shell/index
ERROR - 2021-06-03 20:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:54:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 20:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:56:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 20:57:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 20:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 20:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:04:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:05:11 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-06-03 21:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:07:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:08:35 --> 404 Page Not Found: Env/index
ERROR - 2021-06-03 21:08:36 --> 404 Page Not Found: Vendor/.env
ERROR - 2021-06-03 21:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:12:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 21:12:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:14:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:15:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 21:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:17:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 21:17:50 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-03 21:18:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:21:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 21:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:22:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:22:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 21:23:31 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-03 21:23:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 21:24:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 21:24:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 21:24:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 21:25:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 21:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:27:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:27:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:28:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:28:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 21:28:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 21:29:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:29:22 --> 404 Page Not Found: Order/index
ERROR - 2021-06-03 21:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:33:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 21:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:36:34 --> 404 Page Not Found: Webfig/index
ERROR - 2021-06-03 21:36:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 21:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:37:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 21:37:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 21:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:40:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 21:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:43:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:43:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:44:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:45:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:48:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:52:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:52:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:53:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:53:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:55:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 21:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 21:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:00:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 22:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:05:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:06:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:07:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:08:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:09:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:11:05 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-03 22:14:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:18:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:18:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 22:19:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:19:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:19:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:19:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:20:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:21:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:21:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:22:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 22:22:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 22:22:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 22:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:22:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:22:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:23:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:25:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 22:26:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:28:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 22:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:30:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 22:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:31:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 22:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:32:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:35:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-03 22:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:41:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 22:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:43:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 22:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:43:52 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-06-03 22:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:45:00 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 22:45:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 22:45:00 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-03 22:45:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-03 22:45:00 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 22:45:00 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-03 22:45:01 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-03 22:45:01 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-03 22:45:01 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 22:45:01 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 22:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-03 22:45:02 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-03 22:45:03 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-03 22:45:03 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-03 22:45:03 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-03 22:45:03 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-03 22:45:03 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-03 22:45:03 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-03 22:45:03 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-03 22:45:03 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-03 22:45:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:46:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:46:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:46:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:48:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:51:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 22:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:53:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:53:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 22:54:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 22:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 22:58:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 22:59:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 22:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:00:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:02:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:02:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:03:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 23:03:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:05:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:06:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:06:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:06:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 23:06:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 23:06:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 23:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:08:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:18:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:19:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 23:20:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 23:20:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 23:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:21:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:24:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:27:34 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-03 23:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:30:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:30:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:30:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:32:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:32:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:33:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-03 23:33:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 23:33:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 23:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:34:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:35:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:35:06 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-06-03 23:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:36:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:36:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:38:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:39:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:40:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:40:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:41:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-03 23:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:41:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:41:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 23:44:05 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-06-03 23:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:44:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-03 23:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:49:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:55:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-03 23:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-03 23:59:53 --> 404 Page Not Found: Robotstxt/index
