<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-01 00:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:01:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 00:02:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:05:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 00:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:08:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-01 00:08:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:08:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:08:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:10:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:10:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:11:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:13:51 --> 404 Page Not Found: City/1
ERROR - 2021-06-01 00:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:19:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:20:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 00:20:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:21:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:21:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:21:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:22:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:23:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:26:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 00:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:27:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 00:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:30:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:31:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:32:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 00:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:33:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 00:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:35:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:36:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:36:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 00:36:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:37:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:38:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:39:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:43:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 00:43:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 00:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:49:32 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-01 00:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:51:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:52:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 00:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:54:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 00:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 00:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:00:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:01:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:01:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:02:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:06:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:07:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:11:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:11:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:14:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:15:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:16:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:18:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:20:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 01:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:35:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:35:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:36:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:36:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:37:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:40:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:43:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:46:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 01:47:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:51:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 01:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:52:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:56:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-01 01:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:59:27 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-01 01:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 01:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:01:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 02:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:08:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:08:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 02:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:15:23 --> 404 Page Not Found: City/16
ERROR - 2021-06-01 02:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:17:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 02:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:18:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 02:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:21:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 02:21:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 02:22:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 02:22:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 02:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:32:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:33:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:46:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 02:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:55:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 02:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:56:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 02:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 02:57:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 02:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:03:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:05:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-01 03:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:05:58 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-01 03:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:13:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:14:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:22:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:30:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:32:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:33:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:34:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:34:43 --> 404 Page Not Found: English/index
ERROR - 2021-06-01 03:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:36:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:37:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:38:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:39:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:40:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:41:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:42:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:46:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:49:07 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-01 03:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:50:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:50:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 03:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:56:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 03:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-06-01 04:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:04:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:07:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:07:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:12:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:13:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:14:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:14:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 04:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:15:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:15:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:16:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:17:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:18:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:19:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:20:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:21:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:22:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:27:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:31:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:32:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:33:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:34:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:35:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:38:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 04:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:49:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:50:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:55:55 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-01 04:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:59:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 04:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:01:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:04:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 05:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:05:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 05:05:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 05:06:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 05:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:09:27 --> 404 Page Not Found: E/tool
ERROR - 2021-06-01 05:09:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 05:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:13:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:14:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:21:58 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-01 05:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:28:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 05:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:31:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 05:31:23 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 05:31:23 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-01 05:31:23 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 05:31:23 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 05:31:23 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-01 05:31:23 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 05:31:24 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-01 05:31:24 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 05:31:24 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 05:31:24 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-01 05:31:24 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 05:31:24 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 05:31:24 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-01 05:31:25 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 05:31:25 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-01 05:31:25 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 05:31:25 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 05:31:25 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-01 05:31:25 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 05:31:25 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 05:31:26 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-01 05:31:26 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 05:31:27 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-01 05:31:27 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-01 05:31:27 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-01 05:31:27 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-01 05:31:27 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 05:31:27 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 05:31:28 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 05:31:28 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-01 05:31:29 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-01 05:31:29 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-01 05:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:41:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 05:41:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 05:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:43:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 05:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:49:46 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-01 05:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 05:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:03:58 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-06-01 06:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:25:40 --> 404 Page Not Found: Article/info
ERROR - 2021-06-01 06:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:27:33 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-06-01 06:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:37:03 --> 404 Page Not Found: Article/view
ERROR - 2021-06-01 06:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:43:09 --> 404 Page Not Found: English/index
ERROR - 2021-06-01 06:44:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 06:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 06:57:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 07:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:02:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 07:03:14 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 07:03:14 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-01 07:03:15 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-01 07:03:16 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-01 07:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:05:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 07:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:06:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 07:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:06:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 07:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 07:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:10:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 07:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:12:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 07:13:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 07:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:16:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 07:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:18:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:18:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:18:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:18:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:19:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:19:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:19:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:19:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:19:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:19:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:19:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:22:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 07:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:29:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:29:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:29:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:29:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 07:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:39:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 07:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:51:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:53:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 07:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 07:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:06:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 08:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:16:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 08:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:17:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 08:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:23:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:23:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:24:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:24:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:24:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:25:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:28:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-01 08:28:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:30:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-01 08:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:36:33 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-01 08:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:40:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:44:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:45:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:45:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:45:38 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 08:45:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 08:45:38 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-01 08:45:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 08:45:38 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 08:45:38 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-01 08:45:38 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 08:45:38 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-01 08:45:38 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 08:45:38 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 08:45:39 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-01 08:45:40 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 08:45:40 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-01 08:45:40 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-01 08:45:40 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-01 08:45:40 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-01 08:45:40 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 08:45:40 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 08:45:40 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 08:45:40 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-01 08:45:40 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-01 08:45:40 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-01 08:45:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:45:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 08:45:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 08:45:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:46:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 08:47:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 08:47:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 08:49:37 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-01 08:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:51:20 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-01 08:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:51:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 08:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:52:51 --> 404 Page Not Found: City/10
ERROR - 2021-06-01 08:52:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 08:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:56:30 --> 404 Page Not Found: City/1
ERROR - 2021-06-01 08:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 08:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:02:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 09:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:05:46 --> 404 Page Not Found: City/10
ERROR - 2021-06-01 09:06:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:07:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 09:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:07:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 09:08:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 09:09:20 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-01 09:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:10:29 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-01 09:10:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 09:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:12:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 09:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:21:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 09:21:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-01 09:21:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 09:22:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:23:15 --> 404 Page Not Found: City/1
ERROR - 2021-06-01 09:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:24:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 09:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:24:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 09:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:25:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 09:27:55 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-01 09:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:28:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 09:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:38:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 09:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:39:45 --> 404 Page Not Found: City/10
ERROR - 2021-06-01 09:40:01 --> 404 Page Not Found: 1/all
ERROR - 2021-06-01 09:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:40:15 --> 404 Page Not Found: All/index
ERROR - 2021-06-01 09:40:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 09:40:21 --> 404 Page Not Found: City/1
ERROR - 2021-06-01 09:40:33 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-01 09:41:09 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-01 09:41:10 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-01 09:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:44:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 09:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:47:23 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-01 09:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:49:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:53:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 09:53:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 09:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:57:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 09:57:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 09:57:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 09:57:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 09:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 09:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:00:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:01:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:01:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 10:01:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 10:01:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:01:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:02:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:02:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:03:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:03:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:03:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 10:04:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:04:18 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-01 10:04:18 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-01 10:04:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:08:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 10:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:10:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 10:10:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 10:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:10:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:10:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 10:11:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:12:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:12:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:13:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:17:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:29:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 10:29:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:29:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 10:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:30:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 10:30:56 --> 404 Page Not Found: WebEditor/Upload.asp
ERROR - 2021-06-01 10:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:31:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 10:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:40:41 --> 404 Page Not Found: English/index
ERROR - 2021-06-01 10:40:45 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-01 10:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:45:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:45:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:46:35 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-01 10:46:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:46:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:47:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:48:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:48:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:53:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:53:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:55:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 10:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:57:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:57:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 10:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 10:59:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 10:59:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 11:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:09:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:18:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 11:19:56 --> 404 Page Not Found: Env/index
ERROR - 2021-06-01 11:19:56 --> 404 Page Not Found: Vendor/phpunit
ERROR - 2021-06-01 11:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:24:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 11:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:26:08 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-01 11:28:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:28:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:28:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:29:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:29:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:29:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:29:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:31:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 11:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:35:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:35:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:36:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:36:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:36:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 11:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:36:55 --> 404 Page Not Found: Invoker/readonly
ERROR - 2021-06-01 11:36:55 --> 404 Page Not Found: Manager/html
ERROR - 2021-06-01 11:37:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 11:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:43:19 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-01 11:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:48:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 11:49:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:50:13 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-06-01 11:50:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 11:50:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 11:50:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 11:50:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 11:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 11:59:17 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-01 11:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:06:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-01 12:06:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-01 12:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:08:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 12:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:19:51 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 12:19:51 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 12:19:51 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-01 12:19:51 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 12:19:51 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-01 12:19:52 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 12:19:53 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-01 12:19:53 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-01 12:19:53 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-01 12:19:53 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-01 12:19:53 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 12:19:53 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 12:19:53 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 12:19:53 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-01 12:19:53 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-01 12:19:53 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-01 12:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:21:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:21:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:22:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:23:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:28:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-01 12:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:29:01 --> 404 Page Not Found: City/15
ERROR - 2021-06-01 12:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:32:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:33:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:38:45 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-01 12:39:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:39:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:39:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:39:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:40:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:40:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:40:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:44:27 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-01 12:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:48:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:48:56 --> 404 Page Not Found: City/9
ERROR - 2021-06-01 12:48:57 --> 404 Page Not Found: City/9
ERROR - 2021-06-01 12:48:57 --> 404 Page Not Found: City/9
ERROR - 2021-06-01 12:48:57 --> 404 Page Not Found: City/9
ERROR - 2021-06-01 12:48:57 --> 404 Page Not Found: City/9
ERROR - 2021-06-01 12:49:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:49:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:50:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:50:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:50:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:50:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:50:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:50:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:51:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 12:51:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 12:51:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 12:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:56:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 12:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:05:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 13:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:08:07 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-06-01 13:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:11:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 13:11:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 13:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:17:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 13:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:19:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 13:20:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 13:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:23:48 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-01 13:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:25:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 13:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:28:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 13:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:30:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 13:30:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 13:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:31:47 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-01 13:31:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 13:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:38:26 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-01 13:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:39:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 13:40:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 13:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:46:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 13:46:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 13:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:50:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 13:51:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 13:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:57:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 13:59:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 14:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:02:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 14:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:03:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 14:07:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:08:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:09:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:10:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:11:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:12:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:15:45 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-01 14:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:18:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:18:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:23:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:24:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:24:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:24:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:24:53 --> 404 Page Not Found: E/tool
ERROR - 2021-06-01 14:25:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:25:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:25:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 14:25:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:30:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 14:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:32:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 14:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:35:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:38:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:38:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:39:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:41:20 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 14:41:20 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 14:41:20 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-01 14:41:20 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 14:41:20 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 14:41:20 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-01 14:41:20 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 14:41:20 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-01 14:41:20 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 14:41:20 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 14:41:21 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-01 14:41:22 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 14:41:22 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-01 14:41:22 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-01 14:41:22 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-01 14:41:22 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-01 14:41:22 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 14:41:22 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 14:41:22 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 14:41:22 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-01 14:41:22 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-01 14:41:22 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-01 14:41:26 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-01 14:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:43:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 14:43:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 14:43:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 14:44:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:45:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:46:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:47:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 14:49:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:49:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:49:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:50:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:50:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:52:57 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-01 14:53:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:54:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 14:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:56:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 14:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 14:58:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 15:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:22:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 15:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:26:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 15:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:39:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:39:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:40:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:40:31 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-06-01 15:40:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:40:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:40:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:41:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:41:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:42:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:42:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:43:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:43:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:44:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:45:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 15:46:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:46:30 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 15:46:30 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 15:46:30 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-01 15:46:30 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 15:46:30 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 15:46:31 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-01 15:46:31 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 15:46:31 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-01 15:46:31 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 15:46:31 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 15:46:31 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-01 15:46:31 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 15:46:31 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 15:46:31 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-01 15:46:31 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 15:46:31 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-01 15:46:32 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 15:46:32 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 15:46:32 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-01 15:46:32 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 15:46:32 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 15:46:32 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-01 15:46:32 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 15:46:32 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-01 15:46:32 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-01 15:46:33 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-01 15:46:33 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-01 15:46:33 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 15:46:33 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 15:46:33 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 15:46:33 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-01 15:46:33 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-01 15:46:33 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-01 15:46:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:46:42 --> 404 Page Not Found: Article/view
ERROR - 2021-06-01 15:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:47:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:47:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:47:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 15:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 15:59:02 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-01 15:59:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 15:59:02 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-01 15:59:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 15:59:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 16:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:20:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:25:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:31:57 --> 404 Page Not Found: English/index
ERROR - 2021-06-01 16:35:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 16:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:37:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 16:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:44:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 16:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 16:44:54 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-06-01 16:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:45:06 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-06-01 16:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:45:13 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-06-01 16:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:51:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 16:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 16:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:05:06 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-01 17:05:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:05:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:06:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 17:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:11:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:11:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:11:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:11:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:13:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 17:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:16:12 --> 404 Page Not Found: Env/index
ERROR - 2021-06-01 17:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:21:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 17:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:24:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 17:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:25:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:25:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:26:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:27:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:28:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:28:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:29:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:29:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:29:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:29:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:29:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:29:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:31:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:31:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:31:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:32:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:35:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:37:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 17:37:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:37:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:39:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 17:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:51:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:51:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:51:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:51:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:52:03 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-01 17:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:55:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:55:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:55:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:55:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 17:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 17:57:52 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-01 17:58:12 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-06-01 18:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:03:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 18:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:04:40 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-06-01 18:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:26:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 18:26:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:29:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 18:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:31:31 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 18:31:31 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 18:31:31 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-01 18:31:31 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 18:31:31 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 18:31:31 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-01 18:31:32 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 18:31:33 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-01 18:31:33 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-01 18:31:33 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-01 18:31:33 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-01 18:31:33 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 18:31:33 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 18:31:33 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 18:31:33 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-01 18:31:33 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-01 18:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:33:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 18:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:47:21 --> 404 Page Not Found: English/index
ERROR - 2021-06-01 18:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 18:59:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 19:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:11:23 --> 404 Page Not Found: Nice%20ports%2C/Tri%6Eity.txt%2ebak
ERROR - 2021-06-01 19:13:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:16:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:19:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 19:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:22:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 19:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:27:05 --> 404 Page Not Found: Xxxss/index
ERROR - 2021-06-01 19:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:32:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 19:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:38:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:40:31 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-01 19:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:54:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 19:54:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 19:54:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 19:54:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 19:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:55:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 19:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 19:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:00:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 20:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:03:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:11:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 20:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:12:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:12:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:16:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:18:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:22:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:23:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:23:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:23:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:24:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:24:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:24:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:24:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:25:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:25:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:25:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:26:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:26:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:26:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:26:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:26:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:26:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:27:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:27:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:28:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:28:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:28:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:28:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:28:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:28:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:28:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:28:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:29:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:29:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:29:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:29:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:29:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:30:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:30:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:30:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:30:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:30:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 20:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:30:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:30:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:32:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 20:32:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:33:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 20:34:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:37:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:37:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 20:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:45:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 20:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:53:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:54:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 20:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:02:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:07:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 21:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 21:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 21:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 21:08:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 21:08:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 21:08:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 21:08:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 21:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:12:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:12:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:12:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:13:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:13:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:13:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:14:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 21:15:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:16:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:17:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:17:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:17:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 21:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:18:39 --> 404 Page Not Found: ReportServer/index
ERROR - 2021-06-01 21:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:23:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:27:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:30:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:31:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:44:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:47:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 21:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:50:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 21:50:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 21:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:54:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 21:54:55 --> 404 Page Not Found: All/index
ERROR - 2021-06-01 21:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:57:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 21:59:20 --> 404 Page Not Found: City/1
ERROR - 2021-06-01 21:59:39 --> 404 Page Not Found: City/index
ERROR - 2021-06-01 22:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:05:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 22:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:07:42 --> 404 Page Not Found: English/index
ERROR - 2021-06-01 22:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:10:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 22:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:11:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 22:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:12:06 --> 404 Page Not Found: Haoma/index
ERROR - 2021-06-01 22:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:15:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 22:15:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 22:15:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 22:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:21:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 22:22:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:26:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 22:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:28:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:29:09 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-01 22:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:31:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 22:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:35:21 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-06-01 22:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:42:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 22:42:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 22:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:44:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-01 22:44:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 22:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:46:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 22:47:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-01 22:48:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 22:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:49:19 --> 404 Page Not Found: Env/index
ERROR - 2021-06-01 22:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:52:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 22:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:53:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 22:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:58:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 22:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 22:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:02:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 23:04:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 23:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:06:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 23:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:12:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-01 23:12:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 23:13:05 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-06-01 23:13:07 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-06-01 23:13:09 --> 404 Page Not Found: Pma/index
ERROR - 2021-06-01 23:13:10 --> 404 Page Not Found: Myadmin/index
ERROR - 2021-06-01 23:13:12 --> 404 Page Not Found: Sql/index
ERROR - 2021-06-01 23:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:13:14 --> 404 Page Not Found: Mysql/index
ERROR - 2021-06-01 23:13:17 --> 404 Page Not Found: Mysqladmin/index
ERROR - 2021-06-01 23:13:21 --> 404 Page Not Found: Db/index
ERROR - 2021-06-01 23:13:23 --> 404 Page Not Found: Database/index
ERROR - 2021-06-01 23:14:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 23:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:17:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 23:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:20:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 23:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:24:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 23:26:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 23:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:27:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:28:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 23:30:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 23:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:32:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 23:33:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 23:35:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 23:35:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 23:35:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 23:35:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 23:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:36:18 --> 404 Page Not Found: Wap/trading
ERROR - 2021-06-01 23:36:19 --> 404 Page Not Found: Market/market-ws
ERROR - 2021-06-01 23:36:19 --> 404 Page Not Found: M/ticker
ERROR - 2021-06-01 23:36:19 --> 404 Page Not Found: Base/exchange_article
ERROR - 2021-06-01 23:36:20 --> 404 Page Not Found: Legal/currency
ERROR - 2021-06-01 23:36:20 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-06-01 23:36:20 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-06-01 23:36:21 --> 404 Page Not Found: H5/index
ERROR - 2021-06-01 23:36:22 --> 404 Page Not Found: H5/index
ERROR - 2021-06-01 23:36:24 --> 404 Page Not Found: Otc/index
ERROR - 2021-06-01 23:36:24 --> 404 Page Not Found: M/allticker
ERROR - 2021-06-01 23:36:24 --> 404 Page Not Found: Web/api
ERROR - 2021-06-01 23:36:25 --> 404 Page Not Found: Wap/trading
ERROR - 2021-06-01 23:36:25 --> 404 Page Not Found: admin/Index/index
ERROR - 2021-06-01 23:36:29 --> 404 Page Not Found: User/allroleinfo
ERROR - 2021-06-01 23:36:29 --> 404 Page Not Found: User/userlist
ERROR - 2021-06-01 23:36:29 --> 404 Page Not Found: Room/getRoomBangFans
ERROR - 2021-06-01 23:36:30 --> 404 Page Not Found: Recruit/download_url
ERROR - 2021-06-01 23:36:31 --> 404 Page Not Found: Api/content_bottom
ERROR - 2021-06-01 23:36:31 --> 404 Page Not Found: Home/loadmymanager
ERROR - 2021-06-01 23:36:31 --> 404 Page Not Found: S_api/basic
ERROR - 2021-06-01 23:36:31 --> 404 Page Not Found: Api/user
ERROR - 2021-06-01 23:36:31 --> 404 Page Not Found: S_api/basic
ERROR - 2021-06-01 23:36:32 --> 404 Page Not Found: Index/login
ERROR - 2021-06-01 23:36:34 --> 404 Page Not Found: N/news
ERROR - 2021-06-01 23:36:34 --> 404 Page Not Found: Xianyu/index
ERROR - 2021-06-01 23:36:34 --> 404 Page Not Found: Xy/index
ERROR - 2021-06-01 23:36:36 --> 404 Page Not Found: Data/json
ERROR - 2021-06-01 23:36:37 --> 404 Page Not Found: GetLocale/index
ERROR - 2021-06-01 23:36:37 --> 404 Page Not Found: FePublicInfo/index
ERROR - 2021-06-01 23:36:37 --> 404 Page Not Found: Account/login
ERROR - 2021-06-01 23:36:38 --> 404 Page Not Found: Pc/Lang
ERROR - 2021-06-01 23:36:39 --> 404 Page Not Found: Home/Bind
ERROR - 2021-06-01 23:36:39 --> 404 Page Not Found: Static/local
ERROR - 2021-06-01 23:36:40 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-01 23:36:41 --> 404 Page Not Found: Ajax/allcoin_a
ERROR - 2021-06-01 23:36:41 --> 404 Page Not Found: Mh/phone.do
ERROR - 2021-06-01 23:36:42 --> 404 Page Not Found: Bannerdo/index
ERROR - 2021-06-01 23:36:42 --> 404 Page Not Found: Iframe/rankgiftgotapi
ERROR - 2021-06-01 23:36:42 --> 404 Page Not Found: Home/GetAllGameCategory
ERROR - 2021-06-01 23:36:43 --> 404 Page Not Found: Home/GetQrCodeInfo
ERROR - 2021-06-01 23:36:43 --> 404 Page Not Found: Registerasp/index
ERROR - 2021-06-01 23:36:44 --> 404 Page Not Found: Step1asp/index
ERROR - 2021-06-01 23:36:47 --> 404 Page Not Found: Front/User
ERROR - 2021-06-01 23:36:48 --> 404 Page Not Found: Api/ApiHub
ERROR - 2021-06-01 23:36:48 --> 404 Page Not Found: Ajax/index
ERROR - 2021-06-01 23:36:49 --> 404 Page Not Found: Ajax/index
ERROR - 2021-06-01 23:36:52 --> 404 Page Not Found: Front/FctPage
ERROR - 2021-06-01 23:36:54 --> 404 Page Not Found: Infe/rest
ERROR - 2021-06-01 23:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:36:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-01 23:36:57 --> 404 Page Not Found: CscpLoginWeb/app
ERROR - 2021-06-01 23:37:02 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-06-01 23:37:02 --> 404 Page Not Found: Home/login
ERROR - 2021-06-01 23:37:02 --> 404 Page Not Found: admin//index
ERROR - 2021-06-01 23:37:03 --> 404 Page Not Found: Home/Get
ERROR - 2021-06-01 23:37:03 --> 404 Page Not Found: Mtjahtml/index
ERROR - 2021-06-01 23:37:03 --> 404 Page Not Found: Site/get-hq
ERROR - 2021-06-01 23:37:04 --> 404 Page Not Found: Api/uploads
ERROR - 2021-06-01 23:37:05 --> 404 Page Not Found: Ws/index
ERROR - 2021-06-01 23:37:07 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-06-01 23:37:07 --> 404 Page Not Found: Api/index
ERROR - 2021-06-01 23:37:11 --> 404 Page Not Found: Home/GetInitSource
ERROR - 2021-06-01 23:37:15 --> 404 Page Not Found: Homes/index
ERROR - 2021-06-01 23:37:17 --> 404 Page Not Found: Homes/index
ERROR - 2021-06-01 23:37:17 --> 404 Page Not Found: Mobile/v3
ERROR - 2021-06-01 23:37:18 --> 404 Page Not Found: Static/data
ERROR - 2021-06-01 23:37:19 --> 404 Page Not Found: Sign/index
ERROR - 2021-06-01 23:37:21 --> 404 Page Not Found: Api/site
ERROR - 2021-06-01 23:37:21 --> 404 Page Not Found: Api/stock
ERROR - 2021-06-01 23:37:23 --> 404 Page Not Found: Api/wallet
ERROR - 2021-06-01 23:37:24 --> 404 Page Not Found: H5/index
ERROR - 2021-06-01 23:37:24 --> 404 Page Not Found: Base/goexjs
ERROR - 2021-06-01 23:37:24 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-01 23:37:24 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-01 23:37:24 --> 404 Page Not Found: Index/register.html
ERROR - 2021-06-01 23:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:37:34 --> 404 Page Not Found: Api/currency
ERROR - 2021-06-01 23:37:35 --> 404 Page Not Found: Api/mobile
ERROR - 2021-06-01 23:37:36 --> 404 Page Not Found: Api/apps
ERROR - 2021-06-01 23:37:36 --> 404 Page Not Found: Market/getStockBaseInfo
ERROR - 2021-06-01 23:37:36 --> 404 Page Not Found: Api/contactWay
ERROR - 2021-06-01 23:37:37 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-01 23:37:40 --> 404 Page Not Found: Api/exclude
ERROR - 2021-06-01 23:37:40 --> 404 Page Not Found: Api/user
ERROR - 2021-06-01 23:37:40 --> 404 Page Not Found: Kkrps/im_group
ERROR - 2021-06-01 23:37:40 --> 404 Page Not Found: FriendGroup/list
ERROR - 2021-06-01 23:37:41 --> 404 Page Not Found: Api/index
ERROR - 2021-06-01 23:37:41 --> 404 Page Not Found: Api/common
ERROR - 2021-06-01 23:37:41 --> 404 Page Not Found: Stock/search.html
ERROR - 2021-06-01 23:37:41 --> 404 Page Not Found: Api/user
ERROR - 2021-06-01 23:37:42 --> 404 Page Not Found: Api/product
ERROR - 2021-06-01 23:37:42 --> 404 Page Not Found: Api/config-init
ERROR - 2021-06-01 23:37:42 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-06-01 23:37:42 --> 404 Page Not Found: Portal/index
ERROR - 2021-06-01 23:37:43 --> 404 Page Not Found: Loan/index
ERROR - 2021-06-01 23:37:43 --> 404 Page Not Found: Appxz/index.html
ERROR - 2021-06-01 23:37:48 --> 404 Page Not Found: Home/main
ERROR - 2021-06-01 23:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:39:43 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 23:39:43 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 23:39:43 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-01 23:39:43 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-01 23:39:43 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-01 23:39:44 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-01 23:39:45 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-01 23:40:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 23:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:45:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:46:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-01 23:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:48:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 23:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:49:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-01 23:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-01 23:59:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
