<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-01 00:06:30 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-10-01 00:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 00:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 00:22:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 00:23:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 00:24:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 00:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 00:32:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 00:41:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 00:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 01:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 01:00:48 --> 404 Page Not Found: 1rar/index
ERROR - 2021-10-01 01:00:48 --> 404 Page Not Found: 1zip/index
ERROR - 2021-10-01 01:00:48 --> 404 Page Not Found: 2rar/index
ERROR - 2021-10-01 01:00:48 --> 404 Page Not Found: 2zip/index
ERROR - 2021-10-01 01:00:48 --> 404 Page Not Found: 3rar/index
ERROR - 2021-10-01 01:00:48 --> 404 Page Not Found: 3zip/index
ERROR - 2021-10-01 01:00:48 --> 404 Page Not Found: 4rar/index
ERROR - 2021-10-01 01:00:48 --> 404 Page Not Found: 4zip/index
ERROR - 2021-10-01 01:00:48 --> 404 Page Not Found: 5rar/index
ERROR - 2021-10-01 01:00:48 --> 404 Page Not Found: 5zip/index
ERROR - 2021-10-01 01:00:48 --> 404 Page Not Found: 6rar/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 6zip/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 7rar/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 7zip/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 8rar/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 8zip/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 9rar/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 9zip/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 1targz/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 17z/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 2targz/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 27z/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 3targz/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 37z/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 4targz/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 47z/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 5targz/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 57z/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 6targz/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 67z/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 7targz/index
ERROR - 2021-10-01 01:00:49 --> 404 Page Not Found: 77z/index
ERROR - 2021-10-01 01:00:50 --> 404 Page Not Found: 8targz/index
ERROR - 2021-10-01 01:00:50 --> 404 Page Not Found: 87z/index
ERROR - 2021-10-01 01:00:50 --> 404 Page Not Found: 9targz/index
ERROR - 2021-10-01 01:00:50 --> 404 Page Not Found: 97z/index
ERROR - 2021-10-01 01:00:50 --> 404 Page Not Found: Fuwuqirar/index
ERROR - 2021-10-01 01:00:50 --> 404 Page Not Found: Fuwuqizip/index
ERROR - 2021-10-01 01:00:50 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-10-01 01:00:50 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Wwwrootbakrar/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Wwwrootbakzip/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Webrar/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Webzip/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Wwwbakrar/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Wwwbakzip/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Webbakrar/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Webbakzip/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-10-01 01:00:51 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Wwwxuanhaonetbakrar/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Wwwxuanhaonetbakzip/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Www_xuanhao_netbakrar/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Www_xuanhao_netbakzip/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Wwwxuanhaonetbakrar/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Wwwxuanhaonetbakzip/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Xuanhaonetbakrar/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Xuanhaonetbakzip/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Xuanhaobakrar/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Xuanhaobakzip/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Dbrar/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Dbzip/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Wzrar/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Wzzip/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Fdsarar/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Fdsazip/index
ERROR - 2021-10-01 01:00:52 --> 404 Page Not Found: Wangzhanrar/index
ERROR - 2021-10-01 01:00:53 --> 404 Page Not Found: Wangzhanzip/index
ERROR - 2021-10-01 01:00:53 --> 404 Page Not Found: Rootrar/index
ERROR - 2021-10-01 01:00:53 --> 404 Page Not Found: Rootzip/index
ERROR - 2021-10-01 01:00:53 --> 404 Page Not Found: Adminrar/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Adminzip/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Datarar/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Datazip/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Ggrar/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Ggzip/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Viprar/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Vipzip/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Databackrar/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Databackzip/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Databackuprar/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Databackupzip/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Hdocsrar/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Hdocszip/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Releasezip/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Templaterar/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Templatezip/index
ERROR - 2021-10-01 01:00:54 --> 404 Page Not Found: Arar/index
ERROR - 2021-10-01 01:00:55 --> 404 Page Not Found: Azip/index
ERROR - 2021-10-01 01:00:55 --> 404 Page Not Found: Brar/index
ERROR - 2021-10-01 01:00:55 --> 404 Page Not Found: Bzip/index
ERROR - 2021-10-01 01:00:55 --> 404 Page Not Found: Testrar/index
ERROR - 2021-10-01 01:00:55 --> 404 Page Not Found: Testzip/index
ERROR - 2021-10-01 01:00:55 --> 404 Page Not Found: Barar/index
ERROR - 2021-10-01 01:00:55 --> 404 Page Not Found: Bazip/index
ERROR - 2021-10-01 01:01:02 --> 404 Page Not Found: Beifenrar/index
ERROR - 2021-10-01 01:01:02 --> 404 Page Not Found: Beifenzip/index
ERROR - 2021-10-01 01:01:02 --> 404 Page Not Found: Bfrar/index
ERROR - 2021-10-01 01:01:02 --> 404 Page Not Found: Bfzip/index
ERROR - 2021-10-01 01:01:03 --> 404 Page Not Found: Bakrar/index
ERROR - 2021-10-01 01:01:03 --> 404 Page Not Found: Bakzip/index
ERROR - 2021-10-01 01:01:03 --> 404 Page Not Found: Ebakrar/index
ERROR - 2021-10-01 01:01:03 --> 404 Page Not Found: Ebakzip/index
ERROR - 2021-10-01 01:01:03 --> 404 Page Not Found: Backrar/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Backzip/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Mysqlrar/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Mysqlzip/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Backupdatarar/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Backupdatazip/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Backup_datarar/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Backup_datazip/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Wwwrootbaktargz/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Wwwbaktargz/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Webbaktargz/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-10-01 01:01:04 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-10-01 01:01:05 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-10-01 01:01:05 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-10-01 01:01:05 --> 404 Page Not Found: Wwwxuanhaonetbaktargz/index
ERROR - 2021-10-01 01:01:05 --> 404 Page Not Found: Www_xuanhao_netbaktargz/index
ERROR - 2021-10-01 01:01:05 --> 404 Page Not Found: Wwwxuanhaonetbaktargz/index
ERROR - 2021-10-01 01:01:05 --> 404 Page Not Found: Xuanhaonetbaktargz/index
ERROR - 2021-10-01 01:01:05 --> 404 Page Not Found: Xuanhaobaktargz/index
ERROR - 2021-10-01 01:01:05 --> 404 Page Not Found: Dbtargz/index
ERROR - 2021-10-01 01:01:06 --> 404 Page Not Found: Wztargz/index
ERROR - 2021-10-01 01:01:06 --> 404 Page Not Found: Fdsatargz/index
ERROR - 2021-10-01 01:01:06 --> 404 Page Not Found: Wangzhantargz/index
ERROR - 2021-10-01 01:01:06 --> 404 Page Not Found: Roottargz/index
ERROR - 2021-10-01 01:01:06 --> 404 Page Not Found: Admintargz/index
ERROR - 2021-10-01 01:01:06 --> 404 Page Not Found: Datatargz/index
ERROR - 2021-10-01 01:01:06 --> 404 Page Not Found: Ggtargz/index
ERROR - 2021-10-01 01:01:06 --> 404 Page Not Found: Viptargz/index
ERROR - 2021-10-01 01:01:06 --> 404 Page Not Found: Databacktargz/index
ERROR - 2021-10-01 01:01:07 --> 404 Page Not Found: Databackuptargz/index
ERROR - 2021-10-01 01:01:07 --> 404 Page Not Found: Hdocstargz/index
ERROR - 2021-10-01 01:01:07 --> 404 Page Not Found: Releasetargz/index
ERROR - 2021-10-01 01:01:07 --> 404 Page Not Found: Templatetargz/index
ERROR - 2021-10-01 01:01:07 --> 404 Page Not Found: Atargz/index
ERROR - 2021-10-01 01:01:07 --> 404 Page Not Found: Bbak/index
ERROR - 2021-10-01 01:01:07 --> 404 Page Not Found: Testtargz/index
ERROR - 2021-10-01 01:01:07 --> 404 Page Not Found: Batargz/index
ERROR - 2021-10-01 01:01:14 --> 404 Page Not Found: Beifentargz/index
ERROR - 2021-10-01 01:01:14 --> 404 Page Not Found: Bftargz/index
ERROR - 2021-10-01 01:01:14 --> 404 Page Not Found: Baktargz/index
ERROR - 2021-10-01 01:01:14 --> 404 Page Not Found: Ebaktargz/index
ERROR - 2021-10-01 01:01:14 --> 404 Page Not Found: Backtargz/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Mysqltargz/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Backupdatatargz/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Backup_datatargz/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Xuanhaobak7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Db7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Wz7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Fdsa7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Wangzhan7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Root7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Admin7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Data7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Gg7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Vip7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Databack7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Databackup7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Hdocs7z/index
ERROR - 2021-10-01 01:01:15 --> 404 Page Not Found: Release7z/index
ERROR - 2021-10-01 01:01:16 --> 404 Page Not Found: Template7z/index
ERROR - 2021-10-01 01:01:16 --> 404 Page Not Found: A7z/index
ERROR - 2021-10-01 01:01:16 --> 404 Page Not Found: B7z/index
ERROR - 2021-10-01 01:01:16 --> 404 Page Not Found: Test7z/index
ERROR - 2021-10-01 01:01:16 --> 404 Page Not Found: Ba7z/index
ERROR - 2021-10-01 01:01:19 --> 404 Page Not Found: Beifen7z/index
ERROR - 2021-10-01 01:01:19 --> 404 Page Not Found: Bf7z/index
ERROR - 2021-10-01 01:01:19 --> 404 Page Not Found: Bak7z/index
ERROR - 2021-10-01 01:01:19 --> 404 Page Not Found: Ebak7z/index
ERROR - 2021-10-01 01:01:19 --> 404 Page Not Found: Back7z/index
ERROR - 2021-10-01 01:01:19 --> 404 Page Not Found: Mysql7z/index
ERROR - 2021-10-01 01:01:19 --> 404 Page Not Found: Backupdata7z/index
ERROR - 2021-10-01 01:01:19 --> 404 Page Not Found: Backup_data7z/index
ERROR - 2021-10-01 01:01:19 --> 404 Page Not Found: Wfphprar/index
ERROR - 2021-10-01 01:01:19 --> 404 Page Not Found: Wfphpzip/index
ERROR - 2021-10-01 01:01:19 --> 404 Page Not Found: Wfphp7z/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Wfphptargz/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Order7z/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Ordertargz/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Orderrar/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Orderzip/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Zzfhworderrar/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Zzfhworderzip/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Zzfhworder7z/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Zzfhwordertargz/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Wforderrar/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Wforderzip/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Wforder7z/index
ERROR - 2021-10-01 01:01:20 --> 404 Page Not Found: Wfordertargz/index
ERROR - 2021-10-01 01:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 01:14:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 01:27:02 --> 404 Page Not Found: City/1
ERROR - 2021-10-01 01:53:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 02:20:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 02:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 02:58:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 03:06:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 03:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 03:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 03:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 03:21:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 03:23:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 03:26:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 03:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 03:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 03:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 03:45:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 03:45:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 03:45:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 03:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 03:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 03:59:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 04:01:02 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 275
ERROR - 2021-10-01 04:01:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 04:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 04:28:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 04:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 04:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 05:01:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:01:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:01:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:02:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:02:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 05:03:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:11:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 05:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 05:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 05:31:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:33:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:33:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:40:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:41:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 05:43:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 05:51:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:52:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 05:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:02:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:06:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:07:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:08:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:10:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:14:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:14:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:14:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 06:17:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 06:19:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:26:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:27:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:28:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 06:28:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:29:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:30:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:31:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-01 06:31:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:33:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 06:36:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:38:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:39:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:40:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 06:42:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:44:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:46:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:48:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:48:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:51:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:53:38 --> 404 Page Not Found: Index/login
ERROR - 2021-10-01 06:54:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 06:58:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 06:59:12 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-01 06:59:12 --> 404 Page Not Found: admin//index
ERROR - 2021-10-01 06:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 06:59:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 06:59:13 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-01 06:59:13 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-10-01 06:59:14 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-10-01 06:59:15 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-10-01 06:59:15 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-10-01 06:59:15 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-10-01 06:59:15 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-10-01 06:59:16 --> 404 Page Not Found: User/index
ERROR - 2021-10-01 06:59:16 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-10-01 06:59:16 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-10-01 06:59:16 --> 404 Page Not Found: Wcm/index
ERROR - 2021-10-01 06:59:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 07:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 07:01:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 07:02:39 --> 404 Page Not Found: City/1
ERROR - 2021-10-01 07:03:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-01 07:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 07:26:50 --> 404 Page Not Found: Content/13
ERROR - 2021-10-01 07:27:39 --> 404 Page Not Found: Ct/OU4pbp7jL4K2Cz.html
ERROR - 2021-10-01 07:27:45 --> 404 Page Not Found: Ct/Ok4obsSlMI70ED.html
ERROR - 2021-10-01 07:32:24 --> Severity: Warning --> Missing argument 1 for Kefu::show() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 359
ERROR - 2021-10-01 07:35:55 --> 404 Page Not Found: Xinwen/news482395.html
ERROR - 2021-10-01 07:38:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 07:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 07:40:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 07:43:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 07:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 07:45:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 07:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 07:54:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 07:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 07:55:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 08:02:25 --> 404 Page Not Found: City/10
ERROR - 2021-10-01 08:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 08:06:31 --> 404 Page Not Found: City/1
ERROR - 2021-10-01 08:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 08:33:06 --> 404 Page Not Found: City/16
ERROR - 2021-10-01 08:33:07 --> 404 Page Not Found: City/16
ERROR - 2021-10-01 08:33:07 --> 404 Page Not Found: City/16
ERROR - 2021-10-01 08:33:07 --> 404 Page Not Found: City/16
ERROR - 2021-10-01 08:33:07 --> 404 Page Not Found: City/16
ERROR - 2021-10-01 08:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 09:03:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 09:05:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 09:05:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 09:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 09:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 09:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 09:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 09:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 09:22:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 09:25:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 09:25:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 09:26:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 09:27:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 09:27:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 09:29:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 09:29:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 09:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 09:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 09:39:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 09:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 09:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 09:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 10:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 10:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 10:02:24 --> 404 Page Not Found: Cart/index
ERROR - 2021-10-01 10:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 10:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 10:07:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:29:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:30:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:35:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 10:39:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:39:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:40:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:41:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:43:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 10:45:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 10:46:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 10:49:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:49:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:51:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:52:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 10:53:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 10:53:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 11:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 11:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 11:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 11:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 11:21:28 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-01 11:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 11:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 11:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 12:01:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 12:11:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 12:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 12:17:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 12:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 12:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 12:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 12:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 12:51:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 12:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 12:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 12:55:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 12:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 13:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 13:10:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 13:12:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 13:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 13:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 13:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 14:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 14:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 14:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 14:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 14:20:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 14:31:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 14:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 14:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 14:47:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-01 14:50:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 14:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 15:10:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 15:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 15:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 15:20:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:21:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:21:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:21:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:21:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:22:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:22:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:22:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:22:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:23:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 15:24:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:25:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:25:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:28:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 15:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 15:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 15:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 16:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 16:06:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:06:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:26:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:26:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 16:26:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:27:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:27:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:27:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 16:27:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:27:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:27:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:28:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:29:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:29:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 16:29:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:30:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:30:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:30:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:30:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 16:30:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:30:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 16:31:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:31:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:31:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:31:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 16:31:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 16:31:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 16:31:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 16:31:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:32:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 16:32:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:32:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 16:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 16:38:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 16:46:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 16:47:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 16:54:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 16:55:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 17:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 17:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 17:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 17:29:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 17:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 17:52:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 17:53:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 17:53:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 17:57:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 17:59:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-01 18:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 18:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 18:10:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 18:11:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 18:19:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 18:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 18:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 18:29:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 18:34:02 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-10-01 18:34:02 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-10-01 18:34:02 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-10-01 18:34:02 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-10-01 18:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 18:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 18:37:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 18:37:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 18:45:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 18:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 18:47:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 18:47:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 18:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 18:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 19:05:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:07:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:08:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 19:08:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:09:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:10:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:12:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:13:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:13:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:13:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:13:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:14:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:14:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:15:19 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-10-01 19:15:19 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-10-01 19:15:19 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-10-01 19:15:19 --> 404 Page Not Found: Cgi-bin/kerbynet
ERROR - 2021-10-01 19:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:18:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 19:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 19:18:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:19:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:21:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:22:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:22:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:28:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-01 19:28:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 19:28:47 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-10-01 19:32:09 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-10-01 19:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 19:37:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 19:37:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 19:37:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 19:37:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 19:37:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:37:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:37:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 19:37:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 19:37:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 19:37:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 19:38:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:38:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 19:38:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 20:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 20:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 20:06:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-01 20:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 20:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 20:20:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 20:24:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:24:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 20:24:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:25:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:27:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:28:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:28:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:30:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:32:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:32:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:33:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:33:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:34:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:35:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:36:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:38:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:39:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:40:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:41:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:42:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:42:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:43:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:44:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 20:44:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:45:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:45:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 20:45:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 20:46:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:47:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 20:47:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:47:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 20:47:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:48:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 20:48:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:49:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 20:49:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:49:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 20:50:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 20:50:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 20:50:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 21:00:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 21:02:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:03:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:03:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:03:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:04:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:04:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:04:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:05:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:06:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:06:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:06:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:11:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 21:13:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:14:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:14:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:15:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:16:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:16:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:16:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:16:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:16:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:17:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:22:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 21:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:23:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:28:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:30:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:30:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:30:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:40:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:41:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-01 21:41:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 21:45:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 21:45:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 21:45:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 21:45:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 21:45:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 21:45:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 21:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 21:59:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 22:02:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:02:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:03:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:03:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:03:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:03:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:03:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:04:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:04:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:04:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:04:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:04:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:04:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:05:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:05:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:05:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:06:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:06:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:06:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:07:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:08:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:08:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 22:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 22:12:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 22:13:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:13:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:14:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:14:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:16:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:17:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:18:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:19:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 22:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 22:41:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 22:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 22:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 22:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 22:48:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:48:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:49:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 22:56:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 23:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 23:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 23:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 23:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 23:12:38 --> 404 Page Not Found: City/2
ERROR - 2021-10-01 23:14:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:14:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 23:17:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:17:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:17:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:17:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:20:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 23:21:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 23:24:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 23:25:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 23:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 23:26:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 23:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 23:31:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 23:32:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-01 23:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-01 23:53:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:53:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:53:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:53:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:54:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-01 23:58:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-01 23:59:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
