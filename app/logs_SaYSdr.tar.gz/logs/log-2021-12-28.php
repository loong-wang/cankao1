<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-28 00:12:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:12:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:13:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 00:15:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:16:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:17:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 00:17:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:18:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:19:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:21:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:21:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:21:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:23:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:24:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:28:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:29:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:30:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 00:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 00:35:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 00:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 00:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 00:56:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 01:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 01:22:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 01:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 01:53:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 01:54:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 01:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 01:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 02:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 02:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 02:14:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 02:14:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 02:30:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 02:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 02:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 02:39:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 02:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 02:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 02:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 02:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 02:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 03:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 03:04:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 03:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 03:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 03:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 03:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 03:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 03:26:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:27:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:28:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:28:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:29:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:29:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:30:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:31:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:31:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:32:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:32:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:33:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:33:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:34:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:34:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:36:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:37:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:37:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:39:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:41:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:41:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:41:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:43:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:44:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 03:44:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:45:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:46:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:47:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:47:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:48:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:49:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:49:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:49:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:50:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:50:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 03:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 03:50:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:51:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:51:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:52:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:55:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 03:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 04:00:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:01:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:02:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:02:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:02:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:03:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:03:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:03:42 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-28 04:04:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:04:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 04:05:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:06:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:09:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:14:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:19:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:19:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:20:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:20:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 04:24:52 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-28 04:26:49 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-28 04:26:54 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-28 04:27:42 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-28 04:28:09 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-12-28 04:29:06 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-28 04:29:06 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-28 04:31:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 04:34:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 04:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 04:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 04:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 04:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 04:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 04:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 05:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 05:27:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 05:27:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 05:28:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 05:29:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 05:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 05:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 05:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 05:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 05:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 05:55:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 06:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 06:02:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 06:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 06:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 06:08:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 06:08:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 06:23:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 06:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 06:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 06:39:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 06:43:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 06:48:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 06:52:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 06:52:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 06:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 07:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 07:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 07:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 07:28:13 --> 404 Page Not Found: Yidianqiao/2019101129917.html
ERROR - 2021-12-28 07:28:14 --> 404 Page Not Found: Read/122
ERROR - 2021-12-28 07:29:08 --> 404 Page Not Found: Gxfzdjxchtm/index
ERROR - 2021-12-28 07:29:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 07:29:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 07:42:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 07:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 07:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 08:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 08:03:04 --> 404 Page Not Found: Sitemap48524html/index
ERROR - 2021-12-28 08:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 08:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 08:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 08:26:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 08:34:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 08:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 08:44:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 08:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 08:48:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 08:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 08:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 09:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 09:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 09:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 09:10:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 09:10:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 09:10:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 09:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 09:16:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 09:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 09:26:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 09:32:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 09:33:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 09:34:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 09:34:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 09:36:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 09:36:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 09:38:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 09:38:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 09:39:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 09:39:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 09:41:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 09:42:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 09:49:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 09:49:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 09:51:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 09:55:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 09:55:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 09:55:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 09:56:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 09:57:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 09:59:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 10:00:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 10:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 10:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 10:06:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 10:17:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 10:21:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 10:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 10:27:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 10:28:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 10:36:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 10:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 10:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 10:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 10:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 10:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 10:47:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 10:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 10:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 10:53:23 --> 404 Page Not Found: City/10
ERROR - 2021-12-28 10:54:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 10:58:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 11:03:41 --> 404 Page Not Found: City/16
ERROR - 2021-12-28 11:08:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:09:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:11:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:12:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:13:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:13:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:14:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:16:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:17:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:17:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:17:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:18:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:18:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:24:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 11:25:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 11:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 11:25:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:28:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 11:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 11:33:34 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-28 11:34:33 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-28 11:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 11:36:21 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-28 11:36:39 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-28 11:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 11:43:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 11:43:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 11:43:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 11:46:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 11:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 11:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 11:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 12:01:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 12:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 12:08:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:08:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 12:09:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:13:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:23:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 12:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 12:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 12:36:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 12:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 12:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 12:49:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:50:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:51:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:52:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 12:53:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 12:59:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:59:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 12:59:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 13:01:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:03:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:03:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:03:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 13:03:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:04:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 13:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 13:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 13:07:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:07:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:08:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 13:12:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:13:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:15:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:16:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 13:26:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 13:32:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 13:32:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 13:47:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:56:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 13:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 13:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 13:58:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 13:58:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 14:01:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 14:06:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 14:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 14:19:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 14:20:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 14:26:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 14:28:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 14:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 14:30:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 14:34:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 14:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 14:35:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 14:48:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 14:48:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 14:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 14:53:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 14:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 14:58:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:03:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:04:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:04:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:05:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:05:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:05:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:06:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:06:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:06:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:06:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:07:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:07:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:07:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:08:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:08:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:09:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:09:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:09:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:10:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:11:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:11:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:12:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:12:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:14:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:14:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:15:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:15:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:15:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 15:16:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 15:18:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:19:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:19:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:19:50 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-12-28 15:21:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:21:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:24:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:24:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:30:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:38:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 15:45:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:45:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:48:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 15:49:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:49:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:49:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:49:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:49:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 15:55:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 15:56:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 15:56:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 15:58:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:04:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 16:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 16:07:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:07:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:07:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:08:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:08:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:08:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:08:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:08:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:13:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:14:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:19:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:23:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:24:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:24:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:25:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:25:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:25:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:25:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:28:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:28:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:29:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:29:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:30:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:30:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:30:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:30:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:30:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:30:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:31:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:32:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:33:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:33:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:34:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:36:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:36:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:38:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 16:40:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:41:15 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-12-28 16:41:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:42:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:42:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:43:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:43:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:43:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 16:44:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:44:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 16:44:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 16:44:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 16:44:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 16:44:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:44:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:45:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 16:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 16:47:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:49:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:49:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:49:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:49:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:49:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:49:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:49:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:52:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 16:54:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:55:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:56:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 16:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 17:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 17:06:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:10:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:18:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 17:18:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 17:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:24:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 17:25:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 17:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 17:30:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 17:31:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:31:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 17:37:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:37:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:39:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:39:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:39:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:40:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:41:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:45:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 17:46:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:47:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 17:51:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 17:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:07:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:08:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:09:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:11:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:13:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:15:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 18:15:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 18:15:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:16:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 18:16:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 18:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 18:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 18:18:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:20:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:20:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 18:20:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:21:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:22:55 --> 404 Page Not Found: Text4041640686975/index
ERROR - 2021-12-28 18:22:56 --> 404 Page Not Found: Evox/about
ERROR - 2021-12-28 18:22:56 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-12-28 18:22:56 --> 404 Page Not Found: Sdk/index
ERROR - 2021-12-28 18:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:23:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 18:23:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 18:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:25:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 18:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:31:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 18:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:34:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:35:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:41:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 18:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:45:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:53:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 18:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 18:56:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 19:00:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 19:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 19:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 19:04:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 19:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 19:15:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 19:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 19:31:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 19:34:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 19:37:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 19:54:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 19:54:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 19:55:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 19:55:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 19:59:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 20:02:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 20:05:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 20:06:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 20:13:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 20:20:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 20:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 20:25:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 20:26:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 20:30:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 20:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 20:34:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 20:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 20:38:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 20:41:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 20:45:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 20:45:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 20:48:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 20:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 20:50:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 20:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 20:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 21:00:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 21:00:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 21:04:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 21:09:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 21:10:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 21:11:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 21:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 21:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 21:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 21:36:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 21:37:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 21:38:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 21:39:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 21:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 21:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 21:49:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:50:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 21:51:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:51:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:51:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:51:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:52:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:54:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:54:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:54:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:56:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:57:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:57:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:57:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:58:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 21:59:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:59:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:59:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:59:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 21:59:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 22:00:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 22:01:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-28 22:03:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 22:04:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 22:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 22:11:19 --> 404 Page Not Found: Core/favicon.ico
ERROR - 2021-12-28 22:16:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 22:20:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 22:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 22:27:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 22:28:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 22:28:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 22:29:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 22:40:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 22:41:47 --> 404 Page Not Found: City/1
ERROR - 2021-12-28 22:45:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 22:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 23:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 23:09:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 23:15:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:15:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 23:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 23:22:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 23:25:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:27:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:28:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 23:29:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:30:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:30:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:32:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:32:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:33:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 23:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 23:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 23:35:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-28 23:36:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:36:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:37:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-28 23:38:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:40:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:41:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:41:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:41:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:42:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:45:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 23:57:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:57:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-28 23:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-28 23:58:43 --> 404 Page Not Found: Robotstxt/index
