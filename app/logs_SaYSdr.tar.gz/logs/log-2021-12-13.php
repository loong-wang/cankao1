<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-13 00:00:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 00:03:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 00:04:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 00:04:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 00:05:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 00:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 00:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 00:14:45 --> 404 Page Not Found: Defaultaspx/index
ERROR - 2021-12-13 00:18:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 00:24:13 --> 404 Page Not Found: Cn/search.asp
ERROR - 2021-12-13 00:29:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 00:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 00:38:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 00:38:31 --> 404 Page Not Found: Assets/js
ERROR - 2021-12-13 00:43:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 00:50:52 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-12-13 01:04:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 01:07:57 --> 404 Page Not Found: Cn/inc
ERROR - 2021-12-13 01:12:50 --> 404 Page Not Found: JS/ueditor
ERROR - 2021-12-13 01:14:09 --> 404 Page Not Found: City/1
ERROR - 2021-12-13 01:17:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 01:17:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 01:18:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 01:19:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 01:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 01:27:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 01:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 01:45:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 01:47:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 01:47:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 01:49:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 01:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 01:58:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 02:10:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 02:11:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 02:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 02:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 02:18:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 02:18:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 02:19:02 --> 404 Page Not Found: Script/UeDitor
ERROR - 2021-12-13 02:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 02:20:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 02:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 02:24:04 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-13 02:24:04 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-13 02:24:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 02:24:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 02:24:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 02:24:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 02:24:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 02:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 02:24:05 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-13 02:24:05 --> 404 Page Not Found: Member/space
ERROR - 2021-12-13 02:24:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 02:24:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 02:24:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 02:24:05 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 02:24:06 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 02:24:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 02:24:06 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-13 02:24:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 02:24:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 02:24:06 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 02:24:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 02:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 02:39:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 02:43:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 02:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 02:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 02:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 02:51:42 --> 404 Page Not Found: 1/10000
ERROR - 2021-12-13 02:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 02:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 02:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 03:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 03:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 03:20:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 03:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 03:28:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 03:28:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 03:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 03:40:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 03:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 03:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 04:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 04:07:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 04:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 04:23:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 04:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 04:40:09 --> 404 Page Not Found: En/ueditor
ERROR - 2021-12-13 04:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 04:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 04:52:56 --> 404 Page Not Found: Common/ueditor
ERROR - 2021-12-13 04:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 04:54:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 04:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 05:00:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 05:03:53 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-12-13 05:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 05:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 05:14:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:14:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:15:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:15:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:18:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 05:21:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:21:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:21:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:23:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:24:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 05:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 05:28:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:28:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 05:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 05:43:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:45:17 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-12-13 05:45:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:46:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:47:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:49:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:50:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:50:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 05:52:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:54:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:55:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:56:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 05:59:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 06:00:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:05:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 06:09:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:12:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:14:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 06:14:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 06:17:01 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-13 06:17:02 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-13 06:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 06:17:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 06:17:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 06:17:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 06:17:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 06:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 06:17:03 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-13 06:17:03 --> 404 Page Not Found: Member/space
ERROR - 2021-12-13 06:17:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 06:17:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 06:17:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 06:17:03 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 06:17:03 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 06:17:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 06:17:04 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-13 06:17:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 06:17:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 06:17:04 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 06:17:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 06:20:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:24:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 06:31:00 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-12-13 06:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 06:31:55 --> 404 Page Not Found: City/1
ERROR - 2021-12-13 06:31:58 --> 404 Page Not Found: City/1
ERROR - 2021-12-13 06:31:58 --> 404 Page Not Found: City/1
ERROR - 2021-12-13 06:32:35 --> 404 Page Not Found: City/1
ERROR - 2021-12-13 06:33:07 --> 404 Page Not Found: City/1
ERROR - 2021-12-13 06:38:32 --> 404 Page Not Found: Simplewind/Core
ERROR - 2021-12-13 06:38:32 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-13 06:43:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:45:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:45:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:45:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:45:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:45:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:45:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:46:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:46:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:47:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:47:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:47:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:50:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:56:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 06:58:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 07:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 07:13:19 --> 404 Page Not Found: Shell/index
ERROR - 2021-12-13 07:14:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 07:15:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 07:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 07:31:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 07:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 07:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 07:45:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 07:50:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 07:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 07:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 08:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 08:08:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 08:11:56 --> 404 Page Not Found: Data/s.asp
ERROR - 2021-12-13 08:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 08:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 08:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 08:34:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 08:34:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 08:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 08:42:24 --> 404 Page Not Found: Common/ueditor
ERROR - 2021-12-13 08:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 08:46:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 08:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 08:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 08:58:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 09:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 09:37:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 09:37:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 09:43:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 09:51:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 09:53:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:53:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:53:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:53:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:53:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:53:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:58:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:59:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:59:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:59:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:59:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:59:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:59:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:59:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:59:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 09:59:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 10:04:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:05:46 --> 404 Page Not Found: Login/index
ERROR - 2021-12-13 10:11:42 --> 404 Page Not Found: Data/img
ERROR - 2021-12-13 10:11:42 --> 404 Page Not Found: Data/img
ERROR - 2021-12-13 10:11:42 --> 404 Page Not Found: Data/img
ERROR - 2021-12-13 10:19:27 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-12-13 10:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 10:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 10:35:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 10:36:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 10:41:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 10:42:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:42:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:43:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:43:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:43:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:44:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:44:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:49:47 --> 404 Page Not Found: Assets/js
ERROR - 2021-12-13 10:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 10:54:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 10:55:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:57:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 10:59:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 11:02:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 11:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:04:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 11:08:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 11:09:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 11:12:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 11:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:16:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 11:21:07 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-13 11:21:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 11:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:22:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 11:23:01 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-13 11:23:09 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-13 11:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:25:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 11:26:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 11:29:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 11:29:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 11:30:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 11:30:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:35:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 11:38:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 11:39:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 11:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:46:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 11:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 11:50:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 11:51:30 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-12-13 11:56:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 11:57:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 12:00:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 12:01:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 12:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 12:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 12:06:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 12:10:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 12:15:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 12:17:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 12:18:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 12:19:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 12:19:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 12:21:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 12:22:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 12:25:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 12:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 12:35:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 12:47:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 12:51:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 12:51:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 12:53:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 12:57:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 12:57:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 12:57:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:00:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 13:01:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 13:01:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 13:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 13:04:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:07:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:07:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:09:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 13:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 13:11:36 --> 404 Page Not Found: Data/data.asp
ERROR - 2021-12-13 13:21:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:24:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:27:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:28:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 13:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 13:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 13:31:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:34:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 13:37:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 13:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 13:41:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:41:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:44:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Member/space
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 13:44:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 13:44:18 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 13:44:18 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 13:44:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 13:44:18 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-13 13:44:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 13:44:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 13:44:18 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 13:44:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 13:44:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 13:45:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 13:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 13:47:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:50:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 13:50:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 13:51:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 13:52:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 13:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 13:54:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 13:58:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 13:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 13:59:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 14:01:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 14:05:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 14:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 14:07:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 14:11:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 14:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 14:14:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 14:17:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 14:21:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 14:23:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 14:28:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 14:31:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 14:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 14:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 14:38:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 14:43:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 14:44:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 14:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 14:49:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 14:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 14:52:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 14:53:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 14:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 14:54:21 --> 404 Page Not Found: Administration/Content
ERROR - 2021-12-13 14:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 14:55:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 14:59:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 15:04:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 15:04:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 15:06:08 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-13 15:06:09 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-13 15:06:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 15:06:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 15:06:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 15:06:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 15:06:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 15:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 15:06:09 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-13 15:06:09 --> 404 Page Not Found: Member/space
ERROR - 2021-12-13 15:06:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 15:06:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 15:06:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 15:06:10 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 15:06:10 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 15:06:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 15:06:10 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-13 15:06:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 15:06:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 15:06:11 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-13 15:06:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 15:06:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:10:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:13:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 15:16:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:16:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:20:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 15:21:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 15:22:40 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-12-13 15:26:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:26:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:30:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:33:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 15:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 15:39:59 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-13 15:40:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 15:43:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:45:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 15:46:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:50:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:51:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 15:56:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 15:56:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:02:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:03:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 16:06:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:10:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:10:53 --> 404 Page Not Found: Administration/Content
ERROR - 2021-12-13 16:13:09 --> 404 Page Not Found: En/ueditor
ERROR - 2021-12-13 16:13:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:15:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:15:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:15:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:15:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:16:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:18:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:18:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:20:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:23:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:23:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:23:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:23:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:24:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:24:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:26:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:30:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:30:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 16:32:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 16:33:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:33:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 16:36:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:36:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 16:39:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 16:40:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 16:40:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:40:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:43:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:45:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 16:46:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:48:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 16:50:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:50:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:53:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 16:55:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:55:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 16:56:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 16:59:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 17:00:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 17:03:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 17:05:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 17:08:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 17:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 17:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 17:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 17:23:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 17:24:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 17:24:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 17:24:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 17:31:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 17:33:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 17:36:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 17:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 17:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 17:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 17:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 17:41:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 17:46:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 17:50:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 17:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 17:57:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 17:58:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 17:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 18:00:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:00:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:00:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 18:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 18:10:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 18:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 18:16:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 18:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 18:20:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:20:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:20:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:20:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:20:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:20:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:20:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:20:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:20:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:31:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 18:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 18:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 18:48:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 18:49:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 18:57:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 19:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 19:02:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 19:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 19:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 19:13:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 19:16:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 19:21:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 19:25:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 19:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 19:34:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 19:36:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 19:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 19:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 19:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 19:57:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 19:58:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 19:58:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 19:58:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 19:59:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 20:00:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 20:02:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 20:02:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 20:03:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 20:04:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 20:07:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 20:14:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 20:14:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 20:15:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 20:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 20:19:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 20:29:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 20:35:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 20:35:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 20:38:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 20:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 20:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 20:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 20:44:06 --> 404 Page Not Found: Aspsqlasp/index
ERROR - 2021-12-13 20:48:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 20:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 20:50:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 20:51:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 20:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 20:51:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 20:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 20:58:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 20:59:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:00:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 21:00:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 21:00:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 21:00:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:02:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:02:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:02:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:02:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:07:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 21:13:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:13:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 21:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 21:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 21:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 21:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 21:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 21:16:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 21:18:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 21:23:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 21:25:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 21:27:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:27:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 21:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 21:27:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:27:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:30:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 21:33:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 21:33:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:33:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:33:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:33:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:33:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:34:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:34:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:34:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:36:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 21:36:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 21:37:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 21:39:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 21:40:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 21:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 21:42:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 21:43:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 21:46:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:50:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 21:50:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 21:52:22 --> 404 Page Not Found: JS/ueditor
ERROR - 2021-12-13 21:53:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 21:53:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 21:53:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:54:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:54:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:54:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:55:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:55:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 21:57:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 21:57:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 21:57:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 21:59:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:00:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:00:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:00:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:01:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:02:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 22:02:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:02:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 22:02:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:02:58 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-12-13 22:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 22:06:24 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-13 22:07:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 22:10:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 22:14:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:18:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 22:23:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:23:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:23:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 22:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 22:27:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 22:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 22:30:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:30:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:31:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:31:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:31:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:31:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:31:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:32:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:32:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:32:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:33:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:36:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:37:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:40:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 22:43:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 22:47:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:48:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:48:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-13 22:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 22:53:11 --> 404 Page Not Found: Kangasp/index
ERROR - 2021-12-13 22:54:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 22:54:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 22:55:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 22:57:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 23:00:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:00:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 23:04:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:05:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-13 23:07:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 23:20:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 23:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 23:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 23:30:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-13 23:31:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 23:34:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 23:34:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 23:39:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:39:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:40:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:41:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:42:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 23:43:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:44:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:44:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:44:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:50:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 23:53:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:53:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:54:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:54:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 23:57:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-13 23:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-13 23:58:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-13 23:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
