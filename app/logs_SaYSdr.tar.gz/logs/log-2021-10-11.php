<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-11 00:00:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:01:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:03:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:04:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:04:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:05:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:06:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:06:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:08:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:10:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:11:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:13:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:14:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:17:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:17:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-11 00:18:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:18:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:19:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:21:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:24:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:26:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:27:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:29:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:32:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:35:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:37:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:38:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:41:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:44:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 00:47:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:48:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:55:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:55:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-11 00:55:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:55:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:56:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 00:56:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 00:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 00:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 00:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 00:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 00:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 00:59:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 01:00:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 01:02:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-11 01:03:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 01:04:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:05:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:06:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 01:06:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:07:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:07:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:08:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 01:09:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:10:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:10:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 01:10:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:10:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 01:11:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 01:14:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-11 01:17:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 01:20:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 01:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 01:36:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 01:42:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:42:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:43:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:43:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:44:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 01:45:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 01:52:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 01:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 01:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 01:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 01:58:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 02:02:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 02:05:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 02:20:25 --> 404 Page Not Found: City/10
ERROR - 2021-10-11 02:22:26 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-11 02:22:26 --> 404 Page Not Found: admin//index
ERROR - 2021-10-11 02:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 02:22:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 02:22:28 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-11 02:22:28 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-10-11 02:22:28 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-10-11 02:22:28 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-10-11 02:22:29 --> 404 Page Not Found: User/index
ERROR - 2021-10-11 02:22:29 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-10-11 02:22:29 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-10-11 02:22:29 --> 404 Page Not Found: Wcm/index
ERROR - 2021-10-11 02:41:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 02:42:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 02:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 02:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 03:01:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 03:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 03:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 03:10:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 03:33:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 03:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 03:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 03:45:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 03:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 04:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 04:03:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 04:04:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 04:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 04:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 04:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 04:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 04:50:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 04:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 04:54:38 --> 404 Page Not Found: User/index
ERROR - 2021-10-11 04:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 05:01:17 --> 404 Page Not Found: CurrentTime/index
ERROR - 2021-10-11 05:02:19 --> 404 Page Not Found: City/index
ERROR - 2021-10-11 05:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 05:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 05:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 05:10:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 05:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 05:17:44 --> 404 Page Not Found: Cart/index
ERROR - 2021-10-11 05:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 05:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 05:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 05:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 06:04:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 06:04:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 06:11:08 --> 404 Page Not Found: User/index
ERROR - 2021-10-11 06:12:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 06:15:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-11 06:19:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-11 06:23:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-11 06:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 06:37:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 06:37:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 06:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 06:45:39 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-11 06:45:39 --> 404 Page Not Found: admin//index
ERROR - 2021-10-11 06:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 06:45:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 06:45:40 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-11 06:45:40 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-10-11 06:45:40 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-10-11 06:45:42 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-10-11 06:45:42 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-10-11 06:45:43 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-10-11 06:45:43 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-10-11 06:45:43 --> 404 Page Not Found: User/index
ERROR - 2021-10-11 06:45:43 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-10-11 06:45:43 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-10-11 06:45:43 --> 404 Page Not Found: Wcm/index
ERROR - 2021-10-11 06:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 07:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 07:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 07:19:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 07:30:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 07:30:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 07:30:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 07:30:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 07:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 07:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 07:40:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 07:40:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 07:51:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 08:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 08:02:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 08:09:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 08:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 08:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 08:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 08:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 08:22:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 08:31:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 08:38:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 08:38:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 08:38:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 08:38:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 08:41:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 08:43:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 08:44:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 08:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 09:01:07 --> 404 Page Not Found: City/10
ERROR - 2021-10-11 09:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 09:02:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 09:05:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 09:07:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 09:29:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 09:29:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 09:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 09:30:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 09:37:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 09:39:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 09:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 09:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 09:52:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 09:54:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 09:54:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 09:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 09:56:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 09:56:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:01:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:01:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:02:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:03:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:04:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 10:12:02 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-10-11 10:12:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:14:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:15:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 10:16:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:16:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:17:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:17:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:20:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:22:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:23:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:24:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:24:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:25:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:25:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:26:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:26:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:26:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:29:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:30:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:30:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:31:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:31:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:33:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 10:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 10:46:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:47:48 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-11 10:47:48 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-11 10:49:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:49:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:50:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:50:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:51:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:53:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:53:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:53:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:53:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:53:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 10:54:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:54:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 10:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 10:57:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 11:00:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 11:00:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 11:02:41 --> 404 Page Not Found: Index/login
ERROR - 2021-10-11 11:06:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 11:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 11:15:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 11:21:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 11:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 11:44:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 11:53:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 11:53:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 11:58:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 11:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 12:23:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 12:28:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 12:37:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 12:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 12:46:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 12:46:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 12:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 12:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 13:11:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 13:19:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 13:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 13:31:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 13:33:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 13:33:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 13:34:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 13:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 13:35:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 13:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 13:45:39 --> 404 Page Not Found: Cweb/Process
ERROR - 2021-10-11 13:46:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 13:46:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 13:46:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 13:46:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 13:46:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 13:47:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 13:47:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 13:47:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 13:47:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 13:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 13:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 13:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 13:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 13:57:44 --> 404 Page Not Found: Cweb/Process
ERROR - 2021-10-11 14:00:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 14:00:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 14:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 14:06:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 14:12:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 14:14:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 14:14:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 14:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 14:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 14:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 14:18:11 --> 404 Page Not Found: Xinwen/page.aspx
ERROR - 2021-10-11 14:21:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 14:21:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 14:27:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 14:31:01 --> 404 Page Not Found: Xinwen/page.aspx
ERROR - 2021-10-11 14:43:37 --> 404 Page Not Found: Web/index
ERROR - 2021-10-11 14:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 14:56:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-11 14:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 15:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 15:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 15:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 15:17:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 15:21:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 15:22:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-11 15:22:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 15:31:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 15:36:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 15:37:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 15:37:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 15:43:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 15:49:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 15:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 15:51:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 15:52:48 --> 404 Page Not Found: Catalogasp/index
ERROR - 2021-10-11 15:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 16:05:28 --> 404 Page Not Found: Catalogasp/index
ERROR - 2021-10-11 16:14:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 16:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 16:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 16:20:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 16:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 16:34:07 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-11 16:37:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:39:09 --> 404 Page Not Found: City/16
ERROR - 2021-10-11 16:39:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:41:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:41:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:43:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:43:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:43:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:44:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:44:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:45:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 16:45:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:45:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:45:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 16:55:21 --> 404 Page Not Found: S/index
ERROR - 2021-10-11 16:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 17:00:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 17:09:49 --> 404 Page Not Found: S/index
ERROR - 2021-10-11 17:18:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 17:18:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 17:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 17:26:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 17:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 17:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 17:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 17:54:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 18:01:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 18:02:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 18:02:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 18:03:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 18:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 18:12:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-11 18:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 18:23:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 18:24:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 18:24:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 18:32:49 --> 404 Page Not Found: 404/index.html
ERROR - 2021-10-11 18:32:49 --> 404 Page Not Found: 404/index.html
ERROR - 2021-10-11 18:45:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-11 18:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 18:56:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 18:58:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 19:09:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 19:12:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-11 19:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 19:12:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 19:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 19:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 19:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 19:24:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 19:26:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 19:26:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 19:26:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 19:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 19:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 19:27:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 19:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 19:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 19:51:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 19:52:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 19:57:47 --> 404 Page Not Found: S/index
ERROR - 2021-10-11 19:59:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 20:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 20:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 20:21:22 --> 404 Page Not Found: S/index
ERROR - 2021-10-11 20:22:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 20:25:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 20:36:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 20:38:03 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-11 20:38:43 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-10-11 20:45:27 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-11 20:48:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 20:49:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 20:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 21:03:55 --> 404 Page Not Found: Quanzhi/index
ERROR - 2021-10-11 21:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 21:07:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 21:23:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 21:26:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 21:27:33 --> 404 Page Not Found: Quanzhi/index
ERROR - 2021-10-11 21:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 21:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 22:06:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 22:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 22:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 22:09:50 --> 404 Page Not Found: X/search
ERROR - 2021-10-11 22:10:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 22:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 22:10:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 22:11:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 22:13:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 22:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 22:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 22:26:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 22:27:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 22:30:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 22:34:07 --> 404 Page Not Found: X/search
ERROR - 2021-10-11 22:36:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 22:38:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 22:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 23:00:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 23:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 23:16:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 23:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 23:23:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 23:31:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 23:31:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-11 23:38:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:39:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:39:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:39:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-11 23:39:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:40:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:41:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:41:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:41:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:41:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:41:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:42:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 23:52:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-11 23:53:13 --> 404 Page Not Found: Zh-cn/learning
ERROR - 2021-10-11 23:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-11 23:58:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
