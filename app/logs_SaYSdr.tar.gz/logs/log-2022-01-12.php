<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-12 00:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 00:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 00:26:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 00:27:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 00:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 00:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 00:31:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 00:33:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 00:38:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 00:47:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 00:55:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 01:08:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 01:10:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 01:12:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 01:16:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 01:17:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 01:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 01:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 01:43:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 02:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 02:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 02:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 02:18:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 02:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 02:24:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 02:24:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 02:26:16 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-12 02:26:16 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-12 02:26:24 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-12 02:28:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 02:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 02:36:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 02:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 02:48:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 02:53:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 02:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 02:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 02:58:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 02:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 03:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 03:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 03:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 03:04:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 03:15:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 03:16:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 03:22:11 --> 404 Page Not Found: 404/index.html
ERROR - 2022-01-12 03:22:11 --> 404 Page Not Found: 404/index.html
ERROR - 2022-01-12 03:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 03:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 03:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 03:44:21 --> 404 Page Not Found: City/1
ERROR - 2022-01-12 03:58:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 04:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 04:01:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 04:05:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 04:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 04:09:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-01-12 04:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 04:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 04:23:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 04:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 04:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 04:50:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 04:53:19 --> 404 Page Not Found: City/16
ERROR - 2022-01-12 04:56:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 05:13:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 05:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 05:16:42 --> 404 Page Not Found: City/15
ERROR - 2022-01-12 05:18:03 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2022-01-12 05:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 05:26:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 05:29:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 05:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 05:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 05:35:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 05:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 05:59:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 05:59:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 06:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 06:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 06:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 06:10:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 06:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 06:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 06:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 06:41:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 06:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 06:44:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 06:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 06:54:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 07:02:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 07:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 07:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 07:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 07:06:43 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-01-12 07:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 07:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 07:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 07:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 07:25:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 07:33:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 07:41:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 07:42:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 07:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 07:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 07:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 07:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:00:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 08:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:01:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 08:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:05:18 --> 404 Page Not Found: M/qitachongwu
ERROR - 2022-01-12 08:05:20 --> 404 Page Not Found: Detail/43258.html
ERROR - 2022-01-12 08:05:56 --> 404 Page Not Found: Thread-447352-1-1html/index
ERROR - 2022-01-12 08:05:58 --> 404 Page Not Found: Waf_50xhtml/index
ERROR - 2022-01-12 08:06:00 --> 404 Page Not Found: Wap/index
ERROR - 2022-01-12 08:06:00 --> 404 Page Not Found: Bbs/thread
ERROR - 2022-01-12 08:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:06:16 --> 404 Page Not Found: Flash/7191.htm
ERROR - 2022-01-12 08:06:42 --> 404 Page Not Found: Tagcloud/HwcOJ5vd0wMW3wMB85LgJ5vi85uk2.html
ERROR - 2022-01-12 08:07:13 --> 404 Page Not Found: Meinv/index
ERROR - 2022-01-12 08:07:31 --> 404 Page Not Found: 364/363244
ERROR - 2022-01-12 08:07:50 --> 404 Page Not Found: 2015-04-15/detail-icczmvun9508183.d.html
ERROR - 2022-01-12 08:07:51 --> 404 Page Not Found: M/index
ERROR - 2022-01-12 08:08:08 --> 404 Page Not Found: Shop/24550186
ERROR - 2022-01-12 08:08:10 --> 404 Page Not Found: Tieba/index
ERROR - 2022-01-12 08:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:10:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 08:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:15:29 --> 404 Page Not Found: App/views
ERROR - 2022-01-12 08:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:17:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 08:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:34:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 08:35:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 08:35:37 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-01-12 08:37:54 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-12 08:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:42:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 08:47:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 08:47:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 08:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 08:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 09:02:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 09:03:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:04:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:04:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:07:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 09:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 09:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 09:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 09:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 09:22:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 09:23:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:24:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:28:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 09:28:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 09:29:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:30:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:30:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:30:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:31:47 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-12 09:31:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 09:32:29 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-12 09:32:32 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-01-12 09:33:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:34:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:35:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:36:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:36:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:36:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:37:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 09:37:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 09:37:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:37:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:37:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:38:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:38:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:38:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:40:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:40:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:40:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:40:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 09:41:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:42:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:42:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:44:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 09:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 09:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 09:54:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:54:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:56:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 09:56:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 10:07:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:09:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 10:09:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 10:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:12:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:13:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:13:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 10:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 10:16:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:16:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:16:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:17:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:17:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 10:18:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:22:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:23:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:23:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 10:32:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:34:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:35:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:35:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:37:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:38:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:38:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:38:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:39:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:39:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:39:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:40:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:40:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:46:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:46:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:47:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:48:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:48:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 10:57:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:58:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:58:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:59:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:59:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 10:59:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 11:00:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:07:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:08:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:08:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:08:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:12:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:12:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 11:13:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:13:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 11:15:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:16:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 11:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:17:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 11:22:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 11:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 11:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 11:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 11:34:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 11:34:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 11:34:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:35:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 11:35:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:36:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 11:45:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 11:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 11:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 11:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 12:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 12:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 12:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 12:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 12:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 12:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 12:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 12:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 12:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 12:55:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 12:55:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 12:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 12:57:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 12:58:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 12:58:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 12:59:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 13:00:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 13:01:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 13:02:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 13:04:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 13:04:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 13:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 13:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 13:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 13:30:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 13:35:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 13:46:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 13:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 13:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 14:08:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 14:08:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 14:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 14:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 14:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 14:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 14:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 14:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 14:45:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:47:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:47:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:47:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:48:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:48:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:48:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:50:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:50:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:50:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:51:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:52:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:52:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:53:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:53:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:53:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:53:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:54:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:55:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:55:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:55:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:55:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:56:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 14:57:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:00:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:01:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:02:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:03:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:03:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:03:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 15:04:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:04:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:05:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:05:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:06:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:07:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:08:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:24:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:24:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:25:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 15:37:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 15:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 15:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 15:44:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:44:20 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-12 15:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 15:49:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:50:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 15:52:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 15:52:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:53:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 15:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 15:56:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 16:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 16:04:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 16:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 16:07:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 16:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 16:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 16:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 16:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 16:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 16:16:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 16:17:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 16:17:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 16:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 16:18:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 16:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 16:30:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 16:30:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 16:33:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 17:02:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 17:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 17:24:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 17:25:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 17:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 17:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 17:34:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 17:37:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 17:38:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 17:45:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 17:45:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 17:45:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 17:46:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 17:48:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 17:49:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 17:49:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 18:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 18:23:20 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 18:24:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 18:24:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 18:24:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 18:24:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 18:24:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 18:24:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 18:24:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 18:24:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 18:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 18:27:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 18:29:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 18:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 18:33:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 18:34:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 18:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 18:53:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 18:54:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 18:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 18:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 19:06:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:07:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 19:15:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 19:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 19:46:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 19:46:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 19:51:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:52:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 19:52:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:52:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:53:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:53:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:54:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 19:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:54:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:55:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:55:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 19:55:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 19:59:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 19:59:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 20:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:11:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:11:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:11:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:11:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:11:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:11:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:11:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:12:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:12:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:14:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:14:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:15:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:15:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:17:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:18:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 20:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:30:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 20:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:57:54 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-12 20:57:58 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-12 20:57:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 20:57:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 20:57:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 20:57:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 20:57:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 20:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 20:57:59 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-12 20:58:04 --> 404 Page Not Found: Member/space
ERROR - 2022-01-12 20:58:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 20:58:04 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 20:58:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 20:58:05 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-12 20:58:05 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-12 20:58:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 20:58:06 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-12 20:58:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 20:58:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 20:58:06 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-12 20:58:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 20:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 21:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 21:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 21:09:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 21:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 21:41:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:41:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:41:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 21:42:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:42:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:49:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:50:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:50:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:51:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:51:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:51:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:53:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:53:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:54:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:55:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:55:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:56:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 21:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 22:02:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 22:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 22:07:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 22:07:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 22:08:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 22:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 22:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 22:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 22:19:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 22:24:12 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2022-01-12 22:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 22:35:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 22:42:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 22:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 22:52:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 22:58:19 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 22:59:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 23:00:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 23:02:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 23:04:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-12 23:07:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 23:09:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 23:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 23:28:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 23:29:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 23:29:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 23:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 23:30:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 23:32:20 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-12 23:32:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 23:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 23:39:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-12 23:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-12 23:56:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-12 23:57:48 --> 404 Page Not Found: Robotstxt/index
