<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-06 00:03:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:03:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:04:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:04:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:04:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:05:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:05:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:06:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:07:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:07:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:09:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:09:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:10:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:11:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:11:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:13:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:13:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:15:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:15:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:16:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:16:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:17:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:17:09 --> 404 Page Not Found: Wspath/okd.asp
ERROR - 2021-12-06 00:18:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:18:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 00:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 00:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 00:21:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:21:17 --> 404 Page Not Found: Sneidi/2016-08-31
ERROR - 2021-12-06 00:21:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:21:54 --> 404 Page Not Found: D1609445html/index
ERROR - 2021-12-06 00:22:16 --> 404 Page Not Found: Woa/public
ERROR - 2021-12-06 00:22:32 --> 404 Page Not Found: Product/252.html
ERROR - 2021-12-06 00:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 00:40:03 --> 404 Page Not Found: Article/4161468222135256.htm
ERROR - 2021-12-06 00:40:25 --> 404 Page Not Found: Guide/d-tanpeilei-1174475
ERROR - 2021-12-06 00:41:14 --> 404 Page Not Found: 2021/0404
ERROR - 2021-12-06 00:41:39 --> 404 Page Not Found: Redian/shaanxi
ERROR - 2021-12-06 00:41:47 --> 404 Page Not Found: Kecheng/detail_1412670
ERROR - 2021-12-06 00:42:06 --> 404 Page Not Found: Train-%B2%D7%D6%DD-%D5%C5%BC%D2%BF%DA/index
ERROR - 2021-12-06 00:42:28 --> 404 Page Not Found: Info/1004
ERROR - 2021-12-06 00:42:46 --> 404 Page Not Found: News/3619.html
ERROR - 2021-12-06 00:42:50 --> 404 Page Not Found: News/68362
ERROR - 2021-12-06 00:42:52 --> 404 Page Not Found: News/1229.html
ERROR - 2021-12-06 00:43:12 --> 404 Page Not Found: News/1671.html
ERROR - 2021-12-06 00:43:15 --> 404 Page Not Found: Article-item-80html/index
ERROR - 2021-12-06 00:43:28 --> 404 Page Not Found: Art/2012
ERROR - 2021-12-06 00:44:20 --> 404 Page Not Found: Plus/tags
ERROR - 2021-12-06 00:44:30 --> 404 Page Not Found: Fang/169896_dt
ERROR - 2021-12-06 00:44:39 --> 404 Page Not Found: Zh/hongkong
ERROR - 2021-12-06 00:44:43 --> 404 Page Not Found: Ticket/82880380100
ERROR - 2021-12-06 00:45:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 00:50:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 00:51:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:52:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 00:53:43 --> 404 Page Not Found: Guohu/index
ERROR - 2021-12-06 00:53:44 --> 404 Page Not Found: Jiaoshi/20180818
ERROR - 2021-12-06 00:54:18 --> 404 Page Not Found: Article/hydt
ERROR - 2021-12-06 01:00:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 01:02:55 --> 404 Page Not Found: News/10000367.html
ERROR - 2021-12-06 01:02:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 01:03:15 --> 404 Page Not Found: A/155981844_728179
ERROR - 2021-12-06 01:03:17 --> 404 Page Not Found: Html/2020
ERROR - 2021-12-06 01:03:21 --> 404 Page Not Found: Thread-475480-1-7html/index
ERROR - 2021-12-06 01:03:25 --> 404 Page Not Found: Article-detail-id-2284182html/index
ERROR - 2021-12-06 01:03:33 --> 404 Page Not Found: News/2366.html
ERROR - 2021-12-06 01:03:44 --> 404 Page Not Found: GB/n2
ERROR - 2021-12-06 01:03:59 --> 404 Page Not Found: Shop/wkx4052803
ERROR - 2021-12-06 01:04:07 --> 404 Page Not Found: M/hgxx
ERROR - 2021-12-06 01:04:14 --> 404 Page Not Found: Xxmw/index.html
ERROR - 2021-12-06 01:10:28 --> 404 Page Not Found: Global/en
ERROR - 2021-12-06 01:10:52 --> 404 Page Not Found: H-pd-7304html/index
ERROR - 2021-12-06 01:11:25 --> 404 Page Not Found: Article-detail-id-2634796html/index
ERROR - 2021-12-06 01:12:16 --> 404 Page Not Found: M/jccn
ERROR - 2021-12-06 01:12:46 --> 404 Page Not Found: Contents/65
ERROR - 2021-12-06 01:13:13 --> 404 Page Not Found: Aliyun-10755shtml/index
ERROR - 2021-12-06 01:13:22 --> 404 Page Not Found: Contents/113
ERROR - 2021-12-06 01:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 01:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 01:31:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 01:31:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 01:49:38 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-12-06 01:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 02:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 02:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 02:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 02:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 02:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 03:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 03:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 03:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 03:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 03:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 03:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 03:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 03:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 03:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 03:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 03:57:48 --> 404 Page Not Found: English/index
ERROR - 2021-12-06 03:58:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 03:58:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 03:59:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 04:05:25 --> 404 Page Not Found: Upload/uploxawad.asp
ERROR - 2021-12-06 04:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 04:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 04:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 04:33:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 04:34:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 04:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 04:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 04:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 04:47:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 04:50:38 --> 404 Page Not Found: Upload/manaxge.asp
ERROR - 2021-12-06 04:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 05:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 05:13:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 05:15:45 --> 404 Page Not Found: Vod-play-id-2671-sid-0-pid-221html/index
ERROR - 2021-12-06 05:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 05:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 06:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 06:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 06:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 06:18:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 06:18:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 06:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 06:31:16 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-12-06 06:36:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 06:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 06:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 06:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 06:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 06:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 06:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 07:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 07:01:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:01:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:01:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:01:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:01:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:02:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:02:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:02:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:02:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:03:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:03:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:03:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:03:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:03:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:03:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:03:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:03:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:04:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:04:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:04:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:05:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:05:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:05:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:05:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:06:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:06:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:06:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:06:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:06:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:06:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:06:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:07:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:07:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:07:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:07:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:07:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:07:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:07:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:08:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:08:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:08:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:08:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:08:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:08:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:08:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:09:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:09:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:09:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:09:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:09:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:09:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:09:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:10:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:10:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:10:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:10:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:10:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:10:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:11:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:11:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:11:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:12:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:12:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:12:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:13:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:13:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:13:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:13:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:13:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:13:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:14:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:14:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 07:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 07:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 07:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 07:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 07:36:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 07:40:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 08:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 08:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 08:18:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:18:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:18:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:18:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:22:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 08:30:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:30:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:32:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:32:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:36:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:36:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:36:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:36:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:36:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:36:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:36:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:36:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:36:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:37:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:37:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:37:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:37:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:37:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:37:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:37:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:37:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:37:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:37:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:37:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:37:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:37:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:38:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:38:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:38:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:38:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:39:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 08:44:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:46:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:53:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:53:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 08:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 08:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 08:56:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:00:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:00:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:02:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:02:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 09:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 09:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:05:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:05:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:05:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 09:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:07:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:10:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:11:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 09:11:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:12:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:15:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:15:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:16:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:16:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:16:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:16:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:17:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 09:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:18:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:19:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 09:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:19:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:20:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 09:23:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:25:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 09:29:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:29:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:30:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:35:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:36:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:37:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 09:39:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 09:40:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 09:42:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:43:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:45:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:45:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:45:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:46:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:46:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:46:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:47:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:47:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:50:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:51:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:52:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:52:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:53:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:54:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:56:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:56:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:56:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:56:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:57:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 09:58:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:58:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 09:59:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 09:59:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 09:59:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:01:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:01:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 10:01:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:03:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:03:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:03:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 10:04:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:04:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:05:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:06:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:07:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:08:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:09:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:11:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:11:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:13:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 10:13:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 10:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:17:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:17:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 10:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 10:31:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 10:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:32:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:34:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:34:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 10:35:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:35:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 10:40:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:43:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:43:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:45:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:46:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:46:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:46:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:46:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:51:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 10:51:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 10:52:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 10:54:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 10:54:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 11:00:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:00:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:01:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:01:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:01:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:01:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 11:05:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 11:05:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 11:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:05:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:05:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:07:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:07:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:08:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 11:12:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 11:35:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 11:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 11:37:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 11:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 11:39:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 11:44:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 11:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 11:50:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 11:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 11:57:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 11:57:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 11:58:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 11:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 12:00:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 12:03:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 12:04:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 12:05:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 12:06:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 12:06:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 12:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 12:07:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 12:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 12:17:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 12:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 12:19:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 12:22:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 12:24:48 --> 404 Page Not Found: Templates/red.asp
ERROR - 2021-12-06 12:28:12 --> 404 Page Not Found: 16/10000
ERROR - 2021-12-06 12:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 12:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 12:30:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 12:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 12:32:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 12:33:48 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-12-06 12:33:53 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-12-06 12:34:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 12:34:24 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-12-06 12:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 12:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 12:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 12:57:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 13:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 13:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 13:19:41 --> 404 Page Not Found: City/1
ERROR - 2021-12-06 13:23:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 13:23:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 13:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 13:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 13:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 13:36:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 13:44:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 13:56:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 14:06:58 --> 404 Page Not Found: City/2
ERROR - 2021-12-06 14:08:20 --> 404 Page Not Found: City/18
ERROR - 2021-12-06 14:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 14:09:13 --> 404 Page Not Found: City/19
ERROR - 2021-12-06 14:10:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 14:10:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 14:12:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 14:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 14:20:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 14:22:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 14:22:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 14:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 14:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 14:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 14:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 14:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 14:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 15:01:42 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-06 15:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 15:07:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 15:11:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 15:11:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 15:16:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:22:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:23:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:24:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:25:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:29:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:30:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:31:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 15:31:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:32:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:33:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:33:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:33:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:34:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 15:34:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:36:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 15:36:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 15:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 15:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 15:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:42:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:42:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:42:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:43:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:43:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:43:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:43:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:43:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:44:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:44:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:45:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 15:47:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 15:47:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 15:47:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 15:48:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:49:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:49:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:49:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:50:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 15:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 15:58:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 15:59:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 16:00:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 16:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 16:04:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 16:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 16:21:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 16:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 16:33:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 16:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 16:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 16:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 16:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 16:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 16:41:32 --> 404 Page Not Found: Sitemap11732html/index
ERROR - 2021-12-06 16:45:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 16:57:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-06 16:59:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 17:01:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 17:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 17:13:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 17:24:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 17:24:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 17:27:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 17:29:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 17:30:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 17:31:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 17:36:17 --> 404 Page Not Found: SqlOutasp/index
ERROR - 2021-12-06 17:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 17:46:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-06 18:09:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 18:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 18:45:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 18:45:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 18:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 18:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 18:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:02:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 19:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:11:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 19:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:12:25 --> 404 Page Not Found: Somnus/Somnus.asp
ERROR - 2021-12-06 19:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:21:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 19:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:27:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:32:03 --> 404 Page Not Found: admin/Lib/ueditor
ERROR - 2021-12-06 19:37:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:45:11 --> 404 Page Not Found: admin/Lib/ueditor
ERROR - 2021-12-06 19:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:49:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 19:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 19:50:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 19:51:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 20:01:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 20:02:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 20:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 20:14:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 20:28:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-06 20:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 20:37:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 20:37:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 20:44:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 21:00:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 21:15:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 21:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 21:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 21:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 21:32:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 21:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 21:36:05 --> 404 Page Not Found: Sitemap/templates
ERROR - 2021-12-06 21:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 21:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 21:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 21:51:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 21:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 21:53:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 21:59:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-06 22:01:01 --> 404 Page Not Found: admin/SqlInasp/index
ERROR - 2021-12-06 22:11:32 --> 404 Page Not Found: admin/Lib/ueditor
ERROR - 2021-12-06 22:12:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:12:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:13:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 22:27:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:27:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:27:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:28:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:28:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:28:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:28:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:28:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:28:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:29:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:29:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:29:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:30:37 --> 404 Page Not Found: Uploads/2015
ERROR - 2021-12-06 22:31:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:32:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:38:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 22:40:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 22:59:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:02:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:03:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:04:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:04:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:04:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:05:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:15:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:18:49 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-06 23:20:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:24:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:26:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-06 23:38:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-06 23:49:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:50:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:50:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:50:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:50:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-06 23:50:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:50:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:50:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:50:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:50:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:50:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:51:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:51:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:51:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:51:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:51:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:51:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:51:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:52:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:52:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:52:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:53:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:53:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:54:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:54:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:54:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:54:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:54:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-06 23:59:01 --> 404 Page Not Found: Robotstxt/index
