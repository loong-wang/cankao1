<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-09 00:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 00:11:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 00:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 00:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 00:15:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 00:15:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 00:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 00:16:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 00:16:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 00:19:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 00:22:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 00:27:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 00:30:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 00:30:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 00:32:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 00:32:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 00:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 00:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 00:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 00:54:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 01:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 01:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 01:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 01:46:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 02:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 02:20:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-09 02:20:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-09 02:27:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 02:28:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 02:42:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-09 02:43:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 02:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 03:06:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 03:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 03:32:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 03:34:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-09 03:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 03:50:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 03:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 04:03:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 04:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 04:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 04:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 04:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 04:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 04:54:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 05:05:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 05:09:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 05:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 05:16:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-09 05:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 05:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 05:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 05:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 05:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 05:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 05:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 05:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 05:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 06:21:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 06:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 06:27:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 06:27:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 06:38:05 --> 404 Page Not Found: City/1
ERROR - 2021-10-09 06:41:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 06:45:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 06:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 06:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 06:52:09 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-09 06:52:09 --> 404 Page Not Found: admin//index
ERROR - 2021-10-09 06:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 06:52:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 06:52:11 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-09 06:52:11 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-10-09 06:52:11 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-10-09 06:52:13 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-10-09 06:52:13 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-10-09 06:52:13 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-10-09 06:52:13 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-10-09 06:52:13 --> 404 Page Not Found: User/index
ERROR - 2021-10-09 06:52:13 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-10-09 06:52:13 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-10-09 06:52:13 --> 404 Page Not Found: Wcm/index
ERROR - 2021-10-09 06:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 07:00:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 07:03:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 07:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 07:25:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 07:29:28 --> 404 Page Not Found: Youxishuma/diannao
ERROR - 2021-10-09 07:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 07:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 07:42:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 07:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 07:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 07:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 07:54:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 07:55:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 07:56:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 07:57:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 08:05:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 08:06:22 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-10-09 08:08:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 08:08:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 08:10:13 --> 404 Page Not Found: Index/login
ERROR - 2021-10-09 08:16:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 08:16:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 08:16:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 08:16:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 08:17:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 08:17:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 08:17:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 08:17:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 08:25:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 08:32:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 08:32:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 08:38:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 08:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 08:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 08:50:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 09:00:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 09:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 09:06:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 09:10:45 --> 404 Page Not Found: City/15
ERROR - 2021-10-09 09:20:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 09:20:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 09:21:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 09:22:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 09:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 09:36:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 09:36:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 09:36:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 09:36:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 09:36:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:39:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:42:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:42:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:43:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:43:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:43:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 09:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 09:48:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 09:49:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 09:49:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 09:50:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:51:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:51:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:53:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:54:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:54:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:55:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:55:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:55:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:55:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 09:55:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:55:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:56:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:57:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 09:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 10:03:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 10:05:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 10:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 10:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 10:06:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 10:14:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 10:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 10:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 10:26:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 10:26:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 10:29:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 10:30:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 10:30:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 10:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 10:37:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 10:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 10:43:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 10:51:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 10:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 10:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 10:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 10:53:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 10:56:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 11:00:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:08:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:12:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:12:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:12:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 11:15:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:16:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:17:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:20:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:24:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:31:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 11:36:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 11:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 11:36:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 11:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 11:38:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 11:53:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 11:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 11:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 11:55:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 12:06:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:07:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:07:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:11:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 12:16:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:16:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:20:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:22:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:23:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:24:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:24:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:24:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:25:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:27:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:33:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:33:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:36:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:37:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:38:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:38:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:39:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 12:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 12:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 12:51:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 12:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 13:21:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 13:25:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 13:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 13:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 13:27:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:28:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 13:28:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:29:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:30:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 13:33:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:34:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:34:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:34:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:35:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:35:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:36:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:36:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 13:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 13:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 13:47:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 13:56:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 13:56:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 13:56:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 14:01:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 14:12:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 14:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 14:19:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 14:19:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 14:22:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 14:46:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 14:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 14:58:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 15:10:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:11:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:14:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:14:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:15:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:15:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:16:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:17:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 15:26:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:26:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:29:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:32:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:33:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:33:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:34:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 15:39:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:39:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:42:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:42:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:48:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 15:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 15:51:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:52:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:52:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 15:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 15:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:57:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:57:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:57:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 15:57:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 16:01:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 16:04:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 16:04:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 16:04:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 16:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 16:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 16:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 16:11:43 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-09 16:14:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 16:15:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 16:16:58 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-10-09 16:17:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 16:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 16:18:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 16:19:01 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-10-09 16:20:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 16:20:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 16:20:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 16:24:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 16:26:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 16:27:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 16:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 16:40:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 16:42:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 16:46:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 16:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 16:50:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 16:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 17:03:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 17:15:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-09 17:16:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 17:25:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 17:30:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 17:33:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 17:40:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 17:47:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 17:49:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 17:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 17:52:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 17:53:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 17:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 18:02:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 18:19:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 18:25:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 18:25:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 18:26:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 18:26:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 18:27:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 18:28:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 18:28:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 18:33:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 18:37:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 18:38:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 18:39:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 18:39:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 18:45:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 18:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 18:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 18:51:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 18:57:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 19:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 19:02:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 19:08:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 19:09:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 19:09:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 19:11:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 19:18:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 19:24:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 19:27:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-09 19:27:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 19:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 19:31:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 19:39:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 19:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 19:43:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 19:44:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 19:46:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-09 19:52:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 19:54:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 19:54:45 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-09 19:59:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 20:01:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 20:05:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 20:09:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 20:17:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 20:24:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 20:25:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-09 20:30:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 20:37:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 20:46:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 20:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 20:49:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 20:53:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 20:58:59 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-10-09 20:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 21:00:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 21:07:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 21:08:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 21:12:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 21:25:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 21:32:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 21:36:27 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-10-09 21:37:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 21:47:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-09 21:47:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 21:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 21:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 21:50:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 21:57:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 22:04:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 22:05:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 22:06:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 22:07:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 22:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 22:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 22:22:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:23:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 22:27:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 22:28:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 22:29:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:30:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 22:30:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 22:31:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 22:34:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 22:36:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 22:39:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:39:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 22:42:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 22:45:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 22:50:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:50:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:51:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:52:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 22:56:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:56:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:58:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:58:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 22:59:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:00:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:01:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-09 23:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 23:03:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:03:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:04:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 23:12:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 23:21:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:23:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:25:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:25:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:26:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:26:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:27:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:34:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:34:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:35:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:35:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:35:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:37:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 23:43:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-09 23:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-09 23:47:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:56:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:56:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:57:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-09 23:57:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
