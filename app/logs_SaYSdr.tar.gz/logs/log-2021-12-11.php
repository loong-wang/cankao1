<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-11 00:04:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:04:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:04:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 00:06:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 00:08:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 00:13:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:13:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 00:15:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:16:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:16:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:17:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:18:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:18:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:18:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 00:21:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 00:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 00:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 00:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:27:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 00:33:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 00:33:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 00:33:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 00:34:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 00:34:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 00:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 00:56:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 00:59:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 01:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 01:15:50 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-12-11 01:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:22:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:23:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:23:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:23:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:23:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:23:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:23:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:24:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:24:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:24:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:24:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:24:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:24:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:24:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:24:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:26:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 01:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:27:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 01:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 01:48:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 02:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 02:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 02:08:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 02:21:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 02:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 02:27:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 02:28:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 02:31:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 02:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 02:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 02:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 02:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 02:54:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 02:57:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 02:58:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 02:59:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 03:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 03:01:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 03:04:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 03:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 03:07:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 03:10:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 03:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 03:14:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 03:20:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 03:20:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 03:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 03:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 03:23:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 03:23:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 03:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 03:30:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 03:31:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 03:34:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 03:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 03:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 03:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 03:44:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 03:44:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 03:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 03:47:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 03:47:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 03:54:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 03:54:31 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-12-11 03:54:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 03:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:01:19 --> 404 Page Not Found: City/1
ERROR - 2021-12-11 04:04:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 04:07:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 04:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:18:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 04:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:20:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:30:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 04:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:48:13 --> 404 Page Not Found: City/16
ERROR - 2021-12-11 04:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 04:50:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 05:09:22 --> 404 Page Not Found: Login/V2.decryption
ERROR - 2021-12-11 05:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 05:20:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 05:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 05:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 05:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 05:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 05:50:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 05:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 06:21:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 06:23:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 06:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 06:34:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 06:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 06:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 06:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 06:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 06:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 07:13:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 07:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 07:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 07:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 07:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:24 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:25 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:26 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:26 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:26 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:26 --> 404 Page Not Found: Http:/weilansky.com
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:31 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:37:32 --> 404 Page Not Found: Http:/xuanhao.net
ERROR - 2021-12-11 07:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 07:54:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 07:54:55 --> 404 Page Not Found: Inc/config.asp
ERROR - 2021-12-11 07:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 07:55:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 08:05:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:07:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:12:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 08:26:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:27:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 08:27:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:27:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:28:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:28:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:29:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:30:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:30:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:32:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:33:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:34:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:35:20 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-12-11 08:35:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 08:35:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 08:39:25 --> 404 Page Not Found: Inc/config.asp
ERROR - 2021-12-11 08:40:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:41:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:42:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 08:42:25 --> 404 Page Not Found: Book/47032
ERROR - 2021-12-11 08:42:41 --> 404 Page Not Found: Detail/s
ERROR - 2021-12-11 08:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 08:54:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 09:03:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:03:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:04:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:04:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:04:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:05:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:06:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:07:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 09:08:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:09:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:11:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:12:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:12:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:12:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:13:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:15:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 09:19:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:24:13 --> 404 Page Not Found: Inc/AspCms_AdvJs.asp
ERROR - 2021-12-11 09:27:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 09:27:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:32:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 09:40:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 09:40:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 09:41:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 09:43:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 09:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 09:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:27 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:28 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:47:29 --> 404 Page Not Found: Http:/xuanhao.com.cn
ERROR - 2021-12-11 09:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 09:51:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:55:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 09:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 10:04:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 10:07:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 10:09:06 --> 404 Page Not Found: Img/xfw
ERROR - 2021-12-11 10:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 10:11:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 10:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 10:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 10:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 10:22:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 10:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 10:23:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 10:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 10:26:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 10:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 10:37:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 10:45:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 10:45:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 10:47:52 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-12-11 10:48:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 10:50:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 10:52:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 10:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 10:53:49 --> 404 Page Not Found: Images/Thumb.asp
ERROR - 2021-12-11 10:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 11:15:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 11:16:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 11:16:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 11:16:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 11:16:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 11:18:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 11:19:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 11:22:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 11:22:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 11:29:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 11:41:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 11:42:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:05:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 12:06:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:06:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 12:12:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:15:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:15:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:15:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:16:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:17:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:18:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 12:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 12:30:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:35:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 12:41:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 12:44:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 12:45:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:46:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:46:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 12:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:47:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:48:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:51:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 12:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 12:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 12:56:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 12:56:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 13:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 13:06:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 13:17:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 13:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 13:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 13:24:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 13:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 13:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 13:26:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 13:39:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 13:41:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 13:46:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 13:48:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 13:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 13:50:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 14:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 14:07:08 --> 404 Page Not Found: Images/search_info_ico.gif.asp
ERROR - 2021-12-11 14:08:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 14:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 14:16:38 --> 404 Page Not Found: Indexasp/index
ERROR - 2021-12-11 14:24:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:27:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 14:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 14:29:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:30:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:30:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:30:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:42:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:42:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:42:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:42:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:43:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:43:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:47:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:47:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:47:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 14:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 14:49:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 14:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 14:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 14:54:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:06:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 15:08:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:10:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:11:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:12:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 15:13:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:13:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:16:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:16:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 15:16:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 15:19:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:20:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:21:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:22:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 15:22:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 15:22:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 15:31:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 15:35:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 15:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 15:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 15:42:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:43:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 15:54:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:55:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 15:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 16:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 16:02:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 16:21:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 16:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 16:31:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 16:31:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 16:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 16:34:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 16:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 16:38:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 16:39:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 16:40:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 16:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 16:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 16:52:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 16:52:42 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-12-11 16:54:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 17:01:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 17:03:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 17:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 17:13:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 17:21:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 17:24:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 17:24:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 17:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 17:38:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 17:43:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 17:44:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 17:44:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 17:44:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 17:44:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 17:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 17:57:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 17:59:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 18:00:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 18:01:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 18:03:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 18:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 18:04:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 18:06:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 18:06:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 18:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 18:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 18:22:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 18:22:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 18:22:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 18:25:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 18:30:02 --> 404 Page Not Found: Seeyon/thirdpartyController.do
ERROR - 2021-12-11 18:30:02 --> 404 Page Not Found: Seeyon/htmlofficeservlet
ERROR - 2021-12-11 18:30:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 18:36:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 18:45:16 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-12-11 18:45:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 18:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 18:49:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 18:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 18:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 19:01:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 19:01:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 19:01:40 --> 404 Page Not Found: Images/css
ERROR - 2021-12-11 19:07:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 19:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 19:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 19:19:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 19:19:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 19:20:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 19:20:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 19:21:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 19:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 19:23:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 19:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 19:31:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 19:31:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 19:31:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 19:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 19:44:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 19:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 19:45:41 --> 404 Page Not Found: admin/Ueditor/net
ERROR - 2021-12-11 19:48:22 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-12-11 19:48:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 19:50:26 --> 404 Page Not Found: QeeB/index
ERROR - 2021-12-11 19:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 19:50:32 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-11 19:50:32 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-11 19:51:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 19:54:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 19:55:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 19:56:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 19:56:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 19:56:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 20:02:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 20:02:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:02:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 20:03:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 20:03:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 20:03:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 20:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 20:24:13 --> 404 Page Not Found: Login/index
ERROR - 2021-12-11 20:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 20:33:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 20:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 20:39:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:41:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:42:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:42:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:42:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:42:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:44:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:45:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:45:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:49:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 20:50:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:51:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:52:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:52:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:52:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 20:59:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 21:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 21:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 21:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 21:15:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:15:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:23:24 --> 404 Page Not Found: Images/cache.asp
ERROR - 2021-12-11 21:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:24:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:24:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 21:25:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:25:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:32:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:33:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 21:33:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:33:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:36:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:36:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:38:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:40:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 21:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 21:43:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:43:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:44:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:45:37 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-11 21:45:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:46:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:46:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:47:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 21:47:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:47:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:47:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:51:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:52:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:53:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:53:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:54:38 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-12-11 21:56:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 21:57:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:57:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:58:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 21:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 22:00:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 22:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 22:06:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 22:06:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 22:06:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 22:11:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 22:14:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 22:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 22:20:21 --> 404 Page Not Found: City/1
ERROR - 2021-12-11 22:21:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 22:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 22:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 22:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 22:27:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 22:34:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 22:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 22:47:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 22:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 22:55:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-11 22:55:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-11 22:58:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 23:00:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 23:00:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 23:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 23:08:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 23:10:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 23:11:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 23:13:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 23:13:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-11 23:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 23:30:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 23:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 23:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 23:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-11 23:47:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-11 23:55:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 23:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 23:56:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 23:56:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 23:56:40 --> 404 Page Not Found: Iasp/index
ERROR - 2021-12-11 23:57:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-11 23:57:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
