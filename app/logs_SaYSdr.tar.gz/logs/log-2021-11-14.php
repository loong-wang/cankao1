<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-14 00:06:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 00:20:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 00:27:49 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-11-14 00:37:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 00:37:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 00:37:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 00:37:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 01:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 01:07:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 01:07:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 01:14:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 01:15:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 01:16:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 01:16:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 01:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 01:24:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 01:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 01:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 01:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 01:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 01:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 01:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 01:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:17:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 02:19:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:23:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 02:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 03:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 03:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 03:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 03:17:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 03:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 03:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 03:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 03:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 03:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 03:48:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-14 03:54:02 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-14 03:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 03:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 04:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 04:04:35 --> 404 Page Not Found: Sitemap92835html/index
ERROR - 2021-11-14 04:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 04:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 04:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 04:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 04:26:28 --> 404 Page Not Found: Sitemap95177html/index
ERROR - 2021-11-14 04:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 04:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 04:33:12 --> 404 Page Not Found: Sitemap91843html/index
ERROR - 2021-11-14 04:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 04:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 04:47:13 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-14 04:48:54 --> Severity: Warning --> Missing argument 1 for Mobile::getrenz() /www/wwwroot/www.xuanhao.net/app/controllers/Mobile.php 41
ERROR - 2021-11-14 05:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 05:20:09 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-14 05:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 05:24:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 05:26:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 05:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 05:33:19 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-14 05:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 05:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 05:41:43 --> 404 Page Not Found: 404/index.html
ERROR - 2021-11-14 05:41:43 --> 404 Page Not Found: 404/index.html
ERROR - 2021-11-14 05:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 05:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 05:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 06:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 06:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 06:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 06:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 06:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 06:28:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 06:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 06:50:09 --> 404 Page Not Found: City/1
ERROR - 2021-11-14 06:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 06:55:08 --> 404 Page Not Found: Article/view
ERROR - 2021-11-14 07:06:04 --> 404 Page Not Found: City/10
ERROR - 2021-11-14 07:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 07:21:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-14 07:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 07:28:26 --> 404 Page Not Found: City/1
ERROR - 2021-11-14 07:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 07:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 07:49:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 07:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:01:28 --> 404 Page Not Found: Article/info
ERROR - 2021-11-14 08:01:43 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-14 08:01:49 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-14 08:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:24:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 08:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 08:27:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 08:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 08:45:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 08:45:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 08:45:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 08:45:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 09:02:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 09:02:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 09:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 09:05:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 09:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 09:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 09:12:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 09:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 09:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 09:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 09:36:53 --> 404 Page Not Found: All/index
ERROR - 2021-11-14 09:37:03 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-14 09:37:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 09:38:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 09:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 10:01:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 10:01:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 10:07:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 10:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 10:18:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 10:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 10:27:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-14 10:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 10:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 10:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 10:51:20 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-14 10:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 10:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 11:02:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 11:03:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 11:03:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 11:06:32 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-14 11:08:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 11:09:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 11:11:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 11:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 11:13:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 11:35:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 11:36:15 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-14 11:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 11:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 11:46:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 11:46:19 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-14 11:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 11:51:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 11:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 12:05:25 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-14 12:08:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-14 12:13:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 12:13:25 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-14 12:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 12:22:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 12:23:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 12:30:03 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-14 12:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 12:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 12:35:34 --> 404 Page Not Found: Article/index
ERROR - 2021-11-14 12:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 13:02:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:03:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:03:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:03:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:04:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:04:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:04:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:04:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:05:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:05:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:06:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:11:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 13:14:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:16:38 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-14 13:17:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:18:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 13:18:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 13:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 13:33:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 13:44:54 --> 404 Page Not Found: News_showasp/index
ERROR - 2021-11-14 13:50:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 13:50:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 13:50:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 13:50:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 13:50:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 13:50:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 13:51:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 13:51:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 13:53:32 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-11-14 13:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 13:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:01:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 14:02:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 14:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:02:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 14:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:08:12 --> 404 Page Not Found: City/16
ERROR - 2021-11-14 14:08:20 --> 404 Page Not Found: City/16
ERROR - 2021-11-14 14:08:20 --> 404 Page Not Found: City/16
ERROR - 2021-11-14 14:08:20 --> 404 Page Not Found: City/16
ERROR - 2021-11-14 14:08:20 --> 404 Page Not Found: City/16
ERROR - 2021-11-14 14:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:14:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:24:22 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-14 14:30:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 14:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:41:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 14:41:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 14:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:43:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 14:43:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 14:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:52:12 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-14 14:57:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 14:58:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 14:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 14:58:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 14:59:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 14:59:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:00:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:02:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:03:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:03:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:03:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:05:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:06:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:06:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:06:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:07:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:08:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:08:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 15:16:26 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-14 15:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 15:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 15:30:58 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-14 15:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 15:46:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 15:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 15:55:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:56:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:57:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 15:57:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-14 15:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 16:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 16:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 16:08:54 --> 404 Page Not Found: Sitemap95242html/index
ERROR - 2021-11-14 16:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 16:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 16:10:33 --> 404 Page Not Found: News_showasp/index
ERROR - 2021-11-14 16:12:16 --> 404 Page Not Found: Article/info
ERROR - 2021-11-14 16:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 16:16:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-14 16:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 16:20:17 --> 404 Page Not Found: Sitemap41464html/index
ERROR - 2021-11-14 16:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 16:21:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-14 16:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 16:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 16:33:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 16:35:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 16:39:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 16:41:56 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-14 16:44:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 16:48:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 16:48:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 16:48:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 16:48:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 16:48:48 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-14 16:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:09:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-14 17:11:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 17:11:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 17:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:12:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 17:14:57 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-14 17:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:17:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 17:19:03 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-11-14 17:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:25:54 --> 404 Page Not Found: Html-cn/hot-products-CQxmJTnWDEvg-1-0-2-1.html
ERROR - 2021-11-14 17:27:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:34:09 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-14 17:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:43:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-14 17:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:47:44 --> 404 Page Not Found: Text4041636883264/index
ERROR - 2021-11-14 17:47:44 --> 404 Page Not Found: Evox/about
ERROR - 2021-11-14 17:47:45 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-11-14 17:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 17:57:18 --> 404 Page Not Found: Sitemap57660html/index
ERROR - 2021-11-14 17:58:11 --> 404 Page Not Found: Expensesasp/index
ERROR - 2021-11-14 17:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 18:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 18:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 18:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 18:14:39 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-14 18:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 18:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 18:22:52 --> 404 Page Not Found: Sitemap79840html/index
ERROR - 2021-11-14 18:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 18:27:53 --> 404 Page Not Found: Sitemap10400html/index
ERROR - 2021-11-14 18:31:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 18:54:49 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-11-14 19:04:58 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-11-14 19:07:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 19:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 19:09:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 19:10:09 --> Severity: Warning --> Missing argument 1 for Kefu::show() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 359
ERROR - 2021-11-14 19:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 19:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 19:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 19:26:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 19:27:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 19:27:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 19:27:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 19:28:57 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-11-14 19:30:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 19:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 19:31:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 19:31:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 19:33:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-14 19:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 19:37:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 19:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 19:51:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 19:51:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 19:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 19:55:08 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-14 20:09:26 --> 404 Page Not Found: City/10
ERROR - 2021-11-14 20:09:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 20:11:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 20:12:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 20:12:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 20:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 20:15:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 20:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 20:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 20:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 20:31:48 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-14 20:34:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 20:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 20:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 20:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 20:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 21:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 21:08:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:09:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:09:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:10:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:10:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:10:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 21:11:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:11:48 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-11-14 21:12:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:17:25 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-11-14 21:20:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 21:21:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:22:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 21:23:24 --> 404 Page Not Found: Sitemap38648html/index
ERROR - 2021-11-14 21:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 21:26:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:27:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:28:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:28:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:28:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:29:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:29:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:30:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:31:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:32:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 21:35:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:36:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 21:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 21:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 21:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 21:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 22:01:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 22:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 22:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 22:12:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 22:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 22:16:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 22:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 22:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 22:41:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 22:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 23:10:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 23:12:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 23:12:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 23:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 23:13:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-14 23:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 23:16:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 23:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 23:35:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 23:36:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 23:36:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 23:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 23:36:46 --> 404 Page Not Found: Order/index
ERROR - 2021-11-14 23:38:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 23:38:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 23:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 23:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 23:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-14 23:52:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-14 23:53:11 --> 404 Page Not Found: News_showasp/index
ERROR - 2021-11-14 23:57:36 --> 404 Page Not Found: Robotstxt/index
