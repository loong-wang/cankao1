<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-09-20 00:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:01:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:07:11 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-20 00:08:30 --> 404 Page Not Found: Manage/login.asp
ERROR - 2021-09-20 00:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:09:33 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-20 00:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:10:12 --> 404 Page Not Found: Vod-play-id-2612-sid-0-pid-26html/index
ERROR - 2021-09-20 00:10:20 --> 404 Page Not Found: Vod-search-wd-%E9%A9%AC%E7%89%B9%C2%B7%E8%8E%B1%E6%96%AF%E5%88%87%E5%B0%94-p-1html/index
ERROR - 2021-09-20 00:10:31 --> 404 Page Not Found: Vod-search-wd-%E5%87%AF%E7%91%9F%E7%90%B3%C2%B7%E9%BA%A6%E8%8F%B2-p-1html/index
ERROR - 2021-09-20 00:10:46 --> 404 Page Not Found: Vod-search-wd-%E6%9D%8E%E7%9B%B8%E7%83%A8-p-1html/index
ERROR - 2021-09-20 00:10:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 00:10:49 --> 404 Page Not Found: Vod-play-id-2742-sid-0-pid-21html/index
ERROR - 2021-09-20 00:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:10:52 --> 404 Page Not Found: Vod-play-id-2606-sid-0-pid-125html/index
ERROR - 2021-09-20 00:10:59 --> 404 Page Not Found: Vod-play-id-2554-sid-0-pid-2html/index
ERROR - 2021-09-20 00:11:04 --> 404 Page Not Found: Vod-play-id-2779-sid-0-pid-4html/index
ERROR - 2021-09-20 00:11:14 --> 404 Page Not Found: Vod-play-id-2682-sid-0-pid-202html/index
ERROR - 2021-09-20 00:11:19 --> 404 Page Not Found: Vod-search-wd-%E5%B2%A9%E7%94%B0%E5%85%89%E5%A4%AE-p-1html/index
ERROR - 2021-09-20 00:11:24 --> 404 Page Not Found: Vod-play-id-2226-sid-0-pid-171html/index
ERROR - 2021-09-20 00:11:32 --> 404 Page Not Found: Vod-read-id-2769html/index
ERROR - 2021-09-20 00:11:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 00:11:42 --> 404 Page Not Found: Vod-play-id-2280-sid-0-pid-161html/index
ERROR - 2021-09-20 00:11:45 --> 404 Page Not Found: Vod-play-id-2604-sid-0-pid-49html/index
ERROR - 2021-09-20 00:11:58 --> 404 Page Not Found: Vod-play-id-2675-sid-0-pid-109html/index
ERROR - 2021-09-20 00:12:06 --> 404 Page Not Found: Vod-play-id-2669-sid-0-pid-80html/index
ERROR - 2021-09-20 00:12:18 --> 404 Page Not Found: Vod-play-id-2606-sid-0-pid-154html/index
ERROR - 2021-09-20 00:12:22 --> 404 Page Not Found: Vod-play-id-2604-sid-0-pid-1html/index
ERROR - 2021-09-20 00:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:12:47 --> 404 Page Not Found: Vod-play-id-2597-sid-0-pid-98html/index
ERROR - 2021-09-20 00:13:00 --> 404 Page Not Found: Vod-play-id-2704-sid-0-pid-167html/index
ERROR - 2021-09-20 00:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:13:10 --> 404 Page Not Found: Vod-play-id-2280-sid-0-pid-39html/index
ERROR - 2021-09-20 00:13:26 --> 404 Page Not Found: Vod-play-id-2682-sid-0-pid-205html/index
ERROR - 2021-09-20 00:13:29 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-20 00:13:29 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-20 00:13:29 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-20 00:13:29 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-20 00:13:29 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-20 00:13:29 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-20 00:13:29 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-20 00:13:29 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-20 00:13:30 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-20 00:13:30 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-20 00:13:30 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-20 00:13:30 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-20 00:13:30 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-20 00:13:30 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-20 00:13:30 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-20 00:13:30 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-20 00:13:30 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-20 00:13:30 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-20 00:13:30 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-20 00:13:31 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-20 00:13:37 --> 404 Page Not Found: Vod-play-id-2609-sid-0-pid-54html/index
ERROR - 2021-09-20 00:14:09 --> 404 Page Not Found: Vod-play-id-2669-sid-0-pid-15html/index
ERROR - 2021-09-20 00:14:23 --> 404 Page Not Found: Vod-play-id-2421-sid-0-pid-2html/index
ERROR - 2021-09-20 00:14:30 --> 404 Page Not Found: Vod-play-id-2805-sid-0-pid-5html/index
ERROR - 2021-09-20 00:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:15:20 --> 404 Page Not Found: Vod-play-id-2309-sid-0-pid-6html/index
ERROR - 2021-09-20 00:15:25 --> 404 Page Not Found: Vod-search-wd-%E6%9D%A8%E9%94%A6%E9%BA%9F-p-1html/index
ERROR - 2021-09-20 00:15:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:15:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:48 --> 404 Page Not Found: Vod-play-id-2228-sid-0-pid-167html/index
ERROR - 2021-09-20 00:15:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:15:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:15:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:16:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:16:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:16:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:16:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:16:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:16:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:16:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:16:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 00:16:24 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-122html/index
ERROR - 2021-09-20 00:16:32 --> 404 Page Not Found: Vod-play-id-2390-sid-0-pid-109html/index
ERROR - 2021-09-20 00:16:40 --> 404 Page Not Found: Vod-play-id-2661-sid-0-pid-183html/index
ERROR - 2021-09-20 00:16:46 --> 404 Page Not Found: Vod-play-id-2671-sid-0-pid-9html/index
ERROR - 2021-09-20 00:17:05 --> 404 Page Not Found: Vod-play-id-2787-sid-0-pid-7html/index
ERROR - 2021-09-20 00:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:17:18 --> 404 Page Not Found: Vod-play-id-2804-sid-0-pid-18html/index
ERROR - 2021-09-20 00:17:25 --> 404 Page Not Found: Vod-play-id-2606-sid-0-pid-138html/index
ERROR - 2021-09-20 00:17:27 --> 404 Page Not Found: Vod-play-id-2346-sid-0-pid-71html/index
ERROR - 2021-09-20 00:17:29 --> 404 Page Not Found: Vod-play-id-2604-sid-0-pid-8html/index
ERROR - 2021-09-20 00:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:22:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:27:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:29:19 --> 404 Page Not Found: Order/index
ERROR - 2021-09-20 00:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:30:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 00:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:37:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 00:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:41:22 --> 404 Page Not Found: Article/index
ERROR - 2021-09-20 00:41:31 --> 404 Page Not Found: Vod-play-id-2608-sid-0-pid-275html/index
ERROR - 2021-09-20 00:41:34 --> 404 Page Not Found: Vod-search-wd-%E6%9D%BE%E9%87%8D%E4%B8%B0-p-1html/index
ERROR - 2021-09-20 00:41:38 --> 404 Page Not Found: Vod-play-id-2606-sid-0-pid-10html/index
ERROR - 2021-09-20 00:41:43 --> 404 Page Not Found: Vod-play-id-2604-sid-0-pid-50html/index
ERROR - 2021-09-20 00:41:46 --> 404 Page Not Found: Vod-play-id-2661-sid-0-pid-109html/index
ERROR - 2021-09-20 00:41:48 --> 404 Page Not Found: Vod-play-id-2279-sid-0-pid-74html/index
ERROR - 2021-09-20 00:41:53 --> 404 Page Not Found: Vod-search-wd-%E4%B8%BD%E5%85%B9%C2%B7%E5%8D%A1%E6%BD%98-p-1html/index
ERROR - 2021-09-20 00:42:00 --> 404 Page Not Found: Vod-play-id-2628-sid-0-pid-1html/index
ERROR - 2021-09-20 00:42:03 --> 404 Page Not Found: Vod-play-id-2704-sid-0-pid-48html/index
ERROR - 2021-09-20 00:42:05 --> 404 Page Not Found: Vod-play-id-2226-sid-0-pid-50html/index
ERROR - 2021-09-20 00:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:42:08 --> 404 Page Not Found: Vod-play-id-2682-sid-0-pid-74html/index
ERROR - 2021-09-20 00:42:10 --> 404 Page Not Found: Vod-play-id-2661-sid-0-pid-45html/index
ERROR - 2021-09-20 00:42:14 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-20 00:42:15 --> 404 Page Not Found: Vod-play-id-2742-sid-0-pid-107html/index
ERROR - 2021-09-20 00:42:22 --> 404 Page Not Found: Vod-play-id-2671-sid-0-pid-209html/index
ERROR - 2021-09-20 00:42:24 --> 404 Page Not Found: Vod-play-id-2606-sid-0-pid-50html/index
ERROR - 2021-09-20 00:42:34 --> 404 Page Not Found: Vod-play-id-2781-sid-0-pid-27html/index
ERROR - 2021-09-20 00:42:36 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-125html/index
ERROR - 2021-09-20 00:42:41 --> 404 Page Not Found: Vod-play-id-2603-sid-0-pid-178html/index
ERROR - 2021-09-20 00:42:44 --> 404 Page Not Found: Vod-play-id-2309-sid-0-pid-69html/index
ERROR - 2021-09-20 00:42:49 --> 404 Page Not Found: Vod-play-id-2226-sid-0-pid-78html/index
ERROR - 2021-09-20 00:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:42:51 --> 404 Page Not Found: Vod-play-id-2736-sid-0-pid-12html/index
ERROR - 2021-09-20 00:42:53 --> 404 Page Not Found: Vod-play-id-2320-sid-0-pid-15html/index
ERROR - 2021-09-20 00:42:56 --> 404 Page Not Found: Vod-play-id-2682-sid-0-pid-122html/index
ERROR - 2021-09-20 00:42:58 --> 404 Page Not Found: Vod-play-id-2743-sid-0-pid-37html/index
ERROR - 2021-09-20 00:43:01 --> 404 Page Not Found: Vod-play-id-2709-sid-0-pid-17html/index
ERROR - 2021-09-20 00:43:03 --> 404 Page Not Found: Vod-play-id-2608-sid-0-pid-113html/index
ERROR - 2021-09-20 00:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:43:10 --> 404 Page Not Found: Vod-play-id-2309-sid-0-pid-37html/index
ERROR - 2021-09-20 00:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:43:17 --> 404 Page Not Found: Vod-play-id-2767-sid-0-pid-4html/index
ERROR - 2021-09-20 00:43:22 --> 404 Page Not Found: Vod-play-id-2597-sid-0-pid-4html/index
ERROR - 2021-09-20 00:43:22 --> 404 Page Not Found: Vod-play-id-2606-sid-0-pid-15html/index
ERROR - 2021-09-20 00:43:27 --> 404 Page Not Found: Vod-play-id-2607-sid-0-pid-208html/index
ERROR - 2021-09-20 00:43:29 --> 404 Page Not Found: Vod-search-wd-NormanLear-p-1html/index
ERROR - 2021-09-20 00:43:32 --> 404 Page Not Found: Vod-play-id-2346-sid-0-pid-47html/index
ERROR - 2021-09-20 00:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:43:34 --> 404 Page Not Found: Vod-play-id-2320-sid-0-pid-29html/index
ERROR - 2021-09-20 00:43:37 --> 404 Page Not Found: Vod-play-id-2675-sid-0-pid-1html/index
ERROR - 2021-09-20 00:43:39 --> 404 Page Not Found: Vod-play-id-2608-sid-0-pid-205html/index
ERROR - 2021-09-20 00:43:48 --> 404 Page Not Found: Vod-play-id-2682-sid-0-pid-167html/index
ERROR - 2021-09-20 00:44:00 --> 404 Page Not Found: Vod-play-id-2671-sid-0-pid-195html/index
ERROR - 2021-09-20 00:44:03 --> 404 Page Not Found: Vod-play-id-2743-sid-0-pid-19html/index
ERROR - 2021-09-20 00:44:05 --> 404 Page Not Found: Vod-play-id-2704-sid-0-pid-61html/index
ERROR - 2021-09-20 00:44:08 --> 404 Page Not Found: Vod-play-id-2729-sid-0-pid-170html/index
ERROR - 2021-09-20 00:44:10 --> 404 Page Not Found: Vod-play-id-2604-sid-0-pid-20html/index
ERROR - 2021-09-20 00:44:12 --> 404 Page Not Found: Vod-play-id-2743-sid-0-pid-8html/index
ERROR - 2021-09-20 00:44:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 00:44:19 --> 404 Page Not Found: Vod-play-id-2709-sid-0-pid-165html/index
ERROR - 2021-09-20 00:44:24 --> 404 Page Not Found: Vod-play-id-2608-sid-0-pid-190html/index
ERROR - 2021-09-20 00:44:27 --> 404 Page Not Found: Vod-play-id-2675-sid-0-pid-26html/index
ERROR - 2021-09-20 00:44:34 --> 404 Page Not Found: Vod-play-id-2390-sid-0-pid-95html/index
ERROR - 2021-09-20 00:44:49 --> 404 Page Not Found: Vod-play-id-2421-sid-0-pid-107html/index
ERROR - 2021-09-20 00:44:51 --> 404 Page Not Found: Vod-search-wd-%E5%B4%94%E9%92%9F%E8%AE%AD-p-1html/index
ERROR - 2021-09-20 00:44:57 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-19html/index
ERROR - 2021-09-20 00:44:59 --> 404 Page Not Found: Vod-play-id-2680-sid-0-pid-165html/index
ERROR - 2021-09-20 00:45:06 --> 404 Page Not Found: Vod-play-id-2226-sid-0-pid-94html/index
ERROR - 2021-09-20 00:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:45:11 --> 404 Page Not Found: Vod-play-id-2612-sid-0-pid-42html/index
ERROR - 2021-09-20 00:45:16 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-24html/index
ERROR - 2021-09-20 00:45:20 --> 404 Page Not Found: Vod-play-id-2605-sid-0-pid-199html/index
ERROR - 2021-09-20 00:45:23 --> 404 Page Not Found: Vod-play-id-2739-sid-0-pid-28html/index
ERROR - 2021-09-20 00:45:25 --> 404 Page Not Found: Vod-play-id-2607-sid-0-pid-38html/index
ERROR - 2021-09-20 00:45:27 --> 404 Page Not Found: Vod-play-id-2226-sid-0-pid-136html/index
ERROR - 2021-09-20 00:45:38 --> 404 Page Not Found: Vod-play-id-2609-sid-0-pid-152html/index
ERROR - 2021-09-20 00:45:46 --> 404 Page Not Found: Vod-play-id-2311-sid-0-pid-14html/index
ERROR - 2021-09-20 00:45:54 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-86html/index
ERROR - 2021-09-20 00:45:59 --> 404 Page Not Found: Vod-play-id-2607-sid-0-pid-161html/index
ERROR - 2021-09-20 00:46:01 --> 404 Page Not Found: Vod-play-id-2729-sid-0-pid-96html/index
ERROR - 2021-09-20 00:46:13 --> 404 Page Not Found: Vod-play-id-2609-sid-0-pid-153html/index
ERROR - 2021-09-20 00:46:17 --> 404 Page Not Found: Vod-play-id-2607-sid-0-pid-229html/index
ERROR - 2021-09-20 00:46:19 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-20 00:46:21 --> 404 Page Not Found: Vod-play-id-2607-sid-0-pid-154html/index
ERROR - 2021-09-20 00:46:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 00:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:46:27 --> 404 Page Not Found: Vod-play-id-2311-sid-0-pid-7html/index
ERROR - 2021-09-20 00:46:33 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-25html/index
ERROR - 2021-09-20 00:46:35 --> 404 Page Not Found: Vod-search-wd-%E4%BA%95%E6%B5%A6%E6%96%B0-p-1html/index
ERROR - 2021-09-20 00:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:54:58 --> 404 Page Not Found: Manage/login.asp
ERROR - 2021-09-20 00:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 00:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:00:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:02:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 01:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:03:50 --> 404 Page Not Found: English/index
ERROR - 2021-09-20 01:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:07:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 01:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:09:15 --> 404 Page Not Found: Manage/login.asp
ERROR - 2021-09-20 01:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:19:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:30:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:38:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 01:38:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 01:38:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 01:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:38:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 01:39:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 01:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:43:15 --> 404 Page Not Found: Vod-play-id-2669-sid-0-pid-59html/index
ERROR - 2021-09-20 01:43:17 --> 404 Page Not Found: Vod-play-id-2778-sid-0-pid-4html/index
ERROR - 2021-09-20 01:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:43:46 --> 404 Page Not Found: Vod-play-id-2376-sid-0-pid-104html/index
ERROR - 2021-09-20 01:44:07 --> 404 Page Not Found: Vod-play-id-2612-sid-0-pid-38html/index
ERROR - 2021-09-20 01:44:10 --> 404 Page Not Found: Vod-play-id-2682-sid-0-pid-135html/index
ERROR - 2021-09-20 01:44:12 --> 404 Page Not Found: Vod-play-id-2781-sid-0-pid-40html/index
ERROR - 2021-09-20 01:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:44:24 --> 404 Page Not Found: Vod-play-id-2608-sid-0-pid-138html/index
ERROR - 2021-09-20 01:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:44:26 --> 404 Page Not Found: Vod-play-id-2346-sid-0-pid-84html/index
ERROR - 2021-09-20 01:44:39 --> 404 Page Not Found: Vod-play-id-2671-sid-0-pid-157html/index
ERROR - 2021-09-20 01:44:39 --> 404 Page Not Found: Haoma/index
ERROR - 2021-09-20 01:44:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 01:45:02 --> 404 Page Not Found: Vod-play-id-2623-sid-0-pid-22html/index
ERROR - 2021-09-20 01:45:06 --> 404 Page Not Found: Vod-play-id-2228-sid-0-pid-164html/index
ERROR - 2021-09-20 01:45:08 --> 404 Page Not Found: Vod-play-id-2721-sid-0-pid-4html/index
ERROR - 2021-09-20 01:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:45:31 --> 404 Page Not Found: Vod-play-id-2226-sid-0-pid-9html/index
ERROR - 2021-09-20 01:45:32 --> 404 Page Not Found: Vod-play-id-2742-sid-0-pid-15html/index
ERROR - 2021-09-20 01:45:39 --> 404 Page Not Found: Vod-play-id-2775-sid-0-pid-37html/index
ERROR - 2021-09-20 01:45:41 --> 404 Page Not Found: Vod-play-id-2764-sid-0-pid-4html/index
ERROR - 2021-09-20 01:45:44 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-158html/index
ERROR - 2021-09-20 01:45:46 --> 404 Page Not Found: Vod-play-id-2607-sid-0-pid-272html/index
ERROR - 2021-09-20 01:45:51 --> 404 Page Not Found: Vod-play-id-2609-sid-0-pid-95html/index
ERROR - 2021-09-20 01:45:54 --> 404 Page Not Found: Vod-play-id-2739-sid-0-pid-7html/index
ERROR - 2021-09-20 01:46:18 --> 404 Page Not Found: Vod-play-id-2709-sid-0-pid-12html/index
ERROR - 2021-09-20 01:46:20 --> 404 Page Not Found: Vod-play-id-2709-sid-0-pid-12html/index
ERROR - 2021-09-20 01:46:22 --> 404 Page Not Found: Vod-play-id-2609-sid-0-pid-51html/index
ERROR - 2021-09-20 01:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:46:26 --> 404 Page Not Found: Vod-play-id-2376-sid-0-pid-124html/index
ERROR - 2021-09-20 01:46:26 --> 404 Page Not Found: Sitemap38598html/index
ERROR - 2021-09-20 01:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:47:05 --> 404 Page Not Found: Vod-play-id-2759-sid-0-pid-2html/index
ERROR - 2021-09-20 01:47:10 --> 404 Page Not Found: Vod-play-id-2279-sid-0-pid-119html/index
ERROR - 2021-09-20 01:47:21 --> 404 Page Not Found: Vod-play-id-2609-sid-0-pid-70html/index
ERROR - 2021-09-20 01:47:25 --> 404 Page Not Found: Vod-play-id-2612-sid-0-pid-63html/index
ERROR - 2021-09-20 01:47:33 --> 404 Page Not Found: Vod-play-id-2605-sid-0-pid-184html/index
ERROR - 2021-09-20 01:47:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 01:47:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 01:47:46 --> 404 Page Not Found: Vod-play-id-2671-sid-0-pid-103html/index
ERROR - 2021-09-20 01:47:51 --> 404 Page Not Found: Vod-play-id-2709-sid-0-pid-141html/index
ERROR - 2021-09-20 01:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:50:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 01:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:54:28 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-20 01:55:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 01:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 01:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:01:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:12:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:12:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:12:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:13:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:13:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:21:32 --> 404 Page Not Found: Sitemap26932html/index
ERROR - 2021-09-20 02:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:27:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:30:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:30:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:36:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:38:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:39:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:39:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:42:15 --> 404 Page Not Found: 1/all
ERROR - 2021-09-20 02:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:44:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:47:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:48:55 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-20 02:49:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:49:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:49:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 02:49:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:50:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:50:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:51:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:51:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:51:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:51:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 02:51:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:51:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:52:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:52:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:53:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:53:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 02:53:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:53:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:53:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:54:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 02:54:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 02:54:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:57:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:57:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:57:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:58:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:58:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:58:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:58:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 02:58:33 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-09-20 02:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 02:58:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:04:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 03:04:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 03:05:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 03:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:07:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:09:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:14:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:25:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 03:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:27:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:27:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:35:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 03:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:36:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:36:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 03:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:52:45 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-20 03:52:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:53:27 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-20 03:54:06 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-20 03:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:56:01 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-20 03:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 03:57:24 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-20 03:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:00:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 04:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-09-20 04:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:02:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:06:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 04:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:09:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:09:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:11:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 04:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:16:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:22:27 --> 404 Page Not Found: Home/tradeInfo
ERROR - 2021-09-20 04:22:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:26:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 04:27:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 04:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:28:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 04:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 04:29:19 --> 404 Page Not Found: Manager/text
ERROR - 2021-09-20 04:29:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 04:30:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 04:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:31:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:32:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:33:20 --> 404 Page Not Found: Login/index
ERROR - 2021-09-20 04:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:36:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 04:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:39:11 --> 404 Page Not Found: English/index
ERROR - 2021-09-20 04:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:42:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 04:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:44:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:45:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:48:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 04:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:51:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 04:52:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 04:52:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:53:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 04:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 04:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:01:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:08:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:09:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:12:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:14:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:15:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:24:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 05:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:26:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:26:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:26:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:27:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:28:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:30:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:32:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:32:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:33:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:34:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:37:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:37:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:42:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:46:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:48:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:52:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 05:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 05:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:05:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:08:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 06:08:33 --> 404 Page Not Found: City/1
ERROR - 2021-09-20 06:08:35 --> 404 Page Not Found: City/10
ERROR - 2021-09-20 06:09:33 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-20 06:09:33 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-20 06:09:34 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-20 06:09:34 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-20 06:09:34 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-20 06:09:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-20 06:09:35 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-20 06:09:35 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-20 06:09:35 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-20 06:09:35 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-20 06:09:35 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-20 06:09:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-20 06:09:36 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-20 06:09:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-20 06:09:37 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-20 06:09:37 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-20 06:09:37 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-20 06:09:37 --> 404 Page Not Found: Bbsrar/index
ERROR - 2021-09-20 06:09:37 --> 404 Page Not Found: Bbszip/index
ERROR - 2021-09-20 06:09:38 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-20 06:09:38 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-20 06:09:38 --> 404 Page Not Found: 123rar/index
ERROR - 2021-09-20 06:09:38 --> 404 Page Not Found: 123zip/index
ERROR - 2021-09-20 06:09:38 --> 404 Page Not Found: Bakrar/index
ERROR - 2021-09-20 06:09:39 --> 404 Page Not Found: Bakzip/index
ERROR - 2021-09-20 06:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:11:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 06:12:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:13:56 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-20 06:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:16:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:17:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 06:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:17:47 --> 404 Page Not Found: City/index
ERROR - 2021-09-20 06:17:48 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-09-20 06:17:48 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-20 06:17:49 --> 404 Page Not Found: City/15
ERROR - 2021-09-20 06:17:55 --> 404 Page Not Found: City/2
ERROR - 2021-09-20 06:18:05 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-20 06:18:05 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-20 06:18:06 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-09-20 06:18:06 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-09-20 06:18:07 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-20 06:18:07 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-20 06:18:07 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-20 06:18:08 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-20 06:18:08 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-20 06:18:08 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-20 06:18:08 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-09-20 06:18:08 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-09-20 06:18:08 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-20 06:18:09 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-20 06:18:09 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-20 06:18:09 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-20 06:18:09 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-20 06:18:09 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-20 06:18:10 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-09-20 06:18:13 --> 404 Page Not Found: City/16
ERROR - 2021-09-20 06:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:23:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:23:40 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-20 06:23:43 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-20 06:23:44 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-20 06:23:44 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-20 06:23:44 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-20 06:23:44 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-20 06:23:45 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-20 06:23:45 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-09-20 06:23:45 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-20 06:23:45 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-20 06:23:46 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-20 06:23:46 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-20 06:23:46 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-09-20 06:23:47 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-20 06:23:47 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-20 06:23:47 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-20 06:23:47 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-09-20 06:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:26:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 06:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:32:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 06:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:33:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 06:33:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 06:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:40:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-20 06:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:42:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:45:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 06:45:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 06:45:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 06:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:46:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 06:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:47:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 06:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:49:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:55:37 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-20 06:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 06:59:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 07:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:06:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 07:06:48 --> 404 Page Not Found: Manager/html
ERROR - 2021-09-20 07:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:15:43 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-20 07:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:16:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:18:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 07:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:20:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:20:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:23:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 07:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:25:26 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-09-20 07:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:28:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-20 07:29:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 07:29:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:32:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-20 07:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:34:29 --> 404 Page Not Found: Aaa9/index
ERROR - 2021-09-20 07:34:30 --> 404 Page Not Found: Aab9/index
ERROR - 2021-09-20 07:34:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 07:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:35:40 --> 404 Page Not Found: Home/Favourable
ERROR - 2021-09-20 07:35:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 07:36:18 --> 404 Page Not Found: 44/44983
ERROR - 2021-09-20 07:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:36:46 --> 404 Page Not Found: P-4955666883733html/index
ERROR - 2021-09-20 07:37:12 --> 404 Page Not Found: Soft/304763.html
ERROR - 2021-09-20 07:37:19 --> 404 Page Not Found: Pptdown/20180412190616.html
ERROR - 2021-09-20 07:37:24 --> 404 Page Not Found: Xuexi/10255.html
ERROR - 2021-09-20 07:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:37:30 --> 404 Page Not Found: Content/18
ERROR - 2021-09-20 07:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:37:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:37:54 --> 404 Page Not Found: Z187444450/index
ERROR - 2021-09-20 07:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:52:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:55:33 --> 404 Page Not Found: City/1
ERROR - 2021-09-20 07:55:38 --> 404 Page Not Found: City/1
ERROR - 2021-09-20 07:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 07:59:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:35:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:45:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 08:45:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 08:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:48:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:51:13 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-09-20 08:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:54:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 08:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:58:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 08:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 08:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:11:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-20 09:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:16:20 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-20 09:16:21 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-20 09:16:22 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-20 09:16:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-20 09:16:22 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-20 09:16:22 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-20 09:16:22 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-20 09:16:22 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-20 09:16:22 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-20 09:16:22 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-20 09:16:22 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-20 09:16:22 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-20 09:16:22 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-20 09:16:23 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-20 09:16:23 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-20 09:16:23 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-20 09:16:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-20 09:16:23 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-20 09:16:23 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-20 09:16:23 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-20 09:16:23 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-20 09:16:23 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-20 09:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:20:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:25:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:30:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 09:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:32:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 09:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:37:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 09:37:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 09:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:45:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 09:45:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 09:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:48:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:49:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:49:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 09:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:50:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:50:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 09:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:51:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 09:51:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 09:52:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 09:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 09:59:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 10:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:02:20 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-20 10:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:02:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 10:03:17 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-20 10:03:37 --> 404 Page Not Found: Index/login
ERROR - 2021-09-20 10:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:06:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 10:07:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 10:11:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 10:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:12:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:13:30 --> 404 Page Not Found: City/1
ERROR - 2021-09-20 10:14:09 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-09-20 10:14:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:16:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:16:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 10:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:19:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:20:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:21:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:21:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:21:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:21:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:21:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:21:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:22:21 --> 404 Page Not Found: Article/view
ERROR - 2021-09-20 10:22:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 10:23:29 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-20 10:25:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 10:25:25 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-09-20 10:26:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:27:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:27:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:27:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:28:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 10:28:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 10:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:30:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:33:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:42:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:45:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 10:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:46:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:47:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 10:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:47:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 10:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:48:43 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-09-20 10:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:53:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 10:54:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:55:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 10:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:58:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 10:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:00:49 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-20 11:00:50 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-20 11:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:04:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 11:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:05:25 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-20 11:05:25 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-20 11:05:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 11:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 11:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:08:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:12:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 11:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:15:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 11:15:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:15:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 11:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:21:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:23:36 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-20 11:23:36 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-20 11:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:25:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:27:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:29:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:33:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:34:58 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-20 11:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:36:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:40:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:41:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 11:41:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:42:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:42:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:44:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:45:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:47:47 --> 404 Page Not Found: Undefined/index
ERROR - 2021-09-20 11:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:48:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 11:48:16 --> 404 Page Not Found: Undefined/index
ERROR - 2021-09-20 11:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:57:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 11:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:58:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:58:58 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-20 11:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 11:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:01:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 12:01:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 12:03:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:06:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 12:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:08:39 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-09-20 12:09:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 12:10:26 --> 404 Page Not Found: Env/index
ERROR - 2021-09-20 12:10:30 --> 404 Page Not Found: City/16
ERROR - 2021-09-20 12:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:11:43 --> Severity: Warning --> Missing argument 1 for Xinxi::show() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 97
ERROR - 2021-09-20 12:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:12:05 --> 404 Page Not Found: City/10
ERROR - 2021-09-20 12:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:14:52 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-09-20 12:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:21:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:25:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 12:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:33:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 12:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 12:34:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 12:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:37:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 12:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:38:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:48:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 12:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:49:07 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-09-20 12:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:51:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:54:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 12:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:55:15 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-09-20 12:55:29 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-09-20 12:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:55:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 12:55:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 12:56:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 12:56:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 12:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 12:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:04:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:05:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:05:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:06:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:12:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:13:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:13:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 13:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:16:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:16:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:17:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:19:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:20:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 13:21:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 13:21:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 13:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:22:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 13:22:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:22:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:22:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:22:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:22:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:23:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:23:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:23:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:24:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:24:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:24:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:24:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:25:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:25:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:25:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:28:17 --> 404 Page Not Found: Manage/login.asp
ERROR - 2021-09-20 13:28:20 --> 404 Page Not Found: Manage/login.asp
ERROR - 2021-09-20 13:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:28:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 13:28:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:28:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:29:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:31:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 13:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:32:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:33:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 13:33:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:33:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:34:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:35:02 --> 404 Page Not Found: City/1
ERROR - 2021-09-20 13:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:39:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:41:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:42:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:43:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:44:32 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-09-20 13:45:11 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-09-20 13:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:46:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 13:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:46:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 13:46:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 13:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:48:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:48:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:49:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:49:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:49:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:49:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:49:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:53:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 13:54:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:56:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 13:56:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:57:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 13:58:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 13:59:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 13:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 14:00:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 14:00:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 14:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:00:52 --> 404 Page Not Found: Haoma/index
ERROR - 2021-09-20 14:01:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 14:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:02:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 14:03:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 14:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:04:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 14:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:04:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 14:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:04:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 14:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:07:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 14:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:09:11 --> 404 Page Not Found: Haoma/index
ERROR - 2021-09-20 14:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:10:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:16:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 14:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:18:57 --> 404 Page Not Found: City/2
ERROR - 2021-09-20 14:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:21:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 14:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:29:43 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-20 14:30:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:31:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:36:13 --> 404 Page Not Found: Previewdo/index
ERROR - 2021-09-20 14:37:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:45:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:46:51 --> 404 Page Not Found: Sitemap74044html/index
ERROR - 2021-09-20 14:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:47:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:47:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:48:06 --> 404 Page Not Found: Haoma/index
ERROR - 2021-09-20 14:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:50:37 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-20 14:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:52:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 14:53:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 14:53:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 14:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:54:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 14:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 14:59:14 --> 404 Page Not Found: English/index
ERROR - 2021-09-20 14:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:02:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:02:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 15:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:03:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 15:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:04:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 15:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:05:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 15:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:10:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 15:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:13:03 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-09-20 15:13:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 15:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:14:02 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-09-20 15:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:15:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 15:15:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 15:16:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 15:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:17:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-20 15:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:18:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 15:18:15 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-09-20 15:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:18:41 --> 404 Page Not Found: Sites/default
ERROR - 2021-09-20 15:18:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 15:18:53 --> 404 Page Not Found: admin/Controller/extension
ERROR - 2021-09-20 15:19:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 15:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:20:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 15:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:20:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 15:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:21:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 15:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:26:04 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-20 15:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:27:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:28:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:31:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:32:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:32:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:33:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:37:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:37:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:37:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:41:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:41:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:42:55 --> 404 Page Not Found: Config/getuser
ERROR - 2021-09-20 15:43:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:44:00 --> 404 Page Not Found: Cn/Productsa.asp
ERROR - 2021-09-20 15:45:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:45:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:46:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:46:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:46:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:46:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:47:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:47:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 15:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:52:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 15:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:54:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:55:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:57:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:57:35 --> 404 Page Not Found: Haoma/index
ERROR - 2021-09-20 15:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 15:58:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 15:59:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:00:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:01:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:03:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:04:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:04:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 16:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:05:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:05:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:06:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:06:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 16:06:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:09:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:10:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:11:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 16:11:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:13:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:13:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-20 16:14:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:15:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:16:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:17:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 16:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:19:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-20 16:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:24:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 16:25:21 --> 404 Page Not Found: Html-cn/hot-products-CQxmJTnWDEvg-1-0-2-1.html
ERROR - 2021-09-20 16:25:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 16:26:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 16:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:28:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:30:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 16:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:35:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:37:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:38:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:39:19 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-20 16:39:19 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-20 16:39:19 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-20 16:39:19 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-20 16:39:19 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-20 16:39:20 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-20 16:39:20 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-20 16:39:20 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-20 16:39:20 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-20 16:39:20 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-20 16:39:20 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-20 16:39:20 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-20 16:39:20 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-20 16:39:20 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-20 16:39:20 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-20 16:39:21 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-09-20 16:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:42:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 16:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 16:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:00:59 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-20 17:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:03:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 17:03:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 17:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:04:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:04:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:07:36 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-09-20 17:07:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:11:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 17:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:12:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:12:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:12:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:12:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:18:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:19:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:19:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:22:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:23:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:23:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:23:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:27:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:31:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:33:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:37:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:40:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:40:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:40:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:40:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:45:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:57:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:58:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 17:59:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 17:59:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 17:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 17:59:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:00:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:01:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:01:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:02:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:04:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 18:04:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:05:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:05:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:12:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 18:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:13:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 18:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:15:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 18:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:16:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 18:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:18:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 18:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:19:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:20:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:21:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:21:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:22:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 18:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:23:20 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-09-20 18:24:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 18:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:24:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 18:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:26:19 --> 404 Page Not Found: City/index
ERROR - 2021-09-20 18:26:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 18:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:27:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 18:28:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 18:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:30:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 18:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:32:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:46:04 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-09-20 18:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:52:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 18:52:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:52:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:52:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:53:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:55:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:55:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 18:55:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:55:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:55:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:55:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:55:55 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-09-20 18:56:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 18:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 18:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:00:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 19:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:02:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:04:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-20 19:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:05:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:07:00 --> 404 Page Not Found: English/index
ERROR - 2021-09-20 19:07:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:11:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 19:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:13:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 19:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:15:03 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-09-20 19:15:08 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-09-20 19:15:08 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-09-20 19:15:08 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-09-20 19:15:09 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-09-20 19:15:09 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-09-20 19:15:10 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-09-20 19:15:10 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-09-20 19:15:10 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-09-20 19:15:10 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-09-20 19:15:11 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-09-20 19:15:11 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-09-20 19:15:12 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-09-20 19:15:12 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-09-20 19:15:12 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-09-20 19:15:12 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-09-20 19:15:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 19:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:18:25 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-09-20 19:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:19:37 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-09-20 19:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:20:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 19:20:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:23:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 19:25:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 19:27:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:31:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 19:31:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 19:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:32:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:40:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 19:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:42:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 19:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:42:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:46:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 19:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:47:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 19:47:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 19:47:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 19:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:52:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 19:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:54:07 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-09-20 19:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 19:56:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 19:57:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:00:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 20:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:03:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 20:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 20:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 20:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:09:55 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-20 20:09:56 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-09-20 20:09:57 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-09-20 20:09:58 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-09-20 20:09:58 --> 404 Page Not Found: Webrar/index
ERROR - 2021-09-20 20:09:58 --> 404 Page Not Found: Webzip/index
ERROR - 2021-09-20 20:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:11:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 20:13:07 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-09-20 20:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:21:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:24:02 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-09-20 20:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:24:32 --> 404 Page Not Found: City/2
ERROR - 2021-09-20 20:24:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 20:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:27:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:36:43 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-20 20:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:38:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 20:38:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 20:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:40:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:40:46 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-09-20 20:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:42:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:47:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 20:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:48:24 --> 404 Page Not Found: Downloader/index
ERROR - 2021-09-20 20:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:49:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 20:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:52:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 20:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:55:05 --> 404 Page Not Found: Downloader/index
ERROR - 2021-09-20 20:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:57:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:58:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:58:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 20:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:03:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 21:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:06:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:07:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 21:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:11:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:12:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 21:12:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:12:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:12:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:12:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:12:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:13:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:13:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:13:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:13:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:13:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:13:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:13:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:14:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:14:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 21:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:19:18 --> 404 Page Not Found: Downloader/index
ERROR - 2021-09-20 21:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:20:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:21:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:21:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:22:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:26:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:26:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:33:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:36:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:40:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 21:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:42:08 --> 404 Page Not Found: Search/likea
ERROR - 2021-09-20 21:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:43:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 21:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:44:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 21:44:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 21:45:44 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-20 21:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:53:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 21:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:03:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 22:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:05:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:09:37 --> 404 Page Not Found: SiteServer/Ajax
ERROR - 2021-09-20 22:09:37 --> 404 Page Not Found: SiteFiles/SiteTemplates
ERROR - 2021-09-20 22:09:37 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-09-20 22:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:17:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:18:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 22:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:20:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 22:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:22:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 22:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:23:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 22:23:55 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-20 22:23:56 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-09-20 22:24:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 22:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:36:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-09-20 22:37:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:37:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 22:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:42:12 --> 404 Page Not Found: Downloader/index
ERROR - 2021-09-20 22:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:44:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 22:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:46:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 22:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 22:46:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 22:46:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 22:47:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 22:47:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 22:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:47:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:49:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 22:49:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 22:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:50:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 22:51:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:55:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:56:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 22:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:58:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 22:59:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 22:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 22:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:03:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:06:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 23:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:07:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 23:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:08:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 23:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:17:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 23:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:26:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 23:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:26:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 23:27:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 23:27:59 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-09-20 23:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:31:27 --> 404 Page Not Found: Downloader/index
ERROR - 2021-09-20 23:32:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 23:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:34:08 --> 404 Page Not Found: Downloader/index
ERROR - 2021-09-20 23:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:37:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 23:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:39:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 23:39:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 23:39:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 23:39:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-09-20 23:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:40:26 --> 404 Page Not Found: Downloader/index
ERROR - 2021-09-20 23:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:42:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 23:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:43:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:43:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 23:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:44:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 23:45:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 23:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:47:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:50:55 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-09-20 23:50:56 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-09-20 23:54:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 23:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:55:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:56:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:57:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-09-20 23:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:58:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-09-20 23:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-09-20 23:59:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-09-20 23:59:46 --> 404 Page Not Found: Robotstxt/index
