<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-30 00:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:04:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 00:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:06:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:07:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 00:07:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 00:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:07:55 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-30 00:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:09:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:16:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:19:51 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-08-30 00:20:33 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-30 00:20:33 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-30 00:20:33 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-30 00:20:33 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-30 00:20:33 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-30 00:20:34 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-30 00:20:35 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-30 00:20:35 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-30 00:20:35 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-30 00:20:36 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-30 00:20:36 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-30 00:20:36 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-30 00:20:36 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-30 00:20:36 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-30 00:20:36 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-30 00:20:36 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-30 00:20:36 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-30 00:20:36 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-30 00:20:36 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-30 00:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:22:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:28:49 --> 404 Page Not Found: admin/Eweb/login_admin.asp
ERROR - 2021-08-30 00:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:32:09 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-30 00:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:33:43 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-08-30 00:34:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:35:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 00:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:37:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 00:38:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 00:39:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 00:39:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 00:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:43:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:46:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:51:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 00:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 00:57:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:05:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 01:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:10:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:15:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:18:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 01:18:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 01:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:19:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 01:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:29:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 01:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:33:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:38:31 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-30 01:38:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-30 01:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:40:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 01:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:45:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 01:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:55:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 01:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:05:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:12:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:15:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:18:58 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-30 02:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:20:19 --> 404 Page Not Found: Env/index
ERROR - 2021-08-30 02:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:21:28 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-30 02:24:45 --> 404 Page Not Found: Env/index
ERROR - 2021-08-30 02:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:28:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:35:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:54:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:55:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 02:57:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 02:59:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 02:59:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 03:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:02:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 03:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:06:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-30 03:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:10:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:13:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:16:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:17:39 --> 404 Page Not Found: City/10
ERROR - 2021-08-30 03:17:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 03:17:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 03:17:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 03:17:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 03:17:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 03:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:19:12 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-30 03:19:12 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-30 03:19:12 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-30 03:19:12 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-30 03:19:12 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-30 03:19:12 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-30 03:19:12 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-30 03:19:13 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-30 03:19:14 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-30 03:19:14 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-30 03:19:14 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-30 03:19:14 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-30 03:19:14 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-30 03:19:14 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-30 03:19:14 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-30 03:19:14 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-30 03:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:20:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:20:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:21:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:22:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:30:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-30 03:30:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 03:31:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:33:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 03:33:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 03:33:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 03:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:35:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:37:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 03:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:38:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 03:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:58:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 03:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-08-30 04:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:02:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:11:57 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-08-30 04:11:58 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-08-30 04:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:13:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:18:12 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-08-30 04:19:53 --> 404 Page Not Found: Manager/text
ERROR - 2021-08-30 04:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:36:12 --> 404 Page Not Found: Blog/index
ERROR - 2021-08-30 04:36:12 --> 404 Page Not Found: Wp/index
ERROR - 2021-08-30 04:36:12 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-08-30 04:36:13 --> 404 Page Not Found: New/index
ERROR - 2021-08-30 04:36:13 --> 404 Page Not Found: Old/index
ERROR - 2021-08-30 04:36:14 --> 404 Page Not Found: Test/index
ERROR - 2021-08-30 04:36:14 --> 404 Page Not Found: Main/index
ERROR - 2021-08-30 04:36:15 --> 404 Page Not Found: Site/index
ERROR - 2021-08-30 04:36:15 --> 404 Page Not Found: Backup/index
ERROR - 2021-08-30 04:36:16 --> 404 Page Not Found: Demo/index
ERROR - 2021-08-30 04:36:18 --> 404 Page Not Found: Tmp/index
ERROR - 2021-08-30 04:36:18 --> 404 Page Not Found: Cms/index
ERROR - 2021-08-30 04:36:19 --> 404 Page Not Found: Dev/index
ERROR - 2021-08-30 04:36:19 --> 404 Page Not Found: Old-wp/index
ERROR - 2021-08-30 04:36:20 --> 404 Page Not Found: Web/index
ERROR - 2021-08-30 04:36:20 --> 404 Page Not Found: Old-site/index
ERROR - 2021-08-30 04:36:21 --> 404 Page Not Found: Temp/index
ERROR - 2021-08-30 04:36:21 --> 404 Page Not Found: 2018/index
ERROR - 2021-08-30 04:36:21 --> 404 Page Not Found: 2019/index
ERROR - 2021-08-30 04:36:22 --> 404 Page Not Found: Bk/index
ERROR - 2021-08-30 04:36:22 --> 404 Page Not Found: Wp1/index
ERROR - 2021-08-30 04:36:23 --> 404 Page Not Found: Wp2/index
ERROR - 2021-08-30 04:36:23 --> 404 Page Not Found: V1/index
ERROR - 2021-08-30 04:36:24 --> 404 Page Not Found: V2/index
ERROR - 2021-08-30 04:36:24 --> 404 Page Not Found: Bak/index
ERROR - 2021-08-30 04:36:25 --> 404 Page Not Found: 2020/index
ERROR - 2021-08-30 04:36:26 --> 404 Page Not Found: New-site/index
ERROR - 2021-08-30 04:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:38:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:46:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:49:13 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-30 04:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:57:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 04:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:01:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:08:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:23:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:25:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:26:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 05:27:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 05:27:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 05:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:31:15 --> 404 Page Not Found: Env/index
ERROR - 2021-08-30 05:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:34:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:44:30 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-30 05:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:45:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:49:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 05:49:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 05:49:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 05:49:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 05:50:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 05:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:08:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 06:08:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 06:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:14:06 --> 404 Page Not Found: English/index
ERROR - 2021-08-30 06:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:17:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:21:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 06:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:27:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 06:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:33:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:36:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:36:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:37:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:38:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 06:38:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:38:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:39:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:40:50 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-08-30 06:41:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:41:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:42:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:42:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:42:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:43:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:43:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:44:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:44:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:45:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:45:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:45:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 06:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:53:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:55:30 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-30 06:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 06:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:00:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:00:37 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-30 07:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:01:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:01:24 --> 404 Page Not Found: Pv/000000000000.cfg
ERROR - 2021-08-30 07:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:02:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:02:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:03:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:03:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:04:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:04:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:04:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:04:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:05:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:07:10 --> 404 Page Not Found: Manager/html
ERROR - 2021-08-30 07:08:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:08:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:11:13 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-30 07:11:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:11:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:13:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:14:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:14:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:15:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:15:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:15:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:16:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:17:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:17:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:17:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:18:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:18:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:19:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:21:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:23:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:27:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:36:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:43:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:43:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:43:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:44:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:44:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 07:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:45:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:51:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:55:37 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-30 07:56:30 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-08-30 07:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 07:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:02:13 --> 404 Page Not Found: Struts2-rest-showcase/orders.xhtml
ERROR - 2021-08-30 08:02:13 --> 404 Page Not Found: Indexaction/index
ERROR - 2021-08-30 08:02:13 --> 404 Page Not Found: Indexdo/index
ERROR - 2021-08-30 08:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:11:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-30 08:12:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:20:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 08:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:30:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 08:30:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 08:30:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 08:30:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 08:31:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:37:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 08:39:09 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-08-30 08:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:41:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 08:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 08:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:44:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 08:44:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 08:44:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 08:44:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 08:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:46:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 08:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:48:04 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-30 08:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:54:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:55:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 08:57:35 --> 404 Page Not Found: English/index
ERROR - 2021-08-30 08:57:43 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-30 08:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:00:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 09:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:00:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 09:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:02:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 09:02:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 09:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:03:34 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-30 09:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:07:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:09:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:10:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:13:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-30 09:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:17:37 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-30 09:19:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:19:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:25:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 09:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:26:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 09:26:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 09:27:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 09:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:27:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 09:28:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 09:28:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-30 09:29:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 09:29:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 09:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:30:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 09:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:41:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 09:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:45:02 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 09:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 09:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:03:00 --> 404 Page Not Found: admin/Editor/login_admin.asp
ERROR - 2021-08-30 10:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:04:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:07:59 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-30 10:07:59 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-30 10:07:59 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-30 10:07:59 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-30 10:07:59 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-30 10:07:59 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-30 10:07:59 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-30 10:07:59 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-30 10:07:59 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-30 10:07:59 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-30 10:08:00 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-30 10:08:00 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-30 10:08:00 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-30 10:08:00 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-30 10:08:00 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-30 10:08:00 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-30 10:08:00 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-30 10:08:01 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-30 10:08:02 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-30 10:08:02 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-30 10:08:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 10:08:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 10:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:10:07 --> 404 Page Not Found: All/index
ERROR - 2021-08-30 10:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:18:24 --> 404 Page Not Found: Admin_loginasp/index
ERROR - 2021-08-30 10:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:21:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:24:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:34:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 10:34:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 10:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:41:37 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 10:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:44:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:47:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:50:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 10:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:51:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 10:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 10:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:53:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:55:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 10:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 10:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:14:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:19:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:19:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:21:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-30 11:21:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 11:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:23:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:25:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:25:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:27:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:29:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:33:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:33:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 11:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:39:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:39:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:45:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:45:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:45:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:52:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:53:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:56:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:57:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:57:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 11:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:57:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 11:58:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:58:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:58:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:58:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 11:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 11:59:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 12:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:00:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:02:21 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-08-30 12:02:22 --> 404 Page Not Found: Wp/index
ERROR - 2021-08-30 12:02:22 --> 404 Page Not Found: Bc/index
ERROR - 2021-08-30 12:02:23 --> 404 Page Not Found: Bk/index
ERROR - 2021-08-30 12:02:23 --> 404 Page Not Found: Backup/index
ERROR - 2021-08-30 12:02:23 --> 404 Page Not Found: Old/index
ERROR - 2021-08-30 12:02:24 --> 404 Page Not Found: Old-site/index
ERROR - 2021-08-30 12:02:24 --> 404 Page Not Found: Oldsite/index
ERROR - 2021-08-30 12:02:24 --> 404 Page Not Found: New/index
ERROR - 2021-08-30 12:02:25 --> 404 Page Not Found: Main/index
ERROR - 2021-08-30 12:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:03:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 12:03:44 --> 404 Page Not Found: Admin_loginasp/index
ERROR - 2021-08-30 12:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:05:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:10:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:13:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 12:15:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 12:15:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 12:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:15:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:16:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:17:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:18:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:18:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:19:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:19:16 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-30 12:19:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:20:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:20:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:21:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:23:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:24:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:24:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:25:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:25:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:25:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:26:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:32:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:36:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:36:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:36:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:36:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:37:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:37:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:38:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 12:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:48:58 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-08-30 12:49:02 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-08-30 12:49:05 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-08-30 12:49:11 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-08-30 12:49:33 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-08-30 12:49:40 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 12:49:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 12:49:58 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-08-30 12:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:51:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 12:51:29 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-08-30 12:51:29 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-08-30 12:51:31 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-08-30 12:51:33 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-08-30 12:51:33 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-08-30 12:51:35 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-08-30 12:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 12:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:00:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 13:00:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 13:00:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 13:00:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 13:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:11:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:11:29 --> 404 Page Not Found: City/1
ERROR - 2021-08-30 13:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:13:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 13:13:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 13:13:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 13:13:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 13:13:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 13:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:16:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 13:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:18:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:19:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:19:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:19:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:19:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:20:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:20:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:21:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:21:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:21:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:22:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:22:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:22:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:23:10 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 13:23:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 13:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:23:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:30:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:32:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:32:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:37:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 13:38:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 13:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:39:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:39:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:39:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:40:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:40:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:40:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:45:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:45:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:45:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:46:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 13:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:48:30 --> 404 Page Not Found: City/2
ERROR - 2021-08-30 13:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:51:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:55:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:56:21 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-30 13:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 13:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:03:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:04:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 14:04:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 14:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:05:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 14:05:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:12:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 14:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 14:17:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:18:36 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-30 14:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:21:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 14:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 14:21:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 14:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:22:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 14:22:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:23:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 14:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:30:56 --> 404 Page Not Found: English/index
ERROR - 2021-08-30 14:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 14:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:48:31 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-30 14:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:53:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 14:55:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 14:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:02:33 --> 404 Page Not Found: Ewebeditor/login_admin.asp
ERROR - 2021-08-30 15:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:07:00 --> 404 Page Not Found: admin/Ewebeditor/login_admin.asp
ERROR - 2021-08-30 15:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:09:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 15:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:10:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:11:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:13:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:14:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 15:14:58 --> 404 Page Not Found: Env/index
ERROR - 2021-08-30 15:15:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:15:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:16:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:19:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:22:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:24:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:27:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:27:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:28:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:29:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:30:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:32:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:32:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:33:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 15:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:35:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 15:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:37:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 15:37:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 15:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:40:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:43:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:49:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:50:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:51:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:52:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:52:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:52:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:53:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:56:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 15:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 15:59:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 16:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 16:00:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 16:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:02:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 16:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:06:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 16:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:07:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 16:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:16:50 --> 404 Page Not Found: Env/index
ERROR - 2021-08-30 16:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:20:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:21:17 --> 404 Page Not Found: admin/Editor/login_admin.asp
ERROR - 2021-08-30 16:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:32:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 16:32:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 16:32:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 16:32:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 16:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:37:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:37:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:39:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:43:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:45:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 16:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:52:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:55:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 16:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:01:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:03:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:04:10 --> 404 Page Not Found: admin/Eweb/login_admin.asp
ERROR - 2021-08-30 17:04:36 --> 404 Page Not Found: City/1
ERROR - 2021-08-30 17:04:54 --> 404 Page Not Found: Admin_loginasp/index
ERROR - 2021-08-30 17:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:13:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:19:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:33:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:45:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:45:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:50:26 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-30 17:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:51:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:53:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:53:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:54:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:54:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:54:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:55:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:55:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:56:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:56:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:57:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:57:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:58:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:59:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 17:59:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 17:59:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 18:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:00:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 18:00:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 18:01:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 18:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:04:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 18:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:05:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 18:06:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 18:06:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 18:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:06:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 18:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:09:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 18:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:14:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 18:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:17:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 18:19:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:25:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-30 18:26:38 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-30 18:26:39 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-30 18:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:31:36 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-08-30 18:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:34:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:39:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:44:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:45:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:45:22 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-30 18:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:50:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 18:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:00:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:00:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:05:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 19:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:13:59 --> 404 Page Not Found: City/10
ERROR - 2021-08-30 19:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:15:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:16:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:17:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:17:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 19:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:21:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-30 19:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:21:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:23:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:23:54 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 19:24:04 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 19:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:27:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:31:53 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-30 19:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:33:26 --> 404 Page Not Found: City/1
ERROR - 2021-08-30 19:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:36:47 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 19:36:48 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 19:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:37:03 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 19:37:03 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 19:37:06 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 19:37:11 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 19:37:13 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 19:37:14 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-30 19:37:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:38:15 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-30 19:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:38:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:39:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:39:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:40:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:40:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:40:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:41:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 19:41:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 19:41:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:41:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:41:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 19:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:45:54 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-30 19:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:47:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:52:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:57:03 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 19:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 19:59:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:21:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 20:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:26:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:26:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:30:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:31:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:31:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:31:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:32:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:32:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:32:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:37:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:41:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-30 20:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:43:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:44:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:44:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:45:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:45:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:46:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 20:46:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:47:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:47:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 20:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:48:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:56:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 20:56:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 20:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:57:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 20:57:30 --> 404 Page Not Found: Env/index
ERROR - 2021-08-30 20:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:59:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 20:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:03:23 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-08-30 21:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:05:00 --> 404 Page Not Found: Humanstxt/index
ERROR - 2021-08-30 21:05:02 --> 404 Page Not Found: Adstxt/index
ERROR - 2021-08-30 21:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:07:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 21:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:08:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 21:09:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 21:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:11:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:19:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 21:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:23:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 21:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:27:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:29:01 --> 404 Page Not Found: Article/view
ERROR - 2021-08-30 21:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:32:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:40:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 21:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:42:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 21:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:46:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:48:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:48:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:50:39 --> 404 Page Not Found: City/2
ERROR - 2021-08-30 21:51:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 21:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:01:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 22:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:03:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:06:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 22:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:10:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:11:40 --> 404 Page Not Found: Login/index
ERROR - 2021-08-30 22:11:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:19:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 22:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:25:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:52:15 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-30 22:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:54:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 22:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:01:04 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-30 23:01:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:01:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:02:51 --> 404 Page Not Found: Sitemapxmlgz/index
ERROR - 2021-08-30 23:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:07:08 --> 404 Page Not Found: Nmaplowercheck1630336018/index
ERROR - 2021-08-30 23:07:08 --> 404 Page Not Found: Evox/about
ERROR - 2021-08-30 23:07:08 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-08-30 23:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:10:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:10:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:11:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:12:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:12:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:12:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:12:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:13:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:14:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:14:43 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-30 23:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:15:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-30 23:16:25 --> 404 Page Not Found: Sitemap_indexxml/index
ERROR - 2021-08-30 23:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:19:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:22:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:24:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:24:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:32:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:33:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 23:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:40:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-30 23:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:41:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 23:41:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:43:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:44:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:45:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-30 23:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:46:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-30 23:51:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-30 23:57:33 --> 404 Page Not Found: Robotstxt/index
