<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-31 00:03:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 00:04:56 --> 404 Page Not Found: App/views
ERROR - 2021-12-31 00:04:56 --> 404 Page Not Found: App/views
ERROR - 2021-12-31 00:05:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:06:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:08:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:10:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:12:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:14:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:15:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:15:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:15:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 00:17:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 00:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:21:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:23:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:24:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:25:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:27:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 00:28:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:28:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:28:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:32:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:33:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:35:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:35:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:35:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:38:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:38:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:38:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:41:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:42:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:43:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:44:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:46:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:47:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:50:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:51:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 00:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 00:55:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 00:57:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:58:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:58:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 00:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 01:00:39 --> 404 Page Not Found: Sitemap42517html/index
ERROR - 2021-12-31 01:00:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 01:01:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:02:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:02:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 01:05:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 01:05:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 01:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 01:09:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:11:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:13:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:16:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:16:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 01:17:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:18:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 01:24:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:32:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:33:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:37:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 01:39:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:39:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:45:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:49:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 01:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 01:59:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 02:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 02:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 02:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 02:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 02:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 02:24:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 02:30:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 02:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 02:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 02:35:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 02:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 02:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 02:45:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:45:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:45:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:45:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:45:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:45:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:45:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:45:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:46:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:46:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:46:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:46:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 02:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 02:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 02:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:11:04 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 03:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:38:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 03:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:45:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:47:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 03:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 04:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 04:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 04:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 04:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 04:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 04:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 04:54:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 05:00:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 05:12:26 --> 404 Page Not Found: Login/index
ERROR - 2021-12-31 05:13:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 05:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 05:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 05:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 05:17:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 05:31:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 05:39:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 05:47:05 --> 404 Page Not Found: City/16
ERROR - 2021-12-31 05:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 05:56:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 06:01:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 06:02:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 06:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 06:17:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 06:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 06:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 06:18:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 06:31:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 06:35:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 06:54:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 06:55:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 06:55:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 06:56:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 06:57:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 06:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 07:06:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 07:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 07:14:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 07:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 07:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 07:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 07:18:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 07:18:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 07:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 07:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 07:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:01:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 08:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 08:02:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 08:03:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 08:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:28:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 08:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:31:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 08:31:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 08:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:37:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 08:37:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 08:38:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 08:40:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:40:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 08:44:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 08:48:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:48:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 08:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 08:49:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 08:59:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 09:02:38 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-31 09:04:03 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-12-31 09:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 09:14:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 09:14:58 --> 404 Page Not Found: Wwwzhaohaocncomrar/index
ERROR - 2021-12-31 09:14:58 --> 404 Page Not Found: Wwwzhaohaocncomzip/index
ERROR - 2021-12-31 09:14:58 --> 404 Page Not Found: Wwwzhaohaocncomtargz/index
ERROR - 2021-12-31 09:14:58 --> 404 Page Not Found: Wwwzhaohaocncom7z/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Www_zhaohaocn_comrar/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Www_zhaohaocn_comzip/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Www_zhaohaocn_comtargz/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Www_zhaohaocn_com7z/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Wwwzhaohaocncomrar/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Wwwzhaohaocncomzip/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Wwwzhaohaocncomtargz/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Wwwzhaohaocncom7z/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocncomrar/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocncomzip/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocncomtargz/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocncom7z/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocnrar/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocnzip/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocntargz/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocn7z/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocnwwwzip/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocnwwwrar/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocnwwwtargz/index
ERROR - 2021-12-31 09:14:59 --> 404 Page Not Found: Zhaohaocnwww7z/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Zhaohaocnwebrar/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Zhaohaocnwebzip/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Zhaohaocnwebtargz/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Zhaohaocnweb7z/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Zhaohaocnwwwrootzip/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Zhaohaocnwwwrootrar/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Zhaohaocnwwwroottargz/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Zhaohaocnwwwroot7z/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Www7z/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Webrar/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Webzip/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Webtar7z/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-12-31 09:15:00 --> 404 Page Not Found: Wwwroot7z/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Websiterar/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Websitezip/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Websitetargz/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Website17z/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Website1rar/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Website1zip/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Website1targz/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Website17z/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Yuanmazip/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Yuanmarar/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Yuanmatargz/index
ERROR - 2021-12-31 09:15:01 --> 404 Page Not Found: Yuanma7z/index
ERROR - 2021-12-31 09:15:02 --> 404 Page Not Found: Beifenrar/index
ERROR - 2021-12-31 09:15:02 --> 404 Page Not Found: Beifenzip/index
ERROR - 2021-12-31 09:15:02 --> 404 Page Not Found: Beifentargz/index
ERROR - 2021-12-31 09:15:02 --> 404 Page Not Found: Beifen7z/index
ERROR - 2021-12-31 09:15:02 --> 404 Page Not Found: Backuprar/index
ERROR - 2021-12-31 09:15:02 --> 404 Page Not Found: Backupzip/index
ERROR - 2021-12-31 09:15:02 --> 404 Page Not Found: Backuptargz/index
ERROR - 2021-12-31 09:15:02 --> 404 Page Not Found: Backup7z/index
ERROR - 2021-12-31 09:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 09:28:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 09:28:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 09:28:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 09:29:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 09:31:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 09:34:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 09:34:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 09:34:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 09:35:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 09:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 09:42:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 09:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 09:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 10:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 10:08:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 10:10:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 10:10:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 10:13:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 10:13:59 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-12-31 10:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 10:31:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 10:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 10:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 10:44:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 10:46:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 10:46:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 10:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 10:46:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 10:54:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 10:59:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 10:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:08:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:17:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:26:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 11:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:39:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:46:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:47:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:47:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:47:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:47:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:48:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:48:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 11:48:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:48:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:48:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:49:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 11:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:49:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:50:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:50:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:51:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:52:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:52:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:52:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:52:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 11:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 11:58:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 12:00:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 12:00:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 12:00:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 12:02:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 12:08:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 12:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 12:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 12:18:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 12:18:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 12:26:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 12:31:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 12:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 12:41:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 12:41:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 12:47:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 12:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 12:52:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 12:52:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 12:58:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 13:00:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 13:10:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 13:10:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 13:15:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 13:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 13:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 13:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 13:42:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 13:53:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 13:55:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 13:59:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 13:59:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 14:00:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 14:14:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 14:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 14:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 14:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 14:27:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 14:34:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 14:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 14:40:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 14:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 14:50:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 14:50:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 14:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 15:06:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 15:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 15:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 15:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 15:20:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 15:22:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:23:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:23:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:24:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:24:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 15:24:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:24:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:24:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:24:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:24:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:24:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:24:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:24:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:24:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:24:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:25:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:25:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:25:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:25:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:25:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:25:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:25:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 15:25:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:26:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:26:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 15:26:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:27:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:28:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 15:28:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:29:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:29:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:29:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:29:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:30:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:31:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:32:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:32:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 15:32:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:32:38 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-12-31 15:32:45 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-12-31 15:32:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:33:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 15:33:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:34:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:34:06 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-12-31 15:34:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:37:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:37:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:37:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:37:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:37:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:37:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:37:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:38:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:38:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:39:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:40:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:42:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:42:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:43:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:43:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:45:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:45:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:46:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:47:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 15:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 15:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 15:52:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:52:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:53:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:53:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:54:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:55:01 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2021-12-31 15:55:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 15:57:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 15:59:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:00:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:01:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:03:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:08:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:08:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:09:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:09:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:09:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:09:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:09:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:09:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:10:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:10:32 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-31 16:10:33 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-12-31 16:11:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:11:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:11:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 16:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 16:16:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:17:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:17:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:17:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:17:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:17:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:18:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:18:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:18:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:18:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:18:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:19:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:19:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:19:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:20:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 16:20:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:23:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:24:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:25:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:29:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:29:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:29:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:30:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 16:30:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:30:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:30:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:31:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:31:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:33:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:33:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:35:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:35:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:39:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:39:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:40:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:40:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:40:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:40:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:40:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:41:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:41:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:42:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:42:24 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-31 16:42:24 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-31 16:42:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:42:26 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-12-31 16:42:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 16:42:26 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-31 16:42:27 --> 404 Page Not Found: Member/space
ERROR - 2021-12-31 16:42:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:28 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-12-31 16:42:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:42:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:42:28 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-31 16:42:29 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-31 16:42:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:29 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-31 16:42:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:29 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-31 16:42:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 16:42:30 --> 404 Page Not Found: Include/taglib
ERROR - 2021-12-31 16:42:30 --> 404 Page Not Found: Member/space
ERROR - 2021-12-31 16:42:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 16:42:30 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-31 16:42:30 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-31 16:42:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:31 --> 404 Page Not Found: Dede/templets
ERROR - 2021-12-31 16:42:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:42:33 --> 404 Page Not Found: Data/cache
ERROR - 2021-12-31 16:42:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 16:43:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:43:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:43:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 16:44:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 16:48:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:51:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 16:56:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:57:00 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-12-31 16:58:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 16:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:00:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:02:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 17:02:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 17:02:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 17:03:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 17:03:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:03:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:09:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:09:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 17:12:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 17:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 17:17:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 17:20:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 17:24:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:30:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:38:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 17:39:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:40:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 17:43:24 --> 404 Page Not Found: Vod-play-id-2324-sid-0-pid-9html/index
ERROR - 2021-12-31 17:43:35 --> 404 Page Not Found: Vod-play-id-2605-sid-0-pid-58html/index
ERROR - 2021-12-31 17:43:55 --> 404 Page Not Found: Vod-play-id-2703-sid-0-pid-5html/index
ERROR - 2021-12-31 17:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 17:46:34 --> 404 Page Not Found: English/index
ERROR - 2021-12-31 17:46:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:46:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:46:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:46:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:48:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 17:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 17:52:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 18:03:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 18:03:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 18:05:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 18:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 18:08:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 18:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 18:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 18:18:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 18:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 18:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 18:36:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 18:38:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 18:39:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 18:40:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 18:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 18:54:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 18:55:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 18:58:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 19:03:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 19:09:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 19:09:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 19:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 19:14:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 19:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 19:18:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 19:21:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 19:51:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 19:51:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 19:55:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 20:04:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 20:04:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 20:09:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 20:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 20:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 20:23:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 20:27:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 20:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 20:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 21:02:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 21:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 21:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 21:10:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 21:11:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 21:12:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 21:12:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 21:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 21:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 21:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 21:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 21:41:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 21:41:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 21:42:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 21:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 22:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 22:02:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 22:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 22:13:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 22:16:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 22:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 22:18:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 22:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 22:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 22:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 22:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 22:40:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 22:41:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 22:50:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 22:54:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 22:59:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 23:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 23:05:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 23:08:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 23:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 23:16:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 23:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 23:20:45 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-31 23:21:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-31 23:25:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-31 23:45:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-31 23:48:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-31 23:52:30 --> 404 Page Not Found: Robotstxt/index
