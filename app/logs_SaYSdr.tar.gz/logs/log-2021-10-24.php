<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-24 00:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 00:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 00:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 00:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 00:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 00:55:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 00:55:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 00:55:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 01:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 01:17:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 01:17:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 01:23:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 01:23:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 01:41:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 01:55:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 02:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 02:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 03:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 03:22:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 03:29:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 03:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 03:29:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 03:40:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 03:47:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 03:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 04:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 04:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 04:13:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 04:17:27 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-10-24 04:22:27 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-10-24 04:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 04:29:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 04:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 04:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 04:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 05:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 05:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 05:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 05:23:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 05:24:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 05:25:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 05:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 05:25:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 05:25:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 05:26:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 05:26:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 05:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 05:35:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 05:45:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 05:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 05:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 05:58:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 05:59:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 06:09:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 06:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 06:32:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 06:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 06:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 06:47:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 06:48:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 06:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 07:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 07:12:46 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-10-24 07:34:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 07:37:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-24 07:38:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 07:41:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 07:41:56 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-24 07:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 07:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 07:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 07:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 07:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 07:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 07:52:19 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-24 07:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 07:55:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 08:13:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 08:13:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 08:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 08:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 08:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 08:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 08:47:18 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-24 08:58:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 08:59:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 08:59:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 08:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 09:00:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 09:00:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 09:02:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 09:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 09:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 09:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 09:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 09:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 09:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 09:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 09:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 09:47:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 09:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 09:57:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 09:58:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 09:58:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 10:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 10:08:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 10:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:12:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:18:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:18:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:19:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:30:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:31:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:41:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:41:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:41:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 10:48:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:49:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 10:52:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:52:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 10:57:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 11:13:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 11:22:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 11:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 11:31:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 11:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 11:42:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 11:43:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 11:46:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 11:46:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 11:47:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 12:01:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 12:07:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 12:07:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 12:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 12:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 12:17:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 12:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 12:33:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 12:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 12:39:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 12:44:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 12:45:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 12:48:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 12:51:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 12:51:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 12:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 12:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 12:57:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 13:01:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 13:04:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 13:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 13:31:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 13:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 14:01:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 14:01:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 14:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 14:14:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-24 14:24:00 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:24:00 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:35:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 14:35:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 14:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 14:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 14:39:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:39:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:39:06 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:39:06 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:39:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:39:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:39:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:39:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:39:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:39:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:39:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:39:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-24 14:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 14:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 15:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 15:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 15:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 15:16:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 15:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 15:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 15:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 15:30:12 --> 404 Page Not Found: City/15
ERROR - 2021-10-24 15:36:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 15:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 15:48:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 15:49:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 15:49:46 --> 404 Page Not Found: City/1
ERROR - 2021-10-24 15:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 15:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 15:57:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 15:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 15:57:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 15:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 16:10:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 16:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 16:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 16:15:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:15:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:15:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 16:16:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 16:16:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:16:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:17:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:17:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:17:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:27:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 16:37:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 16:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 16:37:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 16:37:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 16:37:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 16:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 16:47:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 16:51:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 16:53:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:53:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 16:54:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 17:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 17:15:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 17:17:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 17:22:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 17:25:23 --> 404 Page Not Found: City/1
ERROR - 2021-10-24 17:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 17:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 17:45:00 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-10-24 17:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 18:04:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 18:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 18:12:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 18:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 18:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 18:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 18:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 18:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 18:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 18:54:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 18:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 19:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 19:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 19:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 19:18:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 19:32:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 19:34:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 19:34:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 19:39:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 19:44:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 19:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 19:59:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-24 20:09:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 20:10:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 20:17:57 --> 404 Page Not Found: 404/index.html
ERROR - 2021-10-24 20:17:57 --> 404 Page Not Found: 404/index.html
ERROR - 2021-10-24 20:26:18 --> 404 Page Not Found: English/index
ERROR - 2021-10-24 20:36:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 20:41:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 20:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 21:03:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 21:04:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 21:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 21:16:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 21:16:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 21:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 21:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 21:18:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 21:18:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 21:19:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 21:20:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 21:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 21:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 21:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 21:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 21:59:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 21:59:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 21:59:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 21:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 21:59:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 22:00:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 22:00:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 22:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 22:26:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 22:28:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 22:29:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 22:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 22:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 22:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 23:15:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 23:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-24 23:24:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 23:35:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 23:36:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-24 23:45:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-24 23:46:14 --> 404 Page Not Found: Robotstxt/index
