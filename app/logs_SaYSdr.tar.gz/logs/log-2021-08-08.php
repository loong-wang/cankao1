<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-08-08 00:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:00:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:01:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:02:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:02:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:02:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:02:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:02:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:03:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:03:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:03:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:04:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:05:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:05:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:05:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:05:50 --> 404 Page Not Found: 16/10000
ERROR - 2021-08-08 00:06:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:06:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:07:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:08:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:11:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:12:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:12:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:13:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:18:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:19:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 00:20:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:23:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:23:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:23:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:25:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:25:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:26:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:30:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:33:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:34:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:36:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:36:33 --> 404 Page Not Found: 10/10000
ERROR - 2021-08-08 00:36:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 00:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:39:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:41:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 00:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:43:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:43:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:43:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:44:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:45:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:45:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:47:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:47:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:47:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:50:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:50:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:50:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:51:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:52:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:52:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:53:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:56:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 00:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 00:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:00:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 01:01:09 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-08 01:01:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:01:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:03:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:04:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:04:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:04:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:05:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:05:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:05:55 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-08-08 01:06:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:08:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:09:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:09:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:10:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:11:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:12:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:12:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:12:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:12:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:12:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:12:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:12:53 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 01:12:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:13:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:13:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:14:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:14:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:14:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:15:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:15:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:15:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:15:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:15:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:15:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:15:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:15:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:16:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 01:16:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:16:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:16:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:16:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:16:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:17:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:18:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:20:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:20:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:22:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:22:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:22:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:24:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 01:24:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:25:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:25:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:25:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:26:32 --> 404 Page Not Found: City/15
ERROR - 2021-08-08 01:27:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:28:14 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 01:28:14 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 01:28:14 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-08 01:28:15 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-08 01:28:16 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-08 01:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:28:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:28:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:31:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:31:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:31:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:34:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:34:23 --> 404 Page Not Found: Env/index
ERROR - 2021-08-08 01:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:37:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:38:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 01:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:40:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:40:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:43:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:43:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:46:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:47:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:49:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:52:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:52:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:52:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:53:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:53:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:53:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:57:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 01:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:58:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:58:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 01:59:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:02:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:03:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:04:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:06:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:07:35 --> 404 Page Not Found: 16/10000
ERROR - 2021-08-08 02:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:09:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:09:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:09:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:10:27 --> 404 Page Not Found: User/index
ERROR - 2021-08-08 02:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:11:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:11:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:15:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:15:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:16:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:16:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:16:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:17:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:17:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:17:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:17:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:18:13 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-08 02:18:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:18:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:19:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:19:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:20:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:22:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:23:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:23:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 02:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:23:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:23:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:26:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:27:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 02:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:27:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 02:28:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:31:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 02:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:33:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:35:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:36:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:36:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:36:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:37:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:37:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:40:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:41:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:41:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:42:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:43:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:43:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:43:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:45:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:45:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:46:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:46:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:46:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:47:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:47:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:48:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:49:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:49:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:50:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:50:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:50:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:53:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:55:16 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-08 02:55:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:57:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:57:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:58:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 02:59:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:59:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 02:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:01:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:01:30 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 03:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:03:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:04:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:05:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:06:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:06:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:07:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:07:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:07:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:08:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:08:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:09:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:11:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:13:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:14:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:15:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:15:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:16:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:16:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:16:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:16:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:16:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:17:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:18:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:20:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:20:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:23:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:23:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:26:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:26:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:27:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:27:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:27:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:27:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:28:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 03:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:28:23 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-08-08 03:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 03:29:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:29:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:29:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:29:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:30:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:30:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:30:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:30:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:31:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:31:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 03:31:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:32:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:32:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:32:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:33:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:33:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:33:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:36:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:37:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:37:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 03:38:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:38:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:39:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:41:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 03:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:42:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:43:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:44:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:44:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:44:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:45:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:45:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:45:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:46:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:47:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 03:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:48:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:48:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:49:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:50:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:51:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:53:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:53:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:53:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:53:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:53:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:54:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 03:54:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:54:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:54:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:55:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:56:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:56:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 03:56:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:56:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:56:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:56:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:58:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 03:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 03:59:37 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-08 04:00:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:00:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:00:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-08-08 04:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:01:42 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-08 04:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:02:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:03:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:04:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:04:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:05:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:08:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:09:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:09:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:10:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:10:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:12:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:15:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:16:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:17:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:17:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:18:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:19:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:20:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:20:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:20:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:20:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 04:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:20:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:20:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:22:28 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-08-08 04:23:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:26:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:26:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:27:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:28:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:29:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:29:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:30:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:30:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:30:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:30:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:32:15 --> 404 Page Not Found: English/index
ERROR - 2021-08-08 04:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:32:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:32:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:34:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:34:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:34:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:36:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:36:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:36:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:38:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:38:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:38:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:38:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:39:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:39:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:39:33 --> 404 Page Not Found: Uc_server/robots.txt
ERROR - 2021-08-08 04:39:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:39:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:40:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:40:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:40:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:40:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:40:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:40:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:40:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:41:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:43:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:43:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:43:50 --> 404 Page Not Found: Uc_server/robots.txt
ERROR - 2021-08-08 04:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:46:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:48:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:52:05 --> 404 Page Not Found: City/10
ERROR - 2021-08-08 04:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:54:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:54:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:55:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:56:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:57:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:57:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:57:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:58:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 04:59:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 04:59:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:02:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:03:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:03:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 05:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:03:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:03:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:04:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:05:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:06:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:06:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 05:08:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:10:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:14:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:14:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:15:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:17:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:17:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:18:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:20:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:20:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:21:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:21:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:22:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:22:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:22:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:22:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:22:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:22:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:23:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:24:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:24:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:29:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:31:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:32:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:32:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:34:08 --> 404 Page Not Found: Login/index
ERROR - 2021-08-08 05:34:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:34:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:35:05 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-08 05:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:35:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:36:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:37:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:38:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:38:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:40:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:41:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:45:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:45:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:45:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:45:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:48:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:48:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:52:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:52:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:53:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:53:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:54:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:55:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:56:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:57:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:57:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 05:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 05:59:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:00:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:01:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:01:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:01:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:03:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:03:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:04:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:04:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:04:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:05:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:05:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:06:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:06:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:06:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:08:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:08:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:12:34 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-08 06:12:39 --> 404 Page Not Found: 16/10000
ERROR - 2021-08-08 06:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:13:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:14:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 06:14:19 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-08 06:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:14:55 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-08 06:14:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:14:59 --> 404 Page Not Found: Article/view
ERROR - 2021-08-08 06:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:15:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:15:27 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-08-08 06:15:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 06:16:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:16:04 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-08 06:16:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:17:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:17:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:17:18 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-08-08 06:17:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:17:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:17:53 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-08-08 06:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:19:04 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-08 06:19:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:19:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:20:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:20:18 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-08 06:20:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:20:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:20:59 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-08 06:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:21:38 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-08 06:22:08 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-08 06:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:22:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:22:41 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-08-08 06:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:23:14 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-08-08 06:23:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:24:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:25:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:29:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:31:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:31:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:32:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:35:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:36:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:41:05 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-08 06:41:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 06:41:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 06:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:41:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:42:02 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 06:42:02 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 06:42:02 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-08 06:42:02 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 06:42:02 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 06:42:02 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-08 06:42:02 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 06:42:02 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-08 06:42:02 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 06:42:02 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 06:42:02 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-08 06:42:03 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 06:42:03 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 06:42:03 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-08 06:42:03 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 06:42:03 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-08 06:42:03 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 06:42:03 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-08 06:42:04 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-08 06:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:43:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:46:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:47:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:47:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:48:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:49:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:49:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 06:50:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:51:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:53:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 06:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 06:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:02:02 --> 404 Page Not Found: Wp-admin/css
ERROR - 2021-08-08 07:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:04:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 07:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:05:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:06:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:06:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:06:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 07:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:08:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:09:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:13:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:21:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:23:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 07:24:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:26:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:28:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:31:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:33:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:40:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:42:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 07:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:42:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:43:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:46:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:50:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 07:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:51:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:52:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:55:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:57:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:57:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 07:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 07:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:00:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:00:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:00:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:00:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:00:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 08:00:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:01:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:01:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:01:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:01:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:01:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:01:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:01:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:01:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:01:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:03:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:03:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:03:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:03:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:03:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:04:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:05:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:05:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:06:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:06:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:07:57 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-08 08:07:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:09:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:09:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:11:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:14:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:14:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:14:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:14:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:15:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:15:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:15:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:15:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 08:17:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:17:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:17:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:17:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:17:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:19:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:21:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:21:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:23:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:24:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:27:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:27:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:27:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:28:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:28:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:28:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:29:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:29:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:29:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:29:45 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-08 08:29:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:29:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:29:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:29:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:29:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:30:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:30:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:30:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:30:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:30:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 08:31:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:31:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:31:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:34:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 08:34:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:34:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:38:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:39:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:41:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:41:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:42:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 08:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:42:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:43:55 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-08-08 08:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:44:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:44:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:45:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:45:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:46:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:46:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:49:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:49:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:52:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:52:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:53:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:54:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:55:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:55:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:55:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:55:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 08:56:15 --> 404 Page Not Found: Uc_server/robots.txt
ERROR - 2021-08-08 08:56:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:56:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 08:58:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:58:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 08:59:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:00:16 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-08-08 09:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:00:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:00:37 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-08-08 09:00:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 09:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:03:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:05:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:07:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:07:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:07:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:08:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:10:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:11:47 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 09:11:47 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-08 09:11:48 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 09:11:49 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 09:11:49 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-08 09:11:49 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 09:11:49 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-08 09:11:49 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-08 09:11:49 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-08 09:11:49 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-08 09:11:49 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 09:11:49 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 09:11:49 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 09:11:49 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-08 09:11:50 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-08 09:12:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:13:27 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-08-08 09:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:13:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:13:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:15:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:17:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:17:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:19:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:24:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:25:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:28:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:28:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:29:51 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-08-08 09:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:31:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:31:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:32:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 09:33:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 09:33:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 09:33:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:36:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:36:59 --> 404 Page Not Found: City/10
ERROR - 2021-08-08 09:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:38:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:40:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:41:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:42:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:44:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:45:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:46:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:46:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:48:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:49:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:49:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:52:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:52:38 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-08-08 09:52:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:53:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:53:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:53:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:54:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:54:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:54:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:54:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:55:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:55:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:56:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:57:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:57:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 09:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:58:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 09:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 09:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:00:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:04:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 10:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 10:04:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:05:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:09:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:12:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:12:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:13:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:14:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:16:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:20:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:21:42 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-08 10:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:30:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:30:53 --> 404 Page Not Found: City/index
ERROR - 2021-08-08 10:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:31:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 10:31:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 10:31:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 10:31:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 10:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:40:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 10:41:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 10:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:42:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 10:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:45:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 10:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:46:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:46:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:48:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 10:48:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:50:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 10:50:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:53:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:53:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:55:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 10:55:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:56:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 10:56:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:57:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:57:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 10:58:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 10:58:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 10:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 10:59:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 10:59:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 10:59:50 --> 404 Page Not Found: English/index
ERROR - 2021-08-08 11:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:03:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:07:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 11:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:10:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:15:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 11:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:16:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 11:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:17:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:18:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 11:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:22:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 11:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:26:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:26:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:26:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 11:27:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:28:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 11:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:30:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:33:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 11:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:34:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:35:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 11:36:36 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2021-08-08 11:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:36:41 --> 404 Page Not Found: Phpinfo/index
ERROR - 2021-08-08 11:36:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 11:36:43 --> 404 Page Not Found: Awsyml/index
ERROR - 2021-08-08 11:36:45 --> 404 Page Not Found: Envbak/index
ERROR - 2021-08-08 11:36:49 --> 404 Page Not Found: Aws/credentials
ERROR - 2021-08-08 11:36:53 --> 404 Page Not Found: Config/aws.yml
ERROR - 2021-08-08 11:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:39:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 11:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:41:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 11:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:44:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 11:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:47:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 11:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:47:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:49:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:52:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 11:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 11:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:56:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:56:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 11:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 11:58:07 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-08 11:59:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:00:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:08:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:13:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:14:23 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-08 12:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:18:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:18:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:19:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:20:00 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-08-08 12:20:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:22:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:24:51 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-08-08 12:25:32 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-08-08 12:26:07 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-08 12:26:48 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-08-08 12:27:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:27:33 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-08-08 12:28:15 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-08 12:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 12:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:28:53 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-08-08 12:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:31:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 12:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:31:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:36:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 12:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:37:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:37:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:39:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:39:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:41:19 --> 404 Page Not Found: Article/view
ERROR - 2021-08-08 12:41:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 12:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:44:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:44:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:47:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:48:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:49:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:50:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:53:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:54:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:54:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:54:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:55:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:57:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:58:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:58:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 12:59:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 12:59:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 12:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:01:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 13:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:03:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:05:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 13:06:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:07:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:09:35 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 13:10:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:11:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:14:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:15:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 13:16:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:17:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:17:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:18:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:19:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:23:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:25:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:25:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:25:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:25:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:25:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:26:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:27:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:28:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:28:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:28:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:28:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:29:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:29:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:30:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:30:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:30:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:30:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:30:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:30:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:32:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:32:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:32:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:32:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:33:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:33:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:33:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:34:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:34:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:34:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:34:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:34:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:35:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:35:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:36:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:36:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:36:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:37:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:37:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:39:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:39:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:40:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:40:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:40:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:40:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:40:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:40:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 13:40:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:40:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:40:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:41:07 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-08-08 13:41:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:41:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:41:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:42:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:42:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:44:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:44:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:45:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:45:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:48:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:48:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:48:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:49:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 13:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:49:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:50:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:50:16 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-08-08 13:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:50:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:52:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:52:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:52:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 13:53:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 13:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:53:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:54:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:54:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:54:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:54:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:55:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:56:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:56:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:57:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:57:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 13:58:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:58:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:59:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 13:59:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 13:59:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:00:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:00:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:00:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:01:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:01:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:02:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:02:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:02:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:03:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:03:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:03:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:03:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:04:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:04:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:04:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 14:05:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:05:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:05:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:05:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:05:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 14:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:06:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:06:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:07:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:08:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:08:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:09:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:09:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:09:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:09:36 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-08-08 14:09:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:10:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:10:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:10:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:11:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:12:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:13:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:14:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:19:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:22:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:23:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:24:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:25:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:27:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:28:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:30:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:30:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:31:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:33:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:34:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:35:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:35:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:37:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:38:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:39:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:41:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:43:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:43:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:44:00 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-08-08 14:44:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:44:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:45:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:46:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:47:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:47:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:48:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:48:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:48:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:48:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:49:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:49:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:50:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:50:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:53:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:53:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:54:03 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 14:54:03 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 14:54:03 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-08 14:54:03 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 14:54:03 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 14:54:03 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-08 14:54:03 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 14:54:03 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-08 14:54:03 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 14:54:04 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-08 14:54:05 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-08 14:54:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:55:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:55:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:55:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:55:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:56:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:56:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:56:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:57:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:57:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:57:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:58:07 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-08-08 14:58:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:58:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 14:59:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 14:59:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:00:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 15:00:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 15:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:00:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:00:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:01:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:01:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:01:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:01:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:02:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:02:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:03:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:04:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:06:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:06:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:06:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:06:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:07:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:07:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:07:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:08:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:08:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:09:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:09:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:10:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:11:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:11:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:11:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:11:29 --> 404 Page Not Found: City/10
ERROR - 2021-08-08 15:11:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:11:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:12:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:12:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:13:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:16:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:16:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:16:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:17:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:17:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:17:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:17:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:18:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:19:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:19:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 15:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:19:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:20:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:20:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:21:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:21:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:21:34 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-08 15:21:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:22:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:23:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:23:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:23:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:24:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:24:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:25:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:25:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:25:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:25:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:27:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:27:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:27:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:28:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:28:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:18 --> 404 Page Not Found: City/1
ERROR - 2021-08-08 15:29:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:29:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:30:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:30:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:32:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:33:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:33:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:34:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:34:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:34:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:35:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:35:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:35:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:36:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:36:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:38:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:38:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:38:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:39:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:39:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:39:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:39:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:40:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:40:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:40:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:41:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:42:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:42:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:42:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 15:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:43:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 15:43:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 15:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:45:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:50:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:51:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:51:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 15:52:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:53:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 15:57:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:01:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:02:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:02:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 16:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 16:03:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:03:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:03:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:03:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:04:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:04:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:04:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:05:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:05:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:05:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:06:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:06:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:07:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:07:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:07:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:09:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:09:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:11:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:12:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:12:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:12:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:12:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:14:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:14:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:15:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:16:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:16:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:16:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:16:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:17:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:17:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:17:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:17:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:18:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:18:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:19:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:21:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:21:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:22:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 16:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:24:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:25:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:26:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:26:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:27:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:27:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:27:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:27:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:27:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:28:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:29:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:29:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:29:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:29:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:30:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:31:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:31:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:31:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:31:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:31:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 16:31:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:32:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 16:32:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:32:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:32:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:33:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:33:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:34:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:34:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:34:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:36:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:37:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:37:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:37:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:37:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:37:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:38:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:39:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:40:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:40:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:40:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:41:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:41:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 16:41:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:42:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:42:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:43:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:43:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:45:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:46:30 --> 404 Page Not Found: English/index
ERROR - 2021-08-08 16:46:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:47:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:47:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:47:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:47:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:50:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:50:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:51:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:51:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:51:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 16:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:53:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 16:53:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 16:53:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:54:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:54:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:55:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:55:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:57:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:57:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:58:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 16:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 16:59:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 17:00:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:01:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 17:03:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:03:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:04:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 17:04:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:06:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:07:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:07:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:07:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:08:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:08:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:08:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:08:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:08:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:09:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:10:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:11:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:11:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:12:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:12:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:12:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:12:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:12:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:13:47 --> 404 Page Not Found: Config/getuser
ERROR - 2021-08-08 17:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:15:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:16:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:17:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:19:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:21:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:22:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:22:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:23:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 17:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:25:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:26:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:27:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:29:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:29:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:30:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:33:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:33:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 17:33:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:35:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:36:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:37:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:37:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:37:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:39:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:39:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:41:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:41:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:41:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:42:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:42:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:42:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:42:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:42:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:42:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:43:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:43:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:43:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:43:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:43:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:43:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:44:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:44:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:44:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:44:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:44:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:44:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:44:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:44:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:44:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:44:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:44:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:44:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:45:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:45:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:46:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 17:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:47:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 17:47:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 17:48:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:48:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:51:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:51:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:51:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:51:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 17:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:53:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 17:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:53:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:53:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:54:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:54:31 --> 404 Page Not Found: Management/Login.Asp
ERROR - 2021-08-08 17:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:56:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:57:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 17:57:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:58:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:59:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 17:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:00:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:00:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:01:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:02:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:02:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:02:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:02:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 18:03:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:04:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:04:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:05:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:06:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:06:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:08:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:08:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:08:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:09:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:09:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:10:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 18:10:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:11:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:12:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:12:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:12:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 18:13:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:13:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:14:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:14:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:14:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:15:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:17:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:19:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:19:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:21:22 --> 404 Page Not Found: Env/index
ERROR - 2021-08-08 18:21:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:23:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 18:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:25:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:25:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:25:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:25:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:26:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:26:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:27:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:28:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:29:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:29:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:29:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:30:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:30:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:31:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:32:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:32:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:33:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:33:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:33:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:34:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:34:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:34:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:34:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:35:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:35:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:36:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:36:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:37:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:37:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:37:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:37:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 18:38:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:38:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:38:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:39:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 18:39:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:39:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:39:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:39:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 18:39:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:40:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:41:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:41:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:41:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:41:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:42:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:42:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 18:42:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 18:43:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:43:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:43:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 18:43:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:44:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 18:45:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:47:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:48:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:48:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:48:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:48:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:48:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:48:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:49:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:49:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 18:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:49:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:50:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:51:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:52:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:52:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:52:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:53:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:53:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:53:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:54:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:54:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:54:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:54:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:54:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:54:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:54:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:55:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:56:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:57:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:57:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:57:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:58:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:58:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:59:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 18:59:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:59:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:59:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 18:59:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:00:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:00:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:00:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:01:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:01:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:01:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:01:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:01:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:01:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:01:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:02:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:02:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:02:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:02:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:03:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:04:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:04:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:04:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:04:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:04:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:05:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:05:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 19:05:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:05:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:05:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:06:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:06:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:07:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:07:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:07:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:07:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:07:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:08:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:08:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:08:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:09:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:09:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:09:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:09:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:09:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:10:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:10:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:10:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:10:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:11:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:11:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:12:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:12:36 --> 404 Page Not Found: City/1
ERROR - 2021-08-08 19:12:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:12:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:13:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:13:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:13:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:13:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:13:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:14:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:14:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:15:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:15:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:15:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:15:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:15:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:15:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:16:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:16:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:16:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:16:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:16:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:17:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:17:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:18:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:18:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:18:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:18:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:19:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:19:44 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-08-08 19:19:47 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-08-08 19:19:47 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-08-08 19:19:48 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-08-08 19:19:48 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-08-08 19:19:48 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-08-08 19:19:49 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-08-08 19:19:49 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-08-08 19:19:49 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-08-08 19:19:49 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-08-08 19:19:50 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-08-08 19:19:50 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-08-08 19:19:50 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-08-08 19:19:51 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-08-08 19:19:51 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-08-08 19:19:51 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-08-08 19:19:51 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-08-08 19:20:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:20:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:21:14 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-08-08 19:21:15 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-08-08 19:21:15 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-08-08 19:21:15 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-08-08 19:21:15 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-08-08 19:21:16 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-08-08 19:21:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:21:16 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-08-08 19:21:16 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-08-08 19:21:17 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-08-08 19:21:17 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-08-08 19:21:17 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-08-08 19:21:17 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-08-08 19:21:18 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-08-08 19:21:18 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-08-08 19:21:18 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-08-08 19:21:19 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-08-08 19:21:19 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-08-08 19:21:19 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-08-08 19:21:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:21:21 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-08-08 19:21:22 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-08-08 19:21:22 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-08-08 19:21:22 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-08-08 19:21:23 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-08-08 19:21:23 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-08-08 19:21:23 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-08-08 19:21:24 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-08-08 19:21:24 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-08-08 19:21:24 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-08-08 19:21:24 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-08-08 19:21:25 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-08-08 19:21:25 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-08-08 19:21:25 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-08-08 19:21:26 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-08-08 19:21:26 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-08-08 19:21:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:21:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:22:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:22:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:22:22 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-08-08 19:22:23 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-08-08 19:22:23 --> 404 Page Not Found: Web/wp-includes
ERROR - 2021-08-08 19:22:23 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-08-08 19:22:23 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-08-08 19:22:24 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-08-08 19:22:24 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-08-08 19:22:24 --> 404 Page Not Found: 2018/wp-includes
ERROR - 2021-08-08 19:22:25 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-08-08 19:22:25 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-08-08 19:22:25 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-08-08 19:22:25 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-08-08 19:22:26 --> 404 Page Not Found: Media/wp-includes
ERROR - 2021-08-08 19:22:26 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-08-08 19:22:26 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-08-08 19:22:27 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-08-08 19:22:27 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-08-08 19:22:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 19:22:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:24:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:24:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:24:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 19:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:24:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:25:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:27:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 19:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:28:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 19:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:29:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:30:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:30:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:30:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 19:31:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:31:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:32:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:32:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:33:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:34:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:34:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:35:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:36:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:37:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:38:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:38:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:39:19 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-08 19:39:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:41:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 19:41:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:43:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:43:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:43:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:43:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:43:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:44:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:45:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:47:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:49:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:51:02 --> 404 Page Not Found: Article/view
ERROR - 2021-08-08 19:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:53:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:53:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 19:53:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:54:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:54:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 19:54:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 19:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 19:55:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:55:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 19:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:56:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 19:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 19:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:00:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:02:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:04:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:11:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:15:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:16:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:20:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:21:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:21:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:22:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:23:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:24:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 20:24:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 20:24:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 20:24:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 20:25:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 20:25:23 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 20:25:23 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-08 20:25:23 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 20:25:23 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 20:25:23 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-08 20:25:23 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 20:25:23 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-08 20:25:24 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 20:25:24 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 20:25:24 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-08 20:25:24 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 20:25:24 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 20:25:24 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-08 20:25:24 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 20:25:24 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 20:25:25 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 20:25:26 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 20:25:26 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-08 20:25:26 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-08 20:25:26 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-08 20:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:26:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:26:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 20:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:31:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 20:32:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:35:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:35:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:35:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:35:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:36:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:37:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:38:09 --> 404 Page Not Found: Search/likea
ERROR - 2021-08-08 20:38:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 20:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:38:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 20:39:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:40:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 20:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:41:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:42:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 20:43:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 20:43:44 --> 404 Page Not Found: 2021/index
ERROR - 2021-08-08 20:43:44 --> 404 Page Not Found: 2021/index
ERROR - 2021-08-08 20:44:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:45:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 20:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:45:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:47:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 20:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:47:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 20:47:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 20:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:50:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 20:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:51:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 20:51:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:53:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:56:49 --> 404 Page Not Found: Feed/index
ERROR - 2021-08-08 20:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 20:59:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:59:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 20:59:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:01:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:06:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:06:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:07:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 21:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:08:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:08:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 21:08:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:09:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 21:10:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 21:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:13:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 21:13:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 21:13:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 21:13:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:13:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 21:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:18:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:19:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:21:15 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 21:21:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:22:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 21:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:23:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:26:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:27:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:27:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 21:27:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:30:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:30:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 21:30:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 21:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:32:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:33:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:34:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:36:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:36:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 21:36:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 21:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:37:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 21:37:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 21:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:38:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 21:38:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 21:38:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:39:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:41:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:42:06 --> 404 Page Not Found: 1/10000
ERROR - 2021-08-08 21:42:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:46:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:46:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:47:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:48:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:49:37 --> 404 Page Not Found: Shell/index
ERROR - 2021-08-08 21:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:54:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:58:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:59:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 21:59:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 21:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:00:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:02:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 22:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:04:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:05:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:07:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:09:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:10:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:10:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:11:54 --> 404 Page Not Found: Install/index.php.bak
ERROR - 2021-08-08 22:13:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:14:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:16:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:20:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-08-08 22:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:22:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:23:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:25:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:26:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:27:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:28:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:28:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:29:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:31:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:31:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:31:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:33:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:34:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:39:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:40:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:40:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:41:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:41:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:41:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:41:52 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 22:41:52 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 22:41:52 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-08-08 22:41:52 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-08-08 22:41:52 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 22:41:52 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-08-08 22:41:52 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-08-08 22:41:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:41:52 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-08-08 22:41:52 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 22:41:52 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-08-08 22:41:53 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-08-08 22:41:54 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-08-08 22:41:54 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-08-08 22:41:54 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-08-08 22:41:54 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-08-08 22:41:54 --> 404 Page Not Found: Webrar/index
ERROR - 2021-08-08 22:41:54 --> 404 Page Not Found: Webzip/index
ERROR - 2021-08-08 22:41:54 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-08-08 22:42:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:42:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:44:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:44:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:44:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:45:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:46:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:46:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 22:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:47:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:47:48 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-08-08 22:48:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:48:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:49:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:49:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:50:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:51:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:51:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:54:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:54:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:56:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:57:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:58:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 22:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 22:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:00:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:00:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:01:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:01:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:02:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:02:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:03:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:03:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-08-08 23:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:04:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:04:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:06:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:07:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:09:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:09:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:10:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 23:10:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:11:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:11:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:12:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:13:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:14:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 23:14:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:15:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:15:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 23:15:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:15:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:16:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:16:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:17:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:18:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:18:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:18:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:18:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:18:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:18:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:18:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:20:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:21:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:23:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:23:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:25:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-08-08 23:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:26:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:28:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:30:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:31:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:33:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:33:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:34:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:37:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:37:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:38:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:38:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:39:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:40:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:41:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:41:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:41:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:42:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:42:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:43:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:43:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:45:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:48:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:50:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:50:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:50:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:51:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:51:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:53:09 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-08-08 23:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:54:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 23:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:55:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-08-08 23:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:56:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-08-08 23:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:56:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:58:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-08-08 23:59:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
