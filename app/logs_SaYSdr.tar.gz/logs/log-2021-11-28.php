<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-28 00:09:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:09:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:09:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:10:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:10:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:10:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:11:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:11:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:12:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 00:17:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 00:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 00:27:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:33:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:33:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:33:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:34:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:34:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:34:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:34:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:34:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:34:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:35:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:35:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:35:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:35:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:35:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:36:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:36:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 00:42:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:46:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 00:50:23 --> 404 Page Not Found: City/1
ERROR - 2021-11-28 00:50:31 --> 404 Page Not Found: City/1
ERROR - 2021-11-28 00:50:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 00:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 00:52:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 00:52:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 00:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 00:52:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 00:55:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 00:58:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 01:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 01:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 01:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 01:02:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 01:04:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:04:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:04:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:04:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:04:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:04:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:04:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:05:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:05:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:05:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:06:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:06:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:10:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:14:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:18:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 01:22:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:26:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:31:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:33:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:33:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:34:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:34:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:35:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:38:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:42:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:46:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 01:50:45 --> 404 Page Not Found: City/10
ERROR - 2021-11-28 01:50:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 01:54:53 --> 404 Page Not Found: 404/index.html
ERROR - 2021-11-28 01:54:53 --> 404 Page Not Found: 404/index.html
ERROR - 2021-11-28 01:54:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 01:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 01:58:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 02:02:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 02:03:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 02:03:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 02:04:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 02:04:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 02:05:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 02:07:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 02:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 02:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 02:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 02:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 02:34:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 02:35:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 02:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 02:37:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 02:37:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 02:37:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 02:37:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 02:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 02:37:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 02:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 02:38:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 02:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 02:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 02:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 03:02:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 03:03:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 03:03:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 03:03:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 03:04:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 03:05:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 03:05:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 03:06:22 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-28 03:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 03:21:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 03:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 03:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 03:26:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 03:32:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 03:33:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 03:33:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 03:33:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 03:33:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 03:33:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 03:33:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 03:44:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 03:51:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 03:53:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 03:53:49 --> 404 Page Not Found: City/18
ERROR - 2021-11-28 03:57:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 04:07:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 04:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 04:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 04:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 04:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 04:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 04:33:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 04:33:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 04:33:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 04:34:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 04:34:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 04:35:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 04:35:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 04:35:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 04:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 04:38:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 04:39:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 04:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 04:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 04:56:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 05:10:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 05:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 05:25:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 05:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 05:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 05:40:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 05:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 05:41:09 --> 404 Page Not Found: City/1
ERROR - 2021-11-28 05:57:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 05:58:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 05:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 05:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 05:59:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 06:00:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:01:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:01:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:02:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 06:02:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 06:03:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:04:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:05:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:06:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:07:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:08:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:08:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 06:11:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 06:11:46 --> 404 Page Not Found: Vod-play-id-2671-sid-0-pid-221html/index
ERROR - 2021-11-28 06:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 06:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 06:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 06:23:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 06:34:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 06:34:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 06:36:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 06:37:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 06:39:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 06:39:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 06:40:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 06:40:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 06:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 06:41:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 06:45:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 06:48:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 06:56:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 06:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 06:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 07:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 07:06:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 07:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 07:14:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 07:15:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 07:15:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 07:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 07:16:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 07:16:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 07:17:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 07:34:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:34:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:34:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:34:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:35:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:35:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:35:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:36:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:37:24 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-11-28 07:38:41 --> Severity: Warning --> Missing argument 1 for Xinxi::show() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 97
ERROR - 2021-11-28 07:38:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:38:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:40:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 07:45:52 --> 404 Page Not Found: City/10
ERROR - 2021-11-28 07:46:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 07:52:48 --> 404 Page Not Found: City/15
ERROR - 2021-11-28 07:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 07:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 08:04:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 08:10:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 08:11:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 08:11:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 08:15:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 08:15:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 08:15:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 08:37:29 --> 404 Page Not Found: Wp-content/plugins
ERROR - 2021-11-28 08:37:29 --> 404 Page Not Found: WordPress/wp-content
ERROR - 2021-11-28 08:39:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 08:40:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 08:55:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 08:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 08:58:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:03:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:04:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:04:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:04:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:04:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:04:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:05:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:06:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:06:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:06:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:07:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:07:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:09:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 09:10:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:11:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:13:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:15:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 09:15:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 09:22:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:22:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 09:25:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 09:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 09:33:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:33:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:33:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:34:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:34:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:34:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:34:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:34:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:34:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:34:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:34:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:34:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:34:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:34:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:35:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 09:35:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:35:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:35:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:35:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:35:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:35:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:36:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:36:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:36:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:36:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:36:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:37:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:37:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:37:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:37:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 09:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 09:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 09:46:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 09:48:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 09:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:56:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:56:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:56:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:57:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:57:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 09:58:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 10:03:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 10:04:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 10:04:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 10:04:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 10:05:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 10:07:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 10:07:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 10:08:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 10:14:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 10:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 10:26:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 10:29:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 10:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 10:34:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 10:36:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 10:36:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 10:36:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 10:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 10:36:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 10:36:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 10:37:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 10:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 10:40:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 10:41:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 10:45:05 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-11-28 10:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 10:58:53 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-28 11:00:33 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-28 11:05:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 11:09:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 11:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 11:12:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 11:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 11:21:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 11:27:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 11:27:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 11:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 11:38:02 --> 404 Page Not Found: Files/File
ERROR - 2021-11-28 11:40:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 11:40:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 11:40:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 11:40:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 11:41:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 11:42:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 11:43:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 11:50:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 11:50:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 11:51:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 11:54:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 11:59:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 11:59:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 11:59:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 11:59:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 11:59:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 12:00:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:00:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 12:00:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:00:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 12:01:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:01:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:01:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 12:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 12:01:28 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-28 12:01:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:02:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:03:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 12:04:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:04:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 12:05:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 12:05:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 12:06:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 12:07:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:07:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:07:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:09:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:10:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:10:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:10:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:11:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:14:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:15:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 12:17:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:17:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:21:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 12:23:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:24:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 12:27:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:31:44 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-11-28 12:34:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:34:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:36:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 12:37:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 12:39:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 12:40:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 12:41:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:41:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-28 12:41:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 12:42:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 12:43:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 12:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 12:44:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:47:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:47:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:48:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:50:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:51:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:51:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 12:52:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:52:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:52:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:53:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 12:54:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:54:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 12:54:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:56:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 12:58:42 --> 404 Page Not Found: City/1
ERROR - 2021-11-28 13:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 13:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 13:04:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:06:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:06:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:06:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:06:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:07:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:07:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:08:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:08:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:08:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 13:11:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:11:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 13:13:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 13:13:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 13:14:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 13:15:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:15:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 13:15:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 13:15:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 13:16:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 13:17:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:18:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 13:19:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 13:21:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:21:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:22:06 --> Severity: Warning --> Missing argument 1 for Taocan::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 181
ERROR - 2021-11-28 13:24:07 --> 404 Page Not Found: City/10
ERROR - 2021-11-28 13:24:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:27:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 13:30:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:34:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 13:34:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 13:34:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:34:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:36:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:36:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:36:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:37:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:38:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 13:40:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 13:41:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:44:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:47:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:51:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 13:57:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 13:57:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 14:02:01 --> 404 Page Not Found: Images/Thumb.asp
ERROR - 2021-11-28 14:02:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 14:06:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 14:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 14:09:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-28 14:12:54 --> 404 Page Not Found: _ignition/execute-solution
ERROR - 2021-11-28 14:12:55 --> 404 Page Not Found: Script/index
ERROR - 2021-11-28 14:12:55 --> 404 Page Not Found: Login/index
ERROR - 2021-11-28 14:12:55 --> 404 Page Not Found: Jenkins/login
ERROR - 2021-11-28 14:12:55 --> 404 Page Not Found: Manager/html
ERROR - 2021-11-28 14:12:57 --> 404 Page Not Found: Users/sign_in
ERROR - 2021-11-28 14:15:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 14:16:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-28 14:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 14:25:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 14:25:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 14:25:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 14:25:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 14:25:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 14:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 14:28:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 14:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 14:28:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 14:30:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 14:30:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 14:34:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 14:34:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 14:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 14:37:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 14:38:17 --> 404 Page Not Found: 16/all
ERROR - 2021-11-28 14:38:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 14:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 14:40:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 14:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 14:44:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 14:46:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 14:47:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 14:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 14:53:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 14:54:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 15:02:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 15:02:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 15:02:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 15:05:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 15:06:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:06:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:07:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 15:07:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:07:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:07:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:07:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:07:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:08:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:08:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:13:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 15:19:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:22:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 15:22:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 15:24:46 --> 404 Page Not Found: City/index
ERROR - 2021-11-28 15:26:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 15:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 15:28:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 15:29:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 15:29:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 15:30:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 15:31:01 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-11-28 15:34:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 15:36:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 15:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 15:45:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 15:47:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 15:52:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 16:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 16:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 16:05:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:06:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:07:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:07:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 16:07:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:08:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:08:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:08:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:09:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:09:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:09:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 16:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 16:09:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 16:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:10:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 16:10:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:11:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 16:13:36 --> 404 Page Not Found: City/16
ERROR - 2021-11-28 16:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 16:32:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 16:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 16:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:42:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 16:44:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 16:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 16:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 16:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 16:50:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-28 16:56:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 17:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 17:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 17:14:29 --> 404 Page Not Found: Sitemap25296html/index
ERROR - 2021-11-28 17:16:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 17:16:57 --> 404 Page Not Found: Webeditor/uploadfile
ERROR - 2021-11-28 17:17:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:19:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:20:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 17:20:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 17:28:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 17:29:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 17:29:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:30:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:32:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:33:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 17:33:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 17:33:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 17:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 17:34:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 17:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 17:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 17:36:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 17:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 17:37:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 17:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 17:38:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 17:40:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 17:43:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:43:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:43:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 17:44:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:44:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:44:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:44:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:44:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:44:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:45:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 17:54:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-28 17:56:25 --> 404 Page Not Found: Gift-tickethtml/index
ERROR - 2021-11-28 18:02:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-28 18:02:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 18:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 18:05:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 18:07:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 18:09:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-28 18:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 18:19:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:22:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 18:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 18:25:39 --> 404 Page Not Found: Sitemap46231html/index
ERROR - 2021-11-28 18:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 18:33:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-28 18:35:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 18:35:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:36:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 18:38:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 18:39:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:40:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 18:41:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:41:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:41:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:41:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:42:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:43:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:43:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:43:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:43:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:43:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:43:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:44:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:44:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 18:44:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:44:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:44:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:44:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:45:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:45:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:45:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:45:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:45:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 18:46:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:46:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 18:47:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:50:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 18:52:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 18:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:52:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:53:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:53:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 18:55:39 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-11-28 18:55:42 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-11-28 18:59:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 19:00:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 19:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 19:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 19:07:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 19:10:23 --> 404 Page Not Found: City/16
ERROR - 2021-11-28 19:11:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 19:15:52 --> 404 Page Not Found: Images/class.asp
ERROR - 2021-11-28 19:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 19:28:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 19:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 19:35:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 19:36:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 19:36:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 19:36:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 19:37:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 19:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 19:38:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 19:38:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 19:39:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 19:39:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 19:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 19:52:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-28 19:54:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-28 19:58:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 19:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 20:01:27 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-28 20:01:27 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-28 20:03:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 20:10:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 20:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 20:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 20:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 20:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 20:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 20:30:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 20:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 20:59:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 20:59:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:03:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:03:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:03:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:04:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:04:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:04:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:05:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 21:06:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:07:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:08:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:08:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:08:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:09:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:09:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:10:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:10:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:10:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:10:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:11:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:11:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:11:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:12:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:13:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:13:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 21:21:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:22:24 --> 404 Page Not Found: City/16
ERROR - 2021-11-28 21:22:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:22:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 21:26:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:26:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:27:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:28:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 21:33:59 --> 404 Page Not Found: WEB_VMS/LEVEL15
ERROR - 2021-11-28 21:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 21:44:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 21:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 21:47:59 --> 404 Page Not Found: City/2
ERROR - 2021-11-28 21:48:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 22:01:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 22:01:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 22:01:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 22:01:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 22:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 22:09:44 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-28 22:17:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-28 22:19:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-28 22:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 22:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 22:30:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 22:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 22:38:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 22:39:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 22:44:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 22:53:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 22:53:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 22:56:48 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-11-28 22:56:49 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-11-28 22:57:56 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-11-28 23:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 23:06:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 23:06:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:07:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 23:09:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:09:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-28 23:09:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:09:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:10:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:10:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:11:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:11:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:12:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:12:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 23:12:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:15:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-28 23:22:31 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-11-28 23:23:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:24:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:25:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:26:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:35:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 23:35:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-28 23:37:52 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-11-28 23:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:58:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-28 23:59:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
