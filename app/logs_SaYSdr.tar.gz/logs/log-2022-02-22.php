<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-22 00:00:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:01:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:03:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:04:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:09:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 00:10:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:11:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:11:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:11:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:11:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:11:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:16:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:18:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:20:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:25:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:26:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:32:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:32:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:33:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:33:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:34:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:35:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:36:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:36:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:38:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:40:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:47:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 00:47:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:49:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:49:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:52:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:53:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:54:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:55:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:56:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 00:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:02:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 01:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:03:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 01:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:04:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:08:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 01:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:16:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 01:17:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 01:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:25:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:26:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:26:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:27:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 01:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:29:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:30:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:36:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:36:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:37:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 01:37:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:37:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:44:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:47:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:48:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:48:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:51:22 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2022-02-22 01:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:53:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:54:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:55:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:56:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:58:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:58:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 01:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:00:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 02:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:01:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:02:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:02:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:03:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:06:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 02:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:06:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:08:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:10:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:14:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:15:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:17:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:19:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:20:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:21:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:35:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 02:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 02:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 02:57:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 03:08:19 --> 404 Page Not Found: App/views
ERROR - 2022-02-22 03:08:19 --> 404 Page Not Found: App/views
ERROR - 2022-02-22 03:08:19 --> 404 Page Not Found: App/views
ERROR - 2022-02-22 03:11:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 03:12:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 03:20:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 03:21:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 03:27:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 03:28:23 --> 404 Page Not Found: Kefu/index
ERROR - 2022-02-22 03:32:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 03:35:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 03:40:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 03:40:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 03:42:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 03:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 04:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 04:24:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 04:29:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 04:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 05:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 05:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 05:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 05:21:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 05:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 05:31:18 --> 404 Page Not Found: Indexphp/index
ERROR - 2022-02-22 05:31:18 --> 404 Page Not Found: Indexphp/index
ERROR - 2022-02-22 05:41:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 05:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 05:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 05:58:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 06:09:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 06:09:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 06:10:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 06:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 06:15:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 06:21:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 06:24:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 06:25:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 06:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:33:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:33:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:33:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:34:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:34:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:34:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:34:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:35:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:37:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:40:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:42:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 06:43:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 06:47:01 --> 404 Page Not Found: Indexphp/index
ERROR - 2022-02-22 06:47:01 --> 404 Page Not Found: Indexphp/index
ERROR - 2022-02-22 06:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 06:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 06:51:34 --> 404 Page Not Found: Sitemap16600html/index
ERROR - 2022-02-22 06:58:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 07:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 07:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 07:24:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 07:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 07:27:21 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2022-02-22 07:28:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 07:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 07:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 07:37:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 07:50:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 07:52:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 07:55:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 07:57:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:01:04 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-22 08:03:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:03:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:04:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:04:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 08:08:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 08:10:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:10:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:14:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:16:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 08:16:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:17:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 08:19:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:20:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:22:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:22:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:23:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:27:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:29:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 08:29:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 08:29:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:30:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:31:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:33:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:36:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:37:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:38:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:39:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:42:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:44:35 --> 404 Page Not Found: Article/view
ERROR - 2022-02-22 08:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 08:46:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 08:49:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:49:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 08:50:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 08:51:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 08:51:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:54:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:56:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 08:56:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:58:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:58:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:58:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 08:59:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:00:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:01:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:01:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 09:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 09:08:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:08:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:08:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:08:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:09:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 09:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 09:14:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 09:17:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:18:03 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-22 09:19:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 09:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 09:35:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:36:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:36:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 09:36:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:36:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:37:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:40:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:40:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:41:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 09:41:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:42:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:42:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:42:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 09:44:45 --> 404 Page Not Found: Article/view
ERROR - 2022-02-22 09:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 09:59:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 10:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 10:08:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 10:08:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 10:08:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 10:09:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 10:11:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 10:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 10:19:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 10:19:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 10:21:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 10:23:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 10:26:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 10:26:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 10:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 10:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 10:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 10:32:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 10:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 10:41:56 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-22 10:42:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 10:44:34 --> 404 Page Not Found: Users/sign_in
ERROR - 2022-02-22 10:47:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 10:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 10:47:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 10:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 10:58:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 11:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 11:05:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:06:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 11:06:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:06:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:09:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:09:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:09:41 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-22 11:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 11:10:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:10:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:10:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:11:24 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-22 11:12:09 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-22 11:12:21 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2022-02-22 11:15:55 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-22 11:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 11:16:51 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-22 11:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 11:17:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 11:17:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 11:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:18:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:19:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 11:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 11:22:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 11:24:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:26:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:26:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:27:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:33:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 11:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 11:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 11:42:21 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2022-02-22 11:43:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:43:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 11:43:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 11:47:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:48:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 11:48:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:49:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 11:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 11:50:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 11:50:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 11:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 11:52:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:55:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 11:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 12:05:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 12:13:00 --> 404 Page Not Found: English/index
ERROR - 2022-02-22 12:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 12:16:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 12:16:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 12:22:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 12:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 12:50:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 12:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 12:52:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 12:54:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 12:54:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 12:54:41 --> 404 Page Not Found: Cdn-cgi/trace
ERROR - 2022-02-22 12:55:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 12:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 13:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 13:02:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 13:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 13:10:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 13:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 13:32:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 13:35:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 13:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 13:42:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 13:48:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 13:48:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 13:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 13:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 14:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 14:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 14:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 14:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 14:13:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 14:13:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 14:13:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 14:14:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 14:15:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 14:23:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 14:27:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 14:48:30 --> 404 Page Not Found: City/17
ERROR - 2022-02-22 14:48:31 --> 404 Page Not Found: City/17
ERROR - 2022-02-22 14:48:31 --> 404 Page Not Found: City/17
ERROR - 2022-02-22 14:48:31 --> 404 Page Not Found: City/17
ERROR - 2022-02-22 14:48:31 --> 404 Page Not Found: City/17
ERROR - 2022-02-22 14:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 14:50:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 14:51:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 14:52:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 14:52:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 14:52:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 14:52:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 14:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 14:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 15:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 15:03:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 15:03:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 15:04:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 15:06:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 15:06:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 15:06:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 15:07:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 15:07:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 15:07:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 15:07:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 15:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 15:13:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 15:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 15:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 15:38:05 --> 404 Page Not Found: 1/10000
ERROR - 2022-02-22 15:44:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 15:52:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 15:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 15:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 15:56:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 15:58:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 15:58:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 15:59:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:02:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:02:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 16:02:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:03:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:03:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:04:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:04:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:04:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:05:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:05:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:06:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:09:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:09:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:10:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:10:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:11:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:11:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:13:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:13:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:13:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:14:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:14:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:15:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 16:18:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 16:19:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:19:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:19:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:20:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:20:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:20:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:20:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:20:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:21:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:21:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:22:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 16:23:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:24:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:24:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:25:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:25:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:26:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:26:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:29:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:29:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 16:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 16:38:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 16:44:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:45:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:46:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 16:46:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 16:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 16:48:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:48:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:56:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 16:57:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:01:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:02:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:04:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 17:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 17:11:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 17:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 17:21:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:22:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:27:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:32:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:38:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 17:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 17:40:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 17:40:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 17:40:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 17:42:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 17:42:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 17:42:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:44:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 17:44:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 17:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:46:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 17:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 17:52:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 17:53:13 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-22 17:55:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 17:57:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 17:58:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:58:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:59:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 17:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 18:01:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:01:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 18:03:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:05:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 18:05:15 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2022-02-22 18:05:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:07:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:09:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:10:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:13:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:14:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:16:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:16:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:16:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:17:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 18:18:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 18:18:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:19:34 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-22 18:19:34 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-22 18:20:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:22:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:24:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:29:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:31:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:33:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 18:42:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 18:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 18:43:08 --> 404 Page Not Found: Sitemap58535html/index
ERROR - 2022-02-22 18:45:50 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-22 18:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 18:56:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 18:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 18:57:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 19:02:56 --> 404 Page Not Found: Ask/102
ERROR - 2022-02-22 19:04:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 19:07:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:11:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:15:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:18:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:18:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:20:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:21:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 19:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 19:23:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:23:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:23:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:23:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:23:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:24:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:24:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:24:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:24:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:24:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:26:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:26:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:27:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:28:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:28:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:29:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:30:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:31:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:31:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:32:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 19:32:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 19:32:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 19:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 19:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 19:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 19:37:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 19:38:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 19:38:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 19:38:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 19:40:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 19:40:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 19:41:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 19:43:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 19:47:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 19:50:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 19:51:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 19:52:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 20:00:43 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2022-02-22 20:00:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 20:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 20:08:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 20:08:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 20:12:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 20:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 20:31:12 --> 404 Page Not Found: Previewdo/index
ERROR - 2022-02-22 20:37:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 20:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 20:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 20:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 20:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 21:02:42 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-22 21:11:06 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-22 21:16:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 21:20:57 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-22 21:20:57 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-22 21:20:57 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-22 21:20:57 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-22 21:20:57 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-22 21:20:57 --> 404 Page Not Found: Inc/config.asp
ERROR - 2022-02-22 21:20:57 --> 404 Page Not Found: Config/AspCms_Config.asp
ERROR - 2022-02-22 21:24:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 21:34:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 21:39:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 21:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 21:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 21:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 22:00:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:00:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 22:07:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 22:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 22:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 22:20:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 22:22:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 22:29:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:30:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:30:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:30:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:34:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:34:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 22:35:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:35:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:35:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:36:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:36:59 --> 404 Page Not Found: City/10
ERROR - 2022-02-22 22:37:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:37:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:37:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:37:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:38:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:38:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 22:39:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-22 22:39:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:39:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:41:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:41:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:42:34 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2022-02-22 22:43:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 22:47:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 22:55:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:55:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 22:56:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 22:56:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-22 22:59:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 23:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 23:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 23:12:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 23:16:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 23:16:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 23:16:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 23:16:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 23:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 23:29:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 23:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 23:43:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 23:49:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 23:50:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-22 23:50:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 23:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 23:53:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-22 23:56:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-22 23:59:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
