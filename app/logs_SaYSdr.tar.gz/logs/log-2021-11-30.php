<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-30 00:09:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 00:18:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 00:28:56 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-11-30 00:39:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-30 00:43:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 01:08:12 --> 404 Page Not Found: City/15
ERROR - 2021-11-30 01:21:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 01:38:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 01:40:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 01:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 01:56:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:01:06 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-11-30 02:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:14:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 02:14:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 02:23:39 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-11-30 02:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:31:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 02:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:41:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 02:42:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 02:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:42:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 02:42:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 02:42:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 02:42:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 02:43:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 02:43:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 02:43:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 02:43:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 02:43:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 02:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 02:56:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 03:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 03:05:28 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-30 03:05:32 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-30 03:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 03:10:18 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-11-30 03:18:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 03:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 03:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 03:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 03:32:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 03:40:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 03:46:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 03:47:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 03:57:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-30 03:58:08 --> 404 Page Not Found: City/index
ERROR - 2021-11-30 04:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 04:01:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 04:01:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 04:02:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 04:05:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 04:05:35 --> 404 Page Not Found: Article/index
ERROR - 2021-11-30 04:09:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 04:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 04:11:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 04:20:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 04:44:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-30 04:58:18 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-11-30 05:00:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-30 05:06:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 05:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 05:31:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 05:44:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 05:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 05:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 06:09:56 --> 404 Page Not Found: Cssasp/index
ERROR - 2021-11-30 06:15:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 06:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 06:27:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 06:27:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 06:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 06:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 06:51:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 06:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 06:57:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 06:58:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 07:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 07:30:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 07:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 07:37:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 07:38:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 07:41:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 07:41:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 07:43:36 --> 404 Page Not Found: Sdk/index
ERROR - 2021-11-30 07:43:36 --> 404 Page Not Found: Text4041638229416/index
ERROR - 2021-11-30 07:43:36 --> 404 Page Not Found: Evox/about
ERROR - 2021-11-30 07:43:36 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-11-30 07:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 07:44:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 07:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 07:51:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 08:09:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 08:09:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 08:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 08:23:48 --> 404 Page Not Found: Ziliao/Logout.asp
ERROR - 2021-11-30 08:23:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 08:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 08:25:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 08:28:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 08:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 08:32:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 08:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 08:34:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 08:39:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 08:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 08:42:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 08:42:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 08:47:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 08:47:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 08:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 08:59:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 09:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 09:30:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 09:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 09:37:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 09:37:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 09:40:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 09:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 10:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 10:16:25 --> 404 Page Not Found: Page/images
ERROR - 2021-11-30 10:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 10:27:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 10:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 10:37:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 10:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 10:47:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 10:47:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 10:53:21 --> 404 Page Not Found: Files/File
ERROR - 2021-11-30 10:57:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 10:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 10:58:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 10:59:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:00:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:01:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:01:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:02:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:02:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:02:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:02:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:03:01 --> 404 Page Not Found: Article/view
ERROR - 2021-11-30 11:03:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:05:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 11:07:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:08:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:08:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 11:08:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 11:09:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:10:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:11:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:11:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:13:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-30 11:15:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:15:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:16:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:17:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:20:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:25:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:26:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:26:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:30:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:31:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 11:31:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 11:31:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:32:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:36:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:37:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:37:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:38:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:38:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:39:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 11:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 11:42:03 --> 404 Page Not Found: Generate/Vote
ERROR - 2021-11-30 11:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 11:56:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 11:56:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 11:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 12:00:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:01:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:06:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:07:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:07:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 12:08:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:14:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:15:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 12:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 12:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 12:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 12:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 12:25:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:25:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:26:09 --> 404 Page Not Found: Stkjwcfhlbaueqo/index
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Web/wap
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/config
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: :8088/index
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/config
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: admin/Event/uploadfile
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Pub/getQhDynamic
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Manifestjson/index
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Pc/tools
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Home/tools
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Application/Home
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Step3asp/index
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/Game
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: AppApi/NotLoggedInApi
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Xmlb/index
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/home
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: V2/start
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/user
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/v1
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/site
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Notice/unreadMsgCount
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/apps
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/v2
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Sys/setting
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/user
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Login/index.asp
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/site
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: History_codeshtml/index
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/login
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Backend/index
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: ChannelHandle/index
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: OpenApi/getHelpInfo
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/shares
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Api/sms
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Default_drawnoticeshtml/index
ERROR - 2021-11-30 12:26:10 --> 404 Page Not Found: Js/preload
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: Service/index
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: Home/login
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: Api/product
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: User/login.html
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: Wallet/index
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: Dock/system
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: H5/login
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: Shujuku/index.asp
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: En/autonews.html
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: Ws/index
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: Api/index
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: Api/getapi
ERROR - 2021-11-30 12:26:11 --> 404 Page Not Found: :8013/index
ERROR - 2021-11-30 12:26:12 --> 404 Page Not Found: Mobile/index.html
ERROR - 2021-11-30 12:26:12 --> 404 Page Not Found: Api/pc
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Api/message
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Index/index
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Index/index
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Web/api
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Views/bank
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Index/index
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Index/index
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Api/nimcc
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Index/pcpage
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Superadmin/lock.lock
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Mobile/loan
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Mobile/index
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Mobile/api
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: M/trial.asp
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Jsonpublic/selectAddtion.asp
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Bin-release/update_descriptor_1.xml
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Index/index
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Resource/ui_config
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Image/delImage
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Login/index
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Loan/SubmitLogin
ERROR - 2021-11-30 12:26:13 --> 404 Page Not Found: Static/appAdd.jsp
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Api/Index
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Index/index
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Trade/quote
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: User/Reg
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Index/lotteryHall.do
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Wx/ZFpass.asp
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Case/index
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Fei1asp/index
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Business/t-ec-info
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Api/uploads
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: admin/Auth/login
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Ajax/index_b_trends
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Index/login
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Platform/passport
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Html/wechat
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Index/chat
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Api/index
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: V1/management
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Melody/api
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Gethmaspx/index
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Native/getStationInfo.do
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Api/exclude
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: View/game
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Template/Home
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Submitasp/index
ERROR - 2021-11-30 12:26:14 --> 404 Page Not Found: Verificationasp/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Dd/order.asp
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Serverhtml/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Control/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Manager/top.asp
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: _login/in
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Gov/manager
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: _vti_pvt/structure.cnf
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: 11txt/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Db/admin_yly.sql
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Aw010072asp/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Public/1.txt
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Msky/v1.0
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: 1asp/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Guanyuhtml/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Detaila/purchaseorder.asp
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Loginasp/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: %23m%23a%23n%23a%23g%23e%23r_/index.asp
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Ht/top.asp
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Wap/tixing.asp
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Networdasp/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Manager/index.asp
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Save2asp/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: T3/Account
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Txt_index_dna_cntxt/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Web_managera/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: 123/stat_login.asp
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Submit-tbasp/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Onlinerunasp/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Ye1asp/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Erroasp/index
ERROR - 2021-11-30 12:26:15 --> 404 Page Not Found: Vwaitasp/index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Jiankonghtm/index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Instructions/toWait.do
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: S1asp/index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Error3asp/index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Postasp/index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Submitasp/index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Zhucheasp/index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Plus/guestbook
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Code/cxk_xym.asp
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Admin/Index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: User/step1.asp
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: %E4%BD%BF%E7%94%A8%E8%AF%B4%E6%98%8Etxt/index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Cxkcasp/index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Captchaasp/index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Api/currency
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Api/index
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Api/zhenren
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Auth/web
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Static/wap
ERROR - 2021-11-30 12:26:16 --> 404 Page Not Found: Api/index
ERROR - 2021-11-30 12:26:17 --> 404 Page Not Found: Api/chat
ERROR - 2021-11-30 12:26:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:28:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:29:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 12:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 12:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 12:40:23 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-11-30 12:41:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:47:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 12:50:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:52:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:53:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:53:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:54:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 12:55:06 --> 404 Page Not Found: City/2
ERROR - 2021-11-30 13:04:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 13:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 13:09:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 13:11:12 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-11-30 13:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 13:26:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 13:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 13:35:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 13:43:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 13:44:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 13:56:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 13:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 14:03:53 --> 404 Page Not Found: City/16
ERROR - 2021-11-30 14:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 14:10:34 --> 404 Page Not Found: Images/login.asp
ERROR - 2021-11-30 14:11:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 14:17:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 14:26:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 14:26:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 14:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 14:30:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 14:40:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:40:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:41:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:41:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:41:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:41:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:41:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 14:42:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 14:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 14:44:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 14:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 14:47:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 14:48:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 14:48:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:50:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:51:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:51:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 14:52:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:52:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:52:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:53:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 14:53:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:00:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:01:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:01:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:01:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:02:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:02:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:02:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:03:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:03:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:04:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 15:17:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:18:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 15:18:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 15:18:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 15:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 15:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 15:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 15:31:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:32:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 15:32:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 15:32:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 15:35:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:35:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:35:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:44:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:45:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:46:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:46:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:47:47 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-11-30 15:48:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:50:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:52:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:52:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 15:53:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 16:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 16:09:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 16:12:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 16:12:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 16:13:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 16:13:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 16:13:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 16:16:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 16:17:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 16:24:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 16:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 16:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 16:37:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 16:43:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 16:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 16:54:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 16:55:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 16:55:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 17:00:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 17:05:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 17:06:02 --> 404 Page Not Found: City/index
ERROR - 2021-11-30 17:10:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:10:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:11:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:12:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:13:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:13:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:15:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:15:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:16:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:16:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:16:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:16:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:16:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:17:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:18:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:19:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:19:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:19:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:19:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:19:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:19:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:19:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:19:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:25:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 17:29:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 17:31:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 17:32:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 17:33:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 17:34:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 17:35:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 17:36:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 17:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 17:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:05:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 18:08:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 18:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:26:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 18:26:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 18:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:36:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 18:36:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 18:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 18:43:50 --> 404 Page Not Found: Sitemap46231html/index
ERROR - 2021-11-30 18:44:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 19:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 19:04:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 19:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 19:24:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:25:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:26:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:26:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:27:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:27:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 19:27:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:28:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:28:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:29:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 19:29:44 --> 404 Page Not Found: Sitemap93816html/index
ERROR - 2021-11-30 19:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 19:40:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 19:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 19:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 19:44:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 19:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 19:59:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 19:59:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:00:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:01:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:02:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:03:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:04:41 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 20:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 20:08:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-30 20:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:12:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:12:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:12:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 20:13:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 20:25:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 20:25:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 20:28:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 20:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 20:42:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 20:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 20:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 20:47:14 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-30 20:47:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 20:51:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 20:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 20:59:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 21:00:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 21:10:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 21:20:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 21:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 21:24:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 21:30:57 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-30 21:31:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 21:31:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 21:31:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 21:32:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 21:33:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 21:33:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 21:35:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 21:43:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 21:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 21:47:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 21:53:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 22:03:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 22:04:03 --> 404 Page Not Found: Vod-play-id-2749-sid-0-pid-106html/index
ERROR - 2021-11-30 22:04:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 22:04:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 22:04:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 22:04:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 22:05:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 22:05:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 22:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 22:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 22:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 22:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 22:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 22:23:17 --> 404 Page Not Found: Order/index
ERROR - 2021-11-30 22:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 22:33:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 22:33:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 22:34:13 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-11-30 22:36:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 22:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 22:40:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 22:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 22:42:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 22:49:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 22:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 22:54:32 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 22:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 23:09:05 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-30 23:11:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 23:13:52 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-11-30 23:15:42 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-11-30 23:27:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 23:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 23:35:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 23:35:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 23:35:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 23:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-30 23:48:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 23:52:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 23:52:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 23:52:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-30 23:54:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-30 23:56:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-30 23:57:00 --> 404 Page Not Found: Robotstxt/index
