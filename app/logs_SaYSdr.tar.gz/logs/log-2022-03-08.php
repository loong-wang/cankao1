<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-08 00:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:09:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:10:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:10:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:10:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:13:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:15:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:19:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:21:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:23:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 00:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 00:25:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:25:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:25:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:26:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 00:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:29:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 00:29:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 00:32:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 00:33:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 00:33:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:33:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:35:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:36:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:36:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:36:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:38:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:38:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:39:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:44:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:45:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:45:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:45:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:47:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:48:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:50:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:53:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:53:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 00:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:55:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:57:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:57:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 00:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:00:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:00:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:01:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:01:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:02:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:05:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 01:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:06:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:07:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:07:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 01:08:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:12:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 01:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:13:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 01:14:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:16:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:18:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:20:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:20:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 01:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:23:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 01:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:27:50 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 01:28:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:35:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:37:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 01:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:44:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:44:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:46:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:48:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:56:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 01:58:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:04:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:13:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:21:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 02:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:23:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:38:03 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 02:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:47:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:52:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:52:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:56:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 02:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 02:59:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 02:59:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 03:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:03:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:08:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 03:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:12:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:19:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 03:19:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 03:20:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 03:20:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 03:20:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 03:22:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 03:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:48:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 03:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 03:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 04:04:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 04:14:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 04:15:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 04:16:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 04:17:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 04:19:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 04:19:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 04:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 04:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 04:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 04:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 04:54:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 04:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 05:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 05:23:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 05:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 05:36:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 05:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 05:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 06:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 06:10:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 06:10:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 06:16:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 06:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 06:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 06:22:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:26:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:28:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:30:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:32:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:33:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 06:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 06:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 06:42:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:42:34 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2022-03-08 06:44:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 06:48:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:50:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:51:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 06:51:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 06:51:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 06:52:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 06:52:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:56:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 06:58:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:00:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:02:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:10:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:10:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:13:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 07:14:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:18:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:20:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:22:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:24:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:26:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:30:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:34:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:35:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:38:16 --> 404 Page Not Found: 4563923asp/index
ERROR - 2022-03-08 07:39:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:43:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:45:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:49:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:51:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:51:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:55:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 07:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 07:57:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:00:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:00:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:01:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:02:20 --> 404 Page Not Found: Cdn-cgi/trace
ERROR - 2022-03-08 08:05:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:07:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 08:11:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:13:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:15:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:18:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:19:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 08:21:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:25:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:27:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:29:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:33:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:35:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 08:37:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:41:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:41:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:45:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:47:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:47:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 08:47:42 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-03-08 08:49:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:51:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:53:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:53:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 08:59:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 09:00:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 09:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 09:02:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 09:04:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 09:06:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 09:06:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 09:07:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 09:07:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 09:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 09:18:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 09:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 09:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 09:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 09:30:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 09:31:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 09:36:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 09:38:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 09:41:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 09:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 09:49:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 09:51:07 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2022-03-08 09:51:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 09:51:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 10:11:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 10:14:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 10:16:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 10:17:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 10:18:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 10:18:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 10:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 10:37:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 10:39:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 10:40:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 10:44:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 10:44:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 10:45:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 10:45:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 10:48:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 10:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 10:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 11:03:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 11:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 11:08:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 11:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 11:13:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 11:22:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 11:22:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 11:29:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 11:29:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 11:31:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 11:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 11:34:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 11:47:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 11:47:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 11:50:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 11:52:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 11:53:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 12:00:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 12:05:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 12:11:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 12:16:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 12:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 12:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 12:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 12:34:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 12:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 12:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 12:49:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 12:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 13:05:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:06:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:06:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:08:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 13:09:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:10:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:10:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:10:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:11:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:12:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:12:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:13:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:13:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:13:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:14:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:14:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:14:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:14:46 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-03-08 13:15:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:15:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:16:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:16:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:17:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:17:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:18:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:18:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:20:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:21:07 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-03-08 13:21:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:21:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:31:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 13:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 13:39:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:42:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:45:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:45:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:45:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:45:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:45:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:45:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:45:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:45:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 13:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 13:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 13:52:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:53:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:54:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 13:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 13:56:42 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-03-08 13:56:43 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-03-08 13:56:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:56:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 13:56:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 13:56:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 13:56:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 13:56:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 13:56:46 --> 404 Page Not Found: Include/taglib
ERROR - 2022-03-08 13:56:50 --> 404 Page Not Found: Member/space
ERROR - 2022-03-08 13:56:50 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 13:56:51 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 13:56:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 13:56:54 --> 404 Page Not Found: Data/cache
ERROR - 2022-03-08 13:56:54 --> 404 Page Not Found: Data/cache
ERROR - 2022-03-08 13:56:54 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 13:56:54 --> 404 Page Not Found: Dede/templets
ERROR - 2022-03-08 13:56:54 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 13:56:57 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 13:56:57 --> 404 Page Not Found: Data/cache
ERROR - 2022-03-08 13:56:58 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-08 14:08:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 14:09:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 14:10:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 14:10:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 14:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 14:13:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 14:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 14:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 14:18:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 14:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 14:31:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 14:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 14:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 14:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 14:55:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 14:55:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 14:55:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 14:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 14:56:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 14:56:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 15:09:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 15:11:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 15:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 15:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 15:22:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 15:32:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 15:33:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 15:34:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 15:35:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 15:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 15:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 15:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 15:57:35 --> 404 Page Not Found: Ask/1
ERROR - 2022-03-08 16:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 16:01:44 --> 404 Page Not Found: Ask/51
ERROR - 2022-03-08 16:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 16:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 16:15:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 16:15:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 16:16:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 16:25:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 16:26:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 16:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 16:34:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 16:37:01 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-03-08 16:40:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 16:50:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 16:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 16:52:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 16:53:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 16:53:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 16:53:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 16:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 16:53:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 16:56:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 17:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 17:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 17:05:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 17:05:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 17:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 17:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 17:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 17:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 17:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 17:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 17:22:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 17:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 17:41:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 17:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 17:44:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 17:45:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 17:45:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 17:51:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 17:59:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:01:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:01:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:02:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:02:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:02:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:02:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:02:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:02:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:02:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:02:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:02:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:02:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 18:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 18:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 18:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 18:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 18:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 18:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 18:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 18:31:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 18:37:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:42:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:42:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 18:43:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:43:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:43:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:44:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:44:33 --> 404 Page Not Found: Ask/66
ERROR - 2022-03-08 18:44:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:44:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:44:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:45:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:45:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:45:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:45:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 18:45:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 18:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:46:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 18:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 19:01:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:03:41 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-03-08 19:06:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 19:10:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 19:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 19:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 19:25:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:27:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:33:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:34:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:44:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 19:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:45:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 19:48:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:48:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:49:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:50:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 19:52:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 19:55:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 19:58:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 20:00:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 20:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 20:02:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 20:02:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 20:02:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 20:05:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 20:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 20:09:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 20:12:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 20:12:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 20:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 20:15:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 20:15:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 20:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 20:19:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 20:21:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 20:30:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 20:31:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 20:38:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 20:38:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 20:39:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 20:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 20:42:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 20:42:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 20:43:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 20:45:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 20:46:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 20:47:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 20:55:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 20:58:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 21:01:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 21:06:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 21:11:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 21:13:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 21:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 21:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 21:28:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 21:35:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 21:37:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 21:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 21:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 21:46:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 21:51:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 21:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 21:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 21:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 22:00:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 22:01:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 22:04:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 22:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 22:14:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 22:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 22:20:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 22:31:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 22:41:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-08 22:46:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 22:49:42 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2022-03-08 22:52:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 22:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 22:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 22:53:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 22:53:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 22:54:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 22:55:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 22:55:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 22:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 22:56:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 22:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 22:58:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 23:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 23:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 23:06:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 23:11:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 23:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 23:14:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-08 23:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 23:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-08 23:54:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 23:56:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 23:57:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 23:57:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-08 23:59:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
