<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-18 00:00:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 00:02:43 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2022-02-18 00:10:12 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-18 00:10:12 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-18 00:10:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 00:10:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 00:10:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 00:10:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 00:10:12 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 00:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 00:10:13 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-18 00:10:13 --> 404 Page Not Found: Member/space
ERROR - 2022-02-18 00:10:13 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 00:10:13 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 00:10:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 00:10:14 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 00:10:14 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 00:10:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 00:10:15 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-18 00:10:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 00:10:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 00:10:15 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 00:10:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 00:17:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 00:18:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 00:19:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 00:21:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 00:21:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 00:24:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 00:28:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 00:30:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 00:43:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 00:45:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 00:48:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 00:53:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 00:54:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 00:55:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 00:58:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 01:00:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 01:00:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 01:03:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 01:03:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 01:23:19 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2022-02-18 01:28:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 01:38:07 --> 404 Page Not Found: 16/all
ERROR - 2022-02-18 01:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 01:48:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 01:51:11 --> 404 Page Not Found: City/1
ERROR - 2022-02-18 01:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 02:01:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 02:13:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 02:16:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 02:16:03 --> 404 Page Not Found: Member/Login
ERROR - 2022-02-18 02:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 02:17:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 02:22:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 02:24:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 02:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 02:26:53 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-18 02:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 02:30:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 02:30:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 02:32:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 02:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 02:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 02:52:12 --> 404 Page Not Found: Staff/index
ERROR - 2022-02-18 02:52:12 --> 404 Page Not Found: Tos/index
ERROR - 2022-02-18 02:52:12 --> 404 Page Not Found: Sharehtml/index
ERROR - 2022-02-18 03:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 03:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 03:08:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 03:09:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 03:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 03:09:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 03:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 03:16:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 03:26:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 03:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:05:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:16:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:29:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:49:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 04:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 04:58:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 04:58:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 05:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 05:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 05:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 05:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 05:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 05:25:27 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-18 05:25:28 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-18 05:25:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 05:25:28 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 05:25:28 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 05:25:28 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 05:25:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 05:25:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 05:25:29 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-18 05:25:29 --> 404 Page Not Found: Member/space
ERROR - 2022-02-18 05:25:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 05:25:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 05:25:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 05:25:30 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 05:25:30 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 05:25:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 05:25:31 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-18 05:25:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 05:25:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 05:25:31 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 05:25:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 05:29:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 05:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 05:32:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 05:32:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 05:34:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 05:40:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 05:50:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 05:50:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 05:53:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 05:53:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 05:54:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 05:57:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 05:57:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 05:57:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:00:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:00:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:02:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 06:02:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 06:04:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:04:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:04:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:07:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 06:14:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:14:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:17:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:18:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:20:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:21:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 06:23:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:24:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:26:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:27:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:29:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:31:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:33:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:35:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:36:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:37:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:40:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:40:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 06:41:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:44:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:44:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:46:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:48:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:50:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:52:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:52:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:54:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:56:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 06:58:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 06:59:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 07:01:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 07:03:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 07:05:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 07:12:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 07:23:06 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-18 07:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 07:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 07:41:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 07:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 07:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 08:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 08:02:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 08:04:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 08:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 08:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 08:11:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:14:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 08:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 08:18:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:19:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 08:19:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:19:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:19:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:20:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 08:20:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:21:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 08:21:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:22:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 08:22:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 08:23:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:23:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 08:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 08:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 08:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 08:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 09:02:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 09:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 09:18:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 09:19:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 09:20:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 09:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 09:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 09:29:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 09:36:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 09:37:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 09:39:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 09:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 09:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 09:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 09:48:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 09:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 09:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 09:56:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 09:56:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 09:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 09:58:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 09:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 10:00:14 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-18 10:01:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 10:01:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 10:01:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 10:01:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 10:04:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 10:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 10:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 10:14:24 --> 404 Page Not Found: Cn/Productsa.asp
ERROR - 2022-02-18 10:20:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:21:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:23:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:23:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 10:31:01 --> 404 Page Not Found: City/index
ERROR - 2022-02-18 10:31:05 --> 404 Page Not Found: City/index
ERROR - 2022-02-18 10:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 10:40:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:40:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:41:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:41:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:43:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:43:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:45:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:45:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 10:46:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:48:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 10:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 10:52:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:52:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:53:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 10:59:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 11:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 11:06:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 11:13:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 11:19:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 11:25:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 11:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 11:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 11:36:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 11:37:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 11:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 11:40:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 11:43:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 11:43:52 --> 404 Page Not Found: City/16
ERROR - 2022-02-18 11:49:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 11:52:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 11:53:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 11:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 11:58:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 11:59:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:00:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:01:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:03:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:04:08 --> 404 Page Not Found: App/views
ERROR - 2022-02-18 12:04:09 --> 404 Page Not Found: App/views
ERROR - 2022-02-18 12:04:09 --> 404 Page Not Found: App/views
ERROR - 2022-02-18 12:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:07:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 12:07:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:07:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:08:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:08:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:08:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:08:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:09:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 12:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:10:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:10:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:14:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:15:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:15:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 12:15:52 --> 404 Page Not Found: App/views
ERROR - 2022-02-18 12:15:52 --> 404 Page Not Found: App/views
ERROR - 2022-02-18 12:15:52 --> 404 Page Not Found: App/views
ERROR - 2022-02-18 12:22:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 12:23:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:24:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 12:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:30:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 12:33:10 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-18 12:33:10 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-18 12:33:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 12:33:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 12:33:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 12:33:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 12:33:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 12:33:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 12:33:14 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-18 12:33:15 --> 404 Page Not Found: Member/space
ERROR - 2022-02-18 12:33:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 12:33:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 12:33:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 12:33:15 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 12:33:19 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 12:33:20 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 12:33:23 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-18 12:33:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 12:33:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 12:33:23 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 12:33:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 12:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 12:41:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 12:41:43 --> 404 Page Not Found: Login/index
ERROR - 2022-02-18 12:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 12:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:57:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:57:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 12:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 13:01:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 13:03:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:03:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:04:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:04:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:08:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:14:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 13:16:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:16:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:18:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:19:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:19:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:19:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:19:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:19:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:20:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 13:22:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 13:22:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:23:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:23:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:23:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:24:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:27:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 13:28:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:28:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 13:29:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:29:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:30:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 13:32:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:33:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:33:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:33:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 13:36:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:37:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:37:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 13:39:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 13:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 13:40:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:40:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 13:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 13:57:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 14:02:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:05:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:11:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:12:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:15:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 14:18:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:18:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:22:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:23:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:25:30 --> 404 Page Not Found: Previewdo/index
ERROR - 2022-02-18 14:26:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:29:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 14:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 14:35:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:35:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 14:36:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:36:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:36:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:39:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:51:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:52:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 14:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 14:56:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 14:57:01 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2022-02-18 15:06:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:07:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:07:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:08:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:09:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:09:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:10:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:10:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:10:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:10:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:10:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:11:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:11:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:11:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:13:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 15:20:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:20:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:20:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:20:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:21:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:21:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:21:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:22:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:22:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:23:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:23:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:23:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:24:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:25:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:26:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:26:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:26:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:26:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:33:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:36:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 15:39:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 15:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 15:46:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 15:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 15:59:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 15:59:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 16:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 16:06:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 16:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 16:11:32 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:22:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 16:23:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 16:24:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 16:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 16:29:23 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-18 16:29:23 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-18 16:29:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 16:29:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:29:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:29:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:29:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 16:29:24 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-18 16:29:26 --> 404 Page Not Found: Member/space
ERROR - 2022-02-18 16:29:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:29:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:29:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 16:29:27 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 16:29:27 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 16:29:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:29:31 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-18 16:29:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:29:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:29:31 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-18 16:29:34 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 16:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 16:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 16:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 16:59:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 16:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 16:59:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 17:02:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 17:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 17:15:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 17:15:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 17:16:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 17:16:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 17:22:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:22:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:22:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 17:34:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 17:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 17:37:55 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 17:40:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:41:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 17:45:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:48:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:48:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:49:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:49:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:50:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:51:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:52:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:56:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:57:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 17:58:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 18:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 18:05:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 18:06:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 18:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 18:13:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 18:14:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 18:14:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 18:14:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 18:16:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 18:18:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 18:19:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-18 18:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 18:22:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 18:26:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 18:28:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 18:34:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 18:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 18:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 18:42:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 18:44:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 18:48:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 18:55:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 18:56:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 18:57:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:02:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 19:04:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:19:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:20:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:20:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:22:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 19:31:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:32:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 19:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 19:43:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 19:44:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:45:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:45:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 19:54:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:56:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 19:56:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:05:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:07:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:12:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:24:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:25:49 --> 404 Page Not Found: Management/Login.Asp
ERROR - 2022-02-18 20:28:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:29:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 20:31:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 20:33:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:34:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:34:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:34:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 20:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 20:36:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 20:36:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:38:32 --> Severity: error --> 11111 test 1
ERROR - 2022-02-18 20:39:19 --> Severity: error --> 11111 test 1
ERROR - 2022-02-18 20:40:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 20:42:35 --> Severity: error --> 11111 test 1
ERROR - 2022-02-18 20:43:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 20:45:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:46:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:47:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:49:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:49:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:53:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:53:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:53:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:53:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:53:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:54:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 20:59:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 21:01:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 21:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 21:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 21:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 21:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 21:17:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 21:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 21:18:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 21:18:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 21:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 21:20:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 21:21:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 21:23:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 21:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 21:28:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:34:22 --> 404 Page Not Found: Ask/102
ERROR - 2022-02-18 21:35:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:35:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:40:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:41:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:41:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:41:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:41:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:41:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:42:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:42:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:42:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:42:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:42:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:43:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:43:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 21:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 21:50:43 --> 404 Page Not Found: Sdk/index
ERROR - 2022-02-18 21:50:44 --> 404 Page Not Found: Text4041645192243/index
ERROR - 2022-02-18 21:50:44 --> 404 Page Not Found: Evox/about
ERROR - 2022-02-18 21:50:44 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-02-18 21:50:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 21:55:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 21:55:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 21:57:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 22:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 22:04:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 22:06:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 22:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 22:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 22:11:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 22:13:49 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 22:28:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 22:28:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 22:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 22:29:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 22:31:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 22:43:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 22:49:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 22:52:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 22:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 22:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 23:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 23:09:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-18 23:09:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:14:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 23:19:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 23:30:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:31:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:31:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:31:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:32:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:32:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:32:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:32:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 23:32:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:32:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:33:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:33:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:33:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:33:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:33:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:33:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:34:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:34:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:34:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:34:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:35:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:35:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:35:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:35:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 23:36:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-18 23:37:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:37:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:37:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:38:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:38:21 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-18 23:38:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:39:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:40:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:41:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-18 23:41:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:41:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-18 23:42:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
