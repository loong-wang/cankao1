<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-25 00:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 00:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 00:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 00:27:15 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-25 00:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 00:34:29 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-25 00:35:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 00:37:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 00:55:55 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 00:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 01:10:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 01:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 01:17:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 01:17:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 01:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 01:23:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 01:31:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 01:36:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 01:36:45 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-25 01:39:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 02:03:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 02:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 02:29:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 02:31:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 02:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 02:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 02:35:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 02:37:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 02:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 02:41:08 --> 404 Page Not Found: City/10
ERROR - 2021-11-25 02:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:03:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:23:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 03:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:27:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 03:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:40:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:44:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 03:56:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 04:03:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 04:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 04:13:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 04:20:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 04:23:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 04:23:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 04:29:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 04:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 04:33:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 04:43:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 04:53:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 05:03:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 05:07:24 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-11-25 05:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 05:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 05:22:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 05:25:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 05:32:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 05:35:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 05:42:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 05:51:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 05:53:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 05:59:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 06:00:53 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-25 06:02:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 06:03:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 06:12:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 06:12:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 06:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 06:17:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 06:17:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 06:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 06:22:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 06:32:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 06:32:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 06:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 06:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 06:51:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 06:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 06:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 06:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 07:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 07:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 07:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 07:27:31 --> 404 Page Not Found: News/81599.html
ERROR - 2021-11-25 07:29:09 --> 404 Page Not Found: City/16
ERROR - 2021-11-25 07:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 07:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 07:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 07:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 07:45:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 07:49:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 08:10:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 08:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 08:21:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 08:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 08:41:59 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-25 08:48:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 08:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 08:57:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 08:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 09:00:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 09:03:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 09:03:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 09:04:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 09:04:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 09:06:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 09:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 09:07:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 09:07:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 09:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 09:11:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 09:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 09:17:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 09:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 09:25:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 09:33:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 09:33:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 09:34:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 09:35:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 09:41:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 09:42:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 09:47:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 09:53:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 09:53:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 10:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 10:03:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:07:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 10:10:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:11:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:11:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 10:15:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:15:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 10:16:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:16:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:16:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:17:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:17:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:18:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:18:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:21:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:22:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:23:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:24:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 10:29:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 10:29:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 10:29:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 10:29:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 10:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 10:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 10:42:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 10:57:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 10:58:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 11:01:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 11:03:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 11:03:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 11:13:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 11:15:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 11:15:55 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:15:55 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:17:41 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:17:41 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:20:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 11:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 11:27:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 11:31:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:40 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:40 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:31:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-11-25 11:35:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-20, 20' at line 6 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_title` LIKE '%8341%' ESCAPE '!'
OR  `hao_user` LIKE '%8341%' ESCAPE '!'
ORDER BY `hao_time` DESC
 LIMIT -20, 20
ERROR - 2021-11-25 11:35:13 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 1234
ERROR - 2021-11-25 11:35:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 11:36:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-20, 20' at line 6 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_title` LIKE '%88%' ESCAPE '!'
OR  `hao_user` LIKE '%88%' ESCAPE '!'
ORDER BY `hao_time` DESC
 LIMIT -20, 20
ERROR - 2021-11-25 11:36:01 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 1234
ERROR - 2021-11-25 11:36:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-20, 20' at line 6 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_title` LIKE '%88%' ESCAPE '!'
OR  `hao_user` LIKE '%88%' ESCAPE '!'
ORDER BY `hao_time` DESC
 LIMIT -20, 20
ERROR - 2021-11-25 11:36:09 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 1234
ERROR - 2021-11-25 11:36:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-20, 20' at line 6 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_title` LIKE '%8341%' ESCAPE '!'
OR  `hao_user` LIKE '%8341%' ESCAPE '!'
ORDER BY `hao_time` DESC
 LIMIT -20, 20
ERROR - 2021-11-25 11:36:57 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 1234
ERROR - 2021-11-25 11:36:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-20, 20' at line 6 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_title` LIKE '%8341%' ESCAPE '!'
OR  `hao_user` LIKE '%8341%' ESCAPE '!'
ORDER BY `hao_time` DESC
 LIMIT -20, 20
ERROR - 2021-11-25 11:36:57 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 1234
ERROR - 2021-11-25 11:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 11:38:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 11:40:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 11:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 11:48:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 12:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 12:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 12:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 12:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 12:21:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 12:21:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 12:25:46 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 12:43:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 12:43:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 12:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 12:46:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 12:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 13:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 13:06:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-25 13:07:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 13:11:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 13:20:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 13:26:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 13:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 13:32:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 13:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 13:36:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 13:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 13:40:46 --> 404 Page Not Found: City/16
ERROR - 2021-11-25 13:44:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 13:44:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 14:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 14:15:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 14:16:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 14:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 14:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 14:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 14:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 14:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 14:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 14:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 14:45:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 14:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 14:46:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 14:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 14:47:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 14:48:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 14:49:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 14:50:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 14:51:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:01:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:01:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:01:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:01:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:02:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:02:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:02:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:03:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:03:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:04:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 15:04:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:04:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:04:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:05:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 15:06:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 15:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 15:10:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:11:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 15:12:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:13:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:21:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 15:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 15:29:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:33:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:35:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:37:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 15:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 15:41:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:41:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:43:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 15:43:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 15:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 15:55:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 16:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 16:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 16:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 16:20:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 16:21:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 16:21:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 16:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 16:22:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 16:23:46 --> 404 Page Not Found: Vod-play-id-2680-sid-0-pid-123html/index
ERROR - 2021-11-25 16:28:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 16:29:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 16:32:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 16:45:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 16:49:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 16:50:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 16:50:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 16:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 16:50:48 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2021-11-25 17:04:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 17:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 17:10:34 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 17:13:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 17:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 17:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 17:24:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 17:24:49 --> 404 Page Not Found: Article/index
ERROR - 2021-11-25 17:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 17:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 17:34:52 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 17:43:08 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-11-25 17:52:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 17:56:24 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:24 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:25 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:25 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:25 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:25 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:25 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:25 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:25 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:26 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:26 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:26 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:26 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:26 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:26 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:26 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:26 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:27 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:27 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:27 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:27 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:27 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:28 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:28 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:28 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:28 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:28 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:28 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:29 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:29 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:29 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:29 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:29 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:30 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:30 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:30 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:30 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:30 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:30 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:31 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:31 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:31 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:31 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:31 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:31 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:31 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:31 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:31 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:32 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:32 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:32 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:32 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:32 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:32 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:32 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:32 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:33 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:33 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:33 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:34 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:34 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:34 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:34 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:34 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:34 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:34 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:34 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:35 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:35 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:35 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:35 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:35 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:35 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:36 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:36 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:36 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:56:36 --> Severity: Parsing Error --> syntax error, unexpected ')' /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 276
ERROR - 2021-11-25 17:57:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 17:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:01:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 18:02:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 18:02:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 18:02:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 18:02:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 18:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:09:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:09:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 18:10:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 18:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:19:39 --> Severity: Error --> Call to a member function log_exception() on a non-object /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php 181
ERROR - 2021-11-25 18:19:40 --> Severity: Error --> Call to a member function log_exception() on a non-object /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php 181
ERROR - 2021-11-25 18:20:03 --> Severity: Warning --> Missing argument 3 for CI_Exceptions::log_exception(), called in /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php on line 182 and defined /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php 102
ERROR - 2021-11-25 18:20:03 --> Severity: Warning --> Missing argument 4 for CI_Exceptions::log_exception(), called in /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php on line 182 and defined /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php 102
ERROR - 2021-11-25 18:20:03 --> Severity: error --> null  
ERROR - 2021-11-25 18:20:23 --> Severity: Warning --> Missing argument 3 for CI_Exceptions::log_exception(), called in /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php on line 182 and defined /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php 102
ERROR - 2021-11-25 18:20:23 --> Severity: Warning --> Missing argument 4 for CI_Exceptions::log_exception(), called in /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php on line 182 and defined /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php 102
ERROR - 2021-11-25 18:20:23 --> Severity: error --> 11111  
ERROR - 2021-11-25 18:20:24 --> Severity: Warning --> Missing argument 3 for CI_Exceptions::log_exception(), called in /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php on line 182 and defined /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php 102
ERROR - 2021-11-25 18:20:24 --> Severity: Warning --> Missing argument 4 for CI_Exceptions::log_exception(), called in /www/wwwroot/www.xuanhao.net/app/controllers/Wxpay.php on line 182 and defined /www/wwwroot/www.xuanhao.net/system/core/Exceptions.php 102
ERROR - 2021-11-25 18:20:24 --> Severity: error --> 11111  
ERROR - 2021-11-25 18:22:19 --> Severity: error --> 11111 1 1
ERROR - 2021-11-25 18:22:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 18:26:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:26:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 18:26:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 18:31:15 --> 404 Page Not Found: City/index
ERROR - 2021-11-25 18:34:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 18:34:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 18:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:51:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 18:55:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 18:56:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 18:59:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 19:00:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 19:00:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 19:00:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 19:01:31 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-11-25 19:01:34 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-11-25 19:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 19:01:40 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-11-25 19:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 19:09:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-25 19:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 19:30:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 19:30:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 19:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 19:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 20:00:37 --> 404 Page Not Found: 16/10000
ERROR - 2021-11-25 20:04:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:04:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:04:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:05:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:05:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 20:13:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:13:28 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-11-25 20:15:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 20:20:18 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-11-25 20:22:30 --> 404 Page Not Found: Company/view
ERROR - 2021-11-25 20:22:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:28:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 20:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 20:37:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:37:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 20:37:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:37:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:37:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 20:37:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:38:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:38:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 20:38:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:40:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:41:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:41:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 20:41:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:41:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:42:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 20:42:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:42:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:42:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 20:42:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:42:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:43:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:46:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 20:46:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:46:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:47:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:47:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:47:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 20:47:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:47:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:50:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:50:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 20:59:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 20:59:23 --> 404 Page Not Found: Order/index
ERROR - 2021-11-25 21:04:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 21:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 21:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 21:05:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:06:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:07:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:07:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:08:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:08:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:08:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:08:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:09:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:09:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:09:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:10:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:10:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:11:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 21:12:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 21:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 21:12:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:18:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:18:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:18:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:19:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:19:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:21:04 --> 404 Page Not Found: Article/view
ERROR - 2021-11-25 21:24:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:24:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:25:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:25:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 21:27:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 21:31:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 21:33:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:33:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:34:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:34:45 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-11-25 21:35:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 21:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 21:45:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 21:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 22:01:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 22:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 22:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 22:10:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 22:12:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 22:16:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 22:19:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 22:23:02 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-25 22:24:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 22:25:52 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-25 22:41:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 22:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 22:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 22:48:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 22:52:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 22:52:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 22:53:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 23:03:19 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-25 23:06:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 23:07:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 23:07:29 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-11-25 23:08:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 23:15:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 23:15:44 --> Severity: Warning --> Missing argument 1 for User::check_register_username() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 267
ERROR - 2021-11-25 23:16:55 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-25 23:23:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-25 23:26:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-25 23:39:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-25 23:47:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 23:48:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 23:48:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 23:49:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 23:50:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 23:50:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 23:51:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-25 23:51:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
