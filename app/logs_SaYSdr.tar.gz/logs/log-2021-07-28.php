<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-07-28 00:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:00:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:02:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:05:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:06:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:07:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:09:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:09:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:11:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:11:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:11:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:11:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:13:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:13:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 00:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:13:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:16:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:17:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:17:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:17:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:18:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:18:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:18:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:18:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:19:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 00:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:19:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:19:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:20:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:22:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:23:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:24:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:24:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:25:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:25:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-28 00:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:30:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:31:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:32:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:32:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:33:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:36:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:36:24 --> 404 Page Not Found: City/1
ERROR - 2021-07-28 00:36:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:37:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:37:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:37:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:38:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:38:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:38:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:38:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:41:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:42:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:42:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:42:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:43:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:44:13 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-28 00:44:13 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-28 00:44:14 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-28 00:44:14 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-28 00:44:14 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-28 00:44:14 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-28 00:44:14 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-28 00:44:15 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-28 00:44:15 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-28 00:44:15 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-28 00:44:16 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-28 00:44:16 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-28 00:44:16 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-28 00:44:16 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-28 00:44:17 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-28 00:44:17 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-28 00:44:17 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-28 00:44:18 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-28 00:44:18 --> 404 Page Not Found: Mrar/index
ERROR - 2021-07-28 00:44:19 --> 404 Page Not Found: Mzip/index
ERROR - 2021-07-28 00:44:19 --> 404 Page Not Found: Mtargz/index
ERROR - 2021-07-28 00:44:19 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-28 00:44:19 --> 404 Page Not Found: Wwwqiangkawangcomrar/index
ERROR - 2021-07-28 00:44:20 --> 404 Page Not Found: Qiangkawangcomrar/index
ERROR - 2021-07-28 00:44:20 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-28 00:44:20 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-28 00:44:20 --> 404 Page Not Found: Qiangkawangrar/index
ERROR - 2021-07-28 00:44:22 --> 404 Page Not Found: Wwwqiangkawangcomzip/index
ERROR - 2021-07-28 00:44:22 --> 404 Page Not Found: Qiangkawangcomzip/index
ERROR - 2021-07-28 00:44:23 --> 404 Page Not Found: Qiangkawangzip/index
ERROR - 2021-07-28 00:44:23 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-28 00:44:25 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-28 00:44:25 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-28 00:44:28 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-28 00:44:29 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-28 00:44:30 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-28 00:44:31 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-28 00:44:31 --> 404 Page Not Found: Wwwqiangkawangcomtargz/index
ERROR - 2021-07-28 00:44:31 --> 404 Page Not Found: Qiangkawangcomtargz/index
ERROR - 2021-07-28 00:44:32 --> 404 Page Not Found: Qiangkawangtargz/index
ERROR - 2021-07-28 00:44:32 --> 404 Page Not Found: Mrar/index
ERROR - 2021-07-28 00:44:33 --> 404 Page Not Found: Mzip/index
ERROR - 2021-07-28 00:44:34 --> 404 Page Not Found: Mtargz/index
ERROR - 2021-07-28 00:44:34 --> 404 Page Not Found: Wwwqiangkawangcomrar/index
ERROR - 2021-07-28 00:44:39 --> 404 Page Not Found: Wwwqiangkawangcomtargz/index
ERROR - 2021-07-28 00:44:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:44:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:47:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:48:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:48:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:49:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:50:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:51:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:51:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:52:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 00:52:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 00:52:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:53:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 00:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:53:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 00:53:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 00:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 00:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:55:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:56:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:56:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 00:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:00:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:00:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:02:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:04:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:04:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:06:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:06:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:07:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:08:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:08:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:10:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:12:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:13:04 --> 404 Page Not Found: Login/index
ERROR - 2021-07-28 01:13:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:14:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:15:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:15:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:17:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:18:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:20:36 --> 404 Page Not Found: City/2
ERROR - 2021-07-28 01:21:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:22:02 --> 404 Page Not Found: A/lianxiwomen
ERROR - 2021-07-28 01:22:02 --> 404 Page Not Found: Haoma/index
ERROR - 2021-07-28 01:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:22:10 --> 404 Page Not Found: Vod-read-id-2605html/index
ERROR - 2021-07-28 01:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:22:15 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-07-28 01:22:16 --> 404 Page Not Found: Vod-read-id-2773html/index
ERROR - 2021-07-28 01:22:23 --> 404 Page Not Found: Vod-read-id-2607html/index
ERROR - 2021-07-28 01:22:26 --> 404 Page Not Found: Vod-read-id-2781html/index
ERROR - 2021-07-28 01:23:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:25:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:26:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:28:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:29:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:30:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:30:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:30:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 01:31:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 01:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:32:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:32:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:32:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 01:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:35:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:35:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 01:35:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:36:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:36:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:36:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:36:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:37:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:37:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:37:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:41:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:41:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:43:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:44:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:45:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:46:27 --> 404 Page Not Found: _profiler/phpinfo
ERROR - 2021-07-28 01:46:29 --> 404 Page Not Found: Phpinfo/index
ERROR - 2021-07-28 01:46:29 --> 404 Page Not Found: Awsyml/index
ERROR - 2021-07-28 01:46:30 --> 404 Page Not Found: Envbak/index
ERROR - 2021-07-28 01:46:31 --> 404 Page Not Found: Aws/credentials
ERROR - 2021-07-28 01:46:32 --> 404 Page Not Found: Config/aws.yml
ERROR - 2021-07-28 01:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:50:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:50:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:50:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:50:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:51:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:52:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:53:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:54:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:55:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:58:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:58:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 01:59:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 01:59:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 01:59:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 01:59:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 02:00:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:00:44 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-28 02:00:45 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-28 02:00:46 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-28 02:00:46 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-28 02:00:46 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-28 02:00:46 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-28 02:00:46 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-28 02:00:46 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-28 02:00:46 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-28 02:00:46 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-28 02:00:46 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-28 02:00:46 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-28 02:00:47 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-28 02:00:47 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-28 02:00:47 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-28 02:00:47 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-28 02:00:47 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-28 02:00:47 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-28 02:00:47 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-28 02:00:47 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-28 02:00:47 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-28 02:00:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:00:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 02:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:02:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 02:02:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:03:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 02:03:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:05:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:09:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:10:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:11:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:12:37 --> 404 Page Not Found: City/15
ERROR - 2021-07-28 02:12:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:13:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:13:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:14:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:16:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:16:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:16:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:16:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:16:55 --> 404 Page Not Found: City/2
ERROR - 2021-07-28 02:17:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:18:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:20:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:20:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:22:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:23:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:28:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:29:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:30:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:31:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:32:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:32:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 02:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:33:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:34:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:35:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:36:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:37:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:37:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 02:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:38:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:38:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:40:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:42:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:42:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:45:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:45:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:47:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 02:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:48:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:49:42 --> 404 Page Not Found: Env/index
ERROR - 2021-07-28 02:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:50:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:50:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:52:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:53:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:54:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:54:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 02:59:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 02:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:00:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:01:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:03:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:05:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:06:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:07:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:07:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:08:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:09:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:09:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:12:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:13:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:15:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:16:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:17:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:18:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:18:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:18:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:19:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:20:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:21:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:26:42 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-28 03:26:42 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-28 03:26:42 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-28 03:26:42 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-28 03:26:42 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-28 03:26:42 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-28 03:26:42 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-28 03:26:43 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-28 03:26:43 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-28 03:26:43 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-28 03:26:43 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-28 03:26:43 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-28 03:26:43 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-28 03:26:43 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-28 03:26:43 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-28 03:26:43 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-28 03:26:43 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-28 03:26:44 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-28 03:26:44 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-28 03:26:44 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-28 03:26:44 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-28 03:26:44 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-28 03:26:44 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-28 03:26:44 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-28 03:26:44 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-28 03:26:45 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-28 03:26:45 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-28 03:26:45 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-28 03:27:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:28:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:28:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:29:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:30:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:31:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:32:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:33:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:33:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-28 03:34:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:36:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:38:10 --> 404 Page Not Found: City/10
ERROR - 2021-07-28 03:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:41:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:42:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:43:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:43:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:44:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:44:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:44:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:45:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:46:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:46:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:48:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:48:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:50:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:50:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:54:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:56:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:57:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 03:59:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 03:59:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:00:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-07-28 04:01:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:07:37 --> 404 Page Not Found: A/chanpinzhongxin
ERROR - 2021-07-28 04:08:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 04:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:09:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:09:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:10:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:10:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:13:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:14:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:16:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:17:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:17:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 04:17:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:18:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:18:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:20:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:20:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:21:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:22:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:23:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:24:19 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-28 04:24:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:25:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:25:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:25:24 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-28 04:25:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:26:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:27:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:28:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:29:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:29:58 --> 404 Page Not Found: Cn/Productsa.asp
ERROR - 2021-07-28 04:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:30:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:31:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:31:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:31:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:31:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:31:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:31:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:32:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:32:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:32:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:32:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:32:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:32:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:32:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:33:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-28 04:33:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:33:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:35:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 04:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:35:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:37:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:38:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:42:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:42:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:42:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:44:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:44:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:45:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 04:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:53:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:56:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:57:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 04:57:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 04:57:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:58:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:58:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 04:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:59:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 04:59:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:00:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:01:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:02:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 05:02:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 05:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:03:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:06:07 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-28 05:06:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:11:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:14:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:19:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:20:02 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-07-28 05:20:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:21:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:23:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:23:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:24:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:25:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:27:13 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 05:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:28:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:29:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:30:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:30:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:34:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:35:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:36:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:37:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:38:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:41:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:44:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:45:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:45:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:46:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-28 05:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:47:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:49:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:49:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:50:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-28 05:50:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:50:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:50:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:52:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:52:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:53:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:55:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:57:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:57:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:57:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 05:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 05:59:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:03:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:03:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:03:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:05:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:06:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:09:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:10:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:11:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:11:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:14:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:14:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:15:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 06:16:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:16:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:16:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:16:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:16:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 06:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:17:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:17:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:18:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:18:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:18:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:18:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:18:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:19:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:19:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:19:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:20:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:20:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:20:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:20:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:20:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:22:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 06:22:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 06:22:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 06:22:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 06:22:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:22:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:23:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:25:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:25:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:25:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:26:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:26:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:27:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:28:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:29:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:29:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:29:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:29:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:30:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:30:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:32:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:33:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:33:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:34:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:34:49 --> 404 Page Not Found: Config/getuser
ERROR - 2021-07-28 06:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:35:03 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-28 06:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:35:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:36:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:37:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:37:27 --> 404 Page Not Found: Env/index
ERROR - 2021-07-28 06:37:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:38:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:38:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 06:39:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:39:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:40:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:41:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:41:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 06:41:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:42:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:43:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:43:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:44:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:44:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:44:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:47:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:47:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:47:59 --> 404 Page Not Found: Env/index
ERROR - 2021-07-28 06:48:00 --> 404 Page Not Found: Env/index
ERROR - 2021-07-28 06:48:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:48:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:48:56 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-07-28 06:49:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:50:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:50:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:51:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:51:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:52:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:52:29 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-28 06:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:53:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:54:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:54:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:55:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:55:14 --> 404 Page Not Found: Env/index
ERROR - 2021-07-28 06:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:56:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:57:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:57:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:57:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:57:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:58:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:58:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:58:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 06:59:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 06:59:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:00:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:01:10 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-07-28 07:01:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:01:47 --> 404 Page Not Found: Vod-show-id-15-p-1html/index
ERROR - 2021-07-28 07:01:48 --> 404 Page Not Found: Article/info
ERROR - 2021-07-28 07:01:48 --> 404 Page Not Found: Article/view
ERROR - 2021-07-28 07:02:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:02:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:04:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:05:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:05:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:06:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:06:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:06:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-28 07:06:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:06:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:06:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:09:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:09:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:12:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:15:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:16:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:16:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:16:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:17:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:18:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:18:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:19:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:19:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:19:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:20:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:20:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:21:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:21:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:22:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:22:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 07:22:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:22:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 07:22:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 07:22:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 07:22:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:23:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:23:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 07:23:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 07:23:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:23:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:23:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:23:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:24:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:24:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:24:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:25:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:25:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:25:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:26:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:26:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:26:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:27:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:27:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:27:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:27:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:28:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:29:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:29:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:29:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:29:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:31:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:31:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:31:35 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-28 07:31:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:32:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:33:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:33:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:34:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:34:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:36:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:36:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:37:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:37:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:37:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:38:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:38:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:39:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:40:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:42:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:44:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:45:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:45:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:46:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:46:39 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-28 07:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:48:01 --> 404 Page Not Found: Sitemap98273html/index
ERROR - 2021-07-28 07:48:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:49:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:51:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:51:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:51:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:51:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:52:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:52:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:52:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:52:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:53:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-28 07:53:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:54:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:54:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:55:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:55:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:56:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:56:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:57:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 07:57:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 07:57:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:00:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:00:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:01:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:01:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:02:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:02:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:02:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:02:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:03:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:03:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:03:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:03:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:04:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:05:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:05:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:05:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:06:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 08:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:07:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:07:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:08:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:10:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:10:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:11:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:12:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:13:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:13:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:15:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:15:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:16:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:17:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:18:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:19:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:19:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:20:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:21:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:22:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:23:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:23:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:24:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:25:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:25:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:26:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 08:26:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:26:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 08:26:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 08:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:26:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 08:27:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 08:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:27:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:27:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 08:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:30:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:30:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:30:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:31:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:31:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:31:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:32:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:32:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:32:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:32:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:33:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 08:33:14 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-07-28 08:33:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:33:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:34:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:34:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:35:32 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-28 08:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:36:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:36:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 08:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:38:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:38:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:38:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 08:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:38:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:39:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:40:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:41:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:42:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:42:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:43:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:43:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:43:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:45:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:45:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:46:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:47:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:47:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:47:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:47:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:48:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:48:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:49:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:50:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 08:51:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:51:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:53:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:56:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:56:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 08:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:57:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 08:58:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 08:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 08:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:00:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:01:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:01:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:01:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:02:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:02:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:02:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:04:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:05:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:06:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:06:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:06:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:06:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:07:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:07:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:07:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:07:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:07:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:07:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:07:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:07:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:08:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:08:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:08:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:08:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:08:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:08:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:09:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:09:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:09:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:09:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:11:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:11:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:11:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:12:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:12:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:12:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:13:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:14:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:15:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:15:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:16:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:17:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:17:55 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-28 09:18:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:18:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:20:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:20:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:21:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:22:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:22:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:23:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:24:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:24:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:24:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:25:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:25:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:25:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:26:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:26:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:27:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:28:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:28:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:28:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:29:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:29:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:29:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:29:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:29:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:29:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:29:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:29:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:30:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:30:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:30:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:30:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:30:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 09:31:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:32:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:33:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:36:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:37:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:37:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:37:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:37:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:38:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 09:38:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:39:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:40:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:42:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:44:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:45:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:47:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:48:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:48:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:49:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:50:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:51:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:52:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:53:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 09:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:56:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:57:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 09:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:01:20 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-28 10:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:02:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:02:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:02:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:02:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:03:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:03:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:04:31 --> 404 Page Not Found: Env/index
ERROR - 2021-07-28 10:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:05:55 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-28 10:05:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 10:06:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:06:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:06:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:06:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:06:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:07:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:07:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:07:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:07:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:07:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:07:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:07:22 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-28 10:07:22 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-28 10:07:29 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-28 10:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:11:58 --> 404 Page Not Found: TelerikWebUIWebResourceaxd/index
ERROR - 2021-07-28 10:12:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:13:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:14:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:14:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:14:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:16:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:17:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:21:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:22:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:26:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 10:26:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:27:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:29:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:30:24 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-07-28 10:31:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:32:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:32:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:33:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:33:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:33:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:35:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:36:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:36:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:36:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:37:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:37:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:38:45 --> 404 Page Not Found: City/9
ERROR - 2021-07-28 10:39:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:40:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:42:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:42:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:42:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:43:19 --> 404 Page Not Found: City/16
ERROR - 2021-07-28 10:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:43:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:43:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:44:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:44:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:44:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:45:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:45:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:47:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:47:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:47:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:47:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:48:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:48:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:48:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:48:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:49:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:49:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:50:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:50:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:50:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 10:51:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:51:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:51:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:51:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:52:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:54:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:55:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:57:19 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiond3808683a4815a70b4393c61c3407d485f0d2cca): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-28 10:57:19 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessiona5d61439cdaef1135c22e7dd26663f91d8db8b98): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-28 10:57:19 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_session0f8be37adc65164aca38dcf3995817614030aa53): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-28 10:57:19 --> Severity: Warning --> unlink(/www/wwwroot/www.xuanhao.net/app/cache/session/fox_sessionf89244c1d17cf979e91e2390990027fc2e4bf872): No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Session/drivers/Session_files_driver.php 354
ERROR - 2021-07-28 10:57:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:57:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:57:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 10:57:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 10:58:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:58:17 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-28 10:58:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-28 10:58:17 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-28 10:58:17 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-28 10:58:17 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-28 10:58:17 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-28 10:58:18 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-28 10:58:18 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-28 10:58:18 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-28 10:58:18 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-28 10:58:18 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-28 10:58:18 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-28 10:58:18 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-28 10:58:18 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-28 10:58:18 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-28 10:58:18 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-28 10:58:18 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-28 10:58:19 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-28 10:58:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 10:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:00:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:00:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:02:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:02:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:02:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:03:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:04:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:04:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:05:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:06:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:06:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:07:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:07:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:07:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:07:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:08:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:08:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:08:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:08:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-28 11:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:08:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:08:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:09:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:09:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:09:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:09:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:09:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 11:09:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:10:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:12:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:12:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:12:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:12:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:14:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 11:14:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:15:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 11:15:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 11:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:17:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:19:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:19:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:20:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:22:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:22:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:22:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:24:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:24:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:25:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:26:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:27:02 --> 404 Page Not Found: 16/10000
ERROR - 2021-07-28 11:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:29:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:31:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:31:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:31:38 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-07-28 11:31:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:32:35 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-28 11:32:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:33:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:33:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 11:33:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 11:34:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:34:59 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:34:59 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:35:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 11:35:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:35:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:35:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:35:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:35:31 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:35:31 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:35:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:35:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:35:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:35:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:35:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:37:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:37:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:37:35 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:37:35 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:37:41 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-07-28 11:37:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:37:45 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:37:45 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:38:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:38:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:39:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:39:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 11:40:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:41:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 11:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:41:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:42:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:43:02 --> 404 Page Not Found: City/index
ERROR - 2021-07-28 11:43:16 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:43:16 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:43:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:43:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:43:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:43:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:43:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:43:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:43:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:43:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:43:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:43:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:43:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:44:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 11:44:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:21 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:21 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:26 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:26 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:44:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:45:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 11:45:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:52 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:52 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:45:57 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:45:57 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:02 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:02 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:07 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:07 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:12 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:12 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:17 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:17 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:22 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:22 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:27 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:27 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:32 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:32 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:42 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:42 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:44 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-07-28 11:46:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:46:47 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:47 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:46:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:47:38 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:38 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:43 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:43 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:48 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:48 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:53 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:53 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:58 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:47:58 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:08 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:08 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:13 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:13 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:48:18 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:18 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:23 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:23 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:48:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:48:28 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:28 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:33 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:33 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:37 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:48:37 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-07-28 11:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:49:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 11:49:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 11:51:02 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-07-28 11:51:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:51:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:53:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 11:53:57 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-07-28 11:54:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 11:54:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:55:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:55:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:56:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:56:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:56:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:56:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 11:57:26 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-07-28 11:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 11:59:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:00:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:01:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:03:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:06:45 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-28 12:07:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:09:53 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-07-28 12:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:09:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:10:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:10:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 12:10:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:10:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:10:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:12:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:12:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:12:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:13:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:14:38 --> 404 Page Not Found: City/10
ERROR - 2021-07-28 12:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:15:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:18:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:20:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:23:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:23:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:28:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:28:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:28:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:28:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:29:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:29:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:31:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:32:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:33:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:33:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:33:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:34:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:34:03 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-07-28 12:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:34:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:34:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:35:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:35:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:36:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:36:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:38:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:38:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:40:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:40:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:40:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:40:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:40:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:41:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:41:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:41:53 --> 404 Page Not Found: Nmaplowercheck1627447311/index
ERROR - 2021-07-28 12:41:53 --> 404 Page Not Found: Evox/about
ERROR - 2021-07-28 12:41:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:42:04 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-07-28 12:43:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 12:43:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:44:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:45:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:45:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:46:38 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-07-28 12:46:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:47:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:48:37 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-07-28 12:48:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:50:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:50:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:51:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:51:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:51:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:52:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:52:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 12:52:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:53:45 --> 404 Page Not Found: Vod-play-id-2603-sid-0-pid-39html/index
ERROR - 2021-07-28 12:53:46 --> 404 Page Not Found: Vod-search-wd-%E6%88%B7%E6%9D%BE%E9%81%A5-p-1html/index
ERROR - 2021-07-28 12:53:47 --> 404 Page Not Found: Vod-search-wd-%E4%BB%8A%E4%BA%95%E7%BF%BC-p-1html/index
ERROR - 2021-07-28 12:53:47 --> 404 Page Not Found: Vod-play-id-2346-sid-0-pid-136html/index
ERROR - 2021-07-28 12:53:49 --> 404 Page Not Found: Vod-play-id-2660-sid-0-pid-116html/index
ERROR - 2021-07-28 12:53:51 --> 404 Page Not Found: Vod-play-id-2786-sid-0-pid-3html/index
ERROR - 2021-07-28 12:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:56:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:57:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:58:05 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-07-28 12:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:58:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 12:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 12:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:00:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:00:54 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-07-28 13:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:01:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:01:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:02:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:02:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:02:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:02:26 --> 404 Page Not Found: City/15
ERROR - 2021-07-28 13:03:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:03:11 --> 404 Page Not Found: Wp-includes/index
ERROR - 2021-07-28 13:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:03:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:04:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:05:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:05:54 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-28 13:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:06:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:08:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:09:02 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-07-28 13:09:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:09:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:11:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:11:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:12:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:14:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 13:14:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 13:15:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:15:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 13:17:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:17:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:17:36 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-28 13:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:18:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:18:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:19:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 13:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:20:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:20:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 13:20:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 13:21:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 13:21:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:21:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:21:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:22:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 13:22:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:22:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 13:22:31 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-28 13:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:23:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:25:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:29:05 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-07-28 13:30:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 13:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:31:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:31:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:32:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:32:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:32:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:32:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:32:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:32:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:32:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:33:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:34:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:36:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:44:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:45:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:47:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:49:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:49:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:50:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:51:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:51:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 13:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:52:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 13:52:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 13:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:55:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:58:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:58:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 13:59:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 13:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:01:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:05:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:05:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:06:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:08:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:08:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:08:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:08:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:08:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:09:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:09:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:09:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:09:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:09:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:09:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:09:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:10:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:10:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 14:10:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:14:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:16:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:16:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:17:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:18:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:18:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:18:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:19:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:20:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:20:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:21:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:22:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:25:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:26:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:28:10 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-07-28 14:29:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:29:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:29:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:31:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:33:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:33:24 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-28 14:33:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:34:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:34:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:37:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:37:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:38:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:38:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:38:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:38:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:38:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:39:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:39:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:39:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:41:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:41:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:41:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:42:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:42:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:42:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:44:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:44:52 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-28 14:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:47:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:47:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:48:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:48:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:48:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:48:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:49:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:49:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:50:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:50:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:51:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 14:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:52:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:53:27 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-28 14:53:27 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-28 14:53:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:53:27 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-07-28 14:53:27 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-07-28 14:53:27 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-07-28 14:53:28 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-07-28 14:53:29 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-07-28 14:53:29 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-07-28 14:53:29 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-07-28 14:53:29 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-07-28 14:53:30 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-07-28 14:53:30 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-07-28 14:53:30 --> 404 Page Not Found: Webrar/index
ERROR - 2021-07-28 14:53:30 --> 404 Page Not Found: Webzip/index
ERROR - 2021-07-28 14:53:30 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-07-28 14:55:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 14:55:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:58:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 14:58:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:58:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 14:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:00:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:01:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:03:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:03:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:05:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:07:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:07:55 --> 404 Page Not Found: V1/.env
ERROR - 2021-07-28 15:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:09:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:10:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:11:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:12:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:12:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:13:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:14:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:15:23 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-07-28 15:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:15:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:15:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:17:43 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-07-28 15:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:18:15 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-07-28 15:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:18:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:21:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:22:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-28 15:23:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:23:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:25:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:25:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:25:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:25:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:26:10 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-28 15:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:28:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 15:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:29:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:29:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:29:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:30:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:30:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:30:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:30:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:30:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:30:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:34:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:34:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:34:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:35:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:35:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 15:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:36:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:38:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:39:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:42:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:44:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:45:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:46:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:48:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:49:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:49:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:52:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-07-28 15:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:56:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 15:57:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 15:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:58:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:58:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 15:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:00:26 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 16:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:02:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:02:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:02:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:02:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:03:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:06:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:07:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:08:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:08:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:09:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:11:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:11:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:11:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:14:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:16:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:17:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:18:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:19:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:19:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:20:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:23:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:25:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 16:25:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:28:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:28:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:29:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:29:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:30:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:30:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:31:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:31:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:31:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 16:31:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:31:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:32:19 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 16:32:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:32:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:33:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:34:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:34:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:35:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:36:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:36:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:36:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:36:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:37:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:37:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:37:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 16:37:44 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-28 16:37:44 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-28 16:37:46 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-28 16:38:09 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-28 16:38:09 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-07-28 16:38:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:38:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:38:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:39:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:40:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:41:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:41:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:42:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:43:00 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 16:44:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:44:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:46:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:49:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:49:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:51:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:51:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:54:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:54:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:54:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:55:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:55:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:55:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:55:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:56:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:56:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:56:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 16:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:58:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 16:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 16:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:00:07 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 17:00:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:00:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:02:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:02:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:03:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:03:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 17:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:04:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:04:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:05:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:05:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:06:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:06:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:06:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:06:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:07:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:07:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:08:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:08:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:10:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:11:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:11:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:11:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:12:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:12:31 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-07-28 17:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:14:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:15:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 17:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:16:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:16:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:17:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:17:37 --> 404 Page Not Found: English/index
ERROR - 2021-07-28 17:17:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:18:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:18:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:19:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:19:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:19:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:19:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:20:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:20:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:21:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:21:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:21:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:22:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:22:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:23:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:25:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:25:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:25:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:25:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:25:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 17:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:27:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:28:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:28:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:29:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:29:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:29:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:29:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:29:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:29:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:30:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:30:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:30:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:31:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:34:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:35:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:35:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:35:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:36:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:36:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:36:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:37:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:39:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:39:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:39:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:40:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:40:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:40:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:41:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:41:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:41:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:42:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:43:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:43:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:44:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:44:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 17:44:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 17:44:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:44:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 17:45:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:45:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 17:45:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 17:45:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:45:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 17:45:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:45:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 17:46:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:46:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:46:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:46:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:46:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:47:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:47:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 17:47:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:48:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:48:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:49:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:50:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:50:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:50:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:51:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:52:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:52:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:53:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:53:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:53:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:53:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:53:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:54:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:54:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:54:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:54:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:55:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:56:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:56:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:58:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:58:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 17:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:59:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 17:59:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 17:59:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:00:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 18:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:00:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 18:00:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:00:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 18:01:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:02:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:03:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:04:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 18:04:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 18:04:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 18:05:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:06:03 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-07-28 18:06:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:06:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 18:06:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:07:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:07:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:08:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:08:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 18:08:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:08:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:09:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:09:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:10:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:11:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:12:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:12:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:12:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:14:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:15:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:16:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:16:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:17:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:17:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:17:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:18:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:19:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:19:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:19:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:20:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:20:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:20:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:20:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:20:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:21:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:21:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:21:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:21:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:22:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:22:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:22:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:22:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:23:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:23:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:25:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:25:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:25:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:25:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:25:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:25:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:25:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:26:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:26:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:27:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:27:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:27:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:28:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:28:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:29:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:30:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:30:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:32:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:32:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:32:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:33:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:33:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:33:25 --> Severity: Warning --> Missing argument 1 for Taocan::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 21
ERROR - 2021-07-28 18:33:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:33:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:33:53 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-07-28 18:35:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:36:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:37:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:37:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:37:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:38:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:38:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:38:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:38:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:39:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:39:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:39:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:39:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:39:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:39:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:40:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:40:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:40:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:41:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:41:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:41:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:42:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:42:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:43:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:43:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:44:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:44:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:44:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:45:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:45:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:45:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:45:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:45:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:45:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:46:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:46:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:46:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:46:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:46:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:46:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:46:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:46:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:47:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:47:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:47:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:47:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:47:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:48:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:48:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:48:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:48:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:48:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:49:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:49:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:50:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:50:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:50:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:50:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:51:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:52:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:52:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:53:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:54:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:54:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:55:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:55:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:55:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:56:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:57:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:57:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:58:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:58:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:58:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:58:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:58:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 18:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 18:59:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:00:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:00:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:01:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:01:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:02:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:02:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:02:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:02:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:02:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:02:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:02:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:03:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:03:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:03:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:03:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:04:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:04:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:04:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:05:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:05:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:05:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 19:05:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:05:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:05:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:05:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:05:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:05:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:05:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:06:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:06:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:06:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:06:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:06:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:06:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 19:07:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:07:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:07:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:07:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:07:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:08:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:08:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:08:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:08:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:09:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:09:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:09:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:09:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:10:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:11:00 --> 404 Page Not Found: Cart/index
ERROR - 2021-07-28 19:11:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:11:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:11:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:11:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:13:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:14:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:16:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:17:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:17:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:17:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:18:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:18:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:18:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:19:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:19:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:19:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:20:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:20:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:21:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:21:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:22:10 --> 404 Page Not Found: City/9
ERROR - 2021-07-28 19:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:27:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:27:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:28:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:28:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:29:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:29:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:29:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:31:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:31:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:33:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:33:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:33:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:35:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:35:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:35:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:37:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 19:37:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 19:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:38:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:39:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:40:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 19:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:41:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:41:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:41:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:42:07 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-28 19:42:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 19:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:44:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:44:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:45:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:45:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:45:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 19:45:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:46:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:47:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:47:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:48:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:48:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 19:49:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:49:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:50:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:50:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:50:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:50:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 19:50:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:51:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:51:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:52:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:52:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:52:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:52:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:52:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:43 --> 404 Page Not Found: Search/likea
ERROR - 2021-07-28 19:53:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 19:53:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:53:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:54:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:54:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:54:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:54:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:54:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:54:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:54:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:54:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:54:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:54:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:55:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:55:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:55:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:55:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:55:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:55:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:55:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:55:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:55:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:55:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:55:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:56:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:56:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:56:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:57:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:57:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:58:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:58:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 19:59:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:59:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 19:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:00:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:00:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:00:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 20:00:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:00:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:00:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 20:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:01:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 20:01:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 20:01:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:01:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 20:02:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:02:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:02:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 20:02:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 20:02:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:02:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:02:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 20:02:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:02:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 20:02:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:03:24 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-07-28 20:04:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:04:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:05:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:06:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:07:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:08:52 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-07-28 20:09:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:11:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:13:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:13:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:16:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:17:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:17:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:17:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:18:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:21:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:23:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:23:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:24:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:25:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:25:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:26:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:26:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:26:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:27:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:27:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:28:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:29:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:30:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:31:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:31:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:31:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:31:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:33:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:34:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:36:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:38:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:38:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:39:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:39:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:40:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:41:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:41:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:42:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:43:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:45:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:46:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:47:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 20:48:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:48:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:49:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:49:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:50:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:50:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:50:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 20:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:51:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:52:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:53:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:54:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:56:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 20:57:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 20:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:01:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:03:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:04:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:05:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:05:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:09:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:11:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:12:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:12:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:12:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:13:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:13:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:14:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:14:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:14:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:15:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:15:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:15:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:15:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:15:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:15:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:15:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:17:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:17:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:17:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:18:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 21:18:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:19:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:19:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:20:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:20:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:21:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:22:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:22:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:22:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:23:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:23:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 21:24:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:27:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:34:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:34:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:35:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 21:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:36:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:37:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:38:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:38:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:42:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 21:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:44:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:49:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:51:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:52:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:53:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:53:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:53:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 21:53:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 21:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:54:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:54:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:54:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 21:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:03:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:04:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:06:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:07:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:07:26 --> 404 Page Not Found: English/index
ERROR - 2021-07-28 22:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:08:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:09:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:11:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:13:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:14:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:16:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:22:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:24:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:24:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:24:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 22:24:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 22:24:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 22:24:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 22:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:26:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:28:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:30:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 22:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:37:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:42:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:42:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 22:42:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 22:43:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 22:43:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 22:43:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:44:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:45:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 22:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:48:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 22:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:50:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:50:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:55:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:58:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:59:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 22:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:02:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:03:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:05:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:05:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:06:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:06:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:06:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:06:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 23:07:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:07:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:07:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:07:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:08:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:08:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:08:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:12:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:12:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:12:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:12:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:13:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:15:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:16:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-07-28 23:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:17:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:17:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:18:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:19:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 23:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:21:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:25:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:26:50 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 23:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:29:23 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-07-28 23:31:05 --> 404 Page Not Found: Setupcgi/index
ERROR - 2021-07-28 23:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:34:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 23:34:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-07-28 23:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:35:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:35:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:35:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:35:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:40:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 23:40:56 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 23:42:39 --> 404 Page Not Found: Data/admin
ERROR - 2021-07-28 23:43:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 23:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:44:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:44:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 23:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:45:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-07-28 23:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:45:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:47:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:47:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:51:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:51:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:56:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:59:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-07-28 23:59:50 --> 404 Page Not Found: Data/admin
