<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-12-07 00:00:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 00:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 00:16:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 00:17:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 00:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 00:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 00:34:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 00:50:34 --> 404 Page Not Found: admin/Lib/ueditor
ERROR - 2021-12-07 01:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 01:15:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 01:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 01:31:56 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-12-07 01:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 01:47:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-07 01:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 02:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 02:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 02:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 02:52:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 02:52:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 02:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 03:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 03:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 03:34:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 03:39:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 03:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 03:40:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-07 03:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 03:43:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 03:46:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 03:47:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 04:03:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 04:06:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 04:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 04:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 04:25:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 04:26:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 04:32:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 04:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 04:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 04:33:17 --> 404 Page Not Found: Sitemap93816html/index
ERROR - 2021-12-07 04:33:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 04:34:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 04:35:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 04:37:30 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-12-07 04:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 04:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 05:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 05:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 05:09:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 05:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 05:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 05:36:01 --> 404 Page Not Found: Sitemap79460html/index
ERROR - 2021-12-07 05:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 05:41:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-07 05:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 05:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 06:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 06:02:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 06:02:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 06:11:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 06:19:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 06:19:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 06:25:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 06:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 06:43:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 06:43:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 06:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 06:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 07:04:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 07:04:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 07:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 07:07:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 07:25:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-07 07:26:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 07:27:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 07:27:55 --> 404 Page Not Found: Plus/Reg.aspx
ERROR - 2021-12-07 07:28:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 07:29:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 07:30:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 07:34:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 07:39:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 07:41:04 --> 404 Page Not Found: Templates/red.asp
ERROR - 2021-12-07 07:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 07:45:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 07:45:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 07:47:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 07:47:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 07:47:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 07:47:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 07:48:07 --> 404 Page Not Found: City/index
ERROR - 2021-12-07 07:52:21 --> Severity: Warning --> Missing argument 1 for Taocan::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 21
ERROR - 2021-12-07 07:58:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 08:12:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 08:12:36 --> 404 Page Not Found: Web/index
ERROR - 2021-12-07 08:19:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-07 08:29:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 08:30:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:40:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:41:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:42:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:43:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:44:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:44:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 08:46:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:54:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:54:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 08:54:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 08:54:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:55:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:55:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:56:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:56:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:56:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:58:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 08:58:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 09:03:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:04:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:05:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 09:06:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:10:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 09:13:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 09:13:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 09:16:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:17:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:20:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 09:21:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 09:24:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 09:27:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:27:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:30:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 09:30:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:30:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:32:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:32:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:33:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:33:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:34:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:35:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 09:36:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 09:38:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:40:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:40:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 09:42:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:56:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:56:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:56:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:58:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 09:59:21 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-12-07 10:01:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:04:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:04:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 10:07:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 10:08:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 10:09:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-07 10:10:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:11:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:11:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:11:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:12:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:12:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 10:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 10:28:30 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-12-07 10:30:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:33:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:34:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:34:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:34:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 10:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 10:44:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-07 10:54:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:58:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 10:59:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 10:59:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 11:00:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 11:00:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 11:02:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 11:03:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 11:03:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 11:05:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 11:13:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 11:15:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 11:15:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 11:16:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 11:18:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 11:19:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 11:19:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 11:20:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 11:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 11:27:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 11:31:59 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-12-07 11:36:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 11:36:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 11:55:16 --> 404 Page Not Found: City/2
ERROR - 2021-12-07 12:09:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 12:09:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 12:09:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 12:16:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 12:17:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 12:25:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 12:27:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 12:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 12:34:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-07 12:36:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 12:36:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 12:36:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 12:40:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 12:44:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 12:50:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 12:56:46 --> 404 Page Not Found: English/index
ERROR - 2021-12-07 13:01:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:04:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:05:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 13:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 13:14:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 13:17:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:17:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:18:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 13:19:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:20:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:21:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:21:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 13:22:10 --> 404 Page Not Found: Sitemap99289html/index
ERROR - 2021-12-07 13:26:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 13:27:02 --> 404 Page Not Found: Sitemap89111html/index
ERROR - 2021-12-07 13:40:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:40:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:40:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:40:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:41:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:45:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:46:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:46:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 13:49:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 13:49:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 13:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 13:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 14:02:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:05:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:05:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:06:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:06:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 14:07:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:07:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:07:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:08:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:08:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:08:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:09:34 --> 404 Page Not Found: Js/2014417161510129.aspx
ERROR - 2021-12-07 14:09:38 --> 404 Page Not Found: admin/Lib/ueditor
ERROR - 2021-12-07 14:10:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:11:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:12:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 14:15:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 14:17:45 --> 404 Page Not Found: City/1
ERROR - 2021-12-07 14:24:16 --> 404 Page Not Found: Somnus/Somnus.asp
ERROR - 2021-12-07 14:25:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:26:27 --> 404 Page Not Found: admin/Lib/ueditor
ERROR - 2021-12-07 14:38:03 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-12-07 14:39:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 14:40:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 14:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 14:40:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:41:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 14:43:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 14:49:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 14:51:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 14:51:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 14:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:02:11 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-07 15:07:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 15:10:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:11:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:24:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:25:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 15:34:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 15:39:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 15:40:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:40:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:40:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 15:41:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:41:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:41:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 15:41:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-07 15:44:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-07 15:48:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 15:48:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 15:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 16:02:58 --> 404 Page Not Found: Indexphp/index
ERROR - 2021-12-07 16:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 16:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 16:10:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-07 16:13:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:13:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 16:15:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 16:17:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-07 16:18:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:19:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:19:55 --> 404 Page Not Found: admin/Lib/ueditor
ERROR - 2021-12-07 16:22:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:31:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:31:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:33:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 16:33:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-07 16:35:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 16:35:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 16:39:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:40:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:41:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:41:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:47:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:48:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:48:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:48:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:49:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:57:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 16:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 16:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 16:59:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 17:13:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 17:13:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 17:24:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 17:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 17:32:42 --> 404 Page Not Found: Login/index
ERROR - 2021-12-07 17:33:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 17:44:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 17:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 17:46:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 17:48:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 17:48:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 18:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 18:14:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 18:14:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 18:30:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-07 18:34:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 18:38:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 18:40:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 18:40:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 18:41:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 18:54:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 18:54:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 18:54:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 18:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 18:56:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 18:57:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-12-07 19:02:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 19:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 19:07:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 19:08:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 19:08:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 19:19:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 19:37:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 19:44:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 19:45:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 19:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 19:58:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 19:58:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 19:59:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 20:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 20:16:12 --> 404 Page Not Found: Rosoft/overfill
ERROR - 2021-12-07 20:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 20:28:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 20:38:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 20:44:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 20:49:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 20:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 20:51:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 20:52:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 20:58:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 21:04:18 --> 404 Page Not Found: Rosoft/overfill
ERROR - 2021-12-07 21:10:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 21:12:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 21:12:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 21:12:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 21:13:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 21:13:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 21:20:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 21:21:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 21:22:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 21:25:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 21:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 21:28:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 21:30:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 21:40:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 21:40:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 21:41:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 21:45:19 --> 404 Page Not Found: City/index
ERROR - 2021-12-07 21:47:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 21:49:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 21:57:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-12-07 21:57:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 21:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 21:59:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 22:04:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 22:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 22:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 22:10:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 22:10:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 22:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 22:13:22 --> 404 Page Not Found: admin/Lib/ueditor
ERROR - 2021-12-07 22:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 22:35:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 22:38:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 22:38:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 22:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 22:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 22:45:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 22:48:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 22:51:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 22:58:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-12-07 23:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 23:00:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-07 23:08:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-12-07 23:16:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 23:20:41 --> 404 Page Not Found: City/16
ERROR - 2021-12-07 23:40:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 23:40:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 23:41:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-12-07 23:50:18 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-12-07 23:53:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 23:53:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-12-07 23:58:50 --> 404 Page Not Found: Faviconico/index
