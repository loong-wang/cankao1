<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-07 00:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:05:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-07 00:05:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:06:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:08:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:10:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:12:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:14:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 00:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 00:20:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 00:23:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 00:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 00:24:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:25:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:27:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:27:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 00:32:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:33:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:34:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:35:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:35:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:36:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:37:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:37:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:39:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:44:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:45:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:45:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:46:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 00:46:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 00:46:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:46:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 00:46:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 00:46:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:46:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 00:47:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 00:47:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 00:47:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:47:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 00:50:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:51:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:51:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:53:56 --> Severity: Warning --> Missing argument 1 for Taocan::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 21
ERROR - 2022-02-07 00:54:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:54:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 00:54:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:56:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:57:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:58:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:58:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:58:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 00:59:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 01:12:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 01:24:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 01:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 01:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 01:53:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 02:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 02:07:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 02:17:20 --> 404 Page Not Found: Index/index
ERROR - 2022-02-07 02:18:13 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2022-02-07 02:24:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 02:28:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 02:33:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 02:35:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 02:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 02:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 02:54:16 --> 404 Page Not Found: English/index
ERROR - 2022-02-07 02:59:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 03:15:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 03:24:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 03:35:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 03:45:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 03:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 03:48:33 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-07 03:48:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 03:49:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 03:49:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 03:49:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 03:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 03:53:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 03:53:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 03:55:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 03:55:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 03:56:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 04:06:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 04:14:15 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-07 04:14:16 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-07 04:14:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 04:14:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 04:14:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 04:14:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 04:14:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 04:14:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 04:14:16 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-07 04:14:16 --> 404 Page Not Found: Member/space
ERROR - 2022-02-07 04:14:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 04:14:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 04:14:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 04:14:17 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-07 04:14:18 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-07 04:14:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 04:14:18 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-07 04:14:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 04:14:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 04:14:18 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-07 04:14:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 04:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 04:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 04:33:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 04:33:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 04:34:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 04:34:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 04:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 04:36:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 04:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 04:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 04:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 04:56:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 04:56:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 04:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 05:01:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 05:31:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 05:50:23 --> 404 Page Not Found: Wxxcx/crgt
ERROR - 2022-02-07 05:51:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 05:51:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 05:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 06:11:20 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 06:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 06:34:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 06:39:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 06:48:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 06:52:04 --> 404 Page Not Found: App/views
ERROR - 2022-02-07 06:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 06:59:59 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-07 06:59:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 07:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 07:00:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 07:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 07:33:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 07:38:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 07:39:46 --> 404 Page Not Found: City/1
ERROR - 2022-02-07 07:44:32 --> 404 Page Not Found: City/2
ERROR - 2022-02-07 07:44:42 --> 404 Page Not Found: City/18
ERROR - 2022-02-07 07:44:44 --> 404 Page Not Found: City/19
ERROR - 2022-02-07 07:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 07:49:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 07:55:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-07 07:57:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 08:07:30 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-07 08:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 08:21:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 08:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 08:25:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 08:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 08:31:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 08:36:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 08:38:14 --> 404 Page Not Found: Staff/index
ERROR - 2022-02-07 08:38:14 --> 404 Page Not Found: Tos/index
ERROR - 2022-02-07 08:38:14 --> 404 Page Not Found: Sharehtml/index
ERROR - 2022-02-07 08:43:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 08:43:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 08:46:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 08:48:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 08:48:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 08:48:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 08:49:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 08:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 09:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 09:06:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 09:09:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 09:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 09:13:04 --> 404 Page Not Found: Login/index
ERROR - 2022-02-07 09:13:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 09:20:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 09:21:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 09:22:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 09:28:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 09:28:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 09:37:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 09:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 09:42:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 09:42:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 09:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 09:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 09:57:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 09:57:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 09:58:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 09:59:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 10:03:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 10:05:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 10:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 10:07:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 10:08:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 10:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 10:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 10:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 10:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 10:41:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 10:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 10:58:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 10:58:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 10:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:00:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:00:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:01:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:02:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:03:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:05:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:05:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:06:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:06:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:07:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 11:09:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:10:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:21:49 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-02-07 11:29:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:30:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:39:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:40:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:49:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:50:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:51:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 11:56:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:56:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:57:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 11:57:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 12:13:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 12:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 12:13:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 12:14:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 12:14:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 12:23:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 12:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 12:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 12:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 12:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 12:40:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 12:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 12:48:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 12:55:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 12:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 12:57:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 12:57:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 12:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 13:04:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 13:09:28 --> 404 Page Not Found: Ipquery/index
ERROR - 2022-02-07 13:09:28 --> 404 Page Not Found: Ipquery/index
ERROR - 2022-02-07 13:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 13:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 13:15:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 13:28:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 13:35:20 --> 404 Page Not Found: English/index
ERROR - 2022-02-07 13:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 13:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 13:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 13:41:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 13:42:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 13:44:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 13:52:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 13:56:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 13:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 14:08:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 14:08:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 14:12:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 14:13:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 14:14:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 14:14:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 14:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 14:37:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 14:37:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 14:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 14:41:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 14:47:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 14:50:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 14:51:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 14:51:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 14:51:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 14:51:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 14:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 14:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 14:55:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 14:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 14:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 14:58:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 15:00:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 15:00:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:01:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:04:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 15:16:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:17:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 15:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 15:18:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:22:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:23:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:24:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 15:25:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:25:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:28:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:29:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:40:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 15:46:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 15:48:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 15:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 15:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 15:55:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 15:55:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 15:57:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 15:57:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 15:59:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 16:01:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 16:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 16:18:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 16:18:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 16:36:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 16:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 16:38:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 16:40:01 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 16:40:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 16:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 16:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 16:47:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 16:47:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 16:48:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 16:49:24 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2022-02-07 16:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 16:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 16:52:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 16:56:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 16:56:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 16:56:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 16:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 16:58:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 16:58:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 17:01:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 17:03:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:03:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:03:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:03:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:04:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:04:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:06:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:06:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:06:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 17:07:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:07:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:07:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:07:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:08:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 17:08:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 17:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 17:08:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-07 17:21:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 17:23:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-07 17:23:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-07 17:23:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-07 17:34:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:35:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 17:38:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 17:38:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:40:24 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-07 17:40:39 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-07 17:41:02 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-07 17:41:16 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-07 17:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:50:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 17:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 17:59:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 17:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 18:14:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 18:17:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 18:18:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 18:19:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 18:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 18:27:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 18:38:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 18:49:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 18:56:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 18:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 19:01:39 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 19:15:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-07 19:16:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:16:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 19:16:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:17:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:18:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:19:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 19:19:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:20:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 19:20:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:20:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:21:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:21:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:22:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:22:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:23:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:23:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 19:31:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 19:41:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 19:45:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 19:58:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 20:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 20:03:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 20:06:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 20:06:31 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 20:12:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 20:15:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 20:23:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 20:31:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 20:33:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-07 20:37:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 20:38:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 20:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 20:56:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 20:58:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 20:58:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 20:59:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 20:59:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 20:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 20:59:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 21:10:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 21:11:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:11:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:12:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:12:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:12:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:12:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-07 21:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 21:14:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:14:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:14:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 21:15:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 21:16:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:16:34 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-07 21:16:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:17:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:18:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:18:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:19:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:20:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:21:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:21:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:22:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:22:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:23:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:23:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 21:24:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:26:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:29:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:30:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:31:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:32:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:32:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:33:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:33:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:34:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 21:38:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:41:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 21:43:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:44:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 21:51:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 21:52:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 21:56:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 21:57:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-07 22:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 22:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 22:05:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 22:10:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 22:16:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:18:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:18:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 22:18:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:24:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:30:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:30:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:31:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 22:32:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 22:33:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 22:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 22:42:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 22:42:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:46:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:48:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:50:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:54:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 22:58:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 22:59:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:59:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 22:59:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:00:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-07 23:00:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:00:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:00:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:00:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 23:05:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 23:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:12:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:14:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 23:16:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:16:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:16:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:16:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:17:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:17:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 23:17:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:17:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:20:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-07 23:21:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:22:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:22:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:22:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:23:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:23:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:23:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:24:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:46:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:51:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:54:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-07 23:54:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-07 23:55:46 --> 404 Page Not Found: Robotstxt/index
