<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-21 00:04:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 00:04:46 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-21 00:04:46 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-21 00:04:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 00:04:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 00:04:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 00:04:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 00:04:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 00:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 00:04:47 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-21 00:04:47 --> 404 Page Not Found: Member/space
ERROR - 2022-01-21 00:04:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 00:04:50 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 00:04:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 00:04:50 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 00:04:50 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 00:04:52 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 00:04:52 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-21 00:04:52 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 00:04:52 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 00:04:52 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 00:04:52 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 00:04:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 00:05:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 00:05:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 00:07:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 00:24:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 00:24:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 00:25:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 00:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 00:36:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 00:36:36 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 00:54:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 00:56:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 01:01:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:06:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 01:07:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 01:13:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 01:14:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 01:25:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 01:32:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 01:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 01:36:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 01:37:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 01:39:31 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-21 01:39:31 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Member/space
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 01:39:32 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Member/space
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-21 01:51:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:51:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 01:51:28 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 01:51:28 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 02:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 02:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 02:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 02:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 02:24:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 02:29:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 02:29:29 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 02:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 02:32:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 02:33:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-01-21 02:33:48 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 02:34:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 02:36:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 02:37:37 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 02:37:40 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 02:38:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 02:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 02:41:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 02:46:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 02:46:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 02:50:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 02:50:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 02:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 02:51:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 02:53:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 03:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 03:09:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 03:16:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 03:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 03:22:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 03:24:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 03:26:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 03:31:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 03:38:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 03:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 03:56:20 --> 404 Page Not Found: Index/index
ERROR - 2022-01-21 03:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 03:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 04:15:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 04:21:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 04:29:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 04:30:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 04:55:54 --> 404 Page Not Found: Inc/AspCms_AdvJs.asp
ERROR - 2022-01-21 04:55:54 --> 404 Page Not Found: Inc/AspCms_AdvJs.asp
ERROR - 2022-01-21 05:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 05:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 05:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 05:28:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 05:34:40 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 05:35:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 05:45:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 05:45:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 05:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 05:47:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 05:49:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 05:57:20 --> 404 Page Not Found: Static/admin
ERROR - 2022-01-21 06:23:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 06:24:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 06:24:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 06:24:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 06:24:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 06:24:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 06:25:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 06:25:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 06:28:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 06:29:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 06:30:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 06:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 06:47:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 06:47:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 06:49:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 06:49:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 07:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 07:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 07:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 07:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 07:16:31 --> 404 Page Not Found: Boaform/admin
ERROR - 2022-01-21 07:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 07:18:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 07:25:39 --> 404 Page Not Found: Static/admin
ERROR - 2022-01-21 07:31:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 07:32:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:33:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:33:19 --> 404 Page Not Found: City/16
ERROR - 2022-01-21 07:33:19 --> 404 Page Not Found: City/16
ERROR - 2022-01-21 07:33:19 --> 404 Page Not Found: City/16
ERROR - 2022-01-21 07:33:21 --> 404 Page Not Found: City/16
ERROR - 2022-01-21 07:33:24 --> 404 Page Not Found: City/16
ERROR - 2022-01-21 07:33:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:33:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:33:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:34:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 07:35:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:36:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:36:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:37:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:43:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 07:49:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:49:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:49:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 07:51:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 07:59:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 07:59:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 08:03:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 08:21:42 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-21 08:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 08:25:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 08:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 08:26:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 08:26:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 08:27:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 08:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 08:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 08:40:00 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2022-01-21 08:44:13 --> 404 Page Not Found: App/views
ERROR - 2022-01-21 08:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 08:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 08:59:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 09:07:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 09:12:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 09:13:36 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-21 09:13:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 09:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 09:37:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 09:39:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 09:42:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 09:47:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 09:47:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 09:48:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 09:54:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 09:55:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 09:57:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 09:59:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 09:59:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 09:59:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:00:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 10:03:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:05:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:07:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 10:10:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 10:19:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 10:21:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:21:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 10:24:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:24:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 10:26:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:29:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:30:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 10:34:09 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2022-01-21 10:34:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:37:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 10:43:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:44:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 10:44:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:47:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:48:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:51:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 10:51:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 10:53:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 11:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 11:08:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:13:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:14:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:15:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 11:21:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 11:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 11:24:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 11:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 11:42:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:48:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 11:48:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:51:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:55:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:56:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:56:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:56:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:56:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:57:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:57:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:58:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:58:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 11:58:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 11:58:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:00:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:00:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:00:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:01:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:10:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:11:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:11:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:13:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 12:14:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 12:16:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 12:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 12:20:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:20:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:21:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:22:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:35:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 12:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 12:41:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 12:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:42:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:45:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:46:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:47:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:47:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:47:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:47:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:47:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:47:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:47:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:47:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:47:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:48:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:48:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:49:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:49:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:49:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 12:50:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:52:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:53:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:59:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 12:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 13:00:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 13:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 13:04:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 13:04:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 13:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 13:10:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 13:11:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 13:13:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 13:14:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 13:17:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 13:19:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 13:24:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 13:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 13:43:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 13:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 13:57:30 --> 404 Page Not Found: Text4041642744650/index
ERROR - 2022-01-21 13:57:30 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-21 13:57:30 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-21 13:57:30 --> 404 Page Not Found: Sdk/index
ERROR - 2022-01-21 13:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 14:01:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 14:02:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:02:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:02:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:04:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:06:58 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-21 14:06:58 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Member/space
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 14:07:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:08:08 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-21 14:08:08 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-21 14:08:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:08:08 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:08:08 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:08:08 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:08:08 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 14:08:08 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-21 14:08:09 --> 404 Page Not Found: Member/space
ERROR - 2022-01-21 14:08:09 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:08:10 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:08:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:08:10 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 14:08:11 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 14:08:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:08:11 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-21 14:08:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:08:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:08:11 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-21 14:08:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 14:16:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:16:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:24:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:24:56 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2022-01-21 14:27:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 14:36:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:36:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 14:39:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:42:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 14:43:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:46:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 14:47:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:47:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:48:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:48:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:49:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:57:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:58:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:58:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 14:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 14:59:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:05:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:17:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 15:22:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:24:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:24:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 15:26:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 15:29:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:31:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 15:34:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-01-21 15:34:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 15:36:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:37:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 15:37:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:41:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 15:44:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:44:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:45:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 15:46:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 15:51:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:53:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:56:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 15:56:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 16:00:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 16:06:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 16:09:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 16:12:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 16:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 16:22:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 16:23:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 16:30:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 16:30:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 16:30:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 16:31:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 16:31:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 16:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 16:36:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 16:41:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 16:49:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 16:49:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 16:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 16:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 16:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:03:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 17:04:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 17:10:56 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 17:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 17:22:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:30:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 17:30:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 17:40:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 17:41:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:48:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:48:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:49:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:49:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:49:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:52:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:52:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:52:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:52:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:52:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:52:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:53:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 17:53:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 18:05:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 18:10:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 18:14:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 18:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 18:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 18:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 18:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 18:47:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 18:50:17 --> 404 Page Not Found: Inc/AspCms_AdvJs.asp
ERROR - 2022-01-21 19:18:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 19:19:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 19:30:34 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2022-01-21 19:33:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 19:34:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 19:34:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 19:35:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 19:35:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 19:38:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 19:40:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 19:40:58 --> 404 Page Not Found: Static/admin
ERROR - 2022-01-21 19:41:18 --> 404 Page Not Found: Static/admin
ERROR - 2022-01-21 19:41:18 --> 404 Page Not Found: Indexphp/index
ERROR - 2022-01-21 19:41:18 --> 404 Page Not Found: Indexphp/index
ERROR - 2022-01-21 19:41:19 --> 404 Page Not Found: Haoma/static
ERROR - 2022-01-21 19:41:23 --> 404 Page Not Found: Haoma/index.php
ERROR - 2022-01-21 19:41:25 --> 404 Page Not Found: Haoma/index.php
ERROR - 2022-01-21 19:41:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 19:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 19:43:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 19:43:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 19:46:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 19:53:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 20:01:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 20:02:17 --> 404 Page Not Found: Sdk/index
ERROR - 2022-01-21 20:02:17 --> 404 Page Not Found: Text4041642766537/index
ERROR - 2022-01-21 20:02:17 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-21 20:02:17 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-21 20:02:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 20:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 20:05:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 20:05:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 20:06:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 20:06:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 20:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 20:23:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 20:31:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 20:34:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 20:35:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 20:37:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 20:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 20:53:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 20:55:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 20:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 20:56:29 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2022-01-21 20:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 20:58:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 21:03:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 21:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 21:07:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 21:09:08 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-01-21 21:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 21:12:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 21:17:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 21:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 21:20:40 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 21:24:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 21:27:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 21:28:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 21:35:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 21:37:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 21:37:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 21:40:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 21:44:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 21:44:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 21:49:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 21:49:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 21:49:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 21:52:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 21:53:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 21:53:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 21:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 22:10:05 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 22:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 22:23:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 22:41:13 --> 404 Page Not Found: City/1
ERROR - 2022-01-21 22:41:17 --> 404 Page Not Found: City/1
ERROR - 2022-01-21 22:41:17 --> 404 Page Not Found: City/1
ERROR - 2022-01-21 22:41:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 22:42:04 --> 404 Page Not Found: City/1
ERROR - 2022-01-21 22:42:28 --> 404 Page Not Found: City/1
ERROR - 2022-01-21 22:52:34 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-21 22:53:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 23:05:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:05:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:05:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:06:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:07:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 23:07:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:08:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:08:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:09:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 23:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 23:26:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:26:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 23:26:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:26:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:26:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-21 23:26:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:26:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:26:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:26:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:26:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:26:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:26:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:27:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-21 23:29:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:29:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 23:30:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:31:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:33:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-21 23:36:41 --> 404 Page Not Found: Ip/index
ERROR - 2022-01-21 23:36:41 --> 404 Page Not Found: Ip/index
ERROR - 2022-01-21 23:42:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:42:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:42:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:43:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:43:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:44:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:44:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-21 23:45:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
