<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-25 00:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 00:01:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 00:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:01:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:03:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:12:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:15:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 00:19:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 00:19:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:20:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:21:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:21:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:23:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:24:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:25:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:25:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:25:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 00:26:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:27:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 00:33:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:35:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:35:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:37:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 00:58:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 01:02:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 01:05:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 01:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:09:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:12:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:13:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:14:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:15:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:25:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 01:28:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:28:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:28:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:29:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:30:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:31:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 01:38:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 01:43:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 01:44:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:50:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 01:58:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 01:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 02:04:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 02:09:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 02:11:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 02:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 02:17:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 02:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 02:34:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 02:36:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 02:38:31 --> 404 Page Not Found: City/2
ERROR - 2022-02-25 02:45:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 02:45:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 02:50:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 02:55:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 03:01:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 03:07:07 --> 404 Page Not Found: App/views
ERROR - 2022-02-25 03:07:07 --> 404 Page Not Found: App/views
ERROR - 2022-02-25 03:07:07 --> 404 Page Not Found: App/views
ERROR - 2022-02-25 03:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 03:23:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 03:25:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 03:32:17 --> 404 Page Not Found: City/index
ERROR - 2022-02-25 03:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 03:49:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 03:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:06:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:07:20 --> 404 Page Not Found: Content/js
ERROR - 2022-02-25 04:12:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:15:48 --> 404 Page Not Found: App/views
ERROR - 2022-02-25 04:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:33:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:35:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:39:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:43:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:46:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:54:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:55:01 --> 404 Page Not Found: City/15
ERROR - 2022-02-25 04:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 04:57:08 --> 404 Page Not Found: Controls/Ueditor
ERROR - 2022-02-25 05:06:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 05:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 05:23:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 05:31:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 05:31:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 05:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 05:37:10 --> 404 Page Not Found: 16/10000
ERROR - 2022-02-25 05:53:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 05:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 05:57:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 06:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 06:01:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 06:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 06:27:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 06:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 07:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 07:06:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 07:11:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 07:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 07:19:02 --> 404 Page Not Found: Sitemap40993html/index
ERROR - 2022-02-25 07:31:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 07:33:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 07:37:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 08:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 08:07:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 08:07:40 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-25 08:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 08:14:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 08:20:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-25 08:21:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 08:22:20 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-25 08:24:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 08:29:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 08:29:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:30:16 --> 404 Page Not Found: 1/10000
ERROR - 2022-02-25 08:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 08:58:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:58:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 08:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 09:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 09:01:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 09:03:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 09:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 09:16:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 09:17:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 09:24:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 09:26:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 09:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 09:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 09:57:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 09:58:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 09:59:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 10:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 10:07:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 10:09:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 10:13:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 10:13:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 10:17:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 10:20:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 10:20:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 10:21:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 10:21:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 10:22:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 10:23:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 10:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 10:26:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 10:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 10:31:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 10:32:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 10:34:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 10:35:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 10:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 11:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 11:05:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 11:08:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 11:08:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:12:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 11:19:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 11:19:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 11:21:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:21:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:23:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:24:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 11:26:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:26:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 11:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:27:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:27:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:30:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 11:31:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:31:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:32:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:37:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:38:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:39:05 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-25 11:54:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:55:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 11:59:34 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-25 12:00:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 12:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 12:07:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:08:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:09:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:09:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:09:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:10:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:10:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:18:04 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-25 12:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 12:21:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 12:22:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:22:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 12:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 12:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 12:29:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:29:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:31:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 12:32:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 12:32:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 12:32:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 12:32:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 12:32:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:32:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 12:32:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 12:32:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 12:34:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-25 12:37:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 12:41:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:43:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:44:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 12:46:46 --> 404 Page Not Found: App/views
ERROR - 2022-02-25 12:46:46 --> 404 Page Not Found: App/views
ERROR - 2022-02-25 12:46:46 --> 404 Page Not Found: App/views
ERROR - 2022-02-25 12:56:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 13:05:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 13:06:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 13:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 13:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 13:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 13:12:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 13:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 13:23:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 13:25:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 13:25:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 13:25:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 13:26:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 13:26:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 13:27:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 13:34:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 13:34:50 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2022-02-25 13:41:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 13:42:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 13:42:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 13:57:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 13:57:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 13:57:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 14:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 14:01:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 14:01:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 14:01:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 14:03:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 14:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 14:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 14:16:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 14:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 14:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 14:30:34 --> 404 Page Not Found: Style/images
ERROR - 2022-02-25 14:30:34 --> 404 Page Not Found: Style/images
ERROR - 2022-02-25 14:30:34 --> 404 Page Not Found: Style/images
ERROR - 2022-02-25 14:30:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 14:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 14:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 14:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 14:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 14:56:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 15:01:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 15:02:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 15:02:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 15:05:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 15:08:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 15:17:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 15:17:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 15:17:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 15:17:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 15:18:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 15:18:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 15:18:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 15:19:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 15:36:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 15:36:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 15:36:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 15:37:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 15:49:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 15:52:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 15:52:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 15:52:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 16:02:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 16:02:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 16:08:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 16:15:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 16:15:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 16:28:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 16:28:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 16:33:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 16:33:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 16:49:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 16:49:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 17:04:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 17:04:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 17:06:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 17:08:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 17:08:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 17:13:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 17:20:10 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2022-02-25 17:20:13 --> 404 Page Not Found: City/1
ERROR - 2022-02-25 17:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 17:24:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 17:27:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 17:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 17:34:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 17:50:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 17:51:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 17:51:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 17:53:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 17:54:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 17:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 18:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 18:04:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 18:16:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:16:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:27:06 --> 404 Page Not Found: App/views
ERROR - 2022-02-25 18:27:06 --> 404 Page Not Found: App/views
ERROR - 2022-02-25 18:27:06 --> 404 Page Not Found: App/views
ERROR - 2022-02-25 18:29:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:31:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:31:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:34:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:36:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:37:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:39:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:41:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:45:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 18:45:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 18:46:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 18:50:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:50:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:50:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 18:52:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 19:14:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 19:22:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 19:28:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 19:44:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 19:44:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 19:45:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 19:56:13 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-25 20:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 20:02:47 --> 404 Page Not Found: City/1
ERROR - 2022-02-25 20:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 20:22:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 20:24:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 20:26:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 20:26:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 20:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 20:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 20:36:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 20:37:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 20:37:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 20:37:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 20:40:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 20:42:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 20:43:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 20:44:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 20:44:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 20:44:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 20:44:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 20:44:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 20:44:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 20:59:00 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2022-02-25 20:59:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 20:59:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:00:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:01:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:01:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 21:02:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:05:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:05:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:08:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 21:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 21:14:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:15:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:15:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:18:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:18:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:19:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 21:19:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 21:20:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:26:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 21:27:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 21:30:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:40:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 21:40:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 21:50:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 21:53:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-25 21:55:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 21:59:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:00:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 22:01:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 22:02:22 --> 404 Page Not Found: Ask/101
ERROR - 2022-02-25 22:02:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 22:09:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 22:09:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:16:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:16:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 22:22:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:22:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:28:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:28:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 22:30:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:39:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-25 22:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 22:59:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 23:07:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 23:27:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 23:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-25 23:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 23:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 23:50:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-25 23:53:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
