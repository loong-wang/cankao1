<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-09 00:00:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 00:01:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 00:02:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 00:02:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 00:03:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 00:03:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 00:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 00:05:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 00:06:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 00:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 00:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 00:26:30 --> 404 Page Not Found: App_lib/index
ERROR - 2022-03-09 00:26:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-09 00:26:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 00:35:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 00:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 00:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 00:52:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 00:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 00:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 00:56:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 01:00:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 01:00:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 01:03:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 01:07:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 01:08:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 01:10:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 01:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 01:23:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:24:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:29:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:30:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 01:30:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:30:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 01:30:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:31:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 01:31:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:31:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 01:31:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:31:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 01:31:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:32:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 01:32:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:32:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:32:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:32:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:32:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:32:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:32:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:42:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 01:46:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:46:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:46:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:47:36 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-03-09 01:47:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:47:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:48:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 01:48:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 02:01:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:04:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:04:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:09:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 02:11:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:14:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:14:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:15:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 02:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 02:21:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:24:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:24:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:28:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:28:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:31:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 02:38:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:41:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:41:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:44:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:47:22 --> 404 Page Not Found: App/views
ERROR - 2022-03-09 02:51:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:54:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 02:54:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:01:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:02:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:04:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:08:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:11:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:14:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:21:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:21:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:21:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 03:24:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:28:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:31:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:32:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 03:34:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:34:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:38:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:41:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:44:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:48:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:50:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 03:51:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:54:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 03:54:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:54:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 03:57:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 04:04:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:04:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:08:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:11:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:11:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:14:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:20:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 04:21:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:21:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:24:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:31:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 04:34:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:38:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:41:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:44:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 04:50:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 04:51:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:51:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 04:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 05:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 05:09:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 05:10:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 05:12:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 05:20:34 --> 404 Page Not Found: Cdn-cgi/trace
ERROR - 2022-03-09 05:25:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 05:48:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 05:48:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 05:58:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 06:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 06:02:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 06:02:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 06:07:04 --> 404 Page Not Found: App/views
ERROR - 2022-03-09 06:07:04 --> 404 Page Not Found: App/views
ERROR - 2022-03-09 06:07:04 --> 404 Page Not Found: App/views
ERROR - 2022-03-09 06:19:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 06:22:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 06:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 06:31:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 06:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 06:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 06:48:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 06:56:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 07:04:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 07:04:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 07:04:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 07:08:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 07:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 07:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 07:33:27 --> 404 Page Not Found: App/views
ERROR - 2022-03-09 07:33:27 --> 404 Page Not Found: App/views
ERROR - 2022-03-09 07:33:28 --> 404 Page Not Found: App/views
ERROR - 2022-03-09 07:35:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 07:42:34 --> 404 Page Not Found: App/264898.html
ERROR - 2022-03-09 07:43:32 --> 404 Page Not Found: A/328003523_120148746
ERROR - 2022-03-09 07:44:28 --> 404 Page Not Found: Xiaoxue/dushubiji
ERROR - 2022-03-09 07:45:04 --> 404 Page Not Found: Shenghuojiaju/shenghuochangshi
ERROR - 2022-03-09 07:51:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 07:51:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 07:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 08:01:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 08:04:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 08:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 08:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 08:15:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 08:17:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 08:29:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:29:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:30:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:33:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:34:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:34:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:35:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:35:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 08:52:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:53:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:53:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:55:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:56:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:56:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:56:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:56:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 08:57:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:04:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 09:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 09:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 09:29:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 09:31:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 09:34:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 09:35:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 09:36:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:39:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 09:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 09:52:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:52:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:53:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 09:53:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:53:30 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-09 09:53:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:54:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:54:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 09:54:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:55:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:55:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 09:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:55:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:55:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 09:56:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:57:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 09:57:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 09:59:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:00:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 10:00:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:01:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:01:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 10:06:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 10:09:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 10:09:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 10:09:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 10:10:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:11:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:12:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:12:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:13:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:13:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:14:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 10:19:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 10:20:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 10:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:30:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:34:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 10:37:19 --> 404 Page Not Found: City/16
ERROR - 2022-03-09 10:38:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:46:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 10:46:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 10:51:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 10:51:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 10:51:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 10:59:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 11:01:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 11:04:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 11:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 11:09:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 11:10:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 11:10:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 11:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 11:20:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 11:20:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 11:23:22 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-03-09 11:41:57 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-09 11:55:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 11:55:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 11:55:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 12:02:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 12:04:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 12:04:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 12:14:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 12:17:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 12:18:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 12:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 12:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 12:43:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 12:44:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 12:46:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 12:47:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 12:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 12:48:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 12:53:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 12:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 12:54:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 12:54:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 12:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 13:16:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 13:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 13:25:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:27:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:29:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 13:32:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 13:37:08 --> 404 Page Not Found: Cdn-cgi/trace
ERROR - 2022-03-09 13:48:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:48:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:50:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:50:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:52:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:53:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:53:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:53:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:54:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:54:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:54:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:54:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:54:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:54:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:55:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:56:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:56:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:57:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:57:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:57:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 13:58:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 14:01:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 14:01:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 14:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 14:01:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 14:02:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 14:02:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 14:05:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 14:06:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 14:11:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 14:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 14:15:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 14:18:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 14:32:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 14:33:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 14:33:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 14:36:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 14:43:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 14:45:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 14:47:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 14:49:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 14:49:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 14:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 14:56:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-09 15:01:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 15:02:29 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-03-09 15:02:44 --> 404 Page Not Found: City/17
ERROR - 2022-03-09 15:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 15:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 15:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 15:18:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-03-09 15:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 15:23:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 15:29:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 15:29:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 15:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 15:39:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 15:40:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 15:41:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 15:42:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 15:42:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 15:46:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 15:48:29 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-03-09 15:49:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 15:51:08 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2022-03-09 15:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 15:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 16:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 16:13:11 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-03-09 16:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 16:16:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 16:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 16:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 16:22:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 16:22:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 16:23:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 16:38:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 16:39:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 16:39:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 16:39:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 16:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 16:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 16:53:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 16:54:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 16:56:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:01:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 17:04:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:05:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:05:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:05:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:06:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:06:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:06:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:07:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:08:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:08:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:09:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:10:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:10:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:12:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 17:17:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:19:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 17:24:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:25:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:25:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:25:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:25:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:29:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 17:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 17:37:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:39:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:40:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:45:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 17:45:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 17:46:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 17:46:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:47:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:48:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 17:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 18:02:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 18:03:21 --> 404 Page Not Found: City/1
ERROR - 2022-03-09 18:10:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 18:12:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 18:14:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 18:15:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 18:17:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 18:17:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 18:17:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 18:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 18:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 18:28:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 18:28:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 18:28:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 18:28:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 18:31:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 18:32:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 18:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 18:41:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 18:45:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 18:46:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 18:51:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 18:52:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 18:57:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 19:13:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 19:13:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 19:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:13:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 19:14:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 19:14:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:14:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 19:14:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 19:14:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 19:15:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:18:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:20:13 --> 404 Page Not Found: Boaform/admin
ERROR - 2022-03-09 19:21:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 19:33:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:33:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:33:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:33:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:33:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:34:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:34:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:36:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:36:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:36:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:40:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:41:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:42:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:49:41 --> 404 Page Not Found: English/index
ERROR - 2022-03-09 19:51:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:51:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:52:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:53:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 19:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 20:01:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 20:13:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 20:17:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 20:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 20:36:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-09 20:38:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 20:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 20:50:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 21:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 21:26:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 21:31:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 21:33:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 21:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 21:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 21:43:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 21:43:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 21:44:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 21:46:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 21:47:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 21:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 21:59:54 --> 404 Page Not Found: 11/index
ERROR - 2022-03-09 21:59:55 --> 404 Page Not Found: 11/index
ERROR - 2022-03-09 22:16:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 22:17:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 22:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 22:19:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 22:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 22:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 22:37:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 22:42:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-03-09 23:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 23:04:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 23:08:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 23:14:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 23:17:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 23:18:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 23:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 23:35:23 --> 404 Page Not Found: City/2
ERROR - 2022-03-09 23:45:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-03-09 23:54:09 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-03-09 23:55:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 23:56:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-03-09 23:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
