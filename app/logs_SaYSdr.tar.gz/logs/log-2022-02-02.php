<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-02 00:01:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 00:02:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-02 00:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 00:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 00:07:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 00:12:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:12:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:13:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 00:17:29 --> 404 Page Not Found: City/15
ERROR - 2022-02-02 00:17:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 00:21:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:22:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:23:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:23:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 00:23:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:24:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:24:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:25:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:25:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:25:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:25:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:25:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:25:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:26:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:26:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:26:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:27:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:28:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:29:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:30:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:30:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:30:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:31:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:32:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:34:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:34:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:35:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:35:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:35:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:36:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:37:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 00:37:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:38:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:38:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 00:38:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:39:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:40:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 00:43:49 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-02 00:43:49 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-02 00:43:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 00:43:49 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 00:43:49 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 00:43:49 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 00:43:49 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 00:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 00:43:49 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-02 00:43:52 --> 404 Page Not Found: Member/space
ERROR - 2022-02-02 00:43:52 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 00:43:52 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 00:43:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 00:43:52 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-02 00:43:52 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-02 00:43:54 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 00:43:54 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-02 00:43:54 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 00:43:54 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 00:43:57 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-02 00:43:57 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 01:01:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-02 01:02:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-02 01:10:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 01:20:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 01:21:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 01:22:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 01:24:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 01:25:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 01:30:46 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2022-02-02 01:35:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 01:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 01:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 01:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 02:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 02:04:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:04:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:04:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:06:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:12:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:12:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:13:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:14:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:24:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:26:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:28:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 02:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 02:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 02:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 02:41:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 02:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 02:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 02:54:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 03:04:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 03:07:18 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-02 03:07:18 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-02 03:07:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 03:07:21 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 03:07:21 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 03:07:21 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 03:07:21 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 03:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 03:07:21 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-02 03:07:21 --> 404 Page Not Found: Member/space
ERROR - 2022-02-02 03:07:21 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 03:07:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 03:07:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 03:07:24 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-02 03:07:24 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-02 03:07:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 03:07:27 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-02 03:07:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 03:07:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 03:07:27 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-02 03:07:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 03:09:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 03:09:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 03:17:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 03:19:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 03:33:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 03:33:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 03:33:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-02 03:39:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 03:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 03:40:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 04:01:02 --> Severity: Warning --> file_get_contents(/www/wwwroot/www.xuanhao.net/app/cache/cityt1): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/system/libraries/Cache/drivers/Cache_file.php 277
ERROR - 2022-02-02 04:01:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-02 04:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 04:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 04:14:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-02 04:16:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 04:31:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 04:34:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 04:40:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 04:41:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 04:50:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 04:51:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 04:58:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:04:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 05:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:10:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 05:12:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:20:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:27:01 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-02 05:27:01 --> 404 Page Not Found: admin//index
ERROR - 2022-02-02 05:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:27:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 05:27:02 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-02 05:27:03 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-02-02 05:27:03 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-02-02 05:27:04 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-02-02 05:27:04 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-02-02 05:27:04 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-02-02 05:27:04 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-02 05:27:04 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-02 05:27:04 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-02 05:27:04 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-02 05:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:43:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 05:48:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 06:04:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 06:07:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 06:16:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 06:17:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 06:18:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 06:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 06:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 06:59:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 07:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 07:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 07:15:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 07:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 07:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 07:32:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 07:46:39 --> 404 Page Not Found: Zl/190313
ERROR - 2022-02-02 07:49:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 07:49:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 07:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 08:04:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 08:15:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 08:20:47 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-02 08:25:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 08:30:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 08:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 08:36:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 08:37:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 08:37:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 08:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 08:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 08:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 08:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 09:10:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 09:12:25 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-02 09:12:25 --> 404 Page Not Found: admin//index
ERROR - 2022-02-02 09:12:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 09:12:26 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-02 09:12:26 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-02 09:12:26 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-02 09:12:26 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-02 09:12:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 09:18:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 09:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 09:39:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 09:50:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:03:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:16:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:17:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 10:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:21:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 10:22:53 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-02 10:22:53 --> 404 Page Not Found: admin//index
ERROR - 2022-02-02 10:22:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:22:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 10:22:54 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-02 10:22:54 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-02-02 10:22:55 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-02-02 10:22:56 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-02-02 10:22:56 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-02-02 10:22:56 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-02-02 10:22:56 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-02 10:22:56 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-02 10:22:56 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-02 10:22:57 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-02 10:25:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:28:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 10:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:40:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:40:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 10:49:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 10:53:00 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-02 10:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 10:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 11:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 11:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 11:15:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 11:16:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 11:16:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 11:19:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 11:20:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 11:21:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 11:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 11:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 11:26:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 11:32:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 11:36:36 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-02 11:36:36 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-02 11:36:36 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-02 11:36:36 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-02 11:36:36 --> 404 Page Not Found: Inc/md5.asp
ERROR - 2022-02-02 11:36:36 --> 404 Page Not Found: Inc/config.asp
ERROR - 2022-02-02 11:36:36 --> 404 Page Not Found: Config/AspCms_Config.asp
ERROR - 2022-02-02 11:36:36 --> 404 Page Not Found: Include/Functionl.asp
ERROR - 2022-02-02 11:36:37 --> 404 Page Not Found: Conconasp/index
ERROR - 2022-02-02 11:36:37 --> 404 Page Not Found: Include/base64.asp
ERROR - 2022-02-02 11:36:37 --> 404 Page Not Found: Data/data.asp
ERROR - 2022-02-02 11:36:37 --> 404 Page Not Found: Inc/config.asp
ERROR - 2022-02-02 11:36:38 --> 404 Page Not Found: Sitemap/templates
ERROR - 2022-02-02 11:36:38 --> 404 Page Not Found: Config/AspCms_Config.asp
ERROR - 2022-02-02 11:36:38 --> 404 Page Not Found: Templates/red.asp
ERROR - 2022-02-02 11:36:38 --> 404 Page Not Found: Data/s.asp
ERROR - 2022-02-02 11:36:39 --> 404 Page Not Found: Base/admin
ERROR - 2022-02-02 11:36:39 --> 404 Page Not Found: Kdatebase/index_.asp
ERROR - 2022-02-02 11:36:39 --> 404 Page Not Found: Somnus/Somnus.asp
ERROR - 2022-02-02 11:36:39 --> 404 Page Not Found: Images/cache.asp
ERROR - 2022-02-02 11:36:39 --> 404 Page Not Found: Admin_gfive/js
ERROR - 2022-02-02 11:36:39 --> 404 Page Not Found: Admin_a/images
ERROR - 2022-02-02 11:36:39 --> 404 Page Not Found: Zhanpushiasp/index
ERROR - 2022-02-02 11:36:39 --> 404 Page Not Found: Configasp/index
ERROR - 2022-02-02 11:49:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 11:49:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 11:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 11:59:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 12:06:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 12:19:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 12:28:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 12:32:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 12:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 12:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 12:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 13:00:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:05:03 --> 404 Page Not Found: App/views
ERROR - 2022-02-02 13:06:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 13:07:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:07:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:07:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:07:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:08:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:24:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 13:26:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 13:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 13:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 13:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 13:37:01 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2022-02-02 13:39:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:41:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:43:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:45:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:46:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 13:49:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 13:50:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:50:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:51:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 13:51:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:01:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:02:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 14:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:12:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:12:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:12:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:12:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:12:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:13:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:13:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:13:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:13:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:13:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:13:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:13:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:13:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:14:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:14:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:14:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:14:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:14:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:15:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:16:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:22:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:24:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 14:27:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 14:31:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 14:34:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 14:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 14:44:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-02 14:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 14:47:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:04:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:04:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:22:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 15:23:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 15:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 15:29:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:30:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:31:14 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2022-02-02 15:31:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 15:34:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:34:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:35:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:36:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:36:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:36:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:37:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:37:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:37:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 15:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 16:06:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 16:10:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 16:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 16:24:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 16:25:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 16:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 16:33:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 16:34:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 16:42:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:43:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:43:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:44:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:44:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:45:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:45:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:45:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:45:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:46:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:46:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:47:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 16:51:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 16:55:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 17:01:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 17:27:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 17:28:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 17:31:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 17:32:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 17:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 17:43:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 17:52:53 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 17:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 17:57:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 17:57:48 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 18:06:29 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2022-02-02 18:11:59 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-02-02 18:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 18:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 18:44:27 --> 404 Page Not Found: 17/10000
ERROR - 2022-02-02 18:44:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 18:44:32 --> 404 Page Not Found: 17/10000
ERROR - 2022-02-02 18:44:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 18:45:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 18:45:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 18:55:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 18:55:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 19:06:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 19:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 19:08:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 19:17:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:19:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:23:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:23:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:23:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:24:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:24:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:24:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:24:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:25:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:27:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:27:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 19:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 19:30:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 19:31:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:32:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 19:32:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 19:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 19:54:58 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2022-02-02 20:04:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 20:09:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 20:09:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 20:09:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 20:10:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 20:11:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 20:12:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 20:26:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 20:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 20:30:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 20:36:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 20:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 20:44:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 20:52:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 20:54:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 21:07:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:07:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:07:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:08:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:08:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:08:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:08:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:08:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:09:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:09:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:09:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 21:10:27 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-02 21:10:28 --> 404 Page Not Found: admin//index
ERROR - 2022-02-02 21:10:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 21:10:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:10:29 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-02 21:10:29 --> 404 Page Not Found: Static/.gitignore
ERROR - 2022-02-02 21:10:29 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2022-02-02 21:10:30 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-02-02 21:10:30 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-02-02 21:10:31 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-02-02 21:10:31 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-02 21:10:31 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-02 21:10:31 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-02 21:10:31 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-02 21:11:45 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-02 21:11:45 --> 404 Page Not Found: admin//index
ERROR - 2022-02-02 21:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 21:11:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:11:45 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-02 21:11:46 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-02 21:11:46 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-02 21:11:46 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-02 21:17:37 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-02 21:17:37 --> 404 Page Not Found: admin//index
ERROR - 2022-02-02 21:17:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 21:17:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:17:38 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-02 21:17:38 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-02 21:17:38 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-02 21:17:38 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-02 21:21:07 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-02 21:21:07 --> 404 Page Not Found: admin//index
ERROR - 2022-02-02 21:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 21:21:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 21:21:07 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-02 21:21:07 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-02 21:21:07 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-02 21:21:07 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-02 21:22:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 21:37:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 21:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 21:40:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 21:42:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 21:49:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 21:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 22:01:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 22:03:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 22:06:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-02 22:07:27 --> 404 Page Not Found: Otsmobile/app
ERROR - 2022-02-02 22:11:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 22:15:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 22:28:11 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 22:29:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 22:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 22:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 22:39:46 --> 404 Page Not Found: City/2
ERROR - 2022-02-02 22:46:25 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2022-02-02 22:46:26 --> 404 Page Not Found: admin//index
ERROR - 2022-02-02 22:46:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 22:46:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 22:46:26 --> 404 Page Not Found: Readmehtml/index
ERROR - 2022-02-02 22:46:26 --> 404 Page Not Found: Licensetxt/index
ERROR - 2022-02-02 22:46:26 --> 404 Page Not Found: Wp-includes/js
ERROR - 2022-02-02 22:46:26 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2022-02-02 22:46:27 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2022-02-02 22:46:27 --> 404 Page Not Found: PhpMyAdmin/explicit_not_exist_path
ERROR - 2022-02-02 22:46:27 --> 404 Page Not Found: PhpMyAdmin/robots.txt
ERROR - 2022-02-02 22:46:27 --> 404 Page Not Found: PhpMyAdmin/favicon.ico
ERROR - 2022-02-02 22:46:27 --> 404 Page Not Found: PhpMyAdmin/readme.html
ERROR - 2022-02-02 22:46:27 --> 404 Page Not Found: PhpMyAdmin/license.txt
ERROR - 2022-02-02 22:46:28 --> 404 Page Not Found: PhpMyAdmin/wp-includes
ERROR - 2022-02-02 22:46:28 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2022-02-02 22:46:28 --> 404 Page Not Found: Phpmyadmin/explicit_not_exist_path
ERROR - 2022-02-02 22:46:28 --> 404 Page Not Found: Phpmyadmin/robots.txt
ERROR - 2022-02-02 22:46:28 --> 404 Page Not Found: Phpmyadmin/favicon.ico
ERROR - 2022-02-02 22:46:28 --> 404 Page Not Found: Phpmyadmin/readme.html
ERROR - 2022-02-02 22:46:28 --> 404 Page Not Found: Phpmyadmin/license.txt
ERROR - 2022-02-02 22:46:28 --> 404 Page Not Found: Phpmyadmin/wp-includes
ERROR - 2022-02-02 22:46:28 --> 404 Page Not Found: Wcm/index
ERROR - 2022-02-02 22:46:29 --> 404 Page Not Found: Wcm/explicit_not_exist_path
ERROR - 2022-02-02 22:46:29 --> 404 Page Not Found: Wcm/robots.txt
ERROR - 2022-02-02 22:46:29 --> 404 Page Not Found: Wcm/favicon.ico
ERROR - 2022-02-02 22:46:29 --> 404 Page Not Found: Wcm/readme.html
ERROR - 2022-02-02 22:46:29 --> 404 Page Not Found: Wcm/license.txt
ERROR - 2022-02-02 22:46:29 --> 404 Page Not Found: Wcm/wp-includes
ERROR - 2022-02-02 22:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 22:58:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 23:03:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 23:05:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 23:06:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 23:07:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 23:13:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 23:16:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 23:20:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-02 23:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 23:21:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 23:22:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-02 23:23:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 23:28:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 23:38:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 23:42:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-02 23:54:51 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-02 23:59:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 23:59:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-02 23:59:39 --> 404 Page Not Found: Faviconico/index
