<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-29 00:06:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 00:06:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 00:06:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 00:07:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 00:07:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 00:08:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 00:10:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 00:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 00:18:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 00:36:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 00:38:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 00:43:06 --> 404 Page Not Found: 1/10000
ERROR - 2021-11-29 00:54:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 00:57:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 00:57:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 00:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 01:07:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 01:08:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 01:08:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 01:09:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 01:10:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 01:13:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 01:33:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 01:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 01:38:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 01:38:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 01:40:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 01:53:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 01:55:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 01:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 01:58:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 02:04:11 --> 404 Page Not Found: Sdk/index
ERROR - 2021-11-29 02:04:11 --> 404 Page Not Found: Text4041638122651/index
ERROR - 2021-11-29 02:04:11 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-11-29 02:04:11 --> 404 Page Not Found: Evox/about
ERROR - 2021-11-29 02:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 02:07:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 02:11:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 02:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 02:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 02:38:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 02:39:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 02:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 02:42:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 02:42:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 02:43:34 --> 404 Page Not Found: City/1
ERROR - 2021-11-29 02:44:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 03:05:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 03:06:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 03:06:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 03:06:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 03:09:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 03:09:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 03:18:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 03:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 03:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 03:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 03:31:06 --> 404 Page Not Found: City/16
ERROR - 2021-11-29 03:31:23 --> 404 Page Not Found: City/16
ERROR - 2021-11-29 03:32:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 03:32:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 03:34:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 03:35:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 03:36:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 03:37:56 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-29 03:38:16 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-29 03:38:17 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-29 03:38:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 03:50:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 04:07:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 04:07:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 04:08:21 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-11-29 04:08:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 04:09:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 04:09:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 04:10:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 04:17:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 04:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 04:36:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 04:41:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 04:43:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 04:43:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 04:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 05:06:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 05:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 05:27:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 05:35:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 05:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 05:35:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 05:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 05:36:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 05:38:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 05:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 05:49:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 05:51:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 05:55:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 05:59:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:06:14 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-11-29 06:16:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:16:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:17:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:19:56 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-11-29 06:20:14 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-11-29 06:23:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:28:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 06:39:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 06:39:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 06:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 07:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 07:06:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 07:07:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 07:09:20 --> 404 Page Not Found: City/10
ERROR - 2021-11-29 07:19:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 07:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 07:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 07:25:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 07:26:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 07:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 07:27:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 07:28:25 --> 404 Page Not Found: City/1
ERROR - 2021-11-29 07:31:17 --> 404 Page Not Found: Gift-tickethtml/index
ERROR - 2021-11-29 07:36:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 07:37:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 07:57:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 08:06:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 08:07:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 08:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 08:08:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 08:12:18 --> 404 Page Not Found: Api/Ticket
ERROR - 2021-11-29 08:12:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-29 08:16:34 --> 404 Page Not Found: Api/Ticket
ERROR - 2021-11-29 08:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 08:33:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 08:40:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 08:52:48 --> 404 Page Not Found: Gift-tickethtml/index
ERROR - 2021-11-29 08:53:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 08:54:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 08:55:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 08:57:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 08:57:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 09:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 09:02:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 09:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 09:16:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 09:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 09:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 09:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 09:35:13 --> 404 Page Not Found: City/17
ERROR - 2021-11-29 09:35:19 --> 404 Page Not Found: City/17
ERROR - 2021-11-29 09:35:19 --> 404 Page Not Found: City/17
ERROR - 2021-11-29 09:35:20 --> 404 Page Not Found: City/17
ERROR - 2021-11-29 09:35:20 --> 404 Page Not Found: City/17
ERROR - 2021-11-29 09:36:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 09:37:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 09:38:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 09:43:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 09:45:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 09:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 09:48:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 09:52:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 09:53:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 09:55:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 10:04:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: insert into `fox_haoma` (hao_city,hao_type,hao_pinpai,hao_title,hao_jiage,hao_huafei,hao_heyue,hao_beizhu,hao_user,hao_time) values 
ERROR - 2021-11-29 10:05:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:06:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 10:06:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 10:08:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 10:08:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 10:11:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:12:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 10:13:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:15:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:15:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:15:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:16:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:19:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:21:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 10:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 10:32:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:34:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:36:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:36:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 10:42:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 10:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 10:51:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:53:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:53:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:53:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:53:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 10:54:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:55:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:55:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:55:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:55:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:56:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:56:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:58:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:58:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 10:59:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:00:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:01:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:01:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:01:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:01:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:01:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:01:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:04:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:05:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:05:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 11:05:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:08:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:09:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:09:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:09:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:12:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:13:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:15:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 11:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 11:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 11:23:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 11:25:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 11:25:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 11:30:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:32:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:33:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:34:00 --> 404 Page Not Found: Text4041638156840/index
ERROR - 2021-11-29 11:34:00 --> 404 Page Not Found: Evox/about
ERROR - 2021-11-29 11:34:00 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-11-29 11:34:00 --> 404 Page Not Found: Sdk/index
ERROR - 2021-11-29 11:34:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 11:34:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:35:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:35:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:35:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:35:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:35:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:35:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:36:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-29 11:36:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:37:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:38:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:45:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:46:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 11:49:34 --> 404 Page Not Found: Interface/SendX
ERROR - 2021-11-29 11:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 12:02:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:10:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 12:12:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:12:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 12:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 12:26:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 12:32:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 12:37:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:37:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:37:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:37:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:37:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:37:51 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:37:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:38:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:38:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:38:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:38:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:47:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 12:47:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-29 12:47:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 12:58:23 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-11-29 13:04:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 13:06:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 13:06:26 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-11-29 13:08:55 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-11-29 13:09:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 13:21:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 13:21:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 13:22:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 13:23:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 13:24:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 13:25:57 --> 404 Page Not Found: Images/qq
ERROR - 2021-11-29 13:26:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 13:28:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 13:29:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 13:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 13:30:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-29 13:37:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 13:38:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 13:42:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 13:49:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 14:06:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 14:07:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:07:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:07:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:08:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:12:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 14:17:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 14:19:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:19:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 14:20:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:20:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:22:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 14:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 14:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 14:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 14:37:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 14:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 14:40:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:40:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 14:40:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 14:41:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-29 14:41:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 14:42:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 14:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 14:45:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 14:48:21 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-11-29 14:50:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 14:50:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 14:51:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 14:51:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 14:51:37 --> 404 Page Not Found: Home/tradeInfo
ERROR - 2021-11-29 15:00:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 15:07:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 15:09:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 15:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 15:16:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 15:17:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 15:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 15:26:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 15:27:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 15:30:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-29 15:31:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 15:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 15:37:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 15:37:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 15:38:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 15:38:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 15:38:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 15:39:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 15:39:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 15:39:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 15:39:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 15:39:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 15:39:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 15:43:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 15:44:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-29 15:47:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 15:49:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 15:49:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 15:58:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 16:00:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 16:04:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 16:04:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 16:07:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 16:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 16:14:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:14:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 16:18:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-29 16:19:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-29 16:19:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 16:19:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 16:19:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 16:20:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 16:20:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 16:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 16:24:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:24:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:25:51 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-29 16:25:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:27:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:28:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:30:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:30:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:43:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 16:46:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:46:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:47:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 16:54:22 --> 404 Page Not Found: Sitemap92256html/index
ERROR - 2021-11-29 16:54:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 16:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 16:55:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 16:55:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:09:07 --> Severity: Warning --> Missing argument 1 for Kefu::show() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 359
ERROR - 2021-11-29 17:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 17:24:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:24:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:25:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:25:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:27:15 --> Severity: Warning --> Missing argument 1 for Taocan::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 21
ERROR - 2021-11-29 17:28:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:36:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:36:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:36:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:36:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:36:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:37:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:43:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:44:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:45:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:46:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:47:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-29 17:48:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 17:50:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 17:50:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 17:53:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 17:55:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 18:00:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 18:05:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 18:10:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 18:17:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 18:17:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 18:17:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 18:18:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 18:22:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 18:22:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 18:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 18:27:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 18:33:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-29 18:33:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 18:34:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-29 18:34:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 18:34:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 18:34:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 18:39:13 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-29 18:39:30 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-29 18:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 18:44:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 18:47:33 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-29 18:48:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 18:51:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 19:00:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 19:00:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 19:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 19:09:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 19:18:31 --> 404 Page Not Found: Inc/config.asp
ERROR - 2021-11-29 19:22:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 19:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 19:25:02 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-29 19:27:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 19:38:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:40:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:41:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:41:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:41:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:42:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:42:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:42:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:42:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 19:43:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:43:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:44:44 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-29 19:45:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:45:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:48:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:48:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 19:48:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 19:48:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 19:48:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:49:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:49:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:49:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:49:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 19:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 19:49:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:50:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:50:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:53:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 19:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 19:56:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 20:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 20:08:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 20:08:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 20:08:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 20:08:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 20:08:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 20:09:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 20:09:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 20:10:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 20:10:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 20:10:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 20:12:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 20:15:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 20:15:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 20:17:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 20:17:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 20:22:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 20:23:02 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-29 20:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 20:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 20:35:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 20:41:06 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-29 20:48:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 20:56:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 20:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 20:56:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 20:56:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 20:58:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-29 21:01:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:02:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:02:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:02:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:03:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 21:03:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:08:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:10:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:11:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:11:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:11:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:11:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:12:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:12:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:13:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:13:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:13:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:14:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:14:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:15:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:15:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:15:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:15:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:16:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:16:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-29 21:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:18:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:20:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:22:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:23:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:25:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 21:25:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 21:27:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:29:55 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-11-29 21:32:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:34:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:44:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:47:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:49:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:50:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 21:50:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:52:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 21:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 21:53:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 21:55:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 21:55:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 22:04:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 22:05:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 22:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 22:08:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 22:09:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 22:13:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 22:15:52 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-11-29 22:21:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 22:23:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 22:29:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 22:30:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 22:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 22:34:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 22:34:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 22:38:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 22:38:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 22:48:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 22:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 22:48:42 --> 404 Page Not Found: Sitemap29932html/index
ERROR - 2021-11-29 22:55:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 23:17:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 23:17:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 23:17:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 23:17:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 23:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 23:18:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-29 23:20:28 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-29 23:23:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 23:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-29 23:25:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-29 23:39:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 23:39:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 23:39:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 23:39:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 23:40:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-29 23:50:22 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-11-29 23:52:15 --> 404 Page Not Found: 404/index.html
ERROR - 2021-11-29 23:52:15 --> 404 Page Not Found: 404/index.html
ERROR - 2021-11-29 23:55:24 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-11-29 23:55:50 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
