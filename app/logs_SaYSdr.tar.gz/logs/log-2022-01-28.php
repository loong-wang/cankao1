<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-01-28 00:42:11 --> 404 Page Not Found: System/ueditor
ERROR - 2022-01-28 00:53:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 00:55:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 01:00:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 01:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 01:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 01:41:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 01:41:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 01:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 01:55:50 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2022-01-28 01:56:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 01:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 02:00:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 02:01:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 02:03:49 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2022-01-28 02:11:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 02:15:49 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2022-01-28 02:18:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 02:18:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 02:19:50 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2022-01-28 02:23:52 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2022-01-28 02:31:50 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2022-01-28 02:34:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 02:36:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 02:43:51 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2022-01-28 02:46:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 02:51:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 02:51:52 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2022-01-28 02:59:54 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2022-01-28 03:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 03:19:54 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2022-01-28 03:27:53 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-01-28 03:30:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 03:40:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 03:43:56 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2022-01-28 03:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 03:51:56 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2022-01-28 03:54:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 03:58:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 04:03:56 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2022-01-28 04:08:33 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2022-01-28 04:16:02 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2022-01-28 04:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 04:19:56 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2022-01-28 04:23:56 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-01-28 04:24:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 04:27:59 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2022-01-28 04:31:56 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2022-01-28 04:34:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 04:35:56 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2022-01-28 04:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 05:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 05:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 05:10:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 05:26:05 --> 404 Page Not Found: City/10
ERROR - 2022-01-28 05:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 05:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 05:52:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 05:57:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 06:05:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 06:05:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 06:08:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 06:09:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 06:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 06:20:20 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2022-01-28 06:33:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 06:34:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 06:45:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 07:04:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 07:17:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 07:29:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 07:30:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 07:30:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 07:31:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 07:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 07:43:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 07:45:35 --> 404 Page Not Found: Ask/index
ERROR - 2022-01-28 07:45:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 07:46:03 --> 404 Page Not Found: City/16
ERROR - 2022-01-28 07:46:03 --> 404 Page Not Found: City/16
ERROR - 2022-01-28 07:46:03 --> 404 Page Not Found: City/16
ERROR - 2022-01-28 07:46:32 --> 404 Page Not Found: City/16
ERROR - 2022-01-28 07:46:48 --> 404 Page Not Found: City/16
ERROR - 2022-01-28 07:50:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 07:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 07:56:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 07:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:00:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:00:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:00:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:05:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:06:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:06:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:08:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:12:24 --> 404 Page Not Found: Login/index
ERROR - 2022-01-28 08:12:26 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2022-01-28 08:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:15:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 08:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:31:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:41:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:45:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 08:46:00 --> 404 Page Not Found: City/15
ERROR - 2022-01-28 08:46:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 08:50:16 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-01-28 09:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 09:00:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 09:08:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 09:12:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:13:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:15:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 09:16:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:17:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:17:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:17:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:18:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:18:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:19:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:19:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:19:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:20:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:20:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 09:28:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:28:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:30:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 09:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 09:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 09:40:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:41:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:41:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:41:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:42:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:43:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 09:43:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:45:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:46:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:47:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:48:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:48:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:49:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:49:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:49:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:49:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:50:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:52:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:52:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:53:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:54:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:55:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:55:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:56:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:56:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:56:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 09:56:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:00:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:00:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:01:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 10:01:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 10:04:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:04:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:05:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:05:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:05:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:05:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:05:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:06:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:06:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:06:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:07:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:07:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:07:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:09:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:09:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:10:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:10:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:11:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:11:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:12:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:14:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:14:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:14:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:15:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:16:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:16:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:16:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:17:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:17:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:17:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:19:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:21:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:22:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:22:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:22:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:23:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:23:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:26:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:30:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:33:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:39:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:39:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:40:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:40:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:42:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:42:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:43:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:45:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:45:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:45:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:45:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:48:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:49:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:51:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:52:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:53:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 10:53:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:53:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:53:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:53:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:54:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:55:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:57:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:57:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:57:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:57:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:57:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:58:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:58:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 10:58:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 10:59:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:00:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:00:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:00:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:00:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:00:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:04:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:07:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:08:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:10:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 11:11:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:14:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:16:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:16:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 11:18:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:19:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:19:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:19:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:20:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:20:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 11:20:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:21:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:21:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:22:25 --> Severity: error --> 11111 test 1
ERROR - 2022-01-28 11:22:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:23:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 11:23:24 --> 404 Page Not Found: Sitemap42517html/index
ERROR - 2022-01-28 11:24:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:24:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:24:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:24:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 11:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 11:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 11:30:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 11:32:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 11:35:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:36:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:37:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:37:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:37:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:38:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 11:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 11:44:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 11:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 11:45:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 12:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 12:06:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 12:13:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:13:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 12:14:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:20:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:21:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:21:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:21:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:21:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:21:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:21:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:21:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:22:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:22:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:22:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:22:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:22:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:22:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:23:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:23:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:23:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:23:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:24:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:24:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:25:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:26:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:26:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:26:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:27:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:28:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:28:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:28:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:28:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:28:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:29:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:30:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:31:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:31:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:31:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:33:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:33:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:33:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:35:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:35:31 --> 404 Page Not Found: Text4041643344530/index
ERROR - 2022-01-28 12:35:31 --> 404 Page Not Found: Sdk/index
ERROR - 2022-01-28 12:35:31 --> 404 Page Not Found: Evox/about
ERROR - 2022-01-28 12:35:31 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-01-28 12:35:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 12:35:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 12:37:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:37:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:37:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:37:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:38:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:38:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:38:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:39:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:40:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:40:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:40:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:41:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:42:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:43:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:45:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:45:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:45:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:46:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:46:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:49:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 12:49:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 12:52:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:53:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:53:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:54:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 12:54:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:00:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:00:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:00:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:00:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:00:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 13:03:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:03:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:05:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 13:05:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 13:06:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:19:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 13:19:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 13:23:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 13:45:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:48:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:51:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 13:57:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 13:58:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 13:59:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 14:01:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 14:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 14:18:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 14:19:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 14:24:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 14:24:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 14:28:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 14:44:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 14:51:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 14:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 14:56:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 14:57:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 14:59:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 15:00:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:04:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 15:06:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 15:06:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 15:07:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 15:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 15:13:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:15:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:19:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:19:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:19:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:19:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:19:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:19:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:20:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:20:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:20:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:20:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:20:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:20:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 15:20:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 15:21:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:21:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:21:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:21:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:21:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:21:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:21:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:21:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:22:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:32:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 15:32:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 15:36:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 15:53:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:54:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:55:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:56:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:56:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:56:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:58:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 15:59:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 16:00:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 16:03:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 16:03:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 16:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 16:05:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 16:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 16:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 16:35:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 16:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 16:57:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 16:59:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 17:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 17:07:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 17:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 17:15:05 --> 404 Page Not Found: City/1
ERROR - 2022-01-28 17:23:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 17:24:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 17:24:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 17:29:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-01-28 17:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 17:33:53 --> 404 Page Not Found: Sitemapxml/index
ERROR - 2022-01-28 17:43:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 17:44:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 17:45:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 17:54:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 17:55:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 17:57:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 17:58:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 17:59:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:07:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:09:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 18:09:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:14:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:22:23 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-28 18:22:23 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-28 18:22:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 18:22:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 18:22:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 18:22:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 18:22:23 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 18:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 18:22:23 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-28 18:22:23 --> 404 Page Not Found: Member/space
ERROR - 2022-01-28 18:22:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 18:22:24 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 18:22:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 18:22:24 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-28 18:22:25 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-28 18:22:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 18:22:25 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-28 18:22:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 18:22:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 18:22:25 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-28 18:22:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 18:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 18:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 18:28:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 18:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 18:36:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 18:43:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:43:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:43:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:43:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:46:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:54:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:54:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:54:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:55:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:56:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 18:58:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 18:59:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 18:59:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 19:03:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 19:03:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 19:03:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 19:04:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 19:05:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 19:07:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 19:14:14 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-28 19:14:14 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-28 19:14:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 19:14:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 19:14:14 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-28 19:14:14 --> 404 Page Not Found: Member/space
ERROR - 2022-01-28 19:14:14 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 19:14:15 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-28 19:14:15 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-28 19:14:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:15 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-28 19:14:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:16 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-28 19:14:16 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:58 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-01-28 19:14:58 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-01-28 19:14:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 19:14:58 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:58 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:58 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:58 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 19:14:59 --> 404 Page Not Found: Include/taglib
ERROR - 2022-01-28 19:14:59 --> 404 Page Not Found: Member/space
ERROR - 2022-01-28 19:14:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:59 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:14:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 19:14:59 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-28 19:14:59 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-28 19:15:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:15:00 --> 404 Page Not Found: Dede/templets
ERROR - 2022-01-28 19:15:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:15:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:15:00 --> 404 Page Not Found: Data/cache
ERROR - 2022-01-28 19:15:00 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 19:23:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 19:30:15 --> 404 Page Not Found: City/1
ERROR - 2022-01-28 19:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 19:33:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 19:46:07 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 19:46:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 19:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 19:59:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:03:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 20:12:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:16:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 20:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:17:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 20:17:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 20:17:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 20:17:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 20:18:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 20:18:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 20:18:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 20:18:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 20:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:34:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:43:36 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-01-28 20:45:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:45:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:46:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:52:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 20:56:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 20:57:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 20:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 20:58:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 20:59:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:00:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:00:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:01:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:01:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:02:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:02:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 21:03:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:03:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 21:03:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 21:04:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 21:06:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:06:50 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 21:07:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:07:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:07:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:08:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 21:09:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:09:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:09:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:10:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:11:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:15:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 21:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 21:30:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 21:36:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 21:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 21:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 21:52:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 21:57:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:00:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 22:00:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:02:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:03:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:03:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:04:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:04:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:04:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:05:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:06:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 22:06:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 22:08:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:10:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 22:10:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:10:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:11:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 22:11:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:12:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:13:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:14:03 --> 404 Page Not Found: Data/admin
ERROR - 2022-01-28 22:19:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:19:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:19:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 22:21:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:27:17 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2022-01-28 22:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 22:35:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 22:35:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 22:39:19 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-01-28 22:50:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 22:50:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 22:58:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 23:00:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 23:01:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 23:01:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 23:12:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 23:31:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 23:37:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-01-28 23:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 23:49:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-28 23:55:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-01-28 23:58:03 --> 404 Page Not Found: Robotstxt/index
