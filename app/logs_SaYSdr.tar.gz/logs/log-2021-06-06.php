<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-06-06 00:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:00:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:00:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:03:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 00:03:58 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 00:03:58 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 00:03:58 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-06 00:03:58 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 00:03:59 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 00:04:00 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-06 00:04:00 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 00:04:00 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 00:04:00 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-06 00:04:00 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 00:04:00 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-06 00:04:00 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-06 00:04:00 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-06 00:04:00 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-06 00:04:00 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 00:04:01 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 00:04:01 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 00:04:01 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-06 00:04:01 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-06 00:04:01 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-06 00:04:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:04:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 00:04:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:04:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 00:04:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 00:04:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:05:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:05:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:05:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:05:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:05:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 00:05:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:05:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 00:05:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:05:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 00:06:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:06:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 00:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 00:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:10:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 00:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:11:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:12:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:13:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:13:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:13:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:13:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:14:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:14:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:14:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:15:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:15:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:16:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:18:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:18:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:18:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 00:18:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:20:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:20:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 00:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:21:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:21:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:23:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:23:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:27:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:27:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:28:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:28:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 00:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:29:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:29:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:29:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:31:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:33:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:34:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:34:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:34:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:34:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:34:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:35:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:35:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:35:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:35:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:35:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:35:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:36:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:36:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:36:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:37:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:37:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 00:37:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:37:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:37:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:37:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:37:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:37:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:37:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 00:38:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:38:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 00:39:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:39:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:39:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:39:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:39:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:39:24 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-06 00:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:39:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:39:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:40:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:40:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:40:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:40:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:40:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:40:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:40:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:40:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:40:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:40:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:41:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:42:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:42:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:42:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:42:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:43:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:43:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 00:43:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:46:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:46:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:46:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:47:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:48:05 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-06 00:49:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:50:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 00:50:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 00:51:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:51:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:54:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:54:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:55:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:55:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:55:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:56:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:56:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:56:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:57:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:57:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:58:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:58:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 00:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 00:59:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 00:59:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:00:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:00:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:00:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:01:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:01:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:01:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:01:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:01:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:02:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:03:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:03:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:03:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:04:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:04:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:04:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 01:04:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:04:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:05:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:05:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:05:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:05:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:05:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:06:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:06:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:06:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:06:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:07:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:07:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:07:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:07:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:08:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:08:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:08:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:09:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:09:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 01:09:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:10:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:10:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:10:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:10:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:12:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:12:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:12:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:13:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:13:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:13:54 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-06 01:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:14:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:14:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:14:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 01:15:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:16:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:16:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:16:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:17:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:17:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:18:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:18:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:19:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:19:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:19:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:19:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:19:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:22:50 --> 404 Page Not Found: H5/index
ERROR - 2021-06-06 01:22:50 --> 404 Page Not Found: Base/exchange_article
ERROR - 2021-06-06 01:22:50 --> 404 Page Not Found: Legal/currency
ERROR - 2021-06-06 01:22:51 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-06-06 01:22:51 --> 404 Page Not Found: Base/exchange_index
ERROR - 2021-06-06 01:22:52 --> 404 Page Not Found: Market/market-ws
ERROR - 2021-06-06 01:22:53 --> 404 Page Not Found: Otc/index
ERROR - 2021-06-06 01:22:54 --> 404 Page Not Found: Wap/trading
ERROR - 2021-06-06 01:22:54 --> 404 Page Not Found: Wap/trading
ERROR - 2021-06-06 01:22:55 --> 404 Page Not Found: admin/Index/index
ERROR - 2021-06-06 01:22:55 --> 404 Page Not Found: H5/index
ERROR - 2021-06-06 01:22:57 --> 404 Page Not Found: Api/content_bottom
ERROR - 2021-06-06 01:22:58 --> 404 Page Not Found: Web/api
ERROR - 2021-06-06 01:22:58 --> 404 Page Not Found: Recruit/download_url
ERROR - 2021-06-06 01:22:58 --> 404 Page Not Found: Home/loadmymanager
ERROR - 2021-06-06 01:22:59 --> 404 Page Not Found: Index/login
ERROR - 2021-06-06 01:23:01 --> 404 Page Not Found: M/ticker
ERROR - 2021-06-06 01:23:01 --> 404 Page Not Found: M/allticker
ERROR - 2021-06-06 01:23:01 --> 404 Page Not Found: Room/getRoomBangFans
ERROR - 2021-06-06 01:23:01 --> 404 Page Not Found: N/news
ERROR - 2021-06-06 01:23:03 --> 404 Page Not Found: S_api/basic
ERROR - 2021-06-06 01:23:04 --> 404 Page Not Found: Room/1002
ERROR - 2021-06-06 01:23:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:23:07 --> 404 Page Not Found: User/allroleinfo
ERROR - 2021-06-06 01:23:08 --> 404 Page Not Found: User/userlist
ERROR - 2021-06-06 01:23:09 --> 404 Page Not Found: Ajax/allcoin_a
ERROR - 2021-06-06 01:23:09 --> 404 Page Not Found: Xy/index
ERROR - 2021-06-06 01:23:10 --> 404 Page Not Found: Pc/Lang
ERROR - 2021-06-06 01:23:10 --> 404 Page Not Found: Home/Bind
ERROR - 2021-06-06 01:23:11 --> 404 Page Not Found: Xianyu/index
ERROR - 2021-06-06 01:23:12 --> 404 Page Not Found: Data/json
ERROR - 2021-06-06 01:23:12 --> 404 Page Not Found: Infe/rest
ERROR - 2021-06-06 01:23:12 --> 404 Page Not Found: Home/GetAllGameCategory
ERROR - 2021-06-06 01:23:12 --> 404 Page Not Found: Iframe/rankgiftgotapi
ERROR - 2021-06-06 01:23:14 --> 404 Page Not Found: V1/management
ERROR - 2021-06-06 01:23:15 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-06-06 01:23:15 --> 404 Page Not Found: GetConfig/listPopFrame.do
ERROR - 2021-06-06 01:23:16 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-06-06 01:23:16 --> 404 Page Not Found: GetLocale/index
ERROR - 2021-06-06 01:23:16 --> 404 Page Not Found: GetConfig/getArticle.do
ERROR - 2021-06-06 01:23:17 --> 404 Page Not Found: FePublicInfo/index
ERROR - 2021-06-06 01:23:17 --> 404 Page Not Found: Infe/rest
ERROR - 2021-06-06 01:23:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:23:18 --> 404 Page Not Found: Api/ApiHub
ERROR - 2021-06-06 01:23:21 --> 404 Page Not Found: Registerasp/index
ERROR - 2021-06-06 01:23:21 --> 404 Page Not Found: Step1asp/index
ERROR - 2021-06-06 01:23:22 --> 404 Page Not Found: Mobile/v3
ERROR - 2021-06-06 01:23:22 --> 404 Page Not Found: Front/User
ERROR - 2021-06-06 01:23:22 --> 404 Page Not Found: Ajax/index
ERROR - 2021-06-06 01:23:23 --> 404 Page Not Found: Ajax/index
ERROR - 2021-06-06 01:23:23 --> 404 Page Not Found: CscpLoginWeb/app
ERROR - 2021-06-06 01:23:23 --> 404 Page Not Found: Front/FctPage
ERROR - 2021-06-06 01:23:24 --> 404 Page Not Found: admin//index
ERROR - 2021-06-06 01:23:24 --> 404 Page Not Found: Home/Get
ERROR - 2021-06-06 01:23:24 --> 404 Page Not Found: Api/index
ERROR - 2021-06-06 01:23:25 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-06 01:23:25 --> 404 Page Not Found: Mtjahtml/index
ERROR - 2021-06-06 01:23:25 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 01:23:26 --> 404 Page Not Found: Site/get-hq
ERROR - 2021-06-06 01:23:26 --> 404 Page Not Found: Api/uploads
ERROR - 2021-06-06 01:23:29 --> 404 Page Not Found: Ws/index
ERROR - 2021-06-06 01:23:29 --> 404 Page Not Found: Bannerdo/index
ERROR - 2021-06-06 01:23:29 --> 404 Page Not Found: Home/GetInitSource
ERROR - 2021-06-06 01:23:30 --> 404 Page Not Found: Home/login
ERROR - 2021-06-06 01:23:30 --> 404 Page Not Found: Api/v
ERROR - 2021-06-06 01:23:31 --> 404 Page Not Found: Static/data
ERROR - 2021-06-06 01:23:32 --> 404 Page Not Found: Promotions/list.mvc
ERROR - 2021-06-06 01:23:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:23:33 --> 404 Page Not Found: Sign/index
ERROR - 2021-06-06 01:23:37 --> 404 Page Not Found: Api/wallet
ERROR - 2021-06-06 01:23:37 --> 404 Page Not Found: Homes/index
ERROR - 2021-06-06 01:23:37 --> 404 Page Not Found: H5/index
ERROR - 2021-06-06 01:23:38 --> 404 Page Not Found: Homes/index
ERROR - 2021-06-06 01:23:39 --> 404 Page Not Found: Base/goexjs
ERROR - 2021-06-06 01:23:39 --> 404 Page Not Found: Index/register.html
ERROR - 2021-06-06 01:23:39 --> 404 Page Not Found: Anquan/qgga.asp
ERROR - 2021-06-06 01:23:40 --> 404 Page Not Found: Index/index
ERROR - 2021-06-06 01:23:40 --> 404 Page Not Found: Api/message
ERROR - 2021-06-06 01:23:40 --> 404 Page Not Found: Api/product
ERROR - 2021-06-06 01:23:41 --> 404 Page Not Found: Api/Index
ERROR - 2021-06-06 01:23:43 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-06 01:23:43 --> 404 Page Not Found: Api/site
ERROR - 2021-06-06 01:23:44 --> 404 Page Not Found: Wap/Api
ERROR - 2021-06-06 01:23:45 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-06-06 01:23:45 --> 404 Page Not Found: Api/apps
ERROR - 2021-06-06 01:23:45 --> 404 Page Not Found: Index/Mobile
ERROR - 2021-06-06 01:23:46 --> 404 Page Not Found: Api/mobile
ERROR - 2021-06-06 01:23:46 --> 404 Page Not Found: Api/index
ERROR - 2021-06-06 01:23:46 --> 404 Page Not Found: Api/currency
ERROR - 2021-06-06 01:23:46 --> 404 Page Not Found: Api/contactWay
ERROR - 2021-06-06 01:23:46 --> 404 Page Not Found: Market/getStockBaseInfo
ERROR - 2021-06-06 01:23:47 --> 404 Page Not Found: Loan/index
ERROR - 2021-06-06 01:23:47 --> 404 Page Not Found: Api/v1
ERROR - 2021-06-06 01:23:47 --> 404 Page Not Found: FriendGroup/list
ERROR - 2021-06-06 01:23:47 --> 404 Page Not Found: Kkrps/im_group
ERROR - 2021-06-06 01:23:49 --> 404 Page Not Found: Api/common
ERROR - 2021-06-06 01:23:50 --> 404 Page Not Found: Api/user
ERROR - 2021-06-06 01:23:50 --> 404 Page Not Found: Stock/search.html
ERROR - 2021-06-06 01:23:50 --> 404 Page Not Found: Portal/index
ERROR - 2021-06-06 01:23:50 --> 404 Page Not Found: Api/config-init
ERROR - 2021-06-06 01:23:50 --> 404 Page Not Found: Appxz/index.html
ERROR - 2021-06-06 01:23:51 --> 404 Page Not Found: Home/main
ERROR - 2021-06-06 01:23:52 --> 404 Page Not Found: Api/exclude
ERROR - 2021-06-06 01:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:23:53 --> 404 Page Not Found: Api/user
ERROR - 2021-06-06 01:23:54 --> 404 Page Not Found: Index/api
ERROR - 2021-06-06 01:23:56 --> 404 Page Not Found: Im/in
ERROR - 2021-06-06 01:23:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 01:24:02 --> 404 Page Not Found: H5/index
ERROR - 2021-06-06 01:24:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:27:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:28:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:29:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:30:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:30:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:31:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:31:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 01:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:32:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:33:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:33:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:34:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:34:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:35:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:35:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:36:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:37:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:37:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:37:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 01:37:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:38:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:38:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:38:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 01:38:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:38:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:39:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 01:40:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:40:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:40:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:42:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:43:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:44:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:44:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:44:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:45:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 01:45:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:45:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:45:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:45:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:46:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 01:46:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:46:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:46:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:47:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:47:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:47:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:47:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:48:00 --> 404 Page Not Found: City/index
ERROR - 2021-06-06 01:48:07 --> Severity: Warning --> Missing argument 1 for Page::show() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 278
ERROR - 2021-06-06 01:48:11 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-06 01:48:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:49:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:50:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:52:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:54:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:55:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:55:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:55:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 01:55:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:56:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 01:57:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:57:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:57:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:57:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:57:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 01:58:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 01:58:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:00:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:01:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:01:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:02:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 02:03:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:03:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:03:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:03:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 02:04:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:05:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:05:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:05:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:06:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:06:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:06:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:07:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:07:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:07:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:07:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:08:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:08:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:08:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:09:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:10:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:10:30 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-06 02:10:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:10:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:11:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:11:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:11:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:11:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:12:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:13:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:13:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:13:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:14:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:14:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:15:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:16:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:18:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:18:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:18:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 02:20:10 --> 404 Page Not Found: City/index
ERROR - 2021-06-06 02:20:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:20:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:21:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:22:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:22:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:22:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:23:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 02:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:23:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:24:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:25:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:25:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:25:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:25:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:26:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:27:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:28:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:30:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:31:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:31:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:31:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 02:31:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:31:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:31:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:31:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:32:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:35:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:36:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:37:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:39:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:39:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:39:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:40:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:41:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 02:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:44:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:45:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:45:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 02:45:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:45:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:46:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:47:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:47:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:48:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:49:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:49:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:49:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 02:50:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:50:13 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-06 02:50:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:51:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:52:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:53:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:55:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 02:55:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:56:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 02:56:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 02:59:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 02:59:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:00:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:00:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:00:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:00:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:01:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:03:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:03:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:05:14 --> 404 Page Not Found: Blog/index
ERROR - 2021-06-06 03:05:14 --> 404 Page Not Found: Wp/index
ERROR - 2021-06-06 03:05:15 --> 404 Page Not Found: Wordpress/index
ERROR - 2021-06-06 03:05:15 --> 404 Page Not Found: New/index
ERROR - 2021-06-06 03:05:15 --> 404 Page Not Found: Old/index
ERROR - 2021-06-06 03:05:16 --> 404 Page Not Found: Test/index
ERROR - 2021-06-06 03:05:16 --> 404 Page Not Found: Main/index
ERROR - 2021-06-06 03:05:17 --> 404 Page Not Found: Site/index
ERROR - 2021-06-06 03:05:17 --> 404 Page Not Found: Backup/index
ERROR - 2021-06-06 03:05:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:05:18 --> 404 Page Not Found: Demo/index
ERROR - 2021-06-06 03:05:19 --> 404 Page Not Found: Tmp/index
ERROR - 2021-06-06 03:05:19 --> 404 Page Not Found: Cms/index
ERROR - 2021-06-06 03:05:20 --> 404 Page Not Found: Dev/index
ERROR - 2021-06-06 03:05:20 --> 404 Page Not Found: Old-wp/index
ERROR - 2021-06-06 03:05:20 --> 404 Page Not Found: Web/index
ERROR - 2021-06-06 03:05:21 --> 404 Page Not Found: Old-site/index
ERROR - 2021-06-06 03:05:21 --> 404 Page Not Found: Temp/index
ERROR - 2021-06-06 03:05:22 --> 404 Page Not Found: 2018/index
ERROR - 2021-06-06 03:05:22 --> 404 Page Not Found: 2019/index
ERROR - 2021-06-06 03:05:22 --> 404 Page Not Found: Bk/index
ERROR - 2021-06-06 03:05:23 --> 404 Page Not Found: Wp1/index
ERROR - 2021-06-06 03:05:24 --> 404 Page Not Found: Wp2/index
ERROR - 2021-06-06 03:05:24 --> 404 Page Not Found: V1/index
ERROR - 2021-06-06 03:05:24 --> 404 Page Not Found: V2/index
ERROR - 2021-06-06 03:05:25 --> 404 Page Not Found: Bak/index
ERROR - 2021-06-06 03:05:26 --> 404 Page Not Found: 2020/index
ERROR - 2021-06-06 03:05:26 --> 404 Page Not Found: New-site/index
ERROR - 2021-06-06 03:07:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:07:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:07:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:07:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:08:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:08:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:08:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:09:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:09:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:10:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:10:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:11:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:11:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:12:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 03:13:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:13:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:13:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:13:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:14:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:16:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:17:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:17:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:18:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:18:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:18:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:18:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:19:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 03:20:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:21:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:22:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:22:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:22:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:22:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:24:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:24:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 03:24:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:25:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:25:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:27:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:29:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-06 03:30:32 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 03:30:33 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-06 03:30:33 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 03:30:33 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-06 03:30:34 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-06 03:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:31:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:33:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:33:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:33:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:36:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:37:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:37:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 03:38:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:38:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:38:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:38:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:39:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:41:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:42:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:43:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:44:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:44:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:44:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:45:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:46:07 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-06 03:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:47:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:48:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:50:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:50:43 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-06 03:50:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:51:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:51:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:51:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:51:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:51:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:51:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:51:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:52:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:52:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:53:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:54:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:54:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:54:37 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-06 03:54:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:54:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:55:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:55:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:56:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:56:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:56:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 03:57:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 03:59:04 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-06 03:59:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:00:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:01:01 --> 404 Page Not Found: admin/Webset/delcachebyauto
ERROR - 2021-06-06 04:01:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:02:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:03:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:03:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:03:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:04:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:04:59 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 04:04:59 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 04:04:59 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 04:05:00 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-06 04:05:01 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-06 04:05:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:07:04 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-06 04:07:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:07:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:08:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:08:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 04:09:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:09:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:10:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:10:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:10:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:10:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 04:11:36 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-06 04:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:12:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:12:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:15:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 04:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:18:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:18:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:18:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:19:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:19:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:19:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:19:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:20:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:24:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:26:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:27:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:29:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:29:11 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-06 04:29:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:31:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 04:33:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 04:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:34:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:34:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:35:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:37:15 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-06 04:38:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:39:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 04:39:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 04:40:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:41:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:43:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 04:44:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 04:45:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:46:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 04:47:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:48:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:48:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:50:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:52:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 04:52:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:54:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:56:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:58:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 04:59:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 04:59:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:00:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:01:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:01:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:02:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:02:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:03:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:04:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:04:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:05:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:07:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:08:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:08:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:09:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:11:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:11:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:12:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 05:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:12:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:12:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:13:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:13:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:13:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:13:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:14:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:14:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:15:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:17:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 05:17:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 05:17:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:18:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:19:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:19:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:21:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:21:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 05:21:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 05:21:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 05:21:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 05:22:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:24:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 05:24:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:24:46 --> 404 Page Not Found: Haoma/index
ERROR - 2021-06-06 05:24:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:24:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:29:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:30:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:32:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:33:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:33:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:33:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 05:35:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:36:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:37:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:38:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:39:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:40:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:40:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 05:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:41:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:42:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 05:44:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:44:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:44:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:44:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:44:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 05:44:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 05:45:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:45:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:46:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:46:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:48:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:48:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:49:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:49:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:49:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:51:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:51:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:52:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:53:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:54:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:54:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:55:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 05:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:56:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 05:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 05:59:29 --> 404 Page Not Found: City/1
ERROR - 2021-06-06 05:59:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:00:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:00:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:00:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:01:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:02:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:02:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:02:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:02:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:02:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:02:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:02:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:02:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:02:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:03:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:03:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:03:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:03:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:03:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:03:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:03:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:03:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:05:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 06:06:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:09:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 06:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:10:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:10:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:10:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:10:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:11:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:11:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:12:20 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-06 06:12:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:12:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:13:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:14:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:16:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:16:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:16:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:16:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:16:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:17:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:18:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:18:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:19:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:21:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:24:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:24:18 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 06:24:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:24:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:24:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:26:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 06:26:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:28:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:28:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:32:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:32:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 06:32:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:35:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:35:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:35:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:35:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:35:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 06:36:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:38:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:38:30 --> 404 Page Not Found: Get/index
ERROR - 2021-06-06 06:39:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:39:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:40:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:41:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 06:41:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 06:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:42:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:42:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 06:42:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 06:42:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 06:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:43:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 06:43:16 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 06:43:16 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 06:43:16 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-06 06:43:16 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 06:43:16 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 06:43:16 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-06 06:43:16 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 06:43:16 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-06 06:43:17 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 06:43:18 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-06 06:43:18 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-06 06:43:18 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-06 06:43:18 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-06 06:43:18 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 06:43:18 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 06:43:18 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 06:43:18 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-06 06:43:18 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-06 06:43:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 06:43:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:45:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:46:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:47:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:47:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:48:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:49:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:50:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:50:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 06:50:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:53:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:55:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:57:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 06:57:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 06:58:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 06:59:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:03:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:03:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:03:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:03:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:03:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:04:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:05:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:05:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:06:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:07:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:08:06 --> 404 Page Not Found: 14/1002
ERROR - 2021-06-06 07:08:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:08:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:08:31 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-06 07:10:34 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 07:10:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:11:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:13:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 07:14:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 07:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:15:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:17:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:18:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:19:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:20:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:20:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:27:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:27:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 07:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:29:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:31:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:31:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:31:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 07:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:32:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:33:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:34:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:34:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:35:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 07:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 07:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 07:38:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 07:38:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:39:00 --> 404 Page Not Found: Nmaplowercheck1622936323/index
ERROR - 2021-06-06 07:39:00 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-06-06 07:39:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:40:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:40:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:41:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 07:41:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 07:42:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:42:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:42:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:42:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:42:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:42:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:42:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:42:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:44:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 07:45:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:46:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:47:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:47:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:48:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:49:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:49:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:49:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:49:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:49:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:50:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:50:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:50:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:51:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:51:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:51:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:52:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:52:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:53:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:53:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 07:54:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:54:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:54:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 07:54:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:55:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 07:55:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 07:56:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:56:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:56:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:56:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:57:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:57:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:57:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:57:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 07:57:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:57:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:57:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:57:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:58:59 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-06 07:59:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:59:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 07:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:00:50 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-06 08:00:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:01:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:02:06 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-06 08:02:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:02:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:02:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:02:53 --> 404 Page Not Found: English/index
ERROR - 2021-06-06 08:03:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:03:24 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-06 08:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:03:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:08:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:09:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:11:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:11:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:11:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:13:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:14:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:14:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:16:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:17:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:17:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:17:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:17:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:17:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:17:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:17:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:18:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:18:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:18:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:18:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:18:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:18:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:18:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:18:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:19:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:19:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:19:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:19:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:19:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:19:19 --> 404 Page Not Found: City/index
ERROR - 2021-06-06 08:19:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:20:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:20:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:20:48 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 08:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:20:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:22:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:22:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:22:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:23:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:23:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:23:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:23:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:23:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:23:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:24:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:24:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:24:09 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-06-06 08:24:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:24:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:24:17 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-06-06 08:24:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:24:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:24:23 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 08:24:27 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 08:24:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:24:29 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 08:24:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:24:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 08:24:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:24:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:24:38 --> 404 Page Not Found: Include/taglib
ERROR - 2021-06-06 08:24:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:24:56 --> 404 Page Not Found: Member/space
ERROR - 2021-06-06 08:24:59 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 08:25:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 08:25:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:25:21 --> 404 Page Not Found: Data/cache
ERROR - 2021-06-06 08:25:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:25:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:25:35 --> 404 Page Not Found: Data/cache
ERROR - 2021-06-06 08:25:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:25:49 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 08:26:02 --> 404 Page Not Found: Dede/templets
ERROR - 2021-06-06 08:26:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:26:12 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 08:26:16 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 08:26:19 --> 404 Page Not Found: Data/cache
ERROR - 2021-06-06 08:26:22 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 08:26:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:27:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 08:28:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:28:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:30:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:30:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:31:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 08:32:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:32:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:35:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:38:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:39:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:41:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:43:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:46:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:46:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 08:47:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:48:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:48:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:48:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:49:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:49:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:50:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:52:35 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-06 08:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:54:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:55:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:56:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:56:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:56:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 08:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:01:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:02:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:03:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 09:05:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:05:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:05:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:05:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:06:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:07:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:07:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:07:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:07:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:07:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 09:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:08:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 09:08:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 09:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:10:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:11:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:11:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:12:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:14:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:14:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:14:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:15:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:17:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 09:17:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:18:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 09:18:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:19:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:19:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:19:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:20:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:21:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:21:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:23:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:24:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:24:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:25:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 09:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:28:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:28:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:28:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:28:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:28:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:28:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:28:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:28:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:29:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:29:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:30:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:30:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:30:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:31:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:31:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:31:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:31:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:32:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 09:32:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:32:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:32:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:32:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:32:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:33:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:33:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:34:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:34:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:35:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:36:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:36:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:37:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:37:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:39:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:39:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 09:40:33 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-06 09:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:40:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:43:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:43:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 09:43:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:44:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:44:22 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-06 09:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:45:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 09:47:02 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-06 09:47:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:47:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:50:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:51:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:52:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:53:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:54:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:54:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:54:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:55:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:55:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:55:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:55:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:56:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:56:40 --> 404 Page Not Found: Ncsitxt/index
ERROR - 2021-06-06 09:56:40 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-06-06 09:56:41 --> 404 Page Not Found: Hudson/script
ERROR - 2021-06-06 09:56:41 --> 404 Page Not Found: Script/index
ERROR - 2021-06-06 09:56:45 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-06-06 09:56:45 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-06-06 09:56:46 --> 404 Page Not Found: PMA/index
ERROR - 2021-06-06 09:56:47 --> 404 Page Not Found: Pma/index
ERROR - 2021-06-06 09:56:48 --> 404 Page Not Found: admin//index
ERROR - 2021-06-06 09:56:49 --> 404 Page Not Found: Dbadmin/index
ERROR - 2021-06-06 09:56:49 --> 404 Page Not Found: Mysql/index
ERROR - 2021-06-06 09:56:49 --> 404 Page Not Found: Myadmin/index
ERROR - 2021-06-06 09:56:50 --> 404 Page Not Found: Openserver/phpmyadmin
ERROR - 2021-06-06 09:56:50 --> 404 Page Not Found: Phpmyadmin2/index
ERROR - 2021-06-06 09:56:51 --> 404 Page Not Found: PhpMyAdmin2/index
ERROR - 2021-06-06 09:56:52 --> 404 Page Not Found: PhpMyAdmin-2/index
ERROR - 2021-06-06 09:56:52 --> 404 Page Not Found: Php-my-admin/index
ERROR - 2021-06-06 09:56:53 --> 404 Page Not Found: PhpMyAdmin-223/index
ERROR - 2021-06-06 09:56:53 --> 404 Page Not Found: PhpMyAdmin-226/index
ERROR - 2021-06-06 09:56:54 --> 404 Page Not Found: PhpMyAdmin-251/index
ERROR - 2021-06-06 09:56:54 --> 404 Page Not Found: PhpMyAdmin-254/index
ERROR - 2021-06-06 09:56:55 --> 404 Page Not Found: PhpMyAdmin-255-rc1/index
ERROR - 2021-06-06 09:56:55 --> 404 Page Not Found: PhpMyAdmin-255-rc2/index
ERROR - 2021-06-06 09:56:57 --> 404 Page Not Found: PhpMyAdmin-255/index
ERROR - 2021-06-06 09:56:58 --> 404 Page Not Found: PhpMyAdmin-256-rc1/index
ERROR - 2021-06-06 09:56:59 --> 404 Page Not Found: PhpMyAdmin-256-rc2/index
ERROR - 2021-06-06 09:57:01 --> 404 Page Not Found: PhpMyAdmin-257/index
ERROR - 2021-06-06 09:57:02 --> 404 Page Not Found: PhpMyAdmin-260-alpha2/index
ERROR - 2021-06-06 09:57:03 --> 404 Page Not Found: PhpMyAdmin-260-beta2/index
ERROR - 2021-06-06 09:57:04 --> 404 Page Not Found: PhpMyAdmin-260-rc1/index
ERROR - 2021-06-06 09:57:05 --> 404 Page Not Found: PhpMyAdmin-260-rc2/index
ERROR - 2021-06-06 09:57:06 --> 404 Page Not Found: PhpMyAdmin-260-rc3/index
ERROR - 2021-06-06 09:57:07 --> 404 Page Not Found: PhpMyAdmin-260/index
ERROR - 2021-06-06 09:57:07 --> 404 Page Not Found: PhpMyAdmin-260-pl1/index
ERROR - 2021-06-06 09:57:07 --> 404 Page Not Found: PhpMyAdmin-260-pl2/index
ERROR - 2021-06-06 09:57:07 --> 404 Page Not Found: PhpMyAdmin-260-pl3/index
ERROR - 2021-06-06 09:57:08 --> 404 Page Not Found: PhpMyAdmin-261-rc1/index
ERROR - 2021-06-06 09:57:08 --> 404 Page Not Found: PhpMyAdmin-261-rc2/index
ERROR - 2021-06-06 09:57:10 --> 404 Page Not Found: PhpMyAdmin-261/index
ERROR - 2021-06-06 09:57:11 --> 404 Page Not Found: PhpMyAdmin-261-pl1/index
ERROR - 2021-06-06 09:57:15 --> 404 Page Not Found: PhpMyAdmin-261-pl2/index
ERROR - 2021-06-06 09:57:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:57:20 --> 404 Page Not Found: PhpMyAdmin-261-pl3/index
ERROR - 2021-06-06 09:57:21 --> 404 Page Not Found: PhpMyAdmin-262-rc1/index
ERROR - 2021-06-06 09:57:22 --> 404 Page Not Found: PhpMyAdmin-262-beta1/index
ERROR - 2021-06-06 09:57:23 --> 404 Page Not Found: PhpMyAdmin-262-rc1/index
ERROR - 2021-06-06 09:57:26 --> 404 Page Not Found: PhpMyAdmin-262-pl1/index
ERROR - 2021-06-06 09:57:26 --> 404 Page Not Found: PhpMyAdmin-263/index
ERROR - 2021-06-06 09:57:33 --> 404 Page Not Found: PhpMyAdmin-263-rc1/index
ERROR - 2021-06-06 09:57:33 --> 404 Page Not Found: PhpMyAdmin-263/index
ERROR - 2021-06-06 09:57:35 --> 404 Page Not Found: PhpMyAdmin-263-pl1/index
ERROR - 2021-06-06 09:57:35 --> 404 Page Not Found: PhpMyAdmin-264-rc1/index
ERROR - 2021-06-06 09:57:35 --> 404 Page Not Found: PhpMyAdmin-264-pl1/index
ERROR - 2021-06-06 09:57:35 --> 404 Page Not Found: PhpMyAdmin-264-pl2/index
ERROR - 2021-06-06 09:57:35 --> 404 Page Not Found: PhpMyAdmin-264-pl3/index
ERROR - 2021-06-06 09:57:36 --> 404 Page Not Found: PhpMyAdmin-264-pl4/index
ERROR - 2021-06-06 09:57:38 --> 404 Page Not Found: PhpMyAdmin-270-beta1/index
ERROR - 2021-06-06 09:57:38 --> 404 Page Not Found: PhpMyAdmin-270-rc1/index
ERROR - 2021-06-06 09:57:38 --> 404 Page Not Found: PhpMyAdmin-270-pl1/index
ERROR - 2021-06-06 09:57:42 --> 404 Page Not Found: PhpMyAdmin-270-pl2/index
ERROR - 2021-06-06 09:57:42 --> 404 Page Not Found: PhpMyAdmin-270/index
ERROR - 2021-06-06 09:57:43 --> 404 Page Not Found: PhpMyAdmin-280-beta1/index
ERROR - 2021-06-06 09:57:43 --> 404 Page Not Found: PhpMyAdmin-280-rc1/index
ERROR - 2021-06-06 09:57:44 --> 404 Page Not Found: PhpMyAdmin-280-rc2/index
ERROR - 2021-06-06 09:57:45 --> 404 Page Not Found: PhpMyAdmin-2801/index
ERROR - 2021-06-06 09:57:45 --> 404 Page Not Found: PhpMyAdmin-2802/index
ERROR - 2021-06-06 09:57:46 --> 404 Page Not Found: PhpMyAdmin-2804/index
ERROR - 2021-06-06 09:57:47 --> 404 Page Not Found: PhpMyAdmin-281-rc1/index
ERROR - 2021-06-06 09:57:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:57:48 --> 404 Page Not Found: PhpMyAdmin-282/index
ERROR - 2021-06-06 09:57:48 --> 404 Page Not Found: Sqlmanager/index
ERROR - 2021-06-06 09:57:50 --> 404 Page Not Found: Mysqlmanager/index
ERROR - 2021-06-06 09:57:50 --> 404 Page Not Found: P/m
ERROR - 2021-06-06 09:57:51 --> 404 Page Not Found: PMA2005/index
ERROR - 2021-06-06 09:57:51 --> 404 Page Not Found: Pma2005/index
ERROR - 2021-06-06 09:57:51 --> 404 Page Not Found: Phpmanager/index
ERROR - 2021-06-06 09:57:52 --> 404 Page Not Found: Php-myadmin/index
ERROR - 2021-06-06 09:57:52 --> 404 Page Not Found: Phpmy-admin/index
ERROR - 2021-06-06 09:57:52 --> 404 Page Not Found: Webadmin/index
ERROR - 2021-06-06 09:57:52 --> 404 Page Not Found: Sqlweb/index
ERROR - 2021-06-06 09:57:53 --> 404 Page Not Found: Websql/index
ERROR - 2021-06-06 09:57:53 --> 404 Page Not Found: Webdb/index
ERROR - 2021-06-06 09:57:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:58:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 09:58:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:59:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 09:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:00:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:01:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:01:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:02:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:02:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:03:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:03:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:03:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:03:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:04:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:04:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:04:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 10:07:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:07:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:09:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:10:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:11:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:12:09 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-06 10:12:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:12:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:12:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:13:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 10:13:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 10:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:14:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:14:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 10:15:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:15:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:16:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:16:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:18:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 10:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:18:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:18:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:19:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:20:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:21:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:24:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 10:24:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:24:55 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-06 10:25:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:26:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:26:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:26:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:26:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:27:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:28:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 10:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:29:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:29:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:29:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 10:29:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:29:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 10:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:30:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:30:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:31:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:32:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:32:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:33:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 10:34:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 10:34:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:34:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:36:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:36:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:36:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:36:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:37:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:37:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:38:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:39:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:40:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 10:40:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:41:28 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 10:41:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:41:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:41:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:42:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:42:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:42:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:42:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:42:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:44:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:44:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:44:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:45:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:45:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:45:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:46:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:46:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:47:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:47:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:47:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:48:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:48:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:48:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:49:53 --> 404 Page Not Found: E/favicon.ico
ERROR - 2021-06-06 10:50:01 --> 404 Page Not Found: Uploads/userup
ERROR - 2021-06-06 10:50:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 10:50:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 10:50:11 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 10:50:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 10:50:18 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 10:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:50:25 --> 404 Page Not Found: Include/taglib
ERROR - 2021-06-06 10:50:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:50:41 --> 404 Page Not Found: Member/space
ERROR - 2021-06-06 10:50:43 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 10:50:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 10:50:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 10:50:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:51:05 --> 404 Page Not Found: Data/cache
ERROR - 2021-06-06 10:51:18 --> 404 Page Not Found: Data/cache
ERROR - 2021-06-06 10:51:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:51:37 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 10:51:46 --> 404 Page Not Found: Dede/templets
ERROR - 2021-06-06 10:51:57 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 10:51:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:52:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:52:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 10:52:05 --> 404 Page Not Found: Data/cache
ERROR - 2021-06-06 10:52:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:52:09 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 10:52:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:52:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:52:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:53:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:53:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:53:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:53:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:53:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:53:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:54:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:54:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:54:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:54:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:54:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:54:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:55:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:55:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:55:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:55:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:55:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:57:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:57:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:58:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:58:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 10:59:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 10:59:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:00:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:00:56 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-06 11:01:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:01:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:01:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:01:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:02:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:03:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:03:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:04:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:04:50 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 11:04:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:05:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:06:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:07:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:07:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:08:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:08:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:08:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:08:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:08:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:09:05 --> 404 Page Not Found: Clientaccesspolicyxml/index
ERROR - 2021-06-06 11:09:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:10:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:10:17 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 11:10:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:10:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:10:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:11:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:12:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:12:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:12:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:13:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:13:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:13:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:14:31 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 11:14:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:14:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:14:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:15:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:15:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:15:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:15:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:15:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:15:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:17:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:17:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 11:17:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:18:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:18:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:20:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:20:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 11:20:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:21:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:21:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:21:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:22:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:22:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:22:28 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-06 11:22:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:23:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:24:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:25:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:25:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:26:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:27:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:27:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:27:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:27:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:27:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:27:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:28:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:28:25 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-06 11:28:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:29:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:29:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:29:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:29:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:30:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:30:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:31:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:32:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:32:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:32:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:33:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 11:34:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:34:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:34:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:35:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:35:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:36:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:36:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:37:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:37:29 --> 404 Page Not Found: Images/Nxrs4tAtO
ERROR - 2021-06-06 11:37:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 11:37:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:37:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:37:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:38:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 11:38:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:40:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:40:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:40:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:41:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:42:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:42:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:42:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:42:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:42:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:42:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 11:44:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:44:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:44:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:45:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:45:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:46:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:46:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:47:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:47:28 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 11:47:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:48:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:48:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:49:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:49:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:49:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:50:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:50:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:50:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:50:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:50:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:50:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:50:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:51:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:51:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:51:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:51:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:52:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:53:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:54:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:55:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 11:55:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 11:55:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 11:55:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 11:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:56:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:56:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:56:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-06 11:58:00 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-06 11:58:01 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-06 11:58:02 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 11:58:02 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 11:58:02 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 11:58:02 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-06 11:58:02 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-06 11:58:02 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-06 11:58:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 11:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:58:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 11:59:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:00:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:01:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 12:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:03:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:03:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:04:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:04:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:05:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:05:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:06:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:06:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:06:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:07:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:07:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:07:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:07:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:08:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:09:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 12:10:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:11:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:12:54 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-06 12:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:12:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:13:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:14:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:14:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 12:16:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:16:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:17:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:19:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:19:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:19:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:19:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:20:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:20:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:21:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:22:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:23:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:24:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 12:25:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:26:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:27:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:28:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:31:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:31:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:31:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:32:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:32:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:32:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:33:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:33:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:33:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:33:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:33:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:33:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:33:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:33:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:34:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:34:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:34:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:34:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:34:31 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-06 12:34:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:34:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 12:36:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:36:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:36:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:38:18 --> 404 Page Not Found: English/index
ERROR - 2021-06-06 12:38:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:39:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:41:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:41:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:42:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 12:42:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:43:26 --> 404 Page Not Found: Jmxw1194/p
ERROR - 2021-06-06 12:43:30 --> 404 Page Not Found: Gczx1/IAwl.html
ERROR - 2021-06-06 12:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:43:50 --> 404 Page Not Found: TravelWeb2007/TourProcess
ERROR - 2021-06-06 12:43:53 --> 404 Page Not Found: Newsclassjsp/index
ERROR - 2021-06-06 12:43:56 --> 404 Page Not Found: Z/yyw28jfwtft2xjj
ERROR - 2021-06-06 12:44:04 --> 404 Page Not Found: V2/article
ERROR - 2021-06-06 12:44:15 --> 404 Page Not Found: Tyzhg/sso.action
ERROR - 2021-06-06 12:44:24 --> 404 Page Not Found: Top-rated/month
ERROR - 2021-06-06 12:44:25 --> 404 Page Not Found: Workflow/request
ERROR - 2021-06-06 12:44:27 --> 404 Page Not Found: Xihongshiniuroutang__shipuchaxun/index
ERROR - 2021-06-06 12:44:27 --> 404 Page Not Found: User/task_list.html
ERROR - 2021-06-06 12:44:27 --> 404 Page Not Found: Model_22790-14928/index
ERROR - 2021-06-06 12:44:30 --> 404 Page Not Found: Country/4345
ERROR - 2021-06-06 12:44:30 --> 404 Page Not Found: Info/1048
ERROR - 2021-06-06 12:44:33 --> 404 Page Not Found: Vod-type-id-7-pg-1html/index
ERROR - 2021-06-06 12:44:39 --> 404 Page Not Found: List/56
ERROR - 2021-06-06 12:44:41 --> 404 Page Not Found: Browsergame/index
ERROR - 2021-06-06 12:44:41 --> 404 Page Not Found: Seeyon/collaboration
ERROR - 2021-06-06 12:44:42 --> 404 Page Not Found: Home/List
ERROR - 2021-06-06 12:44:43 --> 404 Page Not Found: Apfdbqj/skfpssr
ERROR - 2021-06-06 12:44:44 --> 404 Page Not Found: Productasp/index
ERROR - 2021-06-06 12:44:45 --> 404 Page Not Found: Best/teens
ERROR - 2021-06-06 12:44:47 --> 404 Page Not Found: Xwzx/tzgg
ERROR - 2021-06-06 12:44:51 --> 404 Page Not Found: News/industry
ERROR - 2021-06-06 12:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:46:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:47:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:47:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:49:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:49:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 12:49:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:53:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:53:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:53:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:53:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 12:53:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 12:53:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 12:53:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 12:53:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:53:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:54:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:55:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:55:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:57:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 12:57:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 12:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:59:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 12:59:40 --> 404 Page Not Found: 16/10000
ERROR - 2021-06-06 12:59:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 12:59:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:00:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:01:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:01:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 13:01:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:01:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 13:01:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 13:01:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:02:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:04:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:04:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:04:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:05:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:06:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 13:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:08:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 13:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:10:12 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-06 13:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:10:42 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-06 13:11:14 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-06 13:11:47 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-06 13:12:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 13:12:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 13:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:13:21 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-06 13:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:13:52 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-06 13:14:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:15:00 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-06 13:15:31 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-06 13:15:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 13:17:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:20:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:21:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:21:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:21:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 13:21:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:23:20 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-06-06 13:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:25:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-06 13:26:36 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-06 13:26:37 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-06 13:27:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:27:05 --> 404 Page Not Found: Captcha_code/indexs
ERROR - 2021-06-06 13:27:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:27:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:28:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:30:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:31:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:32:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:34:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:35:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:35:37 --> 404 Page Not Found: Article/view
ERROR - 2021-06-06 13:37:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:38:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:38:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:40:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 13:41:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:41:39 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-06 13:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:45:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:46:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 13:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:47:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:47:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:49:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 13:50:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:52:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:52:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:54:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 13:54:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:55:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:56:38 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-06 13:57:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 13:57:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:59:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:59:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 13:59:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:00:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:01:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:01:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 14:02:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:03:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:04:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 14:05:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:06:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:07:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:07:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:08:00 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-06 14:09:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:09:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:11:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:12:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:12:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:13:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:14:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:14:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 14:15:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:16:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:17:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:18:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:18:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 14:18:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 14:19:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:20:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 14:20:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:21:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:21:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:22:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:23:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:23:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 14:24:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 14:25:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 14:25:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 14:25:32 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-06-06 14:25:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:27:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:28:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:28:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:28:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:28:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 14:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:32:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:33:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:35:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:36:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:38:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:38:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:38:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:40:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:41:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:41:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:41:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 14:42:13 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-06 14:42:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:42:48 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-06 14:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:43:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:44:47 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-06-06 14:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:45:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:45:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:46:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:46:01 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-06 14:48:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:48:52 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-06 14:48:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:49:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 14:49:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:49:58 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-06-06 14:50:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:50:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:50:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:51:39 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-06-06 14:52:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:53:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:53:18 --> 404 Page Not Found: admin//index
ERROR - 2021-06-06 14:53:21 --> 404 Page Not Found: Manager/index
ERROR - 2021-06-06 14:53:24 --> 404 Page Not Found: admin/Content/sitetree
ERROR - 2021-06-06 14:53:27 --> 404 Page Not Found: Simpla/index
ERROR - 2021-06-06 14:53:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 14:53:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:54:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:54:46 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-06 14:54:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 14:54:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 14:55:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:55:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:55:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:55:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 14:56:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:56:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 14:56:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:56:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 14:56:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 14:56:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 14:57:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:57:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 14:59:36 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 15:00:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:02:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:04:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:06:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:06:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 15:08:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:08:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:09:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:10:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:10:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:10:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:11:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:12:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:13:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:14:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:14:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:15:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 15:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:16:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:16:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:17:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:17:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:18:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:19:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 15:20:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:20:29 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-06 15:20:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:21:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:21:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:22:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:22:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:23:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:23:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:24:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:24:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:25:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:25:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:25:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:25:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:25:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:25:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:25:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 15:25:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 15:25:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 15:25:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 15:26:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 15:26:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 15:26:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 15:26:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 15:26:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 15:27:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 15:27:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:27:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:27:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:28:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:29:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:29:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:29:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:30:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:30:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:30:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:30:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:30:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:30:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:30:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:31:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:31:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:31:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:32:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:32:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:32:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:34:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:36:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:36:50 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-06 15:38:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:39:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:39:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:40:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:41:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:41:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:43:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:43:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:45:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:45:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:45:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:47:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:47:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:47:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:49:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:50:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:50:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:51:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 15:51:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 15:51:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:53:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:54:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:54:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:56:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 15:58:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 15:59:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 15:59:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:00:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:01:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:02:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 16:02:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:02:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:02:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:02:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:02:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:02:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:02:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:03:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:03:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:04:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:05:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:06:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:07:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:07:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:08:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 16:08:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:09:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:10:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:11:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:11:35 --> 404 Page Not Found: City/1
ERROR - 2021-06-06 16:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:14:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:15:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:17:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:19:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:20:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:21:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:22:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-06-06 16:22:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:23:04 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-06 16:23:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 16:23:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 16:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:24:56 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:25:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:26:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:26:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:26:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:26:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:27:47 --> 404 Page Not Found: English/index
ERROR - 2021-06-06 16:27:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:28:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:29:13 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 16:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:29:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 16:29:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 16:30:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:30:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:32:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:33:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:35:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:38:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:40:03 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 16:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:41:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:42:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:44:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 16:44:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 16:44:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 16:45:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:46:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 16:47:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:48:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:49:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:50:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:50:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:50:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:50:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 16:51:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 16:52:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:52:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:52:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:54:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:55:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:56:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 16:58:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 16:59:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:00:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:01:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:01:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:02:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:02:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:04:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:04:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:04:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:04:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:04:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:04:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:04:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:06:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:06:38 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-06 17:07:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:07:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:08:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:08:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:09:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:09:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:09:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:10:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:10:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:10:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:11:54 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-06 17:11:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 17:11:57 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-06 17:11:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 17:11:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 17:13:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:14:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:14:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:14:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:14:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:16:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:16:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:16:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:17:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:17:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:18:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:18:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:18:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:19:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:19:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:19:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:19:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:20:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:20:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:20:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:20:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:20:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:20:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:20:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:21:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:23:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:23:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:23:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:24:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:24:59 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-06 17:25:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:25:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:26:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:26:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:27:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:30:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:31:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:31:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:33:07 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-06 17:35:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:35:07 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-06 17:36:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:37:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:39:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:39:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:39:43 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 17:39:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:40:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:40:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:41:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:41:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:43:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:43:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 17:43:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:43:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:43:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:44:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:45:46 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-06-06 17:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:46:22 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-06-06 17:46:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:47:00 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-06 17:47:34 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-06 17:47:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 17:47:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:48:12 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-06 17:49:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:50:23 --> 404 Page Not Found: Lxwm/index
ERROR - 2021-06-06 17:50:24 --> 404 Page Not Found: Article/info
ERROR - 2021-06-06 17:50:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:50:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:51:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:53:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:53:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:53:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:53:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:53:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:55:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:56:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:56:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:57:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:57:13 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-06-06 17:58:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 17:59:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:59:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 17:59:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:00:42 --> 404 Page Not Found: City/1
ERROR - 2021-06-06 18:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:01:42 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 18:02:49 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 18:04:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:04:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:04:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:05:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 18:05:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 18:06:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:06:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:06:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:08:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:08:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:08:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 18:09:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:10:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:11:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:13:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 18:13:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:14:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 18:15:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:15:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:15:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:16:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:18:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:19:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:19:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:21:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 18:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:23:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:25:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:25:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:26:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:27:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:28:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:29:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 18:29:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:29:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:29:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:29:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:30:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 18:30:06 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-06-06 18:30:06 --> 404 Page Not Found: Haoma/index
ERROR - 2021-06-06 18:30:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:31:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:32:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 18:32:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:32:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 18:32:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 18:33:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:33:21 --> 404 Page Not Found: Shopasp/index
ERROR - 2021-06-06 18:33:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 18:33:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 18:33:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 18:33:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 18:35:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:35:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:35:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 18:36:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:36:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 18:37:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:37:30 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-06 18:37:34 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-06 18:39:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:40:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:40:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:42:10 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-06 18:42:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:42:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:43:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:43:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:43:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 18:43:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:43:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:44:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:44:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:44:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:44:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 18:44:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:44:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:44:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:44:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:45:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:45:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:45:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:45:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:45:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:46:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:46:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:46:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:46:38 --> 404 Page Not Found: Wp-includes/wlwmanifest.xml
ERROR - 2021-06-06 18:46:40 --> 404 Page Not Found: Blog/wp-includes
ERROR - 2021-06-06 18:46:41 --> 404 Page Not Found: Wordpress/wp-includes
ERROR - 2021-06-06 18:46:42 --> 404 Page Not Found: Website/wp-includes
ERROR - 2021-06-06 18:46:42 --> 404 Page Not Found: Wp/wp-includes
ERROR - 2021-06-06 18:46:43 --> 404 Page Not Found: News/wp-includes
ERROR - 2021-06-06 18:46:44 --> 404 Page Not Found: 2020/wp-includes
ERROR - 2021-06-06 18:46:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:46:44 --> 404 Page Not Found: 2019/wp-includes
ERROR - 2021-06-06 18:46:45 --> 404 Page Not Found: Shop/wp-includes
ERROR - 2021-06-06 18:46:46 --> 404 Page Not Found: Wp1/wp-includes
ERROR - 2021-06-06 18:46:47 --> 404 Page Not Found: Test/wp-includes
ERROR - 2021-06-06 18:46:47 --> 404 Page Not Found: Wp2/wp-includes
ERROR - 2021-06-06 18:46:48 --> 404 Page Not Found: Site/wp-includes
ERROR - 2021-06-06 18:46:49 --> 404 Page Not Found: Cms/wp-includes
ERROR - 2021-06-06 18:46:49 --> 404 Page Not Found: Sito/wp-includes
ERROR - 2021-06-06 18:46:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:46:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:47:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:47:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:48:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:48:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:48:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:50:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:51:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:51:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:51:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:52:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:55:56 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 18:55:56 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 18:55:56 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-06 18:55:56 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 18:55:56 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 18:55:56 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-06 18:55:56 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 18:55:56 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-06 18:55:56 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 18:55:56 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-06 18:55:57 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-06 18:55:58 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-06 18:55:58 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-06 18:55:58 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 18:55:58 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 18:55:58 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 18:55:58 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-06 18:55:58 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-06 18:56:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:56:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:56:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:56:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:56:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:57:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:57:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:57:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 18:58:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:58:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 18:59:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:01:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:01:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:02:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:02:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:03:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:03:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:03:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:03:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:04:01 --> 404 Page Not Found: Home/tradeInfo
ERROR - 2021-06-06 19:04:01 --> 404 Page Not Found: Article/info
ERROR - 2021-06-06 19:04:03 --> 404 Page Not Found: Shop_showasp/index
ERROR - 2021-06-06 19:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:04:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 19:04:19 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-06-06 19:06:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:06:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:06:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 19:06:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 19:06:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 19:06:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 19:06:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:07:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:07:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:07:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:07:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:07:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:08:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:09:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:09:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:10:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:10:21 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 19:10:21 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 19:10:21 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 19:10:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-06 19:10:22 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 19:10:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 19:10:23 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-06 19:10:23 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 19:10:23 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-06 19:10:23 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-06 19:10:23 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-06 19:10:23 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-06 19:10:23 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 19:10:24 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 19:10:24 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 19:10:24 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-06 19:10:24 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-06 19:10:24 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-06 19:10:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:10:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:11:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:11:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:14:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 19:14:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 19:14:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:14:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:15:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:15:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:15:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:15:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:15:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:16:11 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 19:16:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:16:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 19:17:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:17:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:19:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:20:03 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:20:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:22:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:22:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:22:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:23:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:24:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:25:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:28:32 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-06 19:28:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:30:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:31:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:32:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:32:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:33:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:33:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:34:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:34:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:34:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:35:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:35:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:35:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:35:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:37:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:37:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:37:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:37:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:37:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:38:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:38:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:39:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:40:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:41:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:41:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:41:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:41:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:42:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:42:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 19:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:45:01 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 19:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:45:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:46:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:46:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:47:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:49:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:49:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:50:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 19:51:39 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 19:51:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:52:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:52:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:53:05 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 19:53:05 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 19:53:05 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-06-06 19:53:05 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-06-06 19:53:05 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 19:53:05 --> 404 Page Not Found: Xuanhao_netrar/index
ERROR - 2021-06-06 19:53:05 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 19:53:05 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-06 19:53:05 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 19:53:05 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 19:53:05 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Xuanhao_netzip/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Xuanhao_nettargz/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 19:53:06 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 19:53:07 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 19:53:07 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-06 19:53:07 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-06 19:53:07 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-06 19:53:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:53:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:55:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:56:15 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-06-06 19:56:47 --> Severity: Warning --> Missing argument 1 for Zifei::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 22
ERROR - 2021-06-06 19:57:15 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-06-06 19:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:57:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:57:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 19:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Www20210604rar/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Wwwxuanhaonet20210604rar/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Www_xuanhao_net20210604rar/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Wwwxuanhaonet20210604rar/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Xuanhaonet20210604rar/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Xuanhao_net20210604rar/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Xuanhaonet20210604rar/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Xuanhao20210604rar/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Www20210604targz/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Wwwxuanhaonet20210604targz/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Www_xuanhao_net20210604targz/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Wwwxuanhaonet20210604targz/index
ERROR - 2021-06-06 19:58:12 --> 404 Page Not Found: Xuanhaonet20210604targz/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Xuanhao_net20210604targz/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Xuanhaonet20210604targz/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Xuanhao20210604targz/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Www20210604zip/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Wwwxuanhaonet20210604zip/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Www_xuanhao_net20210604zip/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Wwwxuanhaonet20210604zip/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Xuanhaonet20210604zip/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Xuanhao_net20210604zip/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Xuanhaonet20210604zip/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Xuanhao20210604zip/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Www2021-06-04rar/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Wwwxuanhaonet2021-06-04rar/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Www_xuanhao_net2021-06-04rar/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Wwwxuanhaonet2021-06-04rar/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Xuanhaonet2021-06-04rar/index
ERROR - 2021-06-06 19:58:13 --> 404 Page Not Found: Xuanhao_net2021-06-04rar/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Xuanhaonet2021-06-04rar/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Xuanhao2021-06-04rar/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Www2021-06-04targz/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Wwwxuanhaonet2021-06-04targz/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Www_xuanhao_net2021-06-04targz/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Wwwxuanhaonet2021-06-04targz/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Xuanhaonet2021-06-04targz/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Xuanhao_net2021-06-04targz/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Xuanhaonet2021-06-04targz/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Xuanhao2021-06-04targz/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Www2021-06-04zip/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Wwwxuanhaonet2021-06-04zip/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Www_xuanhao_net2021-06-04zip/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Wwwxuanhaonet2021-06-04zip/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Xuanhaonet2021-06-04zip/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Xuanhao_net2021-06-04zip/index
ERROR - 2021-06-06 19:58:14 --> 404 Page Not Found: Xuanhaonet2021-06-04zip/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Xuanhao2021-06-04zip/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Www20210604rar/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Wwwxuanhaonet20210604rar/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Www_xuanhao_net20210604rar/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Wwwxuanhaonet20210604rar/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Xuanhaonet20210604rar/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Xuanhao_net20210604rar/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Xuanhaonet20210604rar/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Xuanhao20210604rar/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Www20210604targz/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Wwwxuanhaonet20210604targz/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Www_xuanhao_net20210604targz/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Wwwxuanhaonet20210604targz/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Xuanhaonet20210604targz/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Xuanhao_net20210604targz/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Xuanhaonet20210604targz/index
ERROR - 2021-06-06 19:58:15 --> 404 Page Not Found: Xuanhao20210604targz/index
ERROR - 2021-06-06 19:58:16 --> 404 Page Not Found: Www20210604zip/index
ERROR - 2021-06-06 19:58:16 --> 404 Page Not Found: Wwwxuanhaonet20210604zip/index
ERROR - 2021-06-06 19:58:16 --> 404 Page Not Found: Www_xuanhao_net20210604zip/index
ERROR - 2021-06-06 19:58:16 --> 404 Page Not Found: Wwwxuanhaonet20210604zip/index
ERROR - 2021-06-06 19:58:16 --> 404 Page Not Found: Xuanhaonet20210604zip/index
ERROR - 2021-06-06 19:58:16 --> 404 Page Not Found: Xuanhao_net20210604zip/index
ERROR - 2021-06-06 19:58:16 --> 404 Page Not Found: Xuanhaonet20210604zip/index
ERROR - 2021-06-06 19:58:16 --> 404 Page Not Found: Xuanhao20210604zip/index
ERROR - 2021-06-06 19:58:16 --> 404 Page Not Found: 20210604rar/index
ERROR - 2021-06-06 19:58:16 --> 404 Page Not Found: 20210604targz/index
ERROR - 2021-06-06 19:58:16 --> 404 Page Not Found: 20210604zip/index
ERROR - 2021-06-06 19:58:25 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-06-06 19:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:00:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:01:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:01:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:03:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:03:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:03:59 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-06-06 20:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:04:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:05:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:06:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:07:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:08:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:08:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:08:56 --> Severity: Warning --> Missing argument 1 for Taocan::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Taocan.php 21
ERROR - 2021-06-06 20:09:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:09:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:10:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:11:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:14:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:14:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:14:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:14:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:15:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:15:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:15:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:15:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:15:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:16:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:16:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:18:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:18:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:18:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:18:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:19:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:19:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:20:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:20:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:20:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:20:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 20:20:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:21:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:22:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:22:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:22:57 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:23:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:23:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:24:12 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:24:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:24:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:24:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:25:01 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:25:07 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:25:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:25:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:26:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:28:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:29:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:29:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:29:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 20:29:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 20:30:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:31:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:31:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:31:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 20:33:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:35:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:35:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:36:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:36:40 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:36:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:36:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 20:37:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:37:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 20:37:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:38:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:38:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:38:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:39:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:39:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:39:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:39:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:39:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:39:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:40:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:40:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 20:41:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:43:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:43:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:44:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:45:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:45:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:46:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:46:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:46:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:46:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:46:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:46:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:46:43 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:46:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:46:49 --> Severity: Warning --> Missing argument 1 for News::duanxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 421
ERROR - 2021-06-06 20:48:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:48:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:48:39 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-06 20:48:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:48:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:49:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:49:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:49:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:49:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:50:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:50:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:51:05 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:51:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:51:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:51:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:52:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:52:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:52:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:52:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:54:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:54:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 20:54:54 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 20:55:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:55:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:55:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:56:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:56:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:57:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:58:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 20:59:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 21:01:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:02:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:02:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:02:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:03:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:06:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:06:10 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:06:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:06:23 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:06:29 --> 404 Page Not Found: Feed/index
ERROR - 2021-06-06 21:06:30 --> 404 Page Not Found: Wp-json/wp
ERROR - 2021-06-06 21:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:06:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:06:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 21:06:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:06:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:07:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:07:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:08:33 --> 404 Page Not Found: Sitemap44082html/index
ERROR - 2021-06-06 21:08:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:09:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:09:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:11:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:15:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:15:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:15:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:16:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:17:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:20:07 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-06 21:20:26 --> 404 Page Not Found: English/index
ERROR - 2021-06-06 21:20:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:20:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:20:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:20:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 21:21:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:22:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:22:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 21:22:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:22:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:23:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:23:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:23:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:23:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:23:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:23:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:23:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:24:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:24:18 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 21:24:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 21:24:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:25:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 21:25:26 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:25:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:25:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:27:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:27:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 21:27:52 --> 404 Page Not Found: Mxuanhaonetrar/index
ERROR - 2021-06-06 21:27:53 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-06-06 21:27:53 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-06-06 21:27:53 --> 404 Page Not Found: Mxuanhaonetzip/index
ERROR - 2021-06-06 21:27:54 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-06-06 21:27:54 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-06-06 21:27:55 --> 404 Page Not Found: Webrar/index
ERROR - 2021-06-06 21:27:55 --> 404 Page Not Found: Webzip/index
ERROR - 2021-06-06 21:27:56 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-06-06 21:27:56 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-06-06 21:27:56 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-06-06 21:27:57 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-06-06 21:27:57 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-06-06 21:27:58 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-06-06 21:27:58 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-06-06 21:27:59 --> 404 Page Not Found: Mxuanhaonettargz/index
ERROR - 2021-06-06 21:27:59 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-06-06 21:28:00 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-06-06 21:28:00 --> 404 Page Not Found: Mrar/index
ERROR - 2021-06-06 21:28:01 --> 404 Page Not Found: Mzip/index
ERROR - 2021-06-06 21:28:01 --> 404 Page Not Found: Mtargz/index
ERROR - 2021-06-06 21:28:02 --> 404 Page Not Found: Mxuanhaonetrar/index
ERROR - 2021-06-06 21:28:02 --> 404 Page Not Found: Mxuanhaonetzip/index
ERROR - 2021-06-06 21:28:03 --> 404 Page Not Found: Mxuanhaonettargz/index
ERROR - 2021-06-06 21:29:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:31:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:31:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:34:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 21:34:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 21:34:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 21:34:14 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 21:34:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:35:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:36:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 21:36:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:37:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:38:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 21:39:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:39:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 21:40:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:43:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:44:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 21:44:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 21:44:50 --> Severity: Warning --> Missing argument 1 for Kefu::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 87
ERROR - 2021-06-06 21:45:20 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-06 21:45:50 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-06-06 21:46:23 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-06 21:46:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:46:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:46:53 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-06-06 21:48:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:48:26 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-06-06 21:48:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:48:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:48:53 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-06-06 21:49:19 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:49:26 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-06-06 21:49:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:50:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 21:51:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:51:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:52:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:53:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:55:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:55:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:57:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 21:57:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 21:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:00:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:02:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:02:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:03:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:03:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:03:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 22:04:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:04:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:04:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:05:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:05:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:05:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:05:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:06:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:07:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:07:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:08:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:08:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:09:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:10:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:10:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:10:37 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-06-06 22:11:37 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/mb_tiaohao/dingdan_show.php 74
ERROR - 2021-06-06 22:12:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:12:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:12:33 --> 404 Page Not Found: City/1
ERROR - 2021-06-06 22:13:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:13:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:13:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:14:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:14:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:15:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:15:11 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:15:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:15:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:16:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:17:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:17:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:17:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:19:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:20:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:21:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:21:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:22:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:23:27 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:23:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:24:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:24:38 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:24:51 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:25:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:25:39 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:26:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:26:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:26:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:26:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 22:27:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:27:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:27:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:27:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:28:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:28:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:28:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:29:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:29:17 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:31:14 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:31:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:31:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:31:50 --> Severity: Warning --> Missing argument 1 for News::xiuxian() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 501
ERROR - 2021-06-06 22:31:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:32:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:33:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:34:51 --> 404 Page Not Found: All/index
ERROR - 2021-06-06 22:35:29 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:36:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:37:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:39:15 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:39:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:40:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:41:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:41:31 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-06-06 22:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:41:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:41:47 --> 404 Page Not Found: City/1
ERROR - 2021-06-06 22:41:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:43:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:43:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:43:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:44:33 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:44:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:44:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:44:45 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:44:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:45:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:45:20 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:45:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:45:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:46:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:47:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:48:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 22:48:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:50:11 --> Severity: Warning --> Missing argument 1 for News::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 101
ERROR - 2021-06-06 22:50:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:52:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:53:09 --> 404 Page Not Found: City/16
ERROR - 2021-06-06 22:53:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:53:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:53:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:54:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:54:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:54:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 22:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:58:37 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 22:59:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 22:59:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:00:44 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 23:00:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 23:01:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:01:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 23:01:32 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:01:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 23:01:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:01:45 --> 404 Page Not Found: Search/likea
ERROR - 2021-06-06 23:02:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:02:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:03:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 23:03:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 23:04:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 23:04:43 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 23:04:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:07:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:07:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:08:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:09:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-06-06 23:09:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:09:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:09:51 --> 404 Page Not Found: City/2
ERROR - 2021-06-06 23:11:16 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:13:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:13:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:15:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:15:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:17:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:17:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:17:59 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:18:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:19:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:19:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:20:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:20:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 23:20:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 23:21:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:21:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:23:20 --> 404 Page Not Found: Data/admin
ERROR - 2021-06-06 23:23:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:24:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:25:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:26:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:26:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:26:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:27:35 --> Severity: Warning --> Missing argument 1 for Page::bangzhu() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 58
ERROR - 2021-06-06 23:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:28:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:29:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:31:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:31:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:32:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:33:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:33:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:33:35 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:33:54 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:34:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:35:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:36:28 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:36:30 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:36:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:36:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:36:34 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:36:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:37:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:37:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2086
ERROR - 2021-06-06 23:38:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:41:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:42:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:43:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:44:04 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:44:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:45:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:46:31 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:46:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:46:46 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:46:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:47:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:47:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:47:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:48:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:51:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:54:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 385
ERROR - 2021-06-06 23:55:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:55:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:56:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:56:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:56:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:57:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:57:41 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:59:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:59:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:59:24 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:59:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-06-06 23:59:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-06-06 23:59:58 --> 404 Page Not Found: Robotstxt/index
