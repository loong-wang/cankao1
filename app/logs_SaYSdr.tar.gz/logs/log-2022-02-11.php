<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-02-11 00:01:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 00:01:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 00:01:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 00:01:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 00:02:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 00:02:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 00:03:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 00:08:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 00:08:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 00:10:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 00:10:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 00:15:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 00:24:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 00:29:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 00:36:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 00:36:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 00:36:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 00:36:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 00:36:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 00:38:35 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 00:40:23 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 00:46:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 00:46:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 00:49:30 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 00:58:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 01:00:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 01:04:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 01:11:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 01:11:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 01:11:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 01:12:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 01:12:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 01:12:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 01:12:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 01:12:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 01:12:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 01:12:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 01:12:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 01:13:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-11 01:15:40 --> 404 Page Not Found: Login/index
ERROR - 2022-02-11 01:23:09 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2022-02-11 01:27:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 01:27:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 01:29:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 01:31:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 01:34:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 01:35:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 01:36:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 01:37:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 01:42:09 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-11 01:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 02:06:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:11:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 02:17:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:24:14 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 02:25:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 02:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:26:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:27:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:28:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:28:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:28:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:28:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:28:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:28:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:29:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:30:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:30:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:31:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:31:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:31:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:31:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:31:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:32:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:33:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:33:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:33:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:34:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:35:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:35:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:35:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:36:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:36:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:36:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:37:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:37:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:37:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:38:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:38:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:39:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:39:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:39:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:39:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:40:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:41:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:42:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:42:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:42:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:42:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:43:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:44:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:44:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:44:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:45:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:45:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:45:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:45:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:46:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:46:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:46:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:47:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:47:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:48:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:48:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:48:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:48:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:49:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:49:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:49:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:50:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:50:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:51:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:52:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 02:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:53:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:53:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:54:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:54:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:55:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 02:55:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:55:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:56:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 02:57:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:57:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:57:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:59:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:59:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 02:59:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:00:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 03:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:00:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:00:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:01:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:01:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:01:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:02:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:02:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:03:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:04:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:04:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:04:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:05:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:06:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:07:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:07:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:09:51 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 03:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:10:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:10:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:10:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:11:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:12:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:12:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:13:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:14:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:16:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:16:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:16:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:16:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:18:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:21:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:23:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:24:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:25:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:25:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:25:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:25:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:26:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:28:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:29:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:29:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:31:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:31:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:34:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:35:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:36:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:38:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:39:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:41:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:43:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:43:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:52:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:52:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:53:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:53:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:56:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:56:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:56:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 03:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:00:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:02:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 04:04:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 04:04:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:05:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:08:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:11:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:11:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:14:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:15:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:16:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:16:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:21:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:28:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:31:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:32:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:39:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:40:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 04:41:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 04:51:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:01:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:11:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:22:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:25:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:30:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:34:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:34:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 05:36:46 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 06:07:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 06:07:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 06:11:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 06:13:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 06:24:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 06:24:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 06:24:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 06:24:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 06:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 06:25:50 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2022-02-11 06:34:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 06:46:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-11 06:46:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 06:50:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 07:03:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 07:04:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 07:20:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 07:20:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 07:21:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 07:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 07:41:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 07:42:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 07:48:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 07:54:20 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-11 07:54:20 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-11 07:54:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 07:54:20 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 07:54:20 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 07:54:20 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 07:54:20 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 07:54:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 07:54:22 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-11 07:54:22 --> 404 Page Not Found: Member/space
ERROR - 2022-02-11 07:54:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 07:54:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 07:54:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 07:54:23 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 07:54:24 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 07:54:25 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 07:54:25 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-11 07:54:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 07:54:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 07:54:27 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 07:54:27 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 07:56:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 07:56:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 07:56:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 07:57:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 07:57:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 07:57:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 07:57:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 07:58:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 07:59:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:00:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:00:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:01:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:01:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:02:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:02:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 08:05:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:06:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 08:06:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 08:06:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:12:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 08:14:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:15:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:15:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:16:23 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 08:18:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:19:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:20:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:20:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:20:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:21:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:22:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:22:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:25:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 08:25:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:26:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:26:39 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-11 08:26:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 08:28:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 08:29:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 08:29:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 08:29:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 08:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 08:42:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:43:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:44:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:46:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:47:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:48:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:48:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:49:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:49:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:49:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:50:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:50:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 08:52:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:03:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:05:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:05:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:06:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:06:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:06:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:07:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:08:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:08:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:10:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:10:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:11:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 09:12:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:13:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 09:13:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:14:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 09:14:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 09:15:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 09:21:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:22:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:23:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 09:24:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:25:38 --> 404 Page Not Found: Xxxss/index
ERROR - 2022-02-11 09:26:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:26:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:27:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 09:27:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:27:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:28:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:29:55 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-11 09:30:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-11 09:30:46 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-11 09:32:03 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-11 09:33:26 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-11 09:34:12 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-11 09:35:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 09:36:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 09:36:40 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-11 09:41:22 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-11 09:41:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 09:41:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 09:44:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 09:49:56 --> 404 Page Not Found: Indexhtml/index
ERROR - 2022-02-11 09:52:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 09:59:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 10:00:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:01:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:01:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:05:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:07:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:09:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:15:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:19:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:21:18 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-11 10:21:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:28:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:29:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:29:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:30:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:31:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:33:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:34:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:36:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:36:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:36:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:37:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:39:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:40:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:43:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:43:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:43:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:43:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:45:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 10:49:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:50:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:50:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:51:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:52:58 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 10:54:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:54:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:55:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:55:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:55:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:56:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 10:56:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:57:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:57:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 10:57:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 11:00:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:00:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:01:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 11:02:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 11:06:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 11:08:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:09:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:09:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:09:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:10:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:11:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:11:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 11:16:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 11:17:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 11:19:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:29:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:38:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:38:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:39:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 11:40:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:40:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:42:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:44:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 11:45:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:45:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:46:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:46:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:46:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:46:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:46:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:51:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 11:51:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:52:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:53:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:54:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:55:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:56:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:57:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 11:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 12:00:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:02:49 --> 404 Page Not Found: City/10
ERROR - 2022-02-11 12:02:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:04:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:04:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:05:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:05:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:08:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:08:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:09:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:10:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 12:11:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:13:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 12:14:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:15:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:15:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:17:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:19:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:21:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:21:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:22:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:22:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:22:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 12:23:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:23:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:24:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:24:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:26:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:26:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:27:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:28:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:28:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:28:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:30:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:32:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:33:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:35:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 12:49:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 12:52:17 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2022-02-11 12:52:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 12:59:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:01:47 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-11 13:02:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 13:05:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:06:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 13:17:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 13:19:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:20:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:20:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 13:21:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:23:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:25:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 13:25:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:26:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:29:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:29:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:30:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:30:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:30:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:30:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 13:31:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:31:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:37:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 13:39:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 13:40:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 13:43:06 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 13:52:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 13:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 14:03:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 14:05:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 14:06:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 14:12:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 14:15:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 14:16:35 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-11 14:16:36 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-11 14:16:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 14:16:38 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 14:16:38 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 14:16:38 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 14:16:38 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 14:16:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 14:16:40 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-11 14:16:41 --> 404 Page Not Found: Member/space
ERROR - 2022-02-11 14:16:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 14:16:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 14:16:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 14:16:41 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 14:16:41 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 14:16:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 14:16:46 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-11 14:16:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 14:16:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 14:16:47 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 14:16:47 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 14:17:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 14:17:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 14:19:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 14:19:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 14:25:56 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 14:37:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 14:55:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 14:55:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 14:56:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 14:56:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 14:57:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 14:57:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 14:57:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 14:57:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 14:58:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 14:58:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 14:59:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:00:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:00:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:00:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:01:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:02:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:02:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:02:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:02:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:03:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:03:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:03:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:03:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:04:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:04:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:06:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:06:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:09:16 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:09:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:15:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 15:20:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:21:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 15:21:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:22:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:24:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:24:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:28:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 15:32:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:32:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:36:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 15:36:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 15:40:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:40:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:40:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:40:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:41:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:41:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:41:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:41:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:41:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:41:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:48:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:48:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:49:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:55:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:56:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 15:57:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 15:59:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 16:02:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:15:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:16:31 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 16:21:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 16:22:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:23:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:24:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:24:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:25:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:27:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:30:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:30:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:38:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 16:38:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:39:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 16:41:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:41:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:42:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:43:01 --> Severity: Warning --> Invalid argument supplied for foreach() /www/wwwroot/www.xuanhao.net/app/views/admin/dingdan_list.php 196
ERROR - 2022-02-11 16:43:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 16:43:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:43:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:44:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:44:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:44:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 16:45:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:45:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:45:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:46:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:46:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:47:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:48:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:48:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:48:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:49:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:49:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:49:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:49:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:50:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:50:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 16:53:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:54:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:55:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:55:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:56:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:58:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:58:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 16:59:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 17:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 17:00:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 17:07:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 17:08:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 17:08:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 17:12:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 17:13:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 17:19:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 17:25:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 17:43:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: insert into `fox_haoma` (hao_city,hao_type,hao_pinpai,hao_title,hao_jiage,hao_huafei,hao_heyue,hao_beizhu,hao_user,hao_time) values 
ERROR - 2022-02-11 17:46:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: insert into `fox_haoma` (hao_city,hao_type,hao_pinpai,hao_title,hao_jiage,hao_huafei,hao_heyue,hao_beizhu,hao_user,hao_time) values 
ERROR - 2022-02-11 18:10:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 18:11:18 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-11 18:11:18 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-11 18:11:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 18:11:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:11:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:11:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:11:18 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:11:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 18:11:19 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-11 18:11:19 --> 404 Page Not Found: Member/space
ERROR - 2022-02-11 18:11:19 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:11:19 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:11:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 18:11:19 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 18:11:19 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 18:11:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:11:22 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-11 18:11:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:11:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:11:22 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 18:11:22 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:14:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 18:14:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 18:17:45 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2022-02-11 18:20:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 18:23:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 18:23:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 18:24:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 18:27:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 18:29:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 18:36:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 18:42:37 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-11 18:42:38 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-11 18:42:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 18:42:38 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:42:39 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:42:39 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:42:39 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:42:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 18:42:39 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-11 18:42:39 --> 404 Page Not Found: Member/space
ERROR - 2022-02-11 18:42:39 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:42:39 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:42:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 18:42:41 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 18:42:41 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 18:42:42 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:42:43 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-11 18:42:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:42:44 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:42:45 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 18:42:46 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 18:42:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 18:45:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 19:08:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 19:11:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 19:11:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 19:21:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 19:45:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 19:47:58 --> 404 Page Not Found: Sdk/index
ERROR - 2022-02-11 19:47:58 --> 404 Page Not Found: Text4041644580078/index
ERROR - 2022-02-11 19:47:58 --> 404 Page Not Found: Evox/about
ERROR - 2022-02-11 19:47:58 --> 404 Page Not Found: HNAP1/index
ERROR - 2022-02-11 19:48:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 19:53:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 19:54:39 --> 404 Page Not Found: E/favicon.ico
ERROR - 2022-02-11 19:54:41 --> 404 Page Not Found: Uploads/userup
ERROR - 2022-02-11 19:54:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 19:54:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 19:54:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 19:54:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 19:54:41 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 19:54:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 19:54:42 --> 404 Page Not Found: Include/taglib
ERROR - 2022-02-11 19:54:42 --> 404 Page Not Found: Member/space
ERROR - 2022-02-11 19:54:42 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 19:54:42 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 19:54:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 19:54:42 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 19:54:42 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 19:54:43 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 19:54:43 --> 404 Page Not Found: Dede/templets
ERROR - 2022-02-11 19:54:43 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 19:54:43 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 19:54:43 --> 404 Page Not Found: Data/cache
ERROR - 2022-02-11 19:54:45 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 19:59:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 20:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 20:07:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 20:13:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 20:20:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 20:23:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 20:24:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 20:29:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 20:30:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 20:30:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 20:31:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 20:36:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 20:37:52 --> 404 Page Not Found: City/1
ERROR - 2022-02-11 20:38:00 --> 404 Page Not Found: City/1
ERROR - 2022-02-11 20:38:00 --> 404 Page Not Found: City/1
ERROR - 2022-02-11 20:38:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 20:38:47 --> 404 Page Not Found: City/1
ERROR - 2022-02-11 20:39:45 --> 404 Page Not Found: City/1
ERROR - 2022-02-11 20:42:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 20:46:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 20:47:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 20:48:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 20:49:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 20:50:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 20:50:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 20:51:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 21:00:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 21:01:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:02:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:03:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 21:03:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 21:13:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-11 21:13:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:15:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:22:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:23:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 21:23:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 21:24:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 21:24:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 21:26:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:29:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:36:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 21:36:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 21:37:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 21:38:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:38:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:39:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:43:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:44:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 21:56:03 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 22:02:15 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 22:06:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 22:13:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:17:49 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-11 22:18:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:18:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:18:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:19:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:19:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:19:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 22:22:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:23:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:23:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:23:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:25:26 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 22:30:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 22:40:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 22:42:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 22:44:21 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 22:50:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:50:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 22:53:08 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 22:58:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 23:02:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 23:07:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 23:12:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:17:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 23:23:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 23:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 23:30:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 23:36:23 --> 404 Page Not Found: LOCKhtm/index
ERROR - 2022-02-11 23:36:25 --> 404 Page Not Found: English/index
ERROR - 2022-02-11 23:38:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '-60, 60' at line 7 - Invalid query: SELECT *
FROM `fox_haoma`
WHERE `hao_city` = '1'
AND  `hao_title` LIKE '%4134%' ESCAPE '!'
AND `hao_lock` <=0
ORDER BY `hao_time` DESC
 LIMIT -60, 60
ERROR - 2022-02-11 23:38:38 --> Severity: Error --> Call to a member function num_rows() on a non-object /www/wwwroot/www.xuanhao.net/app/models/Haoma_m.php 117
ERROR - 2022-02-11 23:38:38 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:42:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:42:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:42:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:42:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:46:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-11 23:48:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 23:48:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 23:48:56 --> 404 Page Not Found: Data/admin
ERROR - 2022-02-11 23:51:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:51:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:51:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:51:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:51:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:51:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:51:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:51:56 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:52:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:52:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2022-02-11 23:54:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 23:55:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 23:55:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 23:56:02 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2022-02-11 23:56:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2022-02-11 23:56:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-02-11 23:58:23 --> 404 Page Not Found: Data/admin
