<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-10-06 00:00:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 00:03:08 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-06 00:05:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 00:05:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 00:08:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 00:08:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 00:15:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 00:36:21 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-06 00:48:09 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 01:00:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 01:00:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 01:04:45 --> Severity: Warning --> Missing argument 1 for Kefu::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 267
ERROR - 2021-10-06 01:05:36 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 01:05:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 01:05:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 01:06:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 01:06:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 01:07:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 01:07:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 01:07:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 01:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 01:17:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 01:17:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 01:22:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 01:25:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 01:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 01:36:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 01:49:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 01:51:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 01:51:54 --> 404 Page Not Found: City/16
ERROR - 2021-10-06 01:52:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 01:58:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 01:59:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 02:02:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 02:18:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 02:23:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 02:24:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 02:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 02:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 02:52:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 02:52:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 02:57:08 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 03:15:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 03:16:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 03:16:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 03:23:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 03:23:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 03:23:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 03:24:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 03:24:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 03:24:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 03:32:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 03:40:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 03:41:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 03:48:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 03:51:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 04:06:06 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
ERROR - 2021-10-06 04:09:22 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 04:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 04:26:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 04:28:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 04:38:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 05:08:42 --> 404 Page Not Found: City/10
ERROR - 2021-10-06 05:11:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 05:21:00 --> 404 Page Not Found: City/index
ERROR - 2021-10-06 05:23:35 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-10-06 05:28:07 --> 404 Page Not Found: 1rar/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 1zip/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 2rar/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 2zip/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 3rar/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 3zip/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 4rar/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 4zip/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 5rar/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 5zip/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 6rar/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 6zip/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 7rar/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 7zip/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 8rar/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 8zip/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 9rar/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 9zip/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 1targz/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 17z/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 2targz/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 27z/index
ERROR - 2021-10-06 05:28:08 --> 404 Page Not Found: 3targz/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 37z/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 4targz/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 47z/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 5targz/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 57z/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 6targz/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 67z/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 7targz/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 77z/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 8targz/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 87z/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 9targz/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: 97z/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: Fuwuqirar/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: Fuwuqizip/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: Wwwrootrar/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: Wwwrootzip/index
ERROR - 2021-10-06 05:28:09 --> 404 Page Not Found: Wwwrootbakrar/index
ERROR - 2021-10-06 05:28:10 --> 404 Page Not Found: Wwwrootbakzip/index
ERROR - 2021-10-06 05:28:10 --> 404 Page Not Found: Wwwrar/index
ERROR - 2021-10-06 05:28:10 --> 404 Page Not Found: Wwwzip/index
ERROR - 2021-10-06 05:28:10 --> 404 Page Not Found: Webrar/index
ERROR - 2021-10-06 05:28:10 --> 404 Page Not Found: Webzip/index
ERROR - 2021-10-06 05:28:10 --> 404 Page Not Found: Wwwbakrar/index
ERROR - 2021-10-06 05:28:10 --> 404 Page Not Found: Wwwbakzip/index
ERROR - 2021-10-06 05:28:10 --> 404 Page Not Found: Webbakrar/index
ERROR - 2021-10-06 05:28:10 --> 404 Page Not Found: Webbakzip/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Www_xuanhao_netrar/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Www_xuanhao_netzip/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Wwwxuanhaonetrar/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Wwwxuanhaonetzip/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Xuanhaonetrar/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Xuanhaonetzip/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Xuanhaorar/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Xuanhaozip/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Wwwxuanhaonetbakrar/index
ERROR - 2021-10-06 05:28:11 --> 404 Page Not Found: Wwwxuanhaonetbakzip/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Www_xuanhao_netbakrar/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Www_xuanhao_netbakzip/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Wwwxuanhaonetbakrar/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Wwwxuanhaonetbakzip/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Xuanhaonetbakrar/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Xuanhaonetbakzip/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Xuanhaobakrar/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Xuanhaobakzip/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Dbrar/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Dbzip/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Wzrar/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Wzzip/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Fdsarar/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Fdsazip/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Wangzhanrar/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Wangzhanzip/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Rootrar/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Rootzip/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Adminrar/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Adminzip/index
ERROR - 2021-10-06 05:28:12 --> 404 Page Not Found: Datarar/index
ERROR - 2021-10-06 05:28:13 --> 404 Page Not Found: Datazip/index
ERROR - 2021-10-06 05:28:13 --> 404 Page Not Found: Ggrar/index
ERROR - 2021-10-06 05:28:13 --> 404 Page Not Found: Ggzip/index
ERROR - 2021-10-06 05:28:13 --> 404 Page Not Found: Viprar/index
ERROR - 2021-10-06 05:28:13 --> 404 Page Not Found: Vipzip/index
ERROR - 2021-10-06 05:28:13 --> 404 Page Not Found: Databackrar/index
ERROR - 2021-10-06 05:28:13 --> 404 Page Not Found: Databackzip/index
ERROR - 2021-10-06 05:28:13 --> 404 Page Not Found: Databackuprar/index
ERROR - 2021-10-06 05:28:13 --> 404 Page Not Found: Databackupzip/index
ERROR - 2021-10-06 05:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 05:28:34 --> 404 Page Not Found: Hdocsrar/index
ERROR - 2021-10-06 05:28:34 --> 404 Page Not Found: Hdocszip/index
ERROR - 2021-10-06 05:28:34 --> 404 Page Not Found: Releasezip/index
ERROR - 2021-10-06 05:28:34 --> 404 Page Not Found: Templaterar/index
ERROR - 2021-10-06 05:28:34 --> 404 Page Not Found: Templatezip/index
ERROR - 2021-10-06 05:28:34 --> 404 Page Not Found: Arar/index
ERROR - 2021-10-06 05:28:34 --> 404 Page Not Found: Azip/index
ERROR - 2021-10-06 05:28:35 --> 404 Page Not Found: Brar/index
ERROR - 2021-10-06 05:28:35 --> 404 Page Not Found: Bzip/index
ERROR - 2021-10-06 05:28:35 --> 404 Page Not Found: Testrar/index
ERROR - 2021-10-06 05:28:35 --> 404 Page Not Found: Testzip/index
ERROR - 2021-10-06 05:28:35 --> 404 Page Not Found: Barar/index
ERROR - 2021-10-06 05:28:35 --> 404 Page Not Found: Bazip/index
ERROR - 2021-10-06 05:28:41 --> 404 Page Not Found: Beifenrar/index
ERROR - 2021-10-06 05:28:41 --> 404 Page Not Found: Beifenzip/index
ERROR - 2021-10-06 05:28:41 --> 404 Page Not Found: Bfrar/index
ERROR - 2021-10-06 05:28:41 --> 404 Page Not Found: Bfzip/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Bakrar/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Bakzip/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Ebakrar/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Ebakzip/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Backrar/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Backzip/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Mysqlrar/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Mysqlzip/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Backupdatarar/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Backupdatazip/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Backup_datarar/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Backup_datazip/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Wwwroottargz/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Wwwrootbaktargz/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Wwwtargz/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Webtargz/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Wwwbaktargz/index
ERROR - 2021-10-06 05:28:42 --> 404 Page Not Found: Webbaktargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Www_xuanhao_nettargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Wwwxuanhaonettargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Xuanhaonettargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Xuanhaotargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Wwwxuanhaonetbaktargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Www_xuanhao_netbaktargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Wwwxuanhaonetbaktargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Xuanhaonetbaktargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Xuanhaobaktargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Dbtargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Wztargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Fdsatargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Wangzhantargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Roottargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Admintargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Datatargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Ggtargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Viptargz/index
ERROR - 2021-10-06 05:28:43 --> 404 Page Not Found: Databacktargz/index
ERROR - 2021-10-06 05:28:44 --> 404 Page Not Found: Databackuptargz/index
ERROR - 2021-10-06 05:28:44 --> 404 Page Not Found: Hdocstargz/index
ERROR - 2021-10-06 05:28:44 --> 404 Page Not Found: Releasetargz/index
ERROR - 2021-10-06 05:28:44 --> 404 Page Not Found: Templatetargz/index
ERROR - 2021-10-06 05:28:44 --> 404 Page Not Found: Atargz/index
ERROR - 2021-10-06 05:28:44 --> 404 Page Not Found: Bbak/index
ERROR - 2021-10-06 05:28:44 --> 404 Page Not Found: Testtargz/index
ERROR - 2021-10-06 05:28:44 --> 404 Page Not Found: Batargz/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Beifentargz/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Bftargz/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Baktargz/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Ebaktargz/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Backtargz/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Mysqltargz/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Backupdatatargz/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Backup_datatargz/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Xuanhaobak7z/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Db7z/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Wz7z/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Fdsa7z/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Wangzhan7z/index
ERROR - 2021-10-06 05:28:48 --> 404 Page Not Found: Root7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: Admin7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: Data7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: Gg7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: Vip7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: Databack7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: Databackup7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: Hdocs7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: Release7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: Template7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: A7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: B7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: Test7z/index
ERROR - 2021-10-06 05:28:49 --> 404 Page Not Found: Ba7z/index
ERROR - 2021-10-06 05:28:55 --> 404 Page Not Found: Beifen7z/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Bf7z/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Bak7z/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Ebak7z/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Back7z/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Mysql7z/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Backupdata7z/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Backup_data7z/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Wfphprar/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Wfphpzip/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Wfphp7z/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Wfphptargz/index
ERROR - 2021-10-06 05:28:57 --> 404 Page Not Found: Order7z/index
ERROR - 2021-10-06 05:28:58 --> 404 Page Not Found: Ordertargz/index
ERROR - 2021-10-06 05:28:58 --> 404 Page Not Found: Orderrar/index
ERROR - 2021-10-06 05:28:58 --> 404 Page Not Found: Orderzip/index
ERROR - 2021-10-06 05:28:58 --> 404 Page Not Found: Zzfhworderrar/index
ERROR - 2021-10-06 05:28:58 --> 404 Page Not Found: Zzfhworderzip/index
ERROR - 2021-10-06 05:28:58 --> 404 Page Not Found: Zzfhworder7z/index
ERROR - 2021-10-06 05:28:58 --> 404 Page Not Found: Zzfhwordertargz/index
ERROR - 2021-10-06 05:28:58 --> 404 Page Not Found: Wforderrar/index
ERROR - 2021-10-06 05:28:58 --> 404 Page Not Found: Wforderzip/index
ERROR - 2021-10-06 05:28:58 --> 404 Page Not Found: Wforder7z/index
ERROR - 2021-10-06 05:28:58 --> 404 Page Not Found: Wfordertargz/index
ERROR - 2021-10-06 05:32:52 --> 404 Page Not Found: City/1
ERROR - 2021-10-06 05:32:53 --> 404 Page Not Found: City/1
ERROR - 2021-10-06 05:32:53 --> 404 Page Not Found: City/1
ERROR - 2021-10-06 05:32:53 --> 404 Page Not Found: City/1
ERROR - 2021-10-06 05:32:53 --> 404 Page Not Found: City/1
ERROR - 2021-10-06 05:36:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 05:43:42 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 05:44:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 05:52:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 05:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 05:52:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 06:10:58 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-06 06:23:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 06:23:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 06:32:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 06:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 06:39:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 06:40:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 06:43:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 06:51:29 --> Severity: Warning --> Missing argument 1 for News::yidong() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 21
ERROR - 2021-10-06 06:58:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 06:59:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:00:19 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-06 07:00:19 --> 404 Page Not Found: admin//index
ERROR - 2021-10-06 07:00:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 07:00:20 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 07:00:21 --> 404 Page Not Found: Explicit_not_exist_path/index
ERROR - 2021-10-06 07:00:21 --> 404 Page Not Found: Static/.gitignore
ERROR - 2021-10-06 07:00:21 --> 404 Page Not Found: 4e5e5d7364f443e28fbf0d3ae744a59a/index
ERROR - 2021-10-06 07:00:22 --> 404 Page Not Found: Readmehtml/index
ERROR - 2021-10-06 07:00:22 --> 404 Page Not Found: Licensetxt/index
ERROR - 2021-10-06 07:00:23 --> 404 Page Not Found: Wp-includes/js
ERROR - 2021-10-06 07:00:23 --> 404 Page Not Found: Images/ofbiz.ico
ERROR - 2021-10-06 07:00:23 --> 404 Page Not Found: User/index
ERROR - 2021-10-06 07:00:23 --> 404 Page Not Found: PhpMyAdmin/index
ERROR - 2021-10-06 07:00:23 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-10-06 07:00:23 --> 404 Page Not Found: Wcm/index
ERROR - 2021-10-06 07:01:04 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 07:01:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:02:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:03:26 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 07:05:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 07:05:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 07:06:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:06:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:07:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:07:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:07:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:08:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:09:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:14:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:15:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:16:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:21:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:22:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 07:23:20 --> 404 Page Not Found: Login/index
ERROR - 2021-10-06 07:27:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 07:53:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 07:53:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 07:54:57 --> 404 Page Not Found: Nmaplowercheck1633478083/index
ERROR - 2021-10-06 07:54:57 --> 404 Page Not Found: Evox/about
ERROR - 2021-10-06 07:54:57 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-10-06 07:55:05 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 08:10:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 08:24:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 08:24:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 08:24:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 08:24:39 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 08:32:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 08:34:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:35:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:35:33 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 08:36:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 08:36:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:36:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:36:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:36:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:37:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:37:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:38:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-10-06 08:38:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:39:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:39:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:40:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:40:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:41:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:41:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:41:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:42:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:42:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:43:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:43:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:44:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:44:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:44:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:47:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:52:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 08:54:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:54:46 --> 404 Page Not Found: Index/login
ERROR - 2021-10-06 08:55:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:55:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:55:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:55:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:55:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:56:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 08:58:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 08:59:34 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-10-06 08:59:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 09:07:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 09:12:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 09:13:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 09:14:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 09:14:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 09:14:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 09:15:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 09:17:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 09:19:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 09:19:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 09:20:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 09:21:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 09:27:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 09:33:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 09:34:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 09:38:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 09:40:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 09:42:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 09:51:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 09:56:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 09:56:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 10:05:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 10:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 10:28:30 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 10:30:27 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 10:34:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 10:38:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 10:42:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 10:58:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 10:59:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 11:00:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 11:02:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:02:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:02:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:02:45 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:20:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 11:21:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 11:24:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 11:30:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 11:32:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 11:37:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 11:38:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:38:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:38:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:38:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:45:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:45:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:45:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:45:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:50:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 11:52:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 11:54:10 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-06 12:01:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 12:03:23 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 12:04:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:04:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:04:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:04:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:04:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:05:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:05:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:05:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:05:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:06:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:08:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:09:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:10:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:11:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:11:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:12:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 12:12:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:12:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:14:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:15:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:17:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:17:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 12:17:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 12:17:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 12:17:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 12:18:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:18:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:18:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:19:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:19:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:20:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:20:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:20:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:20:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:20:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:21:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:21:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:21:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:24:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 12:31:29 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 12:35:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 12:38:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 12:40:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:40:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 12:43:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 12:46:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:47:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 12:47:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 13:05:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 13:26:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 13:27:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 13:28:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 13:34:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 13:35:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 13:39:45 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-06 13:43:15 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 13:43:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 13:43:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 13:44:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 13:46:37 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 13:50:47 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-06 14:05:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:06:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:08:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:08:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:09:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:12:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:12:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:13:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:14:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:14:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:15:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:21:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 14:28:13 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 14:28:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 14:28:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 14:30:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:30:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 14:32:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 14:37:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 14:37:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 14:51:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 14:51:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 14:52:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 14:54:00 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 14:54:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 14:54:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 15:02:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 15:02:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 15:02:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 15:02:06 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 15:04:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 15:08:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 15:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 15:40:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 15:40:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 15:42:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 15:43:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 15:50:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 16:03:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 16:03:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 16:10:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 16:15:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 16:15:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 16:16:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 16:16:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 16:16:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 16:16:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 16:23:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 16:25:12 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 16:27:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 16:28:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 16:31:47 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 16:32:54 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 16:34:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 16:36:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 16:42:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 16:42:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 16:43:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 16:43:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 16:43:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 16:57:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 16:57:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 16:57:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 17:28:16 --> Severity: Warning --> Missing argument 1 for Zifei::show() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 277
ERROR - 2021-10-06 17:31:37 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 17:31:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 17:53:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 17:58:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 18:03:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 18:11:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 18:17:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 18:18:18 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 18:22:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 18:22:32 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 18:27:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 18:27:22 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 18:36:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 18:39:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 18:41:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 18:41:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 18:43:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 18:44:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 19:00:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 19:00:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 19:00:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 19:00:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 19:02:14 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-06 19:07:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 19:27:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 19:29:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 19:36:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 19:50:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 19:52:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 19:52:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 19:52:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 19:52:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 19:56:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 19:56:13 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 19:56:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:06:12 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 20:18:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 20:20:20 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 20:29:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:30:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:31:12 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 20:32:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 20:35:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 20:37:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:38:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:38:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 20:40:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:44:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:44:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:44:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:46:45 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:47:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:47:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:47:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:48:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:48:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:49:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 20:50:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 20:50:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:52:57 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 20:53:04 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:53:04 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:53:10 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:53:10 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:53:15 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:53:15 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:53:20 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:53:20 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:53:25 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:53:25 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:53:30 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:53:30 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 20:54:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:54:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 20:54:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:55:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:58:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:58:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:59:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 20:59:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 21:00:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:06:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 21:06:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 21:07:38 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 21:08:26 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:08:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:10:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:10:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:11:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:14:10 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:16:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:19:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 21:20:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:26:25 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-06 21:35:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:36:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 21:37:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:38:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:39:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 21:40:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 21:41:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 21:41:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 21:43:03 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:03 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:09 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:09 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:14 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:14 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:19 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:19 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:24 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:24 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:29 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:29 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:34 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:34 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:39 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:39 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:44 --> Severity: Warning --> include_once(/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php): failed to open stream: No such file or directory /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:43:44 --> Severity: Warning --> include_once(): Failed opening '/www/wwwroot/www.xuanhao.net/app/libraries/wxpayset.php' for inclusion (include_path='.:/www/server/php/53/lib/php') /www/wwwroot/www.xuanhao.net/app/third_party/weixin/WxPayPubHelpers.php 31
ERROR - 2021-10-06 21:46:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 22:00:38 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-06 22:08:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 22:14:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 22:16:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 22:27:54 --> 404 Page Not Found: Data/admin
ERROR - 2021-10-06 22:29:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 22:40:36 --> 404 Page Not Found: City/1
ERROR - 2021-10-06 22:50:12 --> 404 Page Not Found: City/2
ERROR - 2021-10-06 22:50:47 --> 404 Page Not Found: City/18
ERROR - 2021-10-06 22:50:50 --> 404 Page Not Found: City/19
ERROR - 2021-10-06 23:13:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 23:17:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:27:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:27:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:28:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:28:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:28:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:28:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:32:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 23:37:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:37:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:38:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:38:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:39:22 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:40:41 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-10-06 23:42:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:44:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:45:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:45:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:45:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:46:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:46:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:48:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:48:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:52:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-10-06 23:52:53 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-10-06 23:54:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 23:57:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-10-06 23:57:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
