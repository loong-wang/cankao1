<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-11-20 00:02:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 00:06:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 00:06:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 00:06:21 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 00:09:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 00:15:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 00:15:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 00:19:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 00:19:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 00:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 00:21:21 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-11-20 00:38:38 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 00:43:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 00:46:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 01:24:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 01:25:16 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2021-11-20 01:33:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 01:37:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 01:49:51 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 01:50:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 02:14:48 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:14:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 02:18:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:19:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 02:24:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 02:25:50 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:28:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 02:28:58 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:29:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 02:29:44 --> 404 Page Not Found: Jdybsc/index
ERROR - 2021-11-20 02:31:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 02:31:21 --> 404 Page Not Found: Sitemap52624html/index
ERROR - 2021-11-20 02:32:06 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:34:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 02:35:13 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:38:21 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:41:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 02:44:36 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:47:44 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:50:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:54:00 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:58:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 02:58:55 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 02:59:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 03:01:42 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 03:19:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:19:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:20:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:20:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:21:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:21:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:21:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:21:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:21:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:22:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:22:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:22:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:23:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:23:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:23:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:23:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:24:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:24:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:24:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:24:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:24:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 03:24:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:24:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:24:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:25:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 03:31:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 03:32:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 03:50:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 04:00:39 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 04:00:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 04:08:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 04:16:05 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-20 04:19:11 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-11-20 04:19:40 --> Severity: Warning --> Missing argument 1 for Page::pays() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 190
ERROR - 2021-11-20 04:20:09 --> Severity: Warning --> Missing argument 1 for Zifei::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 192
ERROR - 2021-11-20 04:21:10 --> 404 Page Not Found: City/index
ERROR - 2021-11-20 04:21:38 --> Severity: Warning --> Missing argument 1 for News::youhui() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 341
ERROR - 2021-11-20 04:21:56 --> Severity: Warning --> Missing argument 1 for Xinxi::flist() /www/wwwroot/www.xuanhao.net/app/controllers/Xinxi.php 21
ERROR - 2021-11-20 04:22:29 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 04:23:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 04:23:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 04:24:08 --> Severity: Warning --> Missing argument 1 for Kefu::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Kefu.php 177
ERROR - 2021-11-20 04:24:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 04:24:46 --> Severity: Warning --> Missing argument 1 for Page::hezuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 21
ERROR - 2021-11-20 04:25:07 --> Severity: Warning --> Missing argument 1 for Page::wes() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 234
ERROR - 2021-11-20 04:25:10 --> Severity: Warning --> Missing argument 1 for News::dianxin() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 181
ERROR - 2021-11-20 04:25:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 04:26:13 --> Severity: Warning --> Missing argument 1 for Page::songhuo() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 146
ERROR - 2021-11-20 04:26:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 04:32:40 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 04:34:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 04:53:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 05:05:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 05:05:48 --> 404 Page Not Found: Sitemap41019html/index
ERROR - 2021-11-20 05:10:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 05:19:16 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 05:21:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 05:29:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 05:33:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 05:34:40 --> 404 Page Not Found: City/15
ERROR - 2021-11-20 05:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 05:44:55 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 05:49:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 06:15:17 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-11-20 06:28:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 06:29:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 06:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 06:41:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 06:41:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 06:44:20 --> Severity: Warning --> Missing argument 1 for Page::wenti() /www/wwwroot/www.xuanhao.net/app/controllers/Page.php 102
ERROR - 2021-11-20 06:50:53 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 06:54:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 06:54:13 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 07:29:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 07:53:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 08:03:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 08:10:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 08:11:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 08:11:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 08:15:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 08:17:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 08:39:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 08:40:52 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 08:42:52 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 08:44:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 08:48:20 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 09:02:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 09:02:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 09:03:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 09:03:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 09:03:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 09:07:34 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-20 09:20:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 09:38:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 09:40:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 09:45:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 09:52:48 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 09:58:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 10:00:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 10:11:18 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-20 10:13:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 10:14:19 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 10:17:03 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:18:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:19:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 10:19:34 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 10:19:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:20:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:20:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:21:19 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 10:21:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:21:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:21:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:21:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:22:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:22:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:22:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:22:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:22:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:22:57 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:22:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:22:59 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:23:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:23:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:23:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:26:08 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 10:26:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:26:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:26:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:28:25 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 10:29:37 --> 404 Page Not Found: Text4041637375377/index
ERROR - 2021-11-20 10:29:37 --> 404 Page Not Found: HNAP1/index
ERROR - 2021-11-20 10:29:38 --> 404 Page Not Found: Evox/about
ERROR - 2021-11-20 10:29:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 10:31:44 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 10:31:48 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 10:32:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 10:35:58 --> Severity: Warning --> Missing argument 1 for Zifei::liantong() /www/wwwroot/www.xuanhao.net/app/controllers/Zifei.php 107
ERROR - 2021-11-20 10:38:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:42:44 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-20 10:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 10:43:33 --> 404 Page Not Found: Boaform/admin
ERROR - 2021-11-20 10:45:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:46:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:47:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:47:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:50:42 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:52:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:52:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:54:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:57:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:57:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:58:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:58:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 10:58:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 10:59:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:00:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:00:06 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:01:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:02:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:02:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:03:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:03:17 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 11:03:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:04:02 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 11:05:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:06:33 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:07:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:08:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:10:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:10:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:11:07 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 11:11:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:11:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:12:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 11:13:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:13:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:14:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:14:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:16:38 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:17:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:17:34 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:18:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:19:35 --> 404 Page Not Found: City/1
ERROR - 2021-11-20 11:22:01 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 11:24:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 11:32:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 11:33:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 11:35:25 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 11:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 11:39:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 11:39:41 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 11:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 11:40:05 --> 404 Page Not Found: Sitemaphtml/index
ERROR - 2021-11-20 11:40:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 11:41:08 --> Severity: Warning --> Missing argument 2 for Cart::del() /www/wwwroot/www.xuanhao.net/app/controllers/Cart.php 118
ERROR - 2021-11-20 11:41:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 11:46:40 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 11:46:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 11:49:21 --> 404 Page Not Found: Shell/index
ERROR - 2021-11-20 11:49:47 --> 404 Page Not Found: Shell/index
ERROR - 2021-11-20 11:50:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 11:52:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 11:52:33 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 11:52:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 11:52:46 --> 404 Page Not Found: Sitemap90146html/index
ERROR - 2021-11-20 11:53:04 --> 404 Page Not Found: Sitemap82177html/index
ERROR - 2021-11-20 11:53:06 --> 404 Page Not Found: Sitemap86343html/index
ERROR - 2021-11-20 11:55:55 --> 404 Page Not Found: Install/templates
ERROR - 2021-11-20 11:55:55 --> 404 Page Not Found: Templets/default
ERROR - 2021-11-20 11:55:55 --> 404 Page Not Found: Templets/plus
ERROR - 2021-11-20 11:55:55 --> 404 Page Not Found: Templets/plus
ERROR - 2021-11-20 11:55:55 --> 404 Page Not Found: Templets/plus
ERROR - 2021-11-20 11:55:56 --> 404 Page Not Found: Templets/plus
ERROR - 2021-11-20 11:55:56 --> 404 Page Not Found: Templets/plus
ERROR - 2021-11-20 11:55:56 --> 404 Page Not Found: Templets/plus
ERROR - 2021-11-20 11:55:56 --> 404 Page Not Found: Templets/default
ERROR - 2021-11-20 11:55:56 --> 404 Page Not Found: Templets/default
ERROR - 2021-11-20 11:55:56 --> 404 Page Not Found: Templets/default
ERROR - 2021-11-20 11:55:56 --> 404 Page Not Found: Member/templets
ERROR - 2021-11-20 11:55:56 --> 404 Page Not Found: Member/templets
ERROR - 2021-11-20 11:55:56 --> 404 Page Not Found: Member/templets
ERROR - 2021-11-20 11:55:56 --> 404 Page Not Found: Member/templets
ERROR - 2021-11-20 11:55:57 --> 404 Page Not Found: Member/templets
ERROR - 2021-11-20 11:55:57 --> 404 Page Not Found: Member/templets
ERROR - 2021-11-20 11:55:57 --> 404 Page Not Found: Install/sql-dfdata.txt
ERROR - 2021-11-20 11:55:57 --> 404 Page Not Found: Templets/default
ERROR - 2021-11-20 11:55:58 --> 404 Page Not Found: Templets/default
ERROR - 2021-11-20 11:55:58 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:58 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:58 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:58 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:58 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:58 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:58 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:58 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:58 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:59 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:59 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:59 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:59 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:59 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:59 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:59 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:59 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:59 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:55:59 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:00 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:00 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:00 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:00 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:00 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:00 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:00 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:00 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:00 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:00 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:01 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:01 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:01 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:01 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:01 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:01 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:01 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:01 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:01 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:01 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:02 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:02 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:02 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:02 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:02 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:02 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:02 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:02 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:02 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:02 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:03 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:03 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:03 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:03 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:03 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:03 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:03 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:03 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:03 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:03 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:04 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:04 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:04 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:04 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:04 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:04 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:04 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:04 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:05 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:05 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:05 --> 404 Page Not Found: Include/taglib
ERROR - 2021-11-20 11:56:05 --> 404 Page Not Found: Include/taglib
ERROR - 2021-11-20 11:56:05 --> 404 Page Not Found: Include/taglib
ERROR - 2021-11-20 11:56:05 --> 404 Page Not Found: Include/taglib
ERROR - 2021-11-20 11:56:05 --> 404 Page Not Found: Include/taglib
ERROR - 2021-11-20 11:56:05 --> 404 Page Not Found: Include/taglib
ERROR - 2021-11-20 11:56:05 --> 404 Page Not Found: Templets/system
ERROR - 2021-11-20 11:56:06 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:06 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:06 --> 404 Page Not Found: Member/space
ERROR - 2021-11-20 11:56:06 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-11-20 11:56:06 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-11-20 11:56:06 --> 404 Page Not Found: Templets/lurd
ERROR - 2021-11-20 11:56:07 --> 404 Page Not Found: Dede/templets
ERROR - 2021-11-20 11:56:07 --> 404 Page Not Found: Dede/templets
ERROR - 2021-11-20 11:56:07 --> 404 Page Not Found: Dede/templets
ERROR - 2021-11-20 11:56:07 --> 404 Page Not Found: Dede/templets
ERROR - 2021-11-20 11:56:07 --> 404 Page Not Found: Dede/templets
ERROR - 2021-11-20 11:56:07 --> 404 Page Not Found: Dede/templets
ERROR - 2021-11-20 11:56:07 --> 404 Page Not Found: Dede/templets
ERROR - 2021-11-20 11:56:07 --> 404 Page Not Found: Dede/templets
ERROR - 2021-11-20 11:56:08 --> 404 Page Not Found: Dede/templets
ERROR - 2021-11-20 11:56:08 --> 404 Page Not Found: Install/templates
ERROR - 2021-11-20 11:57:55 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:08:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:09:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 12:09:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 12:09:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:12:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 12:12:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:12:55 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-20 12:19:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:21:46 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:21:53 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:22:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:22:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:22:31 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:22:39 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-20 12:22:44 --> 404 Page Not Found: Sitemap35142html/index
ERROR - 2021-11-20 12:24:36 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:26:30 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:26:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:26:49 --> 404 Page Not Found: Article/view
ERROR - 2021-11-20 12:28:47 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:30:15 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:30:53 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:30:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 12:32:59 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:33:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:34:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:35:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:37:10 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:39:16 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:41:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:41:21 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:43:27 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 12:47:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:51:57 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:52:16 --> 404 Page Not Found: Sitemap78583html/index
ERROR - 2021-11-20 12:52:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 12:52:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 13:10:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 13:13:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 13:14:05 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-20 13:21:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 13:21:37 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 13:21:47 --> 404 Page Not Found: Sitemap36220html/index
ERROR - 2021-11-20 13:21:56 --> 404 Page Not Found: Sitemap97179html/index
ERROR - 2021-11-20 13:28:02 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 13:28:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 13:28:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 13:33:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 13:50:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 13:59:38 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-20 14:14:41 --> 404 Page Not Found: Haoma/index
ERROR - 2021-11-20 14:15:42 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:18:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:20:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:22:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:22:21 --> 404 Page Not Found: Sitemap85456html/index
ERROR - 2021-11-20 14:23:53 --> 404 Page Not Found: Indexhtml/index
ERROR - 2021-11-20 14:24:52 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:28:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:31:45 --> Severity: Warning --> Missing argument 1 for User::check_captcha_code() /www/wwwroot/www.xuanhao.net/app/controllers/User.php 282
ERROR - 2021-11-20 14:32:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 14:32:39 --> 404 Page Not Found: Sitemap84496html/index
ERROR - 2021-11-20 14:32:55 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:34:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:36:52 --> 404 Page Not Found: City/10
ERROR - 2021-11-20 14:37:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:39:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:40:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:41:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:41:48 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:42:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:42:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:42:31 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:42:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:42:43 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:43:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:43:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:43:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:44:02 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:44:41 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:44:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:44:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:45:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:45:49 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:47:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:47:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:47:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:48:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:48:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 14:51:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:51:36 --> 404 Page Not Found: Sitemap26097html/index
ERROR - 2021-11-20 14:51:52 --> 404 Page Not Found: Sitemap97701html/index
ERROR - 2021-11-20 14:52:09 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 14:52:28 --> 404 Page Not Found: Sitemap30738html/index
ERROR - 2021-11-20 14:52:34 --> 404 Page Not Found: Sitemap25296html/index
ERROR - 2021-11-20 14:57:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:08:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:17:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:18:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:24:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:24:29 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:25:04 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:25:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:26:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:28:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:29:04 --> 404 Page Not Found: Sitemap48655html/index
ERROR - 2021-11-20 15:29:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:30:09 --> 404 Page Not Found: Sitemap30658html/index
ERROR - 2021-11-20 15:43:33 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 15:46:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:52:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:54:58 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:55:18 --> 404 Page Not Found: Sitemap26481html/index
ERROR - 2021-11-20 15:55:24 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 15:56:02 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 15:56:21 --> 404 Page Not Found: Sitemap13643html/index
ERROR - 2021-11-20 16:00:10 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 16:10:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 16:10:47 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 16:17:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 16:18:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 16:19:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 16:20:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 16:22:40 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 16:23:34 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 16:24:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 16:34:25 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 17:04:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 17:04:35 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 17:08:01 --> 404 Page Not Found: Data/admin
ERROR - 2021-11-20 17:17:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 17:18:55 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 17:19:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:31:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 17:32:28 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:33:07 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 17:33:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 17:34:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:35:27 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:36:00 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 17:36:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:36:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:38:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:39:32 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 17:42:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 17:43:50 --> 404 Page Not Found: Company/view
ERROR - 2021-11-20 17:46:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:46:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:47:56 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:48:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:48:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:51:05 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 17:55:14 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:58:05 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:58:09 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 17:58:28 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 18:13:46 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 18:20:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 18:23:15 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 18:27:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 18:33:03 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 18:33:06 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 18:35:46 --> 404 Page Not Found: Phpmyadmin/index
ERROR - 2021-11-20 18:42:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 18:44:32 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 18:49:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:49:41 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 18:51:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:51:24 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:52:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:52:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:52:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:53:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:53:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:55:20 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:56:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:56:01 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:56:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 18:56:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:57:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 18:59:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:00:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:03:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:14:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:14:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:14:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:14:49 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:14:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:14:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:15:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:15:00 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:15:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:15:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:15:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:15:05 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:16:56 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 19:18:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 19:20:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:24:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:33:50 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:35:25 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:35:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:36:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:38:57 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:45:19 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:47:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:48:58 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 19:49:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:55:36 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 19:58:24 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 20:00:52 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 20:09:04 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:09:52 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:10:32 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:11:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:12:15 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:12:44 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:13:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:13:11 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:13:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:15:23 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:15:40 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:17:18 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:18:35 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 20:18:46 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:19:00 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:20:26 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 20:21:35 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:32:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:34:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:34:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:34:24 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 20:34:51 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:35:17 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 20:40:14 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 20:41:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 20:41:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 20:41:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 20:41:50 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 20:43:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 21:00:27 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 21:02:59 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 21:08:11 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 21:10:18 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 21:19:29 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 21:20:30 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 21:27:36 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 21:27:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 21:28:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 21:28:01 --> 404 Page Not Found: Faviconico/index
ERROR - 2021-11-20 21:31:42 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 21:36:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 21:38:07 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 21:38:39 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 21:38:47 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 21:40:08 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 21:42:43 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 21:43:17 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 22:01:42 --> 404 Page Not Found: Jdybsc/kline
ERROR - 2021-11-20 22:04:37 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-20 22:10:50 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 22:14:45 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 22:23:58 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 22:32:51 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 22:52:26 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 22:53:08 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 22:55:59 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 23:01:11 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 23:04:12 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 23:16:04 --> Severity: Warning --> Missing argument 3 for Haoma::show() /www/wwwroot/www.xuanhao.net/app/controllers/Haoma.php 2088
ERROR - 2021-11-20 23:18:54 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 23:23:21 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 23:32:53 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 23:33:16 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 23:33:54 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 23:34:31 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 23:34:37 --> Severity: Warning --> Missing argument 4 for Search::liket() /www/wwwroot/www.xuanhao.net/app/controllers/Search.php 566
ERROR - 2021-11-20 23:35:22 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 23:36:11 --> Severity: Warning --> Missing argument 1 for Tourl::gourl() /www/wwwroot/www.xuanhao.net/app/controllers/Tourl.php 12
ERROR - 2021-11-20 23:38:10 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 23:40:49 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 23:44:03 --> 404 Page Not Found: Robotstxt/index
ERROR - 2021-11-20 23:58:40 --> Severity: Warning --> Missing argument 1 for News::hangye() /www/wwwroot/www.xuanhao.net/app/controllers/News.php 261
